/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.core.service;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.DataObject;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Query;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.util.CayenneUtils;

public class BaseService {

    /** The default database fetch limit. */
    public static final int FETCH_LIMIT = 1000;

    /** The class logger. */
    private Logger logger;

    /** The default query fetch limit. */
    private int fetchLimit = FETCH_LIMIT;

    // ------------------------------------------------------ Protected Methods

    /**
     * Return the default query fetch limit.
     *
     * @return the default query fetch limit
     */
    protected int getFetchLimit() {
        return fetchLimit;
    }

    /**
     * Set the default query fetch limit.
     *
     * @param limit the default query fetch limit
     */
    protected void setFetchLimit(int limit) {
        fetchLimit = limit;
    }

    /**
     * Return the service log.
     *
     * @return the service log
     */
    protected Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

    @SuppressWarnings("deprecation")
    protected DataContext getDataContext() {
        try {
            return DataContext.getThreadDataContext();

        } catch (IllegalStateException ise) {
            DataContext dataContext = DataContext.createDataContext(false);
            DataContext.bindThreadDataContext(dataContext);

            if (getLogger().isDebugEnabled()) {
                getLogger().debug("creating and binding DataContext to thread");
            }

            return dataContext;
        }
    }

    protected void registerNewObject(DataObject dataObject) {
        getDataContext().registerNewObject(dataObject);
    }

    @SuppressWarnings("deprecation")
    protected DataObject createAndRegisterNewObject(Class dataObjectClass) {
        return getDataContext().createAndRegisterNewObject(dataObjectClass);
    }

    protected void deleteObject(DataObject dataObject) {
        getDataContext().deleteObject(dataObject);
    }

    protected void deleteObjects(Collection dataObjects) {
        getDataContext().deleteObjects(dataObjects);
    }

    protected void commitChanges() {
        getDataContext().commitChanges();
    }

    protected void rollbackChanges() {
        getDataContext().rollbackChanges();
    }

    protected Object getObjectForPK(Class dataObjectClass, Object id) {
        if (id == null) {
            return null;

        } else if (StringUtils.isBlank(id.toString())) {
               return null;
        }

        return CayenneUtils.getObjectForPK(dataObjectClass, id);
    }

    protected DataObject findObject(Class dataObjectClass, String property, Object value) {

        if (dataObjectClass == null) {
            String msg = "Null dataObjectClass parameter";
            throw new IllegalArgumentException(msg);
        }

        if (property == null) {
            throw new IllegalArgumentException("Null property parameter");
        }

        if (property == null) {
            throw new IllegalArgumentException("Null value parameter");
        }

        Expression qual = ExpressionFactory.matchExp(property, value);
        List list = performQuery(new SelectQuery(dataObjectClass, qual));

        if (list.size() == 1) {
            return (DataObject) list.get(0);

        } else if (list.size() > 1) {
            String msg = "SelectQuery for " + dataObjectClass.getName() + " where " + property + " equals "
                + value + " returned " + list.size() + " rows";
            throw new RuntimeException(msg);

        } else {
            return null;
        }
    }

    protected int[] performNonSelectingQuery(Query query) {
        return getDataContext().performNonSelectingQuery(query);
    }

    protected int[] performNonSelectingQuery(String queryName) {
        return getDataContext().performNonSelectingQuery(queryName);
    }

    protected int[] performNonSelectingQuery(String queryName, Map parameters) {
        return getDataContext().performNonSelectingQuery(queryName, parameters);
    }

    /**
     * Perform the given select query and set the default fetch limit, if no
     * fetch limit has been set.
     */
    protected List performQuery(SelectQuery query) {
        if (query.getFetchLimit() == 0) {
            query.setFetchLimit(getFetchLimit());
        }

        return getDataContext().performQuery(query);
    }

    protected List performNamedQuery(String queryName, boolean refresh) {
        return getDataContext().performQuery(queryName, refresh);
    }

    protected List performNamedQuery(String queryName, Map parameters, boolean refresh) {

        return getDataContext().performQuery(queryName, parameters, refresh);
    }

    protected List performNamedQuery(String queryName, String[] keys, String[] values, boolean refresh) {

        return performNamedQuery(queryName, toMap(keys, values), refresh);
    }

    protected List performQuery(Class dataObjectClass, String property, Object value) {

        if (dataObjectClass == null) {
            String msg = "Null dataObjectClass parameter";
            throw new IllegalArgumentException(msg);
        }

        if (property == null) {
            throw new IllegalArgumentException("Null property parameter");
        }

        if (property == null) {
            throw new IllegalArgumentException("Null value parameter");
        }

        Expression qual = ExpressionFactory.matchExp(property, value);

        return performQuery(new SelectQuery(dataObjectClass, qual));
    }

    protected int[] performNonSelectingQuery(String queryName, String[] keys, String[] values) {

        return performNonSelectingQuery(queryName, toMap(keys, values));
    }

    public List performQueryMatchAll(BaseEntity baseEntity) {

        Map valuesMap = baseEntity.getValuesMap();

        Expression qual = ExpressionFactory.matchAllExp(valuesMap, Expression.EQUAL_TO);

        SelectQuery query = new SelectQuery(baseEntity.getClass(), qual);

        return performQuery(query);
    }

    protected Map toMap(String key, Object value) {
        return Collections.singletonMap(key, value);
    }

    protected Map toMap(String[] keys, Object[] values) {

        if (keys == null || keys.length == 0) {
            return Collections.EMPTY_MAP;
        }

        int len = keys.length;
        if (len == 1) {
            return Collections.singletonMap(keys[0], values[0]);
        }

        Map map = new HashMap();
        for (int i = 0; i < len; i++) {
            map.put(keys[i], values[i]);
        }

        return map;
    }
}

package com.avoka.core.xml.importer;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.util.CayenneUtils;

public class ImportTableBean{

    ImportLogger    importLogger;

    private String  tableName;
    private Map     rowMap    = new Hashtable();
    private Map     oldKeyMap = new Hashtable();

    // Controls what happens during import. If true will search for a existing record
    private boolean findFlag;

    // During import controls if existing records should be updated.
    private boolean updateFlag;

    // Is this table used in a prod system.
    private boolean productionTableFlag;

    // Replace all child values. If this is a child table - say employee what this means is that it
    // will go to the parent object and from the parent will delete all existing employees. This
    // only works when you have a simple child table that has only 1 FK to the parent object.

    private boolean deleteAllChildRowsFlag;

    public ImportTableBean(ImportLogger importLogger){

        this.importLogger = importLogger;
    }

    public String getTableName(){
        return tableName;
    }

    public void setTableName(String tableName){
        this.tableName = tableName;
    }

    public void addRow(String oldKey, RowBean rowBean, boolean cacheRowFlag){

        // PRC - Trying to reduce import memory footprint. Introducing OldKeyMap so that we don't
        // need to keep all objects in memory.

        String newKey = rowBean.getBaseEntity().getId().toString();

        String msg = "ImportTableManager - Added Row - Table=" + rowBean.getTableBean().getTableName() + " Old Key="
            + oldKey + " New Key" + newKey;
        importLogger.logInfoMessage(msg);

        oldKeyMap.put(oldKey, newKey);

        if (cacheRowFlag) {
            rowMap.put(newKey, rowBean);
        }
    }

    public BaseEntity findRowUsingOldKey(String oldKey){

        String newKey = (String) oldKeyMap.get(oldKey);
        if (newKey == null) {
            return null;
        }

        RowBean rowBean = (RowBean) rowMap.get(newKey);
        if (rowBean == null) {
            // need to get it from the database.

            importLogger.logInfoMessage("Looking up uncached object. TableName=" + tableName + " OID=" + newKey);

            BaseEntity baseEntity = (BaseEntity) CayenneUtils.getObjectForPK(tableName, newKey);
            if (baseEntity == null) {
                throw new RuntimeException("Unable to locate Entity. Type =" + tableName + " New OID=" + newKey);
            }

            return baseEntity;

        }

        return rowBean.getBaseEntity();

    }

    public int rowSize(){
        return oldKeyMap.size();
    }

    /**
     * Note - if the rows are not cached this will be null
     *
     * @return
     */
    public Collection<RowBean> getRows(){
        return rowMap.values();
    }

    public boolean isFindFlag(){
        return findFlag;
    }

    public void setFindFlag(boolean findFlag){
        this.findFlag = findFlag;
    }

    public boolean isUpdateFlag(){
        return updateFlag;
    }

    public void setUpdateFlag(boolean updateFlag){
        this.updateFlag = updateFlag;
    }

    public boolean isDeleteAllChildRowsFlag(){
        return deleteAllChildRowsFlag;
    }

    public void setDeleteAllChildRowsFlag(boolean deleteAllChildRowsFlag){
        this.deleteAllChildRowsFlag = deleteAllChildRowsFlag;
    }

    public boolean isProductionTableFlag(){
        return productionTableFlag;
    }

    public void setProductionTableFlag(boolean productionTableFlag){
        this.productionTableFlag = productionTableFlag;
    }

}

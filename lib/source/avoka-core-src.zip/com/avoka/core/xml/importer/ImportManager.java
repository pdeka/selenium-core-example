package com.avoka.core.xml.importer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.xml.export.MetaDataManager;
import com.avoka.core.xml.export.MetaDataTableBean;

/**
 * 1. Assume that all parent (FK) objects must be in the import file. These will be located prior to
 * processing any child objects.
 *
 * @author pcopeland
 *
 */

public class ImportManager{

    // The current active table.
    ImportTableBean            currentTableBean = null;

    MetaDataManager            metaDataManager;

    ImportLogger               importLogger     = new ImportLogger();

    ArrayList<ImportTableBean> orderedTableList = new ArrayList<ImportTableBean>();

    Map                        tableMap         = new HashMap();

    public void addRow(RowBean rowBean){

        MetaDataTableBean entityMetaData = metaDataManager.getEntityMetaData(rowBean.getTableBean().getTableName());

        currentTableBean.addRow(rowBean.getOldKeyValue(), rowBean, entityMetaData.isCacheRowFlag());
    }

    public void addTable(String name, ImportTableBean tableBean){
        tableMap.put(name.toLowerCase(), tableBean);
        orderedTableList.add(tableBean);
        currentTableBean = tableBean;
    }

    /**
     * Find the Row matching the oldKey
     *
     * @param tableName
     * @param oldKey
     * @return
     */
    public BaseEntity findEntityWithOldKey(String tableName, String oldKey){

        importLogger.logInfoMessage("Searching for FK. Table=" + tableName + " Old Key=" + oldKey);

        ImportTableBean tableBean = (ImportTableBean) tableMap.get(tableName.toLowerCase());
        if (tableBean == null) {
            return null;
            // throw new ImportExportException("Cannot locate table. Name=" + tableName);
        }

        BaseEntity parentBaseEntity = tableBean.findRowUsingOldKey(oldKey);
        if (parentBaseEntity == null) {

            return null;
            // throw new ImportExportException("Cannot locate foreign row. Table Name=" + tableName
            // + " OldKey=" + oldKey);
        }

        importLogger.logInfoMessage("Located FK. Parent Table=" + tableName + " Old Key=" + oldKey + " New OID="
                + parentBaseEntity.getId());
        return parentBaseEntity;

    }

    public ImportTableBean getCurrentTableBean(){
        return currentTableBean;
    }

    public String getCurrentTableName(){

        return currentTableBean.getTableName();

    }

    /**
     * Loop over all tables and resolve all foreign keys.
     *
     */
    public void resolveAllForeignKeys(boolean resolveLateFkFlag){

        Collection collection = tableMap.values();

        if (resolveLateFkFlag) {
            importLogger.logInfoMessage("Resolving Foreign Keys - Phase 2................ ");
        } else {
            importLogger.logInfoMessage("Resolving Foreign Keys - Phase 1............... ");
        }
        for (Iterator iter = collection.iterator(); iter.hasNext();) {
            ImportTableBean tableBean = (ImportTableBean) iter.next();
            resolveForeignKeys(tableBean, resolveLateFkFlag);
        }
    }

    public void resolveForeignKeys(ImportTableBean tableBean, boolean resolveLateFkFlag){

        importLogger.logInfoMessage("\nProcessing Foreign Keys for table: " + tableBean.getTableName());

        // Get all the rows...

        Collection<RowBean> rowList = tableBean.getRows();
        for (RowBean rowBean : rowList) {

            resolveForeignKey(tableBean, resolveLateFkFlag, rowBean);
        }
    }

    public void resolveForeignKey(ImportTableBean tableBean, boolean resolveLateFkFlag, RowBean rowBean){
        BaseEntity rowBaseEntity = rowBean.getBaseEntity();

        // These are keys (columns) in the child object - and relate back to the PK in the
        // parent.
        Collection foreignKeyList = rowBean.getForeignKeys();
        for (Iterator iter = foreignKeyList.iterator(); iter.hasNext();) {
            ColumnBean columnBean = (ColumnBean) iter.next();
            boolean resolveNow = false;

            if ((resolveLateFkFlag == false) && (columnBean.isFkResolveLate() == false)) {
                resolveNow = true;
            } else if ((resolveLateFkFlag == true) && (columnBean.isFkResolveLate() == true)) {
                resolveNow = true;
            }

            if ((columnBean.getValue() != null) && resolveNow) {
                BaseEntity parentBaseEntity =
                    findEntityWithOldKey(columnBean.getFkTargentEntityName(), columnBean.getValue());

                if (parentBaseEntity != null) {
                    rowBaseEntity.setToOneTarget(columnBean.getFkRelationshipName(), parentBaseEntity, true);

                } else {
                    importLogger.logInfoMessage("Cannot locate foreign row. Table Name=" + tableBean.getTableName()
                            + " Foreign Key Entity Name=" + columnBean.getFkTargentEntityName() + " OldKey="
                            + columnBean.getValue());
                }
            }
        }
    }

    public MetaDataManager getMetaDataManager(){
        return metaDataManager;
    }

    public void setMetaDataManager(MetaDataManager metaDataManager){
        this.metaDataManager = metaDataManager;
    }

    public ImportLogger getImportLogger(){
        return importLogger;
    }

}

package com.avoka.core.xml.importer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.codec.binary.Base64;

import com.avoka.core.dao.BaseDao;
import com.avoka.core.entity.BaseEntity;
import com.avoka.core.xml.export.MetaDataManager;
import com.avoka.core.xml.export.MetaDataTableBean;

public class RowBean extends BaseDao{

    ArrayList       alternateKeyList     = new ArrayList();
    BaseEntity      baseEntity           = null;
    ArrayList       foreignKeyList       = new ArrayList();
    // The OID of the PK from the import
    String          oldKeyValue          = null;

    Map             rowMap               = new HashMap();

    boolean         newCayenneEntityFlag = false;

    ImportTableBean tableBean            = null;

    ImportLogger    importLogger         = null;

    ImportManager   importManager        = null;

    MetaDataManager metaDataManager      = null;

    DataContext     dataContext          = null;

    @SuppressWarnings("deprecation")
    public RowBean(ImportTableBean tableBean,ImportManager dataManager){
        this.tableBean = tableBean;
        this.importManager = dataManager;
        this.importLogger = dataManager.getImportLogger();
        metaDataManager = dataManager.getMetaDataManager();
        dataContext = DataContext.getThreadDataContext();
    }

    public void addColumn(ColumnBean bean) {
        rowMap.put(bean.getName(), bean);
    }

    public void setColumn(String name, String value) {
        ColumnBean columnBean = (ColumnBean) rowMap.get(name);
        if (columnBean != null) {
            columnBean.overwriteValue(value);
        }
    }

    public String getColumn(String name) {
        ColumnBean columnBean = (ColumnBean) rowMap.get(name);
        if (columnBean != null) {
            return columnBean.getValue();
        }
        return null;
    }

    /**
     * Creates the Cayenne Entity except for any Foreign Keys. We'll do them in the second pass once
     * eveything has been created.
     *
     */
    public void createCayenneEntity(){

        loadKeys();

        importLogger.logInfoMessage("\nNew Entity:" + tableBean.getTableName() + " FindFlag=" + tableBean.isFindFlag()
                + " UpdateFlag=" + tableBean.isUpdateFlag());

        if (tableBean.isFindFlag()) {
            // Search for the record using the ALternate Keys.

            baseEntity = findExistingRow();
            if (baseEntity == null) {
                newCayenneEntityFlag = true;
                createNewEntity();
            } else {
                newCayenneEntityFlag = false;
                importLogger.logInfoMessage("Located existing entity successfully - OID=" + baseEntity.getId());
            }
        } else {
            newCayenneEntityFlag = true;
            createNewEntity();
        }

        if ((newCayenneEntityFlag == true) || tableBean.isUpdateFlag()) {
            Collection<ColumnBean> collection = rowMap.values();
            for (ColumnBean columnBean : collection) {

                if ((columnBean.isPkFlag() == false)
                    && (columnBean.isFkFlag() == false)
                    && (columnBean.getValue() != null)) {

                    if (columnBean.getJavaType().equalsIgnoreCase("java.util.Date")) {
                        Date aDate = new Date(Long.parseLong(columnBean.getValue()));
                        baseEntity.writeProperty(columnBean.getName(), aDate);
                    } else if (columnBean.getJavaType().equalsIgnoreCase("byte[]")) {

                        Base64 base64 = new Base64();
                        byte[] bs = base64.decode(columnBean.getValue().getBytes());
                        baseEntity.writeProperty(columnBean.getName(), bs);
                    } else {
                        baseEntity.writeProperty(columnBean.getName(), columnBean.getValue());
                    }
                }
            }
        }

        deleteDependantEntities();

    }

    private void deleteDependantEntities(){

        MetaDataTableBean entityMetaData = metaDataManager.getEntityMetaData(tableBean.getTableName());
        ArrayList<String> dependantEntityList = entityMetaData.getDependantEntityList();
        importLogger.logInfoMessage("Dependant entities - size=" + dependantEntityList.size());

        for (String relationshipName : dependantEntityList) {
            importLogger.logInfoMessage("Deleting child entity(ies) - name=" + relationshipName);

            Object property = (Object) baseEntity.readProperty(relationshipName);

            if (property instanceof BaseEntity) {
                dataContext.deleteObject(property);
                importLogger.logInfoMessage("Deleted child entity - name=" + relationshipName);

            } else if (property instanceof List) {
                List childEntityList = (List) property;
                int deletedCount = childEntityList.size();
                dataContext.deleteObjects(childEntityList);
                importLogger.logInfoMessage("Deleted child entities - name=" + relationshipName + " Count="
                    + deletedCount);
            }
        }
    }

    @SuppressWarnings("deprecation")
    private void createNewEntity(){
        baseEntity = (BaseEntity) dataContext.createAndRegisterNewObject(tableBean.getTableName());
        importLogger.logInfoMessage("Creating new entity:" + tableBean.getTableName());
    }

    /**
     * Use the alternate key to locate an existing row - if one exists.
     *
     * @return
     */
    public BaseEntity findExistingRow(){

        int size = alternateKeyList.size();
        if (size < 1) {
            throw new ImportExportException("NoAlternateKeys", "Table=" + tableBean.getTableName(),
                    "ImportError - No Alternate Keys defined for table", "");
        }

        SelectQuery query = new SelectQuery(tableBean.getTableName());
        importLogger.logDebugMessage("Alternate Key List size =" + size);

        for (Iterator iterator = alternateKeyList.iterator(); iterator.hasNext();) {
            ColumnBean columnBean = (ColumnBean) iterator.next();

            importLogger.logDebugMessage("Using Alternate Key=" + columnBean.getName());

            if (columnBean.isFkFlag() == false) {
                query.andQualifier(ExpressionFactory.matchExp(columnBean.getName(), columnBean.getValue()));
                String msg = "Find using Alternate Key " + columnBean.getName() + "=" + columnBean.getValue();
                importLogger.logInfoMessage(msg);

            } else {

                // This AK column is also a FK.

                // First we have to find the FK Object. We should have it already.
                BaseEntity parentBaseEntity =
                    importManager.findEntityWithOldKey(columnBean.getFkTargentEntityName(), columnBean.getValue());

                if (parentBaseEntity == null) {
                    String context = "Table=" + tableBean.getTableName() + " FKTableName="
                        + columnBean.getFkTargentEntityName() + " FK Value=" + columnBean.getValue();
                    throw new ImportExportException("MissingForeignKey",
                                                    context,
                                                    "Import Error - Cannot locate Foreign Key in Import Data.",
                                                    "");
                }

                // PRC - Not needed
                // if (parentBean.isNewCayenneEntity()) {
                // // This means that the parent entity is a newly created row and therefore the
                // // kids will have to be new objects as well
                // importManager.logDebugMessage("New Cayenne Parent Entity found - exiting
                // alternate key search");
                // return null;
                // }

                if (parentBaseEntity != null) {
                    // BaseEntity parentBaseEntity = parentBean.getBaseEntity();
                    Expression exp = ExpressionFactory.matchExp(columnBean.getFkRelationshipName(), parentBaseEntity);
                    query.andQualifier(exp);

                    String msg = "Located FK Parent Entity successfully. Table Name=" + tableBean.getTableName()
                        + " Relationship Name=" + columnBean.getFkRelationshipName() + " OldKeyValue="
                        + columnBean.getValue() + " New OID=" + parentBaseEntity.getId();
                    importLogger.logInfoMessage(msg);

                } else {
                    // TODO - PRC 20/4/2008 - Think this should really be an Exception
                    // NB - No its not - the base row does not exist.
                    String msg = "Unable to locate FK Parent Entity. Table Name=" + tableBean.getTableName()
                        + " Relationship Name=" + columnBean.getFkRelationshipName() + " OldKeyValue="
                        + columnBean.getValue();
                    importLogger.logWarnMessage(msg);
                }

            }
        }

        List list = performQuery(query);

        if (list.isEmpty() == false) {

            return (BaseEntity) list.get(0);

        } else {
            return null;
        }

    }

    public BaseEntity getBaseEntity(){
        return baseEntity;
    }

    public Collection getForeignKeys(){
        return foreignKeyList;
    }

    public String getOldKeyValue(){
        return oldKeyValue;
    }

    /**
     * Setup all the FK's and AK's associated with this row.
     */
    private void loadKeys(){
        Collection<ColumnBean> collection = rowMap.values();
        for (ColumnBean columnBean : collection) {
            if (columnBean.isAlternateKeyFlag()) {
                alternateKeyList.add(columnBean);
            }
            if (columnBean.isPkFlag()) {
                oldKeyValue = columnBean.getValue();
            }
            if (columnBean.isFkFlag()) {
                foreignKeyList.add(columnBean);
            }
        }
    }

    public void setBaseEntity(BaseEntity baseEntity){
        this.baseEntity = baseEntity;
    }

    public void setOldKeyValue(String oldKeyValue){
        this.oldKeyValue = oldKeyValue;
    }

    public boolean isNewCayenneEntity(){
        return newCayenneEntityFlag;
    }

    public void setNewCayenneEntity(boolean newCayenneEntity){
        this.newCayenneEntityFlag = newCayenneEntity;
    }

    public ImportTableBean getTableBean(){
        return tableBean;
    }

}

package com.avoka.core.xml.importer;

public class TableSummaryBean{

    String  tableName;
    int     rowCount;
    boolean updateFlag;

    public String getTableName(){
        return tableName;
    }

    public void setTableName(String tableName){
        this.tableName = tableName;
    }

    public int getRowCount(){
        return rowCount;
    }

    public void setRowCount(int rowCount){
        this.rowCount = rowCount;
    }

    public boolean isUpdateFlag(){
        return updateFlag;
    }

    public void setUpdateFlag(boolean updateFlag){
        this.updateFlag = updateFlag;
    }

}

package com.avoka.core.xml.importer;


public interface IEntityValidator {
    public void validateEntity(RowBean newRow) throws ValidationException;
}

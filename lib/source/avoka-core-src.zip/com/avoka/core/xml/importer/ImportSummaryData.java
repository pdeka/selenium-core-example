package com.avoka.core.xml.importer;

import java.util.ArrayList;
import java.util.List;

public class ImportSummaryData{

    private String                      importType;
    private String                      environmentName;
    private String                      name;
    private String                      description;
    private String                      exportDate;
    private String                      exportVersion;

    private ArrayList<TableSummaryBean> tableSummaryList = new ArrayList();

    public void addTableSummaryBean(TableSummaryBean table){
        tableSummaryList.add(table);
    }

    public List<TableSummaryBean> getTableSummaryList(){
        return tableSummaryList;
    }

    public String getImportType(){
        return importType;
    }

    public void setImportType(String importType){
        this.importType = importType;
    }

    public String getEnvironmentName(){
        return environmentName;
    }

    public void setEnvironmentName(String environmentName){
        this.environmentName = environmentName;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getDescription(){
        return description;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public String getExportDate(){
        return exportDate;
    }

    public void setExportDate(String exportDate){
        this.exportDate = exportDate;
    }

    public String getExportVersion(){
        return exportVersion;
    }

    public void setExportVersion(String exportVersion){
        this.exportVersion = exportVersion;
    }

}

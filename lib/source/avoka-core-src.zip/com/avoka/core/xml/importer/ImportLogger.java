package com.avoka.core.xml.importer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.util.FileUtils;

public class ImportLogger{

    public static final String MSG_Debug         = "DEBUG";
    public static final String MSG_Error         = "ERROR";
    public static final String MSG_Info          = "INFO";
    public static final String MSG_Warning       = "WARN";

    String                     importLogDirectory;

    // Used to record importMessages.
    ArrayList<String>          importMessageList = new ArrayList<String>();

    /** The class logger. */
    private Logger             logger;

    /**
     * Return the service log.
     *
     * @return the service log
     */
    protected Logger getLogger(){
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

    public void logDebugMessage(String msg){
        logImportMessage(MSG_Debug, msg);
    }

    public void logErrorMessage(String msg){
        logImportMessage(MSG_Error, msg);
    }

    public void logImportMessage(String type, String msg){
        importMessageList.add(type + "," + msg);
        getLogger().info(type + "," + msg);
    }

    public void logInfoMessage(String msg){
        logImportMessage(MSG_Info, msg);
    }

    public void logWarnMessage(String msg){
        logImportMessage(MSG_Warning, msg);
    }

    public void writeImportLog(){

        StringBuffer buffer = new StringBuffer();
        for (Iterator iterator = importMessageList.iterator(); iterator.hasNext();) {
            String message = (String) iterator.next();
            buffer.append(message);
            buffer.append("\n\r");
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
            String name = sdf.format(new Date());

            FileUtils.writeToFile(importLogDirectory + "import" + name + ".log", buffer.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public String getImportLogDirectory(){
        return importLogDirectory;
    }

    public void setImportLogDirectory(String importLogDirectory){
        this.importLogDirectory = importLogDirectory;
    }

}

package com.avoka.core.xml.importer;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.xml.export.ExportConstants;
import com.avoka.core.xml.export.MetaDataManager;

public class XMLReader{

    XMLStreamReader parser        = null;

    /** The class logger. */
    private Logger  logger;

    ImportManager   importManager = new ImportManager();

    protected List<IAddEntityListener> addEntityListeners = new ArrayList<IAddEntityListener>();
    protected List<IEntityValidator> validators = new ArrayList<IEntityValidator>();

    /**
     * Return the service log.
     *
     * @return the service log
     */
    protected Logger getLogger(){
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

    @SuppressWarnings("deprecation")
    public void importXml(InputStream inputStream,
            MetaDataManager metaDataManager,
            String importDirectory,
            boolean productionEnvironmentFlag){

        importManager.setMetaDataManager(metaDataManager);
        ImportLogger importLogger = importManager.getImportLogger();

        importLogger.setImportLogDirectory(importDirectory);

        /*
         * Manage our own Cayenne Transactions....
         *
         * see http://cayenne.apache.org/doc/understanding-transactions.html
         *
         */
        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction sqlTransaction = domain.createTransaction();

        Transaction.bindThreadTransaction(sqlTransaction);

        try {

            sqlTransaction.begin();

            XMLInputFactory factory = getFactory();
            parser = factory.createXMLStreamReader(inputStream);

            RowBean rowBean = null;
            ColumnBean columnBean = null;
            boolean columnModeFlag = false;

            String name = null;

            for (int event = parser.next(); event != XMLStreamConstants.END_DOCUMENT; event = parser.next()) {
                switch (event) {
                case XMLStreamConstants.START_ELEMENT:
                    name = parser.getLocalName();
                    if (name.equalsIgnoreCase(ExportConstants.TABLE_Element)) {

                        ImportTableBean importTableBean = new ImportTableBean(importLogger);
                        int count = parser.getAttributeCount();
                        for (int i = 0; i < count; ++i) {
                            String attribute = parser.getAttributeLocalName(i);
                            if (attribute.equalsIgnoreCase(ExportConstants.TABLE_AttributeName)) {
                                String tableName = parser.getAttributeValue(i);
                                importTableBean.setTableName(tableName);
                                // This also sets this table to be "active" or "current"
                                importManager.addTable(tableName, importTableBean);
                            } else if (attribute.equalsIgnoreCase(ExportConstants.TABLE_AttributeFind)) {
                                String findFlag = parser.getAttributeValue(i);
                                if (findFlag.equalsIgnoreCase("1")) {
                                    importTableBean.setFindFlag(true);
                                } else {
                                    importTableBean.setFindFlag(false);
                                }
                            } else if (attribute.equalsIgnoreCase(ExportConstants.TABLE_AttributeUpdate)) {
                                String flag = parser.getAttributeValue(i);
                                if (flag.equalsIgnoreCase("1")) {
                                    importTableBean.setUpdateFlag(true);
                                } else {
                                    importTableBean.setUpdateFlag(false);
                                }
                            } else if (attribute.equalsIgnoreCase(ExportConstants.TABLE_AttributeProductionTable)) {
                                String flag = parser.getAttributeValue(i);
                                if (flag.equalsIgnoreCase("1")) {
                                    importTableBean.setProductionTableFlag(true);
                                } else {
                                    importTableBean.setProductionTableFlag(false);
                                }
                            }
                        }
                    } else if (name.equalsIgnoreCase(ExportConstants.ROW_Element)) {
                        rowBean = new RowBean(importManager.getCurrentTableBean(), importManager);
                    } else if (name.equalsIgnoreCase(ExportConstants.COLUMN_Element)) {
                        columnModeFlag = true;
                        columnBean = new ColumnBean();
                        int count = parser.getAttributeCount();
                        for (int i = 0; i < count; ++i) {
                            String attribute = parser.getAttributeLocalName(i);
                            if (attribute.equalsIgnoreCase(ExportConstants.COLUMN_AttributeName)) {
                                String columnName = parser.getAttributeValue(i);
                                columnBean.setName(columnName);
                            }
                            if (attribute.equalsIgnoreCase(ExportConstants.COLUMN_AttributeType)) {
                                String columnType = parser.getAttributeValue(i);
                                columnBean.setJavaType(columnType);
                            } else if (attribute.equalsIgnoreCase(ExportConstants.COLUMN_AttributePK)) {
                                columnBean.setPkFlag(true);
                            } else if (attribute.equalsIgnoreCase(ExportConstants.COLUMN_AlternateKey)) {
                                columnBean.setAlternateKeyFlag(true);
                            } else if (attribute.equalsIgnoreCase(ExportConstants.COLUMN_FKRelationshipName)) {
                                String fkTable = parser.getAttributeValue(i);
                                columnBean.setFkFlag(true);
                                columnBean.setFkRelationshipName(fkTable);
                            } else if (attribute.equalsIgnoreCase(ExportConstants.COLUMN_FKTargetEntityName)) {
                                String value = parser.getAttributeValue(i);
                                columnBean.setFkFlag(true);
                                columnBean.setFkTargentEntityName(value);
                            } else if (attribute.equalsIgnoreCase(ExportConstants.COLUMN_FKResolveLate)) {
                                columnBean.setFkResolveLate(true);
                            }
                        }
                    }
                    break;
                case XMLStreamConstants.END_ELEMENT:
                    name = parser.getLocalName();
                    if (name.equalsIgnoreCase(ExportConstants.ROW_Element)) {
                        // Create the Cayene Object and then add to the table
                        boolean importRowFlag = false;

                        ImportTableBean currentTableBean = importManager.getCurrentTableBean();

                        // Check if this table row should be imported.
                        if (productionEnvironmentFlag == true) {

                            if (currentTableBean.isProductionTableFlag()) {
                                importRowFlag = true;
                            } else {
                                importRowFlag = false;
                            }

                        } else {
                            importRowFlag = true;
                        }

                        if (importRowFlag) {
                            notifyPreAdd(rowBean);

                            validate(rowBean);

                            rowBean.createCayenneEntity();
                            importManager.resolveForeignKey(currentTableBean, false, rowBean);

                            // This will save the changes to the database - but not commit them yet.
                            DataContext.getThreadDataContext().commitChanges();
                            DataContext.getThreadDataContext().getObjectStore().getDataRowCache().clear();

                            importManager.addRow(rowBean);

                            notifyPostAdd(rowBean.getBaseEntity());
                        }

                    } else if (name.equalsIgnoreCase(ExportConstants.COLUMN_Element)) {
                        // Add the column to the RowManager
                        columnModeFlag = false;
                        getLogger().debug(columnBean.toString());
                        rowBean.addColumn(columnBean);

                    } else if (name.equalsIgnoreCase(ExportConstants.TABLE_Element)) {
                        // This will save the changes to the database - but not commit them yet.
                        // importManager.resolveForeignKeys(importManager.getCurrentTableBean(),
                        // false);
                        // DataContext.getThreadDataContext().commitChanges();
                    }

                    break;
                case XMLStreamConstants.CHARACTERS:
                    // Lets try getting text here as well.
                    if (columnModeFlag) {
                        String text = parser.getText();
                        //
                        columnBean.setValue(text);
                    }
                    break;
                case XMLStreamConstants.CDATA:
                    break;
                } // end switch
            } // end while
            parser.close();

            importManager.resolveAllForeignKeys(true);
            DataContext.getThreadDataContext().commitChanges();

            sqlTransaction.commit();

        } catch (Exception ex) {
            try {
                sqlTransaction.rollback();
                getLogger().warn("SQL Transaction Rolled back successfully....");
            } catch (Exception e) {
                getLogger().error("Error Rolling back transaction..." + e.getMessage(), e);
            }

            String message = ex.getMessage();
            if (message == null) {
                message = "Import failed";
            }
            throw new ImportExportException("ImportFailed", ex, "Importing from file", ex.getMessage(), null);

        } finally {

            Transaction.bindThreadTransaction(null);
            IOUtils.closeQuietly(inputStream);
            importLogger.writeImportLog();
        }

    }

    public ImportSummaryData getSummaryData(InputStream inStream){

        ImportSummaryData importSummaryData = null;
        TableSummaryBean tableSummaryBean = null;

        try {

            XMLInputFactory factory = getFactory();
            parser = factory.createXMLStreamReader(inStream);

            String name;

            for (int event = parser.next(); event != XMLStreamConstants.END_DOCUMENT; event = parser.next()) {
                switch (event) {
                case XMLStreamConstants.START_ELEMENT:
                    name = parser.getLocalName();
                    if (name.equalsIgnoreCase(ExportConstants.EXPORT_Element)) {
                        importSummaryData = new ImportSummaryData();
                        int count = parser.getAttributeCount();
                        for (int i = 0; i < count; ++i) {
                            String attribute = parser.getAttributeLocalName(i);
                            if (attribute.equalsIgnoreCase(ExportConstants.EXPORT_AttributeExportEnvironment)) {
                                importSummaryData.setEnvironmentName(parser.getAttributeValue(i));
                            } else if (attribute.equalsIgnoreCase(ExportConstants.EXPORT_AttributeDescription)) {
                                importSummaryData.setDescription(parser.getAttributeValue(i));
                            } else if (attribute.equalsIgnoreCase(ExportConstants.EXPORT_AttributeName)) {
                                importSummaryData.setName(parser.getAttributeValue(i));
                            } else if (attribute.equalsIgnoreCase(ExportConstants.EXPORT_AttributeTime)) {
                                importSummaryData.setExportDate(parser.getAttributeValue(i));
                            } else if (attribute.equalsIgnoreCase(ExportConstants.EXPORT_AttributeType)) {
                                importSummaryData.setImportType(parser.getAttributeValue(i));
                            } else if (attribute.equalsIgnoreCase(ExportConstants.EXPORT_AttributeVersion)) {
                                importSummaryData.setExportVersion(parser.getAttributeValue(i));
                            }
                        }
                    } else if (name.equalsIgnoreCase(ExportConstants.TABLE_Element)) {
                        tableSummaryBean = new TableSummaryBean();
                        importSummaryData.addTableSummaryBean(tableSummaryBean);
                        int count = parser.getAttributeCount();
                        for (int i = 0; i < count; ++i) {
                            String attribute = parser.getAttributeLocalName(i);
                            if (attribute.equalsIgnoreCase(ExportConstants.TABLE_AttributeName)) {
                                String tableName = parser.getAttributeValue(i);
                                tableSummaryBean.setTableName(tableName);
                                // This also sets this table to be "active" or "current"
                            } else if (attribute.equalsIgnoreCase(ExportConstants.TABLE_AttributeUpdate)) {
                                String flag = parser.getAttributeValue(i);
                                if (flag.equalsIgnoreCase("1")) {
                                    tableSummaryBean.setUpdateFlag(true);
                                } else {
                                    tableSummaryBean.setUpdateFlag(false);
                                }
                            }
                        }
                    } else if (name.equalsIgnoreCase(ExportConstants.ROWLIST_Element)) {
                        int count = parser.getAttributeCount();
                        for (int i = 0; i < count; ++i) {
                            String attribute = parser.getAttributeLocalName(i);
                            if (attribute.equalsIgnoreCase(ExportConstants.ROWLIST_AttributeCount)) {
                                String value = parser.getAttributeValue(i);
                                int rowCount = Integer.parseInt(value);
                                tableSummaryBean.setRowCount(rowCount);
                            }
                        }
                    }
                    break;
                } // end switch
            } // end while
            parser.close();

            return importSummaryData;

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException(ex);
        } finally {
            close(inStream);

        }

    }

    public void addAddEntityListener(IAddEntityListener newListener) {
        if (newListener != null) {
            addEntityListeners.add(newListener);
        }
    }

    public boolean removeAddEntityListener(IAddEntityListener listener) {
        if (listener != null) {
            return addEntityListeners.remove(listener);
        }
        return false;
    }

    protected void notifyPreAdd(RowBean newRow) {
        if (newRow != null) {
            for (int i = 0; i < addEntityListeners.size(); i++) {
                IAddEntityListener curListener = addEntityListeners.get(i);
                if (curListener != null) {
                    curListener.preAddEntity(newRow);
                }
            }
        }
    }

    protected void notifyPostAdd(BaseEntity newEntity) {
        if (newEntity != null) {
            for (int i = 0; i < addEntityListeners.size(); i++) {
                IAddEntityListener curListener = addEntityListeners.get(i);
                if (curListener != null) {
                    curListener.postAddEntity(newEntity);
                }
            }
        }
    }

    public void addValidator(IEntityValidator newValidator) {
        if (newValidator != null) {
            validators.add(newValidator);
        }
    }

    public boolean removeValidator(IEntityValidator validator) {
        if (validator != null) {
            return validators.remove(validator);
        }
        return false;
    }

    protected void validate(RowBean newEntity) throws ValidationException {
        if (newEntity != null) {
            for (int i = 0; i < validators.size(); i++) {
                IEntityValidator curValidator = validators.get(i);
                if (curValidator != null) {
                    curValidator.validateEntity(newEntity);
                }
            }
        }
    }

    protected XMLInputFactory getFactory(){
        // Stax ref. impl. is the default, no need to override?
        // System.setProperty("javax.xml.stream.XMLInputFactory", "com.bea.xml.stream.MXParser");

        XMLInputFactory factory = XMLInputFactory.newInstance();
        System.out.println("Factory instance: " + factory.getClass());

        factory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
        // f.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
        factory.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE);
        // f.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.FALSE);
        factory.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.TRUE);

        factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.TRUE);
        // f.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);

        factory.setProperty(XMLInputFactory.IS_VALIDATING, Boolean.FALSE);

        // f.setProperty(XMLInputFactory.REPORTER, new TestReporter());
        // f.setProperty(XMLInputFactory.RESOLVER, new TestResolver1());

        return factory;
    }

    private void close(InputStream inStream){
        if (inStream != null) {
            try {
                inStream.close();
            } catch (IOException e) {
            }
        }
    }
}

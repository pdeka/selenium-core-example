package com.avoka.core.xml.importer;

public class ColumnBean{

    private String  name;
    private String  javaType;
    private String  value;
    private boolean pkFlag;
    private boolean fkFlag;
    private String  fkRelationshipName;
    private String  fkTargentEntityName;
    private boolean fkResolveLate;

    private boolean alternateKeyFlag;

    public String toString(){
        return "Name=" + name + ", value=" + value + ", pkFlag=" + pkFlag + ", fkFlag=" + fkFlag
            + ", fkRelationshipName=" + fkRelationshipName + ", AlternateKey=" + alternateKeyFlag;
    }

    public boolean isFkFlag(){
        return fkFlag;
    }

    public void setFkFlag(boolean fkFlag){
        this.fkFlag = fkFlag;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public boolean isPkFlag(){
        return pkFlag;
    }

    public void setPkFlag(boolean pkFlag){
        this.pkFlag = pkFlag;
    }

    public String getValue(){

        if (value == null) {
            return null;
        }

        return value;
    }

    public void setValue(String newValue){
        if (value != null) {
            this.value = value + newValue;

        } else {
            this.value = newValue;
        }
    }

    public void overwriteValue(String newValue){
        value = newValue;
    }

    public boolean isAlternateKeyFlag(){
        return alternateKeyFlag;
    }

    public void setAlternateKeyFlag(boolean alternateKeyFlag){
        this.alternateKeyFlag = alternateKeyFlag;
    }

    public String getFkTargentEntityName(){
        return fkTargentEntityName;
    }

    public void setFkTargentEntityName(String fkTargentEntityName){
        this.fkTargentEntityName = fkTargentEntityName;
    }

    public String getFkRelationshipName(){
        return fkRelationshipName;
    }

    public void setFkRelationshipName(String fkRelationshipName){
        this.fkRelationshipName = fkRelationshipName;
    }

    public boolean isFkResolveLate(){
        return fkResolveLate;
    }

    public void setFkResolveLate(boolean fkResolveLate){
        this.fkResolveLate = fkResolveLate;
    }

    public String getJavaType(){
        return javaType;
    }

    public void setJavaType(String javaType){
        this.javaType = javaType;
    }

}

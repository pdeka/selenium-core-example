package com.avoka.core.xml.importer;

import com.avoka.core.entity.BaseEntity;

public interface IAddEntityListener {
    public void preAddEntity(RowBean newRow);
    public void postAddEntity(BaseEntity newEntity);
}

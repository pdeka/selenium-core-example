package com.avoka.core.xml.importer;

import org.apache.commons.lang.Validate;

public class ImportExportException extends RuntimeException{

    /**
     *
     */
    private static final long serialVersionUID = 5877609318484959016L;

    /** The name of the exception. */
    private final String name;

    /** The user context to record any parameters that may be relevant to the exception. */
    private final String context;

    /** The user message type. This will display various messages to the end user. */
    private final String userMessage;

    /** The suggested solution for this problem. */
    private final String solution;



    public String getName(){
        return name;
    }

    public String getContext(){
        return context;
    }

    public String getUserMessage(){
        return userMessage;
    }

    public String getSolution(){
        return solution;
    }

    /**
     * Create an application exception object.
     *
     * @param name
     * @param cause
     * @param context
     * @param userMessage - An optional message about the error.
     * @param solution
     */
    public ImportExportException(String name, Throwable cause, String context, String userMessage,  String solution) {
        super(cause.toString(), cause);

        Validate.notNull(name, "Null name parameter");
        Validate.notNull(cause, "Null cause parameter");
        Validate.notNull(context, "Null context parameter");
        Validate.notNull(userMessage, "Null userMessage parameter");

        this.name = name;
        this.context = context;
        this.userMessage = userMessage;
        this.solution = solution;
    }

    /**
     * Create an application exception object.
     *
     * @param name
     * @param context
     * @param userMessage
     * @param solution
     */
    public ImportExportException(String name, String context, String userMessage, String solution) {
        super(name + ": " + context);

        Validate.notNull(name, "Null name parameter");
        Validate.notNull(context, "Null context parameter");
        Validate.notNull(userMessage, "Null userMessage parameter");

        this.name = name;
        this.context = context;
        this.userMessage = userMessage;
        this.solution = solution;
    }
}

package com.avoka.core.xml.export;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.cayenne.map.ObjEntity;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.service.BaseService;
import com.avoka.core.xml.importer.ImportExportException;

public class ExportManager extends BaseService{

    // Map of all the table beans
    private Hashtable<String, ExportTableBean> tableMap = new Hashtable<String, ExportTableBean>();

    private MetaDataManager metaDataManager;

    public ExportManager(MetaDataManager metaDataManager){
        this.metaDataManager = metaDataManager;
    }

    public void addRow(BaseEntity row){
        addRow(row, false, false);
    }

    /**
     * This will add (or replace) a row.
     *
     * @param row
     * @return
     */
    public void addRow(BaseEntity row, boolean findFlag, boolean updateFlag){

        if (row == null) {
            return;
        }

        ObjEntity objEntity = row.getObjEntity();
        String tableName = objEntity.getName();

        MetaDataTableBean entityMetaData = metaDataManager.getEntityMetaData(tableName);
        if (entityMetaData == null) {
            throw new ImportExportException("NoMetaDataForEntity",
                                            "Table Name=" + tableName,
                                            "Missing metadata for Table",
                                            "Add the table to the metadata definition");
        }

        ExportTableBean exportTableBean = tableMap.get(tableName);
        if (exportTableBean == null) {
            exportTableBean = new ExportTableBean(tableName, findFlag, updateFlag);
            exportTableBean.setProductionTableFlag(entityMetaData.isProductionTableFlag());
            tableMap.put(tableName, exportTableBean);
            getLogger().info("Adding Table " + tableName);
        }

        exportTableBean.addRow(row);

    }

    /**
     * Checks to see if an entity has already been added.
     *
     * @param row
     * @return
     */
    public boolean findRow(BaseEntity row){

        if (row == null) {
            return false;
        }

        ObjEntity objEntity = row.getObjEntity();
        String tableName = objEntity.getName();

        ExportTableBean exportTableBean = tableMap.get(tableName);
        if (exportTableBean == null) {
            return false;
        }

        return exportTableBean.findRow(row);

    }

    public void writeXml(OutputStream outStream,
            String exportTypeName,
            String exportName,
            String description,
            String environmentName){

        XmlWriter xmlWriter = new XmlWriter();

        xmlWriter.export(outStream,
                         tableMap,
                         metaDataManager,
                         exportTypeName,
                         exportName,
                         description,
                         environmentName);

    }

    @SuppressWarnings("deprecation")
    public void deleteRows(){

        /*
         * Manage our own Cayenne Transactions....
         *
         * see http://cayenne.apache.org/doc/understanding-transactions.html
         *
         */
        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction sqlTrasaction = domain.createTransaction();

        Transaction.bindThreadTransaction(sqlTrasaction);

        try {

            sqlTrasaction.begin();

            DataContext threadDataContext = DataContext.getThreadDataContext();

            Collection<MetaDataTableBean> exportSequence = metaDataManager.getExportSequence();
            ArrayList<MetaDataTableBean> exportSequenceList = new ArrayList(exportSequence);
            // To delete we need to do this in reverse.

            int size = exportSequenceList.size();

            for (int i = size - 1; i > -1; i--) {
                MetaDataTableBean metaDataBean = exportSequenceList.get(i);

                String entityName = metaDataBean.getEntityName();
                ExportTableBean exportTableBean = tableMap.get(entityName);

                if (exportTableBean != null) {

                    getLogger().info("Deleting Entity " + entityName + " Rows = " + exportTableBean.rowSize());

                    Collection<BaseEntity> rowCollection = exportTableBean.getRowCollection();

                    threadDataContext.deleteObjects(rowCollection);
                    // for (BaseEntity baseEntity : rowCollection) {
                    // threadDataContext.deleteObject(baseEntity);
                    // }

                    threadDataContext.commitChanges();
                }
            }

            sqlTrasaction.commit();

        } catch (Exception ex) {
            try {
                sqlTrasaction.rollback();
                getLogger().warn("SQL Transaction Rolled back successfully....");

            } catch (Exception e) {
                getLogger().warn("Error Rolling back transaction..." + e.getMessage(), e);
            }

            getLogger().error(ex.toString(), ex);

            throw new RuntimeException(ex);

        } finally {

            Transaction.bindThreadTransaction(null);

        }

    }
}

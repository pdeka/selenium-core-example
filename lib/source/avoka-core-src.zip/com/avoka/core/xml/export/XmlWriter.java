package com.avoka.core.xml.export;

import java.io.OutputStream;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.apache.cayenne.map.DbAttribute;
import org.apache.cayenne.map.DbEntity;
import org.apache.cayenne.map.DbRelationship;
import org.apache.cayenne.map.ObjAttribute;
import org.apache.cayenne.map.ObjEntity;
import org.apache.cayenne.map.ObjRelationship;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.entity.BaseEntity;

public class XmlWriter{

    XMLStreamWriter writer = null;
    MetaDataManager exportMetaData;

    final Logger logger = LoggerFactory.getLogger(XmlWriter.class);

    public void export(OutputStream outStream,
            Map<String, ExportTableBean> tableMap,
            MetaDataManager exportMetaData,
            String exportType,
            String exportName,
            String description,
            String environmentName){

        this.exportMetaData = exportMetaData;

        try {

            XMLOutputFactory factory = XMLOutputFactory.newInstance();

            writer = factory.createXMLStreamWriter(outStream);

            writer.writeStartDocument();

            writer.writeStartElement(ExportConstants.EXPORT_Element);

            // Write the date
            Date now = new Date();

            writer.writeAttribute(ExportConstants.EXPORT_AttributeMilliSeconds, "" + now.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
            writer.writeAttribute(ExportConstants.EXPORT_AttributeTime, sdf.format(now));
            writer.writeAttribute(ExportConstants.EXPORT_AttributeExportEnvironment, environmentName);
            writer.writeAttribute(ExportConstants.EXPORT_AttributeType, exportType);
            writer.writeAttribute(ExportConstants.EXPORT_AttributeName, exportName);
            writer.writeAttribute(ExportConstants.EXPORT_AttributeDescription, description);
            writer.writeAttribute(ExportConstants.EXPORT_AttributeVersion, ExportConstants.EXPORT_VERSION );


            writer.writeStartElement(ExportConstants.TABLELIST_Element);

            // Collection list = tableMap.values();

            Collection<MetaDataTableBean> exportSequenceList = exportMetaData.getExportSequence();
            for (MetaDataTableBean metaDataTableBean : exportSequenceList) {

                ExportTableBean exportBean = tableMap.get(metaDataTableBean.getEntityName());
                if (exportBean != null) {
                    exportTable(exportBean);
                }
            }

            writer.writeEndElement(); // TableList

            writer.writeEndElement(); // export
            writer.writeEndDocument();

            writer.flush();
            writer.close();
            // outStream.close();

        } catch (XMLStreamException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * Note that the FK & PK Column names are not used during the import - Cayenne resolves these
     * using the FK Table Names. In the export file the DBEntity names are used for PK & FK (don't
     * recall why??) for importmation only
     *
     *
     * @param tableBean
     * @throws XMLStreamException
     */

    private void exportTable(ExportTableBean tableBean) throws XMLStreamException{
        Object valueObject = null;

        writer.writeStartElement(ExportConstants.TABLE_Element);
        writer.writeAttribute(ExportConstants.TABLE_AttributeName, tableBean.getTableName());
        writer.writeAttribute(ExportConstants.TABLE_AttributeFind, tableBean.getFindFlag());
        writer.writeAttribute(ExportConstants.TABLE_AttributeUpdate, tableBean.getUpdateFlag());
        writer.writeAttribute(ExportConstants.TABLE_AttributeProductionTable, tableBean.getProductionTableFlag());
        // writer.writeAttribute(ExportConstants.TABLE_AttributeDeleteChildObjects,
        // tableBean.getDeleteAllChildRowsFlag());

        logger.debug("Exporting table " + tableBean.getTableName() + " Rows = " + tableBean.rowSize());

        writer.writeStartElement(ExportConstants.ROWLIST_Element);
        writer.writeAttribute(ExportConstants.ROWLIST_AttributeCount, "" + tableBean.rowSize());

        // Do all the rows
        Iterator iter = tableBean.iterator();
        String objType = null;

        while (iter.hasNext()) {
            BaseEntity baseEntity = (BaseEntity) iter.next();
            writer.writeStartElement(ExportConstants.ROW_Element);

            // Do the PrimaryKey First
            ObjEntity objEntity = baseEntity.getObjEntity();
            DbEntity dbEntity = objEntity.getDbEntity();

            /*
             * PRC.
             *
             * Note that only DBEntities hold the PK . so we have to iterate over the dbEntity for
             * these. There is no corresponding objAttribute - so we have to use the dbAttributeName
             * in the output.
             */

            Collection attributeList = dbEntity.getAttributes();
            for (Iterator iterator = attributeList.iterator(); iterator.hasNext();) {
                DbAttribute dbAttribute = (DbAttribute) iterator.next();

                if (dbAttribute.isPrimaryKey()) {
                    writer.writeStartElement(ExportConstants.COLUMN_Element);
                    writer.writeAttribute(ExportConstants.COLUMN_AttributeName, dbAttribute.getName());
                    writer.writeAttribute(ExportConstants.COLUMN_AttributePK, "1");
                    writer.writeCharacters("" + baseEntity.getId());
                    writer.writeEndElement(); // Column
                }

            }

            // Now all the other attribues except the FK's

            attributeList = objEntity.getAttributes();

            // NB - The FKs are not returned with getAttributes()?
            for (Iterator iterator = attributeList.iterator(); iterator.hasNext();) {
                ObjAttribute objAttribute = (ObjAttribute) iterator.next();
                DbAttribute dbAttribute = objAttribute.getDbAttribute();

                writer.writeStartElement(ExportConstants.COLUMN_Element);
                writer.writeAttribute(ExportConstants.COLUMN_AttributeName, objAttribute.getName());

                if (exportMetaData.isAlternateKey(objEntity.getName(), objAttribute.getName())) {
                    writer.writeAttribute(ExportConstants.COLUMN_AlternateKey, "1");
                }

                // TODO PRC For Debug only - Comment this out once all of this is working
                writer.writeAttribute(ExportConstants.COLUMN_AttributeType, objAttribute.getType());

                valueObject = baseEntity.readProperty(objAttribute.getName());

                if (valueObject != null) {
                    // Deal with Boolean value as 0 or 1
                    /*
                     * PRC - Should also test the DB Type to determine how mapping should be done.
                     * Alternativly make abstract mapping functions that created as needed
                     *
                     * Done for Int to Boolean
                     */

                    /*
                     * Type are java.lang.Long java.lang.String java.util.Date byte[] (blobs)
                     * java.lang.Boolean
                     *
                     *
                     */

                    objType = objAttribute.getType();
                    int dbType = dbAttribute.getType();

                    if ((objType.equalsIgnoreCase("java.lang.Boolean") && (dbType == Types.INTEGER))
                            || (objType.equalsIgnoreCase("boolean") && (dbType == Types.INTEGER))) {

                        String value = valueObject.toString();
                        if (value.equalsIgnoreCase("true")) {
                            writer.writeCharacters("1");
                        } else {
                            writer.writeCharacters("0");
                        }

                    } else if (objType.equalsIgnoreCase("java.util.Date")) {
                        Date aDate = (Date) baseEntity.readProperty(objAttribute.getName());

                        writer.writeCharacters("" + aDate.getTime());

                        logger.debug("Date:" + aDate );

                    } else if (objType.equalsIgnoreCase("byte[]")) {
                        byte[] bytes = (byte[]) baseEntity.readProperty(objAttribute.getName());

                        Base64 base64 = new Base64();
                        byte[] bs = base64.encode(bytes);

                        String test = new String(bs);

                        writer.writeCharacters(test);

                       logger.debug("Bytes base64:" + test );

                    } else {
                        writer.writeCharacters(valueObject.toString());
                    }
                }

               logger.debug("Name=" + objAttribute.getName() + " Type=" + objAttribute.getType());

                writer.writeEndElement(); // Column

            }

            // Now do the relationships back to parent entities
            Collection relationshipList = objEntity.getRelationships();
            for (Iterator iter2 = relationshipList.iterator(); iter2.hasNext();) {
                ObjRelationship objRelationship = (ObjRelationship) iter2.next();

                if (objRelationship.isToPK()) {

                    // This is a child object.

                    // We now have to find the attribute - in Cayenne there can be more than one
                    // - but we only ever use a single fk.
                    List dbRelationshipList = objRelationship.getDbRelationships();
                    DbRelationship dbRelationship = (DbRelationship) dbRelationshipList.get(0);

                   logger.debug("DB Relationship " + dbRelationship.getName());

                    Collection fkAttributesList = dbRelationship.getSourceAttributes();

                    // Assume there will only be 1
                    //
                    DbAttribute fkSourceAttribute = null;
                    for (Iterator iter3 = fkAttributesList.iterator(); iter3.hasNext();) {
                        fkSourceAttribute = (DbAttribute) iter3.next();
                        break;

                    }

                    if (fkSourceAttribute != null) {

                        // Get the foreign object
                        BaseEntity foreignBaseEntity = (BaseEntity) baseEntity.readProperty(objRelationship.getName());

                        /*
                         * PRC - Check that its not null. In some situations you can have FKs that
                         * are not mandatory.
                         *
                         * This enables you to have tables that can have different FK and Alternate
                         * Keys. An example in FormCenter is MetaDataValue that can be a child of
                         * either Client, Form or Template. When specifying the AlternateKeys in the
                         * Export Metadata you would specify all of these - but when each row is
                         * exported it would only export values that thoes that are in use.
                         *
                         *
                         */
                        if (foreignBaseEntity != null) {

                            writer.writeStartElement(ExportConstants.COLUMN_Element);

                            writer.writeAttribute(ExportConstants.COLUMN_AttributeName, fkSourceAttribute.getName());
                            writer.writeAttribute(ExportConstants.COLUMN_FKRelationshipName, objRelationship.getName());
                            writer.writeAttribute(ExportConstants.COLUMN_FKTargetEntityName, objRelationship
                                    .getTargetEntityName());

                            if (exportMetaData.isResolveAfterCommit(objEntity.getName(), objRelationship.getName())) {
                                writer.writeAttribute(ExportConstants.COLUMN_FKResolveLate, "1");
                            }

                            if (exportMetaData.isAlternateKey(objEntity.getName(), objRelationship.getName())) {
                                writer.writeAttribute(ExportConstants.COLUMN_AlternateKey, "1");
                            }

                            // writer.writeAttribute("FK", "1");

                            writer.writeCharacters("" + foreignBaseEntity.getId());
                            writer.writeEndElement(); // Column
                        } else {
                           logger.debug("FK Entity is null");
                        }

                    }

                } else {

                    // Ignore - its a reverse relationship - ie - parent down to child.

                }

            }

            writer.writeEndElement(); // end row
        }
        writer.writeEndElement(); // RowList
        writer.writeEndElement(); // Table

    }

}

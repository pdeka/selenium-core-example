package com.avoka.core.xml.export;

public class ExportConstants{

    public static final String EXPORT_VERSION                    = "2.0.0";

    public static final String EXPORT_Element                    = "Export";
    public static final String EXPORT_AttributeMilliSeconds      = "milli";
    public static final String EXPORT_AttributeTime              = "time";
    public static final String EXPORT_AttributeType              = "type";
    public static final String EXPORT_AttributeName              = "name";
    public static final String EXPORT_AttributeExportEnvironment = "export_environment";
    public static final String EXPORT_AttributeDescription       = "description";
    public static final String EXPORT_AttributeVersion           = "export_version";

    public static final String TABLELIST_Element                 = "TableList";
    public static final String TABLE_Element                     = "Table";
    public static final String TABLE_AttributeName               = "name";
    public static final String TABLE_AttributeFind               = "find";
    public static final String TABLE_AttributeUpdate             = "update";
    public static final String TABLE_AttributeProductionTable    = "production_table";
    // public static final String TABLE_AttributeDeleteChildObjects = "deleteChild";

    public static final String ROWLIST_Element                   = "RowList";
    public static final String ROWLIST_AttributeCount            = "Count";

    public static final String ROW_Element                       = "Row";
    public static final String COLUMN_Element                    = "Column";
    public static final String COLUMN_AttributeName              = "ColName";
    public static final String COLUMN_AttributeType              = "DataType";
    public static final String COLUMN_AttributePK                = "PK";
    public static final String COLUMN_FKRelationshipName         = "FKRelationshipName";
    public static final String COLUMN_FKTargetEntityName         = "FKTargetEntityName";
    public static final String COLUMN_AlternateKey               = "AK";
    public static final String COLUMN_FKResolveLate              = "FKResolveLate";

}

package com.avoka.core.xml.export;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MetaDataManager{

    private Map<String, String> alternatePKMap = new HashMap<String, String>();

    /*
     * Contains a list of FK's that can only be resolved after the first commit. An example in FC is
     * Template which has a link back to Template_Version via the "CurrentVersion" relationship.
     * TemplateVersion is also a child of Template
     */
    private Map<String, String> fkResolveAfterCommitMap = new HashMap<String, String>();

    private LinkedHashMap<String, MetaDataTableBean> entityMap = new LinkedHashMap<String, MetaDataTableBean>();

    public MetaDataTableBean getEntityMetaData(String entityName) {
       return  entityMap.get(entityName);
    }

    public void addEntity(MetaDataTableBean tableBean){

        entityMap.put(tableBean.getEntityName(), tableBean);

        Collection<String> alternateKeyList = tableBean.getAlternateKeyList();
        for (String attributeName : alternateKeyList) {
            alternatePKMap.put(tableBean.getEntityName() + "." + attributeName, attributeName);
        }

        Collection<String> fkLateResolveList = tableBean.getFkLateResolveList();
        for (String attributeName : fkLateResolveList) {
            fkResolveAfterCommitMap.put(tableBean.getEntityName() + "." + attributeName, attributeName);
        }

    }

    public boolean isAlternateKey(String entityName, String attributeName){

        String value = alternatePKMap.get(entityName + "." + attributeName);
        if (value == null) {
            return false;
        }

        return true;

    }

    public boolean isResolveAfterCommit(String entityName, String relationship){

        String value = fkResolveAfterCommitMap.get(entityName + "." + relationship);
        if (value == null) {
            return false;
        }

        return true;
    }

    public Collection<MetaDataTableBean> getExportSequence () {
        return entityMap.values();
    }
}

package com.avoka.core.xml.export;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.util.PropertyComparator;

public class ExportTableBean{

    private String  tableName;

    // Controls what happens during import. If true will search for a existing record
    private boolean findFlag;

    // During import controls if existing records should be updated.
    private boolean updateFlag;

    // Is this table used in the Prod Database
    private boolean productionTableFlag;

    private Map     rowMap = new Hashtable();

    // A list of child dependent tables that need to be cleared.

    public ExportTableBean(String tableName,boolean findFlag,boolean updateFlag){
        this.tableName = tableName;
        this.findFlag = findFlag;
        this.updateFlag = updateFlag;
    }

    public String getTableName(){
        return tableName;
    }

    public void setTableName(String tableName){
        this.tableName = tableName;
    }

    public void addRow(BaseEntity entity){

        // This will add new rows or replace if it already exists
        rowMap.put(entity.getId(), entity);
    }

    public int rowSize(){
        return rowMap.size();
    }

    public Iterator iterator(){
        List<BaseEntity> values = new ArrayList<BaseEntity>();
        values.addAll(rowMap.values());
        Collections.sort(values, new PropertyComparator("id"));

        return values.iterator();
    }

    public Collection<BaseEntity> getRowCollection(){
        List<BaseEntity> values = new ArrayList<BaseEntity>();
        values.addAll(rowMap.values());
        Collections.sort(values, new PropertyComparator("id"));
        return values;
    }

    public boolean findRow(BaseEntity entity){
        BaseEntity baseEntity = (BaseEntity) rowMap.get(entity.getId());
        if (baseEntity == null) {
            return false;
        }
        return true;
    }

    public boolean isFindFlag(){
        return findFlag;
    }

    public void setFindFlag(boolean findFlag){
        this.findFlag = findFlag;
    }

    public boolean isUpdateFlag(){
        return updateFlag;
    }

    public String getFindFlag(){
        if (findFlag) {
            return "1";
        }
        return "0";
    }

    public String getUpdateFlag(){
        if (updateFlag) {
            return "1";
        }
        return "0";
    }

    public String getProductionTableFlag(){
        if (productionTableFlag) {
            return "1";
        }
        return "0";
    }

    public void setUpdateFlag(boolean updateFlag){
        this.updateFlag = updateFlag;
    }

    public boolean isProductionTableFlag(){
        return productionTableFlag;
    }

    public void setProductionTableFlag(boolean productionTableFlag){
        this.productionTableFlag = productionTableFlag;
    }

}

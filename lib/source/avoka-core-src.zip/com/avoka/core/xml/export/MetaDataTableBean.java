package com.avoka.core.xml.export;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.map.ObjEntity;
import org.apache.commons.lang.Validate;

public class MetaDataTableBean {

    private final ObjEntity     objEntity;
    private final boolean         productionTableFlag;
    private final boolean         cacheRowFlag;

    // Signifies that an entity is a child object with only a single parent.
    private boolean             dependantEntityFlag;

    private Map<String, String> alternateKeyList    = new HashMap<String, String> ();
    private Map<String, String> fkLateReolveMap     = new HashMap<String, String>();
    private ArrayList<String>   dependantEntityList = new ArrayList();

    @SuppressWarnings("deprecation")
    public MetaDataTableBean(Class aClass, boolean productionTableFlag, boolean cacheRowFlag) {
        Validate.notNull(aClass, "Null aClass parameter");

        this.objEntity = DataContext.getThreadDataContext().getEntityResolver().lookupObjEntity(aClass);
        this.productionTableFlag = productionTableFlag;
        this.cacheRowFlag = cacheRowFlag;
    }

    public void addAlternateKey(String attributeName){
        alternateKeyList.put( attributeName, attributeName);
    }

    public void addLateResolveFK(String attributeName){
        fkLateReolveMap.put(attributeName, attributeName);
    }

    /**
     * This will enabled all these children to be replaced during import.
     *
     * @param attributeName
     */
    public void addDependantEntity(String attributeName){
        dependantEntityList.add(attributeName);
    }

    public ObjEntity getObjectEntity(){
        return objEntity;
    }

    public String getEntityName(){
        return objEntity.getName();
    }

    public Collection<String> getAlternateKeyList(){
        return alternateKeyList.values();
    }

    public Collection<String> getFkLateResolveList(){
        return fkLateReolveMap.values();
    }

    public boolean isDependantEntityFlag(){
        return dependantEntityFlag;
    }

    public void setDependantEntityFlag(boolean dependantEntityFlag){
        this.dependantEntityFlag = dependantEntityFlag;
    }

    public boolean isProductionTableFlag(){
        return productionTableFlag;
    }

    public ArrayList<String> getDependantEntityList(){
        return dependantEntityList;
    }

    public boolean isCacheRowFlag(){
        return cacheRowFlag;
    }

}

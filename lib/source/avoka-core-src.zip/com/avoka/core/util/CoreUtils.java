/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.core.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Provides FC core utility methods.
 * <p/>
 * Many of these methods are derrived from the Click Framework
 * <tt>ClickUtils</tt> class.
 *
 * @author medgar@avoka.com
 */
public class CoreUtils implements Serializable {

    private static final long serialVersionUID = -6024070399983406946L;

    private static final StringEncrypter ENCRYPTER
        = new StringEncrypter(String.valueOf(serialVersionUID));

    /** Hexidecimal characters for MD5 encoding. */
    private static final char[] HEXADECIMAL = { '0', '1', '2', '3', '4', '5',
        '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

    /**
     * Close the given input stream and ignore any exceptions thrown.
     *
     * @param stream the input stream to close.
     */
    public static void close(InputStream stream) {
        if (stream != null) {
            try {
                stream.close();
            } catch (IOException ex) {
                // Ignore.
            }
        }
    }

    /**
     * Close the given output stream and ignore any exceptions thrown.
     *
     * @param stream the output stream to close.
     */
    public static void close(OutputStream stream) {
        if (stream != null) {
            try {
                stream.close();
            } catch (IOException ex) {
                // Ignore.
            }
        }
    }

    /**
     * Close the given reader and ignore any exceptions thrown.
     *
     * @param reader the reader to close.
     */
    public static void close(Reader reader) {
        if (reader != null) {
            try {
                reader.close();
            } catch (IOException ioe) {
                // Ignore
            }
        }
    }

    /**
     * Return an encoded version of the String value. The value will be
     * serialized and ZLib compressed.
     *
     * @param value the string value to encode
     * @return a serialized and compressed byte array
     * @throws IOException if an I/O error occurs
     * @throws IllegalArgumentException if the value parameter is null
     */
    public static byte[] encodeStringAsBytes(String value) {
        if (value == null) {
            throw new IllegalArgumentException("null value parameter");
        }

        ByteArrayOutputStream bos = null;
        GZIPOutputStream gos = null;
        ObjectOutputStream oos = null;

        try {
            bos = new ByteArrayOutputStream();
            gos = new GZIPOutputStream(bos);
            oos = new ObjectOutputStream(gos);

            oos.writeObject(value);
            oos.close();

            return bos.toByteArray();

        } catch (IOException ioe) {
            throw new RuntimeException(ioe);

        } finally {
            close(oos);
            close(gos);
            close(bos);
        }
    }

    /**
     * Return an string from the {@link #encode(String)} byte array.
     *
     * @param byteData the encoded string byte data
     * @return an String value from the encoded byte data
     */
    public static String decodeBytesAsString(byte[] byteData) {

        Validate.notNull(byteData, "Null byteData parameter");

        ByteArrayInputStream bis = null;
        GZIPInputStream gis = null;
        ObjectInputStream ois = null;
        try {
            bis = new ByteArrayInputStream(byteData);
            gis = new GZIPInputStream(bis);
            ois = new ObjectInputStream(gis);

            return ois.readObject().toString();

        } catch (ClassNotFoundException cnfe) {
            throw new RuntimeException(cnfe);

        } catch (IOException ioe) {
            throw new RuntimeException(ioe);

        } finally {
            close(ois);
            close(gis);
            close(bis);
        }
    }

    /**
     * This does the same as DOMUtil.parseDocumentFromString()
     *
     * @param xml the XML string content
     * @param namespaceAware
     * @param validating
     * @return a new XML Document fromt he given XML string
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    public Document parseDocumentFromString(String xml,
            boolean namespaceAware, boolean validating)
            throws ParserConfigurationException, SAXException {


        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(namespaceAware);
        factory.setValidating(validating);

        DocumentBuilder builder = factory.newDocumentBuilder();
        builder.setErrorHandler(new ErrorHandler() {

            public void fatalError(SAXParseException spe) {
                spe.printStackTrace();
            }

            public void error(SAXParseException spe) {
                spe.printStackTrace();
            }

            public void warning(SAXParseException spe) {
                spe.printStackTrace();
            }
        });

        try {
            return builder.parse(new InputSource(new StringReader(xml)));

        } catch (SAXException e) {
            e.printStackTrace();
            throw new RuntimeException(e);

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     * Return a Base 64 encoded string from the given byte array.
     *
     * @param byteData the byte array data to encode
     * @return a base64 encoded byte array
     */
    public static String toBase64(byte[] byteData) {
        Base64 base64 = new Base64();

        byte[] encodedArray = base64.encode(byteData);

        return new String(encodedArray);
    }

    /**
     * Return an 32 char MD5 encoded string from the given plain text.
     * The returned value is MD5 hash compatible with Tomcat catalina Realm.
     * <p/>
     * Adapted from <tt>org.apache.catalina.util.MD5Encoder</tt>
     *
     * @param plaintext the plain text value to encodet
     * @return encoded MD5 string
     */
    public static String toMD5Hash(String plaintext) {
        if (plaintext == null) {
            throw new IllegalArgumentException("Null plaintext parameter");
        }
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");

            md.update(plaintext.getBytes("UTF-8"));

            byte[] binaryData = md.digest();

            char[] buffer = new char[32];

            for (int i = 0; i < 16; i++) {
                int low = (int) (binaryData[i] & 0x0f);
                int high = (int) ((binaryData[i] & 0xf0) >> 4);
                buffer[i * 2] = HEXADECIMAL[high];
                buffer[i * 2 + 1] = HEXADECIMAL[low];
            }

            return new String(buffer);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Return an 32 char MD5 encoded string from the given byte array.
     * The returned value is MD5 hash compatible with Tomcat catalina Realm.
     * <p/>
     * Adapted from <tt>org.apache.catalina.util.MD5Encoder</tt>
     *
     * @param plaintext the plain text value to encodet
     * @return encoded MD5 string
     */
    public static String toMD5Hash(byte[] bytes) {
        if (bytes == null) {
            throw new IllegalArgumentException("Null bytes parameter");
        }
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");

            md.update(bytes);

            byte[] binaryData = md.digest();

            char[] buffer = new char[32];

            for (int i = 0; i < 16; i++) {
                int low = (int) (binaryData[i] & 0x0f);
                int high = (int) ((binaryData[i] & 0xf0) >> 4);
                buffer[i * 2] = HEXADECIMAL[high];
                buffer[i * 2 + 1] = HEXADECIMAL[low];
            }

            return new String(buffer);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String createAltKey() {
        return toMD5Hash(UUID.randomUUID().toString());
    }

//    public static String toSHA256Hash(String plaintext) {
//
//        if (plaintext == null) {
//            throw new IllegalArgumentException("Null plaintext parameter");
//        }
//
//        try {
//            return toSHA256Hash(plaintext.getBytes("UTF-8"));
//
//        } catch (UnsupportedEncodingException uee) {
//            throw new RuntimeException(uee);
//        }
//    }
//
//    public static String toSHA256Hash(byte[] bytes) {
//        if (bytes == null) {
//            throw new IllegalArgumentException("Null bytes parameter");
//        }
//        try {
//            MessageDigest md = MessageDigest.getInstance("SHA-256");
//
//            md.update(bytes);
//
//            byte[] binaryData = md.digest();
//
//            char[] buffer = new char[64];
//
//            for (int i = 0; i < 32; i++) {
//                int low = (int) (binaryData[i] & 0x0f);
//                int high = (int) ((binaryData[i] & 0xf0) >> 4);
//                buffer[i * 2] = HEXADECIMAL[high];
//                buffer[i * 2 + 1] = HEXADECIMAL[low];
//            }
//
//            return new String(buffer);
//
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }

    /**
     * Return the value string limited to maxlength characters. If the string
     * gets curtailed, "..." is appended to it.
     * <p/>
     * Adapted from Velocity Tools Formatter.
     *
     * @param value the string value to limit the length of
     * @param maxlength the maximum string length
     * @return a length limited string
     */
    public static String limitLength(String value, int maxlength) {
        return limitLength(value, maxlength, "...");
    }

    /**
     * Return the value string limited to maxlength characters. If the string
     * gets curtailed and the suffix parameter is appended to it.
     * <p/>
     * Adapted from Velocity Tools Formatter.
     *
     * @param value the string value to limit the length of
     * @param maxlength the maximum string length
     * @param suffix the suffix to append to the length limited string
     * @return a length limited string
     */
    public static String limitLength(String value, int maxlength, String suffix) {
        if (value != null) {
            String ret = value;
            if (value.length() > maxlength) {
                ret = value.substring(0, maxlength - suffix.length()) + suffix;
            }
            return ret;

        } else {
            return null;
        }
    }

    /**
     * Encrypt the given plain text value
     *
     * @param plaintext the plain text value to encrypt
     * @return the cypher text for the given plain text value.
     */
    public static String encrypt(String plaintext) {
        if (plaintext == null) {
            throw new IllegalArgumentException("Null plaintext param");
        }
        return ENCRYPTER.encrypt(plaintext);
    }

    /**
     * Decrypt the given cyphertext value
     *
     * @param cyphertext the cyper text value to decrypt
     * @return the cypher text for the given plain text value.
     */
    public static String decrypt(String cyphertext) {
        if (cyphertext == null) {
            throw new IllegalArgumentException("Null cyphertext param");
        }
        return ENCRYPTER.decrypt(cyphertext);
    }    /**


     * Extract the file name from a path (e.g. returning "file.txt" for "C:\data\txt\file.txt").
     * Treats "\" and "/" as separators.
     *
     * @param path
     * @return the file name or null if the path was null
     */
    public static String getFileName(final String path) {
        if (path != null) {
            if (path.indexOf("\\") >= 0) {
                // path has \ separator
                return path.substring(path.lastIndexOf("\\") + 1);
            }
            else if (path.indexOf("/") >= 0) {
                // path has / separator
                return path.substring(path.lastIndexOf("/") + 1);
            }
            else {
                // no path separator recognised
                return path;
            }
        }
        return null;
    }

}

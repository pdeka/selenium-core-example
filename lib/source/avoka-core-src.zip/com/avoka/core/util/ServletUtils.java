package com.avoka.core.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.zip.GZIPOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.Validate;

/**
 * Provides Servlet Utility methods.
 *
 * @author medgar
 */
public class ServletUtils {

    /** The using objectTag request parameter name. */
    public static final String PARAM_OBJECT_TAG = "objectTag";

    /** The default PDF open window URL parameters (show toolbar, show navpanes, show scrollbar). */
    public static final String DEFAULT_PDF_OPEN_PARAMS = "#toolbar=1&navpanes=1&scrollbar=1";

    /** The decoded user agent browser types. */
    public enum BrowserType { IE, FF, OTHER };

    /**
     * Return the user agent header (browser string).
     *
     * @param request the servlet request
     * @return the user agent header
     */
    public static String getUserAgent(HttpServletRequest request) {

        Validate.notNull(request);

        return request.getHeader("User-Agent");
    }

    /**
     * Return the browser type [IE, FF, OTHER].
     *
     * @param request the servlet request
     * @return the browser type [IE, FF, OTHER]
     */
    public static BrowserType getBrowserType(HttpServletRequest request) {

        Validate.notNull(request);

        String useragent = request.getHeader("User-Agent").toLowerCase();

        if (useragent.contains("msie")) {
            return BrowserType.IE;

        } else if (useragent.contains("firefox")) {
            return BrowserType.FF;

        } else {
            return BrowserType.OTHER;
        }
    }

    /**
     * Return true if a HTML object tag double request for a PDF form which should be ignored.
     *
     * @param request the servlet request
     * @return
     */
    public static boolean isDoubleObjectTagRequest(HttpServletRequest request) {

        Validate.notNull(request);

        if ("post".equalsIgnoreCase(request.getMethod())) {
            return false;
        }

        if ("true".equalsIgnoreCase(request.getParameter(PARAM_OBJECT_TAG))) {
            String key = request.getQueryString();

            HttpSession session = request.getSession();

            // Test whether request has already been made
            Object value = session.getAttribute(key);

            // If first request
            if (value == null) {
                session.setAttribute(key, key);

                // If IE then ignore first request
                if (getBrowserType(request) == BrowserType.IE) {
                    return true;

                } else {
                    return false;
                }

            } else {
                session.setAttribute(key, key);

                // If FF then ignore second request
                if (getBrowserType(request) == BrowserType.FF) {
                    return true;

                } else {
                    return false;
                }
            }

        } else {
            return false;
        }
    }

    public static boolean acceptsGzipEncoding(HttpServletRequest request) {
        Enumeration e = request.getHeaders("Accept-Encoding");

        while (e.hasMoreElements()) {
            String name = (String) e.nextElement();
            if (name.indexOf("gzip") != -1) {
                return true;
            }
        }

        return false;
    }

    public static void setContentDisposition(HttpServletRequest request, HttpServletResponse response,
            String contentType, String filename, boolean saveAsAttachment) {

        Validate.notNull(request);
        Validate.notNull(response);
        Validate.notNull(contentType);
        Validate.notNull(filename);

        if (saveAsAttachment && contentType.toLowerCase().contains("pdf")) {
            response.setHeader("Content-Disposition", "attachment;filename=" + filename);

        } else {
            // Causes browser issues with IE6.0
            String userAgent = request.getHeader("user-agent");
            if (userAgent != null) {
                if (!userAgent.contains("MSIE 6")  && contentType.toLowerCase().contains("pdf")) {
                    response.setHeader("Content-Disposition", "inline;filename=" + filename);
                }
            }
        }
    }

    public static void setNoCacheHeaders(HttpServletRequest request, HttpServletResponse response) {

        Validate.notNull(request);
        Validate.notNull(response);

        // Must disable caching to enable IE to render form over HTTPS
        // http://support.microsoft.com/default.aspx?scid=kb;en-us;316431
        if (getBrowserType(request) == BrowserType.IE) {
            response.setHeader("Pragma", "");
            response.setHeader("Cache-control", "");

        } else {
            response.setHeader("Pragma", "no-cache");
            response.setHeader("Cache-control", "no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
        }
    }

    public static void setCacheHeaders(HttpServletRequest request, HttpServletResponse response, int durationSecs) {

        Validate.notNull(request);
        Validate.notNull(response);

        String value = MessageFormat.format("max-age={0}, s-maxage={0}, public", durationSecs);
        response.setHeader("Cache-control", value);
    }

    public static long renderByteArray(HttpServletRequest request, HttpServletResponse response, byte[] byteArray)
            throws IOException {

        return renderByteArray(request, response, byteArray, true);
    }

    public static long renderByteArray(HttpServletRequest request, HttpServletResponse response, byte[] byteArray,
            boolean doCompress) throws IOException {

        Validate.notNull(request);
        Validate.notNull(response);
        Validate.notNull(byteArray);

        if (!acceptsGzipEncoding(request)) {
            doCompress = false;
        }

        if (doCompress) {
            response.setHeader("Content-Encoding", "gzip");

            ByteArrayOutputStream bos = null;
            GZIPOutputStream gos = null;
            try {
                bos = new ByteArrayOutputStream();
                gos = new GZIPOutputStream(bos);
                gos.write(byteArray);

            } finally {
                IOUtils.closeQuietly(gos);
                IOUtils.closeQuietly(bos);
            }

            byteArray = bos.toByteArray();
        }

        response.setHeader("Content-Length", String.valueOf(byteArray.length));

        // Write the form to the browser
        OutputStream outputStream = null;
        try {
            outputStream = response.getOutputStream();
            outputStream.write(byteArray);
            outputStream.flush();

        } finally {
            IOUtils.closeQuietly(outputStream);
        }

        return byteArray.length;
    }
}

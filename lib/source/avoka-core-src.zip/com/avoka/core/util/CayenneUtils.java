/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.core.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.cayenne.CayenneRuntimeException;
import org.apache.cayenne.DataObject;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.ObjectId;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.DataNode;
import org.apache.cayenne.conf.Configuration;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.map.DbAttribute;
import org.apache.cayenne.map.DbEntity;
import org.apache.cayenne.map.ObjEntity;
import org.apache.cayenne.map.ObjRelationship;
import org.apache.cayenne.query.ObjectIdQuery;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.reflect.ClassDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.entity.BaseEntity;

/**
 * Provides Cayenne utility methods.
 *
 * @author Malcolm Edgar
 */
public class CayenneUtils {

    /**
     * Create a SelectQuery for the given data object class and id primary key
     * value.
     *
     * @param dataObjectClass the data object class
     * @param id the data object primary key value
     * @return the SelectQuery for the given data object class and primary key id
     */
    public static SelectQuery createQuery(Class dataObjectClass, Object id) {
        if (dataObjectClass == null) {
            throw new IllegalArgumentException("Null dataObjectClass parameter.");
        }
        if (id == null) {
            throw new IllegalArgumentException("Null id parameter.");
        }

        String pkName = getPkName(dataObjectClass);

        Expression qual = ExpressionFactory.matchDbExp(pkName, id);

        return new SelectQuery(dataObjectClass, qual);
    }

    /**
     * Create a SelectQuery from the given data object.
     *
     * @param dataObjectClass the data object class
     * @return the SelectQuery for the given data object
     */
    public static SelectQuery createQuery(DataObject dataObject) {
        if (dataObject == null) {
            throw new IllegalArgumentException("Null dataObject parameter.");
        }

        String pkName = getPkName(dataObject.getClass());

        Object id = DataObjectUtils.pkForObject(dataObject);

        Expression qual = ExpressionFactory.matchDbExp(pkName, id);

        return new SelectQuery(dataObject.getClass(), qual);
    }

    /**
     * Create a new ObjectId for the given data object class and primary key id.
     *
     * @param dataObjectClass the data object class
     * @param id the data object primary key (id) value
     * @return the ObjectId for the given data object class and id
     */
    public static ObjectId createObjectId(Class dataObjectClass, Object id) {
        if (id == null) {
            throw new IllegalArgumentException("Null id parameter.");
        }

        String entityName = getEntityName(dataObjectClass);

        String pkName = getPkName(dataObjectClass);

        return new ObjectId(entityName, pkName, id);
    }

    /**
     * Return the object entity name for the given data object class.
     *
     * @param dataObjectClass the data object class
     * @return the object entity name
     */
    public static String getEntityName(Class dataObjectClass) {
        if (dataObjectClass == null) {
            throw new IllegalArgumentException("Null dataObjectClass parameter.");
        }

        ObjEntity objEntity =
            getDataContext().getEntityResolver().lookupObjEntity(dataObjectClass);



        if (objEntity == null) {
            throw new CayenneRuntimeException("Unmapped DataObject Class: "
                    + dataObjectClass.getName());
        }

        return objEntity.getName();
    }

    /**
     * Perform a database query returning the data object specified by the
     * class and the primary key. This method will perform a database query
     * and refresh the object cache.
     *
     * @param doClass the data object class to retrieve
     * @param id the data object primary key
     * @return the data object for the given class and id
     */
    public static DataObject getObjectForPK(Class doClass, Object id) {
        return getObjectForPK(doClass, id, true);
    }


    public static DataObject getObjectForPK(String entityName , Object id) {

        ClassDescriptor classDescriptor = getDataContext().getEntityResolver().getClassDescriptor(entityName);
        ObjEntity objEntity = classDescriptor.getEntity();

        String pkName = getPkName(objEntity);

        return getObjectForPK(id, true, objEntity, pkName);
    }

    /**
     * Perform a query returning the data object specified by the
     * class and the primary key value. If the refresh parameter is true a
     * database query will be performed, otherwise the a query against the
     * object cache will be performed first.
     *
     * @param doClass the data object class to retrieve
     * @param id the data object primary key
     * @param refresh the refresh the object cache mode
     * @return the data object for the given class and id
     */
    public static DataObject getObjectForPK(Class doClass, Object id, boolean refresh) {
        if (doClass == null) {
            throw new IllegalArgumentException("Null doClass parameter.");
        }

        if (id == null || (id instanceof String && id.toString().length() == 0)) {
            return null;
        }

        ObjEntity objEntity =
            getDataContext().getEntityResolver().lookupObjEntity(doClass);

        if (objEntity == null) {
            throw new CayenneRuntimeException("Unmapped DataObject Class: "
                    + doClass.getName());
        }

        String pkName = getPkName(doClass);

        return getObjectForPK(id, refresh, objEntity, pkName);
    }

    private static DataObject getObjectForPK(Object id, boolean refresh, ObjEntity objEntity, String pkName){
        ObjectId objectId = new ObjectId(objEntity.getName(), pkName, id);

        int refreshMode = (refresh) ? ObjectIdQuery.CACHE_REFRESH : ObjectIdQuery.CACHE;

        ObjectIdQuery objectIdQuery = new ObjectIdQuery(objectId, false, refreshMode);

        return (DataObject) DataObjectUtils.objectForQuery(getDataContext(), objectIdQuery);
    }

    /**
     * Return the database primary key column name for the given data object.
     *
     * @param dataObjectClass the class of the data object
     * @return the primary key column name
     */
    public static String getPkName(Class dataObjectClass) {
        if (dataObjectClass == null) {
            throw new IllegalArgumentException("Null dataObjectClass parameter.");
        }

        ObjEntity objEntity =
            getDataContext().getEntityResolver().lookupObjEntity(dataObjectClass);

        if (objEntity == null) {
            throw new CayenneRuntimeException("Unmapped DataObject Class: "
                    + dataObjectClass.getName());
        }

        return getPkName(objEntity);
    }

    @SuppressWarnings("deprecation")
    private static String getPkName(ObjEntity objEntity){
        DbEntity dbEntity = objEntity.getDbEntity();
        if (dbEntity == null) {
            throw new CayenneRuntimeException("No DbEntity for ObjEntity: "
                    + objEntity.getName());
        }

        List pkAttributes = dbEntity.getPrimaryKey();
        if (pkAttributes.size() != 1) {
            throw new CayenneRuntimeException("PK contains "
                    + pkAttributes.size()
                    + " columns, expected 1.");
        }

        DbAttribute attr = (DbAttribute) pkAttributes.get(0);

        return attr.getName();
    }

    /**
     * Return a pooled Cayenne connection for the shared configuration and the
     * first configured DataNode.
     *
     * @return a pooled SQL connection
     * @throws SQLException if a database connection could not be obtained
     */
    public static Connection getConnection() throws SQLException {
        DataDomain domain = Configuration.getSharedConfiguration().getDomain();

        DataNode node = (DataNode) domain.getDataNodes().iterator().next();

        return node.getDataSource().getConnection();
    }

    /**
     * Return a pooled Cayenne connection for the shared configuration and the
     * given DataNode name.
     *
     * @param a nodeName the name of the Cayenne node
     * @return a pooled SQL connection
     * @throws SQLException if a database connection could not be obtained
     */
    public static Connection getConnection(String nodeName) throws SQLException {
        if (nodeName == null) {
            throw new IllegalArgumentException("nodeName is null");
        }

        DataDomain domain = Configuration.getSharedConfiguration().getDomain();

        DataNode node = domain.getNode(nodeName);

        return node.getDataSource().getConnection();
    }

    /**
     * Perform a shallow clone of an entity, register it with the data context
     * and return the new entity.
     *
     * @param entity The entity to clone
     * @return the new entity
     */
    public static BaseEntity cloneEntity(BaseEntity entity){
        return cloneEntity(entity, null, null);
    }

    /**
     * Perform a deep clone of an entity, progressing only down the paths specified,
     * register it with the data context and return the new entity.
     * <br>
     * <b>Note:</b> This method only supports a single level of depth.
     *
     * @param entity The entity to clone
     * @param copyPaths The deep entity terminating paths to copy.
     *        These must be explicitly specified (wildcards not supported).
     *        If a clone path is multi-level (eg 'customers.address') then
     *        all levels in the path are cloned.
     * @param clonePaths The deep entity terminating paths to clone.
     *        These must be explicitly specified (wildcards not supported).
     *        If a clone path is multi-level (eg 'customers.address') then
     *        all levels in the path are cloned.
     * @return the new entity
     */
    public static BaseEntity cloneEntity(BaseEntity entity, String[] copyPaths, String[] clonePaths){
        // A path tree is used to avoid duplicate path problems.
        return cloneEntity(entity, "", copyPaths, getPathTree(clonePaths));
    }

    /**
     * Return the thread local DataContext.
     *
     * @return the thread local DataContext
     */
    @SuppressWarnings("deprecation")
    public static DataContext getDataContext() {
        try {
            return DataContext.getThreadDataContext();

        } catch (IllegalStateException ise) {
            DataContext dataContext = DataContext.createDataContext(false);
            DataContext.bindThreadDataContext(dataContext);

            Logger logger = LoggerFactory.getLogger(CayenneUtils.class);
            if (logger.isDebugEnabled()) {
                logger.debug("creating and binding DataContext to thread");
            }

            return dataContext;
        }
    }

    // -------------------------------------------------------- Private Methods

    @SuppressWarnings("deprecation")
    private static BaseEntity cloneEntity(
            BaseEntity entity, String currentPath,
            String[] copyPaths, Map cloneTree){

        // Initialise the clone entity
        BaseEntity clone = (BaseEntity)getDataContext().createAndRegisterNewObject(entity.getClass());
        String pkName = getPkName(entity.getClass());

        // Iterate all values
        for (Iterator valueIter = entity.getValuesMap().keySet().iterator(); valueIter.hasNext();) {
            String key = (String) valueIter.next();

            // Ignore primary key value
            if(key.equals(pkName)){
                continue;
            }

            Object value = entity.readProperty(key);

            // Do not copy unresolved faults
            if(value == null || value.getClass().getName().indexOf("DataContextFaults") >= 0){
                continue;
            }

            // Identify entities as different procedure required
            if(value instanceof BaseEntity){
                String fullPath = key;
                if(currentPath.length() > 0){
                    fullPath += currentPath + "." + fullPath;
                }

                if (copyPaths != null) {
                    // Search for a match in the explicit copy paths list
                    for(int p = 0; p < copyPaths.length; p++){
                        if(copyPaths[p].equals(fullPath)){

                            // If a match is found then setup the relationship
                            clone.setToOneTarget(key, (DataObject)value, true);
                            break;
                        }
                    }
                }

            } else {

                String fullPath = key;
                if(currentPath.length() > 0){
                    fullPath += currentPath + "." + fullPath;
                }

                if (value instanceof List) {
                    if (copyPaths != null) {
                        for(int p = 0; p < copyPaths.length; p++){
                            if(copyPaths[p].equals(fullPath)){

                                // If a match is found then setup the relationship
                                clone.writeProperty(key, value);
                                break;
                            }
                        }
                    }
                }
                else {
                    // Copy the value into the cloned entity
                    clone.writeProperty(key, value);
                }
            }
        }

        // Now perform a deep clone on the explicit clone paths provided
        if(cloneTree != null){

            for(Iterator pathIter = cloneTree.keySet().iterator(); pathIter.hasNext();){
                String property = (String)pathIter.next();
                Object propertyValue = entity.readProperty(property);

                // Full path is passed through in recursion for copyPath matching
                String fullPath = property;
                if(currentPath.length() > 0){
                    fullPath += currentPath + "." + fullPath;
                }

                // If the property value is an entity then we simply clone it
                if(propertyValue instanceof BaseEntity){

                    // Clone the child
                    BaseEntity childClone = cloneEntity((BaseEntity)propertyValue,
                             fullPath, copyPaths, (Map)cloneTree.get(property));

                    // Setup the relationship
                    clone.setToOneTarget(property, childClone, true);

                // Deal with collections separately, as parent child relationship
                } else if(propertyValue instanceof List){
                    List children = (List)propertyValue;

                    // Determine the reverse relationship
                    ObjRelationship rel = (ObjRelationship)getDataContext()
                            .getEntityResolver().lookupObjEntity(clone.getObjectId().getEntityName())
                            .getRelationship(property);
                    ObjRelationship revRel = rel.getReverseRelationship();

                    for(int c = 0; c < children.size(); c++){
                        Object child = children.get(c);

                        if(child instanceof BaseEntity){

                            // Clone the child
                            BaseEntity childClone = cloneEntity((BaseEntity)child,
                                     fullPath, copyPaths, (Map)cloneTree.get(property));

                            // Setup the relationship
                            childClone.setToOneTarget(revRel.getName(), clone, true);
                        }
                    }

                } else {
                    // Default to just writing the property value as is
                    clone.writeProperty(property, propertyValue);
                }
            }
        }
        return clone;
    }

    /**
     * Path tokenizer ripped from org.apache.cayenne.CayenneDataObject
     *
     * @param path The path to tokenize in dot notation (eg 'customers.addresses')
     * @return The tokens in the path (eg {'customers', 'addresses'})
     */
    private static final String[] tokenizePath(String path) {
        if (path == null) {
            throw new NullPointerException("Null property path.");
        }

        if (path.length() == 0) {
            throw new IllegalArgumentException("Empty property path.");
        }

        // take a shortcut for simple properties
        if (path.indexOf(".") < 0) {
            return new String[] {
                path
            };
        }

        StringTokenizer tokens = new StringTokenizer(path, ".");
        int length = tokens.countTokens();
        String[] tokenized = new String[length];
        for (int i = 0; i < length; i++) {
            tokenized[i] = tokens.nextToken();
        }

        return tokenized;
    }

    private static Map getPathTree(String[] paths){
        HashMap map = new HashMap();
        if(paths == null || paths.length == 0){
            return map;
        }
        for(int i = 0; i < paths.length; i++){
            if(paths[i] != null && paths[i].length() > 0){
                Map tokenMap = map;
                String[] tokens = tokenizePath(paths[i]);
                for(int t = 0; t < tokens.length; t++){
                    Map tempMap = (Map)tokenMap.get(tokens[t]);
                    if(tempMap == null){
                        tempMap = new HashMap();
                        tokenMap.put(tokens[t], tempMap);
                    }
                    tokenMap = tempMap;
                }
            }
        }
        return map;
    }

}

/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka
 * Technologies ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only as may be permitted in writing by
 * Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited.
 * No part of this work may be produced or transmitted in any form by any
 * means, electronic or mechanical, including photocopying and recording,
 * or by any information storage or retrieval system accept as may be permitted
 * in writing by Avoka Technologies Pty Limited.
 *
 * Created on Mar 13, 2006
 * Created By pcopeland
 */
package com.avoka.core.util;

import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;

/**
 * Provides XML untility methods.
 *
 * @author pcopeland
 */
public class XmlUtils {

    /**
     * Return the string representation of the given XML node.
     *
     * @param node the XML node
     * @return the string representation of the given XML node
     */
    public static String toString(Node node) {
        try {
            Source source = new DOMSource(node);

            StringWriter stringWriter = new StringWriter(1028 * 50);
            Result result = new StreamResult(stringWriter);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(source, result);

            return stringWriter.getBuffer().toString();

        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Return the formatted string representation of the given XML node.
     *
     * @param node the XML node
     * @return the string representation of the given XML node
     */
    public static String toFormattedString(Node node) {
        try {
            Source source = new DOMSource(node);

            StringWriter stringWriter = new StringWriter(1028 * 50);
            Result result = new StreamResult(stringWriter);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            transformer.transform(source, result);

            return stringWriter.getBuffer().toString();

        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This does the same as DOMUtil.parseDocumentFromString()
     *
     * @param aXML
     * @param aNamespaceAware
     * @param aValidating
     * @return
     * @throws ParserConfigurationException
     * @throws RuntimeException if an error occurs
     */
    public static Document parseDocumentFromString(String aXML, boolean aNamespaceAware, boolean aValidating) {

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(aNamespaceAware);
        factory.setValidating(aValidating);

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();

            builder.setErrorHandler(new ErrorHandler() {
                public void fatalError(SAXParseException spe) {
                    spe.printStackTrace();
                }

                public void error(SAXParseException spe) {
                    spe.printStackTrace();
                }

                public void warning(SAXParseException spe) {
                    spe.printStackTrace();
                }
            });

            Document document = builder.parse(new InputSource(new StringReader(aXML)));

            return document;

        } catch (Exception e) {
            Logger logger = LoggerFactory.getLogger(XmlUtils.class);
            logger.error("Error parsing document. Contents: " + aXML, e);
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static Document parseDocumentFromString(String aXML) {

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(false);
        factory.setValidating(false);

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();

            builder.setErrorHandler(new ErrorHandler() {
                public void fatalError(SAXParseException spe) {
                    spe.printStackTrace();
                }

                public void error(SAXParseException spe) {
                    spe.printStackTrace();
                }

                public void warning(SAXParseException spe) {
                    spe.printStackTrace();
                }
            });

            Document document = builder.parse(new InputSource(new StringReader(aXML)));

            return document;

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static Document parseDocumentFromString(String aXML, ErrorHandler eh) {

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(false);
        factory.setValidating(false);

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();

            if (eh != null) {
                builder.setErrorHandler(eh);
            }

            Document document = builder.parse(new InputSource(new StringReader(aXML)));

            return document;

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static Document buildDocument(InputStream inputStream, EntityResolver entityResolver) {
        try {
            DocumentBuilderFactory factory =
                DocumentBuilderFactory.newInstance();

            DocumentBuilder builder = factory.newDocumentBuilder();

            if (entityResolver != null) {
                builder.setEntityResolver(entityResolver);
            }

            return builder.parse(inputStream);

        } catch (Exception ex) {
            throw new RuntimeException("Error parsing XML", ex);
        }
    }

    public static Document buildDocument(InputStream inputStream) {
        return buildDocument(inputStream, null);
    }

    public static List<Element> getChildren(Element element, String name) {
        List list = new ArrayList();
        NodeList nodeList = element.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node instanceof Element) {
                if (node.getNodeName().equals(name)) {
                    list.add(node);
                }
            }
        }
        return list;
    }

    public static Element getChild(Element element, String name) {
        NodeList nodeList = element.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node instanceof Element) {
                if (node.getNodeName().equals(name)) {
                    return (Element) node;
                }
            }
        }
        return null;
    }

    public static Element getLastChild(Element element, String name) {
        NodeList nodeList = element.getChildNodes();
        for (int i = nodeList.getLength() - 1; i >= 0; i--) {
            Node node = nodeList.item(i);
            if (node instanceof Element) {
                if (node.getNodeName().equals(name)) {
                    return (Element) node;
                }
            }
        }
        return null;
    }

    public static String getChildValue(Element parent, String childName) {
        Element child = getChild(parent, childName);
        if (child != null) {
            Node node = child.getFirstChild();
            if (node != null) {
                return node.getNodeValue();
            }
        }
        return null;
    }

    /**
     * Return the first document node value for the given XPath expression.
     *
     * @param document the XML document
     * @param expression the XPath expression
     * @return the first document node value for the given XPath expression
     */
    public static String getXPathValue(Document document, String expression) {
        Validate.notNull(document, "Null document parameter");
        Validate.notNull(document, "Null expression parameter");

        try {
            XPathFactory factory = XPathFactory.newInstance();
            XPath xpath = factory.newXPath();
            XPathExpression expr = xpath.compile(expression);

            Object result = expr.evaluate(document, XPathConstants.NODESET);

            NodeList nodes = (NodeList) result;
            if (nodes.getLength() > 0) {
                return nodes.item(0).getNodeValue();

            } else {
                return null;
            }

        } catch (XPathExpressionException xee) {
            String msg = "XPath expression error for expression: " + expression;
            throw new RuntimeException(msg, xee);
        }
    }

    /**
     * Return the first document node value for the given XPath expression.
     *
     * @param document the XML document
     * @param expression the XPath expression
     * @return the first document node value for the given XPath expression
     */
    public static Element getXPathElement(Document document, String expression) {
        Validate.notNull(document, "Null document parameter");
        Validate.notNull(document, "Null expression parameter");

        try {
            XPathFactory factory = XPathFactory.newInstance();
            XPath xpath = factory.newXPath();
            XPathExpression expr = xpath.compile(expression);

            Object result = expr.evaluate(document, XPathConstants.NODESET);

            NodeList nodes = (NodeList) result;
            if (nodes.getLength() > 0) {
                return (Element) nodes.item(0);

            } else {
                return null;
            }

        } catch (XPathExpressionException xee) {
            String msg = "XPath expression error for expression: " + expression;
            throw new RuntimeException(msg, xee);
        }
    }

    public static Element getOrCreateChild(Element parent, String childName) {
        Validate.notNull(parent, "Null parent parameter");
        Validate.notNull(childName, "Null childName parameter");
        Validate.notNull(parent.getOwnerDocument(), "Null parent.getOwnerDocument()");

        Element childElement = getChild(parent, childName);

        if (childElement == null) {
            childElement = parent.getOwnerDocument().createElement(childName);
            parent.appendChild(childElement);
        }

        return childElement;
    }

    public static void setChildElementValue(Element parent, String childName, String value) {
        Validate.notNull(parent, "Null parent parameter");
        Validate.notNull(childName, "Null childName parameter");

        Element childElement = getOrCreateChild(parent, childName);

        parent.getOwnerDocument();

        if (value != null) {
            Text textNode = parent.getOwnerDocument().createTextNode(String.valueOf(value));

            childElement.appendChild(textNode);
        }
    }

    public static Element createChildElement(Element parent, String childName) {
        Validate.notNull(parent, "Null parent parameter");
        Validate.notNull(childName, "Null childName parameter");

        Element childElement = parent.getOwnerDocument().createElement(childName);

        parent.appendChild(childElement);

        return childElement;
    }

//
//    public static void setChildNodeValue(Element element, String name, String value) {
//        Validate.notNull(element, "Null element param");
//        Validate.notNull(name, "Null name param");
//
//        if (value == null) {
//            value = "";
//        }
//
//        Element child = getChild(element, name);
//        if (child != null) {
//            if (child instanceof Node) {
//                ((Node) child).set
//            }
//
//        } else {
//            // TODO: create child element
//            throw new RuntimeException("No child element named: " + name + " for element: " + element);
//        }
//    }

}

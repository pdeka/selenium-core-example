package com.avoka.core.util;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;

public class HSSFUtils {

    public static boolean isEmptyCell(HSSFRow row, int index) {
        HSSFCell cell = row.getCell((short) index);

        if (cell == null || StringUtils.isBlank(cell.toString())) {
            return true;
        } else {
            return false;
        }
    }

    public static String getCellValue(HSSFRow row, int index) {
        HSSFCell cell = row.getCell((short) index);

        if (cell == null) {
            return null;
        }

        if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
            String value = cell.toString();
            if (value.endsWith(".0")) {
                value = value.substring(0, value.indexOf(".0"));
            }
            return value;
        }

        return cell.toString();
    }
}

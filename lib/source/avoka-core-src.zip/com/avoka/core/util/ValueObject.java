/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.core.util;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Provides a base Value Object (VO) for all application value object to extend.
 * <p/>
 * The ValueObject class support Flex serialization and deserialization of object
 * graphs, providing an intermediary between Cayenne DataObjects and Flex
 * ActionScript objects.
 * <p/>
 * To convert between ValueObject and Cayenne DataObjects use the
 * {@link com.avoka.core.flex.ObjectConverter} utility.
 *
 * @see com.avoka.core.flex.ObjectConverter
 *
 * @author Malcolm Edgar
 */
public class ValueObject {

    /** The object primary key. */
    private Long id;

    /** Flag indicating whether the object has been deleted. */
    private boolean deleted;

    // --------------------------------------------------------- Public Methods

    /**
     * Return true if the object has been deleted.
     *
     * @return true if the object has been deleted
     */
    public boolean getDeleted() {
        return deleted;
    }

    /**
     * Set whether the object has been deleted.
     *
     * @param delete the flag to indicate whether the object has been deleted
     */
    public void setDeleted(boolean delete) {
        this.deleted = delete;
    }

    /**
     * Return the primary key of the object
     *
     * @return the primary key of the object
     */
    public Long getId() {
        return id;
    }

    /**
     * Set the primary key of the object
     *
     * @param id the the primary key of the object
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Return true if the object is new, and has not been persisted.
     *
     * @return true if the object is new
     */
    public boolean isNew() {
        return (id == null || id.longValue() == 0);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}

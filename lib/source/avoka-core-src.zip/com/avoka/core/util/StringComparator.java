package com.avoka.core.util;

import java.util.Comparator;
import java.util.StringTokenizer;

import org.apache.commons.lang.math.NumberUtils;

@SuppressWarnings("unchecked")
public class StringComparator implements Comparator {

    int ascendingSort = 1;

    public StringComparator() {
    }

    public StringComparator(boolean ascending) {
        this.ascendingSort = ascending ? 1 : -1;
    }

    public int compare(Object value1, Object value2) {

        if (value1 instanceof Comparable && value2 instanceof Comparable) {

            if (value1 instanceof String || value2 instanceof String) {
                return stringCompare(value1, value2) * ascendingSort;

            } else {

                return ((Comparable) value1).compareTo(value2) * ascendingSort;
            }

        } else if (value1 != null && value2 != null) {

            return value1.toString().compareToIgnoreCase(value2.toString())
                    * ascendingSort;

        } else if (value1 != null && value2 == null) {

            return +1 * ascendingSort;

        } else if (value1 == null && value2 != null) {

            return -1 * ascendingSort;

        } else {
            return 0;
        }
    }

    protected int stringCompare(Object value1, Object value2) {
        String string1 = value1.toString().trim();
        String string2 = value2.toString().trim();

        StringTokenizer st1 = new StringTokenizer(string1);
        StringTokenizer st2 = new StringTokenizer(string2);

        String token1 = null;
        String token2 = null;

        while (st1.hasMoreTokens()) {
            token1 = st1.nextToken();

            if (st2.hasMoreTokens()) {
                token2 = st2.nextToken();

                int comp = 0;

                if (useNumericSort(token1, token2)) {
                    comp = numericCompare(token1, token2);

                } else {
                    comp = token1.compareToIgnoreCase(token2);
                }

                if (comp != 0) {
                    return comp;
                }

            } else {
                return -1;
            }
        }

        return 0;
    }

    /**
     * Return true if a numeric sort should be used.
     *
     * @param value1 the first value to test
     * @param value2 the second value to test
     * @return true if a numeric sort should be used
     */
    protected boolean useNumericSort(String value1, String value2) {
        return NumberUtils.isDigits(value1) && NumberUtils.isDigits(value2);
    }

    /**
     * Perform a numeric compare on the given string values.
     *
     * @param string1 the first string value to compare
     * @param string2 the second string value to compare
     * @return the numeric comparison result
     */
    protected int numericCompare(String string1, String string2) {
        if (string1.length() > 0 && string2.length() > 0) {
            Double double1 = Double.valueOf(string1);
            Double double2 = Double.valueOf(string2);

            return double1.compareTo(double2);

        } else if (string1.length() > 0) {
            return 1;

        } else if (string2.length() > 0) {
            return -1;

        } else {
            return 0;
        }
    }
}

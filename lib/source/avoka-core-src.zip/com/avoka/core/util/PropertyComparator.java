package com.avoka.core.util;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.ConcurrentHashMap;

import ognl.Ognl;
import ognl.OgnlException;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;


/**
 * Provides a object property string comparator.
 *
 * @author medgar@avoka.com
 */
public class PropertyComparator implements Comparator {

    /** Provides a synchronized cache of OGNL expressions. */
    private static final Map OGNL_EXPRESSION_CACHE = new ConcurrentHashMap();

    private String property;
    private Map cache = new HashMap();

    /**
     * Create a new string comparator, comparing the specified object property.
     *
     * @param property the name of the property to compare
     */
    public PropertyComparator(String property) {
        Validate.notNull(property, "null property parameter");
        this.property = property;
    }

    /**
     * Create a new string comparator, comparing the specified object.
     */
    public PropertyComparator() {
    }

    /**
     * @see Comparator#compare(Object, Object)
     */
    public int compare(Object object1, Object object2) {
        String string1 = null;
        String string2 = null;

        if (property != null) {
            Object value1 = getValueOgnl(object1, property, cache);
            Object value2 = getValueOgnl(object2, property, cache);

            if (value1 == null && value2 == null) {
                return 0;

            } else if (value1 == null) {
                return -1;

            } else if (value2 == null) {
                return 1;
            }
            string1 = value1.toString().trim();
            string2 = value2.toString().trim();

        } else {
            if (object1 == null && object2 == null) {
                return 0;

            } else if (object1 == null) {
                return -1;

            } else if (object2 == null) {
                return 1;
            }

            string1 = object1.toString();
            string2 = object2.toString();
        }

        StringTokenizer st1 = new StringTokenizer(string1);
        StringTokenizer st2 = new StringTokenizer(string2);

        String token1 = null;
        String token2 = null;

        while (st1.hasMoreTokens()) {
            token1 = st1.nextToken();

            if (st2.hasMoreTokens()) {
                token2 = st2.nextToken();

                int comp = 0;

                if (useNumericSort(token1, token2)) {
                    comp = numericCompare(token1, token2);

                } else {
                    comp = token1.toLowerCase().compareTo(token2.toLowerCase());
                }

                if (comp != 0) {
                    return comp;
                }

            } else {
                return -1;
            }
        }

        return 0;
    }

    // -------------------------------------------------------- Private Methods

    private boolean useNumericSort(String value1, String value2) {
        return  NumberUtils.isNumber(value1) && NumberUtils.isNumber(value2);
    }

    private int numericCompare(String string1, String string2) {
        if (string1.length() > 0 && string2.length() > 0) {
            Double double1 = Double.valueOf(string1);
            Double double2 = Double.valueOf(string2);

            return double1.compareTo(double2);

        } else if (string1.length() > 0) {
            return 1;

        } else if (string2.length() > 0) {
            return -1;

        } else {
            return 0;
        }
    }

    /**
     * Return the property value for the given object and property name using
     * the OGNL library.
     * <p/>
     * This method is thread-safe, and caches parsed OGNL expressions in an
     * internal synchronized cache.
     *
     * @param source the source object
     * @param name the name of the property
     * @param context the OGNL context, do NOT modify this object
     * @return the property value for the given source object and property name
     * @throws OgnlException if an OGN error occurs
     */
    public static Object getValueOgnl(Object source, String name, Map context) {
        try {
            Object expression = OGNL_EXPRESSION_CACHE.get(name);
            if (expression == null) {
                expression = Ognl.parseExpression(name);
                OGNL_EXPRESSION_CACHE.put(name, expression);
            }

            return Ognl.getValue(expression, context, source);

        } catch (OgnlException oe) {
            throw new RuntimeException(oe);
        }
    }

}

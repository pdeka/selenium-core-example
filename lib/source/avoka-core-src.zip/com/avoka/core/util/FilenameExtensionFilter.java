/*
 * Copyright (c) 2003 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka
 * Technologies ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only as may be permitted in writing by
 * Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited.
 * No part of this work may be produced or transmitted in any form by any
 * means, electronic or mechanical, including photocopying and recording,
 * or by any information storage or retrival system accept as may be permitted
 * in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.core.util;

import java.io.File;
import java.io.FilenameFilter;

/**
 * Provides a file name extension filter. Note this uses String.endsWith, which
 * is case sensitive!
 *
 * @author Philip Copeland
 */
public class FilenameExtensionFilter implements FilenameFilter  {

    private final String[] allowedExt;

    public FilenameExtensionFilter(String allowedExt) {
        this.allowedExt = new String[] { allowedExt };
    }

    public FilenameExtensionFilter(String[] allowedExt) {
        this.allowedExt = allowedExt;
    }

    public boolean accept(File dir, String name) {

        String extension = FileUtils.getFileExtension(name);
        // Note - endsWith will return true for the empty string
        for (int i = 0; i < allowedExt.length; i++) {
            if (allowedExt[i].equalsIgnoreCase(extension)) {
                return true;
            }
        }
        return false;
    }
}

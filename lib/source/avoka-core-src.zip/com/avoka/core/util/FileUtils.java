/*
 * Copyright (c) 2004-2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on Jul 26, 2004 Created By Philip Copeland
 */
package com.avoka.core.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.zip.ZipFile;

import org.apache.commons.lang.Validate;

/**
 * Provides File utility methods.
 *
 * @author Philip Copeland
 */
public class FileUtils {

    public static List<String> readTextFile(String fileName) throws IOException {
        File file = new File(fileName);
        return readTextFile(file);
    }

    /**
     *
     * Philip Copeland Jul 26, 2004
     *
     * @param fileName
     * @return An arraylist of the lines of text in the file
     * @throws IOException
     */
    public static List<String> readTextFile(File file) throws IOException {

        BufferedReader reader = null;
        try {
            List<String> list = new ArrayList<String>();

            reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            String line = null;

            while (true) {
                line = reader.readLine();
                if (line == null) {
                    break;
                }
                list.add(line);
            }

            return list;

        } finally {
            close(reader);
        }
    }

    public static void writeToFile(String filepath, String str) throws FileNotFoundException, IOException {
        File file = new File(filepath);
        writeToFile(file, str);
    }

    /**
     * @param filepath
     * @param str
     * @throws IOException
     */
    public static void writeToFile(File file, String str) throws FileNotFoundException, IOException {
        checkDirectoryExists(file);

        BufferedWriter bufferedWriter = null;
        try {
            bufferedWriter = new BufferedWriter(new FileWriter(file));
            bufferedWriter.write(str);
            bufferedWriter.flush();

        } finally {
            close(bufferedWriter);
        }
    }

    public static File writeToFile(String filepath, byte[] byteArr) throws FileNotFoundException, IOException {
        File file = new File(filepath);
        checkDirectoryExists (file);
        writeToFile(file, byteArr);
        return file;
    }

    /**
     * @param filepath
     * @param byteArr
     * @throws FileNotFoundException
     * @throws IOException
     * @throws IOException
     */
    public static void writeToFile(File file, byte[] byteArr) throws FileNotFoundException, IOException {
        FileOutputStream outputStream = null;
        BufferedOutputStream bufferedStream = null;

        try {
            outputStream = new FileOutputStream(file);
            bufferedStream = new BufferedOutputStream(outputStream);
            bufferedStream.write(byteArr);

        } finally {
            close(bufferedStream);
            close(outputStream);
        }
    }

    public static String getFileMD5(File file) throws FileNotFoundException, IOException {
        byte[] bytes = FileUtils.readFileAsByteArray(file);
        return CoreUtils.toMD5Hash(bytes);
    }

    public static StringBuffer readFileAsString(String filepath) throws FileNotFoundException, IOException {
        File file = new File(filepath);
        return readFileAsString(file);
    }

    /**
     * @param filepath
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static StringBuffer readFileAsString(File file) throws FileNotFoundException, IOException {
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        StringBuffer buf = new StringBuffer();
        try {
            fileReader = new FileReader(file);
            bufferedReader = new BufferedReader(fileReader);
            int i = bufferedReader.read();
            while (i != -1) {
                char ch = (char) i;
                buf.append(ch);
                i = bufferedReader.read();
            }

        } finally {
            close(fileReader);
            close(bufferedReader);
        }

        return buf;
    }

    /**
     * @param file
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static byte[] readFileAsByteArray(File file) throws FileNotFoundException, IOException {
        BufferedInputStream bufferedStream = null;
        byte[] byteArr;
        try {
            bufferedStream = new BufferedInputStream(new FileInputStream(file));
            byteArr = new byte[bufferedStream.available()];
            bufferedStream.read(byteArr);

        } finally {
            close(bufferedStream);
        }
        return byteArr;
    }

    /**
     * This tries a file rename first then if that does not work it does a copy.
     *
     * Philip Copeland Jul 27, 2004
     *
     */
    public static boolean moveFile(File sourceFile, File destinationFile) throws FileNotFoundException, IOException {
        // This method is a bit ugly - it uses a combination of exceptions and status messages
        // first try a rename....
        // sourceFile.getAbsolutePath());
        boolean movedFlag = sourceFile.renameTo(destinationFile);
        if (movedFlag == false) {

            // copyFile will throw exception if it fails
            copyFile(sourceFile, destinationFile);

            // copyFile throws an exception if it doesn't copy successfully
            boolean deleted = sourceFile.delete();
            if (!deleted) {
                File renamed = new File(sourceFile.getAbsoluteFile() + ".copiedNotMoved");
                sourceFile.renameTo(renamed);
            }
        }

        return movedFlag;
    }

    /**
     * This tries a file rename first then if that does not work it does a copy.
     *
     * Philip Copeland Jul 27, 2004
     *
     */
    public static boolean moveFileUsingCopy(File sourceFile, File destinationFile)
        throws FileNotFoundException, IOException {

        // copyFile will throw exception if it fails
        copyFile(sourceFile, destinationFile);

        // copyFile throws an exception if it doesn't copy successfully
        boolean deleted = sourceFile.delete();
        if (!deleted) {
        }

        return true;
    }

    /**
     * See copyFile for a faster version of this.
     *
     * @param sourceFile
     * @param destinationFile
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static void copyFileOld(File sourceFile, File destinationFile)
        throws FileNotFoundException, IOException {

        BufferedInputStream inStream = null;
        BufferedOutputStream outStream = null;

        try {
            inStream = new BufferedInputStream(new FileInputStream(sourceFile));
            outStream = new BufferedOutputStream(new FileOutputStream(destinationFile));
            int c;
            while ((c = inStream.read()) != -1) {
                outStream.write(c);
            }

        } catch (IOException ex) {
            throw ex;

        } finally {
            close(outStream);
            close(inStream);
        }
    }

    /**
     * Copies one file to another
     *
     * @param sourceFile
     * @param destinationFile
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static void copyFile(File sourceFile, File destinationFile) throws FileNotFoundException, IOException {
        BufferedInputStream inStream = null;
        BufferedOutputStream outStream = null;

        try {

            inStream = new BufferedInputStream(new FileInputStream(sourceFile));
            outStream = new BufferedOutputStream(new FileOutputStream(destinationFile));

            // It's 3-8 times faster using a byte buffer to do this rather than a single
            // byte at a time (depending on the size of the file - tested at 200K)
            // There is no degradation for small file sizes
            int n = 0;
            int blockSize = 1024 * 10;
            byte[] buffer = new byte[blockSize];
            while ((n = inStream.read(buffer, 0, blockSize)) > 0) {
                outStream.write(buffer, 0, n);
            }
        } finally {
            close(outStream);
            close(inStream);
        }
    }

    public static boolean checkDirectoryExists(File fileToCheck) {
        String directory = fileToCheck.getParent();

        File fileDir = new File(directory);

        if (fileDir.exists() == false) {
           return fileDir.mkdirs();
        } else {
            return true;
        }
    }

    public static boolean ensureDirectoryExists(String path) {
        Validate.notNull(path, "Null path parameter");

        File directory = new File(path);

        if (!directory.isDirectory()) {
            if (directory.mkdirs()) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    /**
     * Creates a date subdirectory under a given directory...
     *
     * Philip Copeland Jul 29, 2004
     *
     * @param directory
     * @return
     * @throws AvokaException
     */
    public static File createDateSubdirectory(File directory) throws IOException {
        // create the date subdirectory if needed

        Calendar cal = new GregorianCalendar();
        Date today = cal.getTime();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String dateSubdirectory = df.format(today);

        File dateDirectory = new File(directory, dateSubdirectory);
        if (!dateDirectory.exists()) {
            boolean dateDirectoryCreated = dateDirectory.mkdirs();
            if (dateDirectoryCreated == false) {
                String msg = "Cannot create sub-directory: " + dateDirectory.getAbsolutePath();
                // This will start a ErrorNotficationProcess then throw a
                // PATServiceException and stop here.
                throw new IOException(msg);
            }

        }
        if (dateDirectory.canWrite() == false) {
            String msg = "Cannot write to destination directory: " + dateDirectory.getAbsolutePath();
            // This will start a ErrorNotficationProcess then throw a PATServiceException
            // and stop here.
            throw new IOException(msg);
        }
        return dateDirectory;

    }

    public static String[] fileNameSplit(String fileName) {

        int dotIndex = fileName.lastIndexOf(".");

        String[] filePart = new String[2];
        filePart[0] = fileName.substring(0, dotIndex);
        filePart[1] = fileName.substring(dotIndex, fileName.length());
        return filePart;
    }

    /**
     * Philip Copeland Aug 4, 2004
     *
     * @param fileName
     * @return
     */
    public static String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf(".");
        return fileName.substring(dotIndex + 1, fileName.length());
    }

    public static String changeFileExtension(String fileName, String newExtension) {
        int dotIndex = fileName.lastIndexOf(".");
        return fileName.substring(0, dotIndex + 1) + newExtension;
    }

    /**
     * Parth Pandya Aug 10, 2005
     *
     * @param fileArray
     * @return largestFile
     */
    public static String getFileName(String fileNameWithExtension) {
        int dotIndex = fileNameWithExtension.lastIndexOf(".");
        return fileNameWithExtension.substring(0, dotIndex);
    }

    /**
     * Gets the oldest file in the list.
     *
     * Philip Copeland Oct 5, 2004
     *
     * @param fileArray containing a names of files (as returned by File.listFiles()
     * @return
     */
    public static File getOldestFile(File[] fileArray) {

        File oldestFile = null;
        if (fileArray.length == 0) {
            return null;
        } else {
            oldestFile = fileArray[0];
        }
        for (int i = 0; i < fileArray.length; i++) {

            if (fileArray[i].lastModified() < oldestFile.lastModified()) {
                // A smaller number which means its an older file.
                oldestFile = fileArray[i];
            }
        }
        return oldestFile;
    }

    /**
     * Gets the newest file in the list.
     *
     * @param fileArray containing a names of files (as returned by File.listFiles()
     * @return
     */
    public static File getNewestFile(File[] fileArray) {

        File newestFile = null;
        if (fileArray.length == 0) {
            return null;
        } else {
            newestFile = fileArray[0];
        }
        for (int i = 0; i < fileArray.length; i++) {
            if (fileArray[i].lastModified() > newestFile.lastModified()) {
                // A smaller number which means its an older file.
                newestFile = fileArray[i];
            }
        }
        return newestFile;
    }

    /**
     * Parth Pandya Aug 10, 2005
     *
     * @param fileArray
     * @return smallestFile
     */
    public static File getSmallestFile(File[] fileArray) {
        File smallestFile = null;

        if (fileArray.length == 0) {
            return null;
        } else {
            smallestFile = fileArray[0];
        }

        for (int i = 0; i < fileArray.length; i++) {
            if (fileArray[i].length() < smallestFile.length()) {
                smallestFile = fileArray[i];
            }
        }
        return smallestFile;
    }

    /**
     * Parth Pandya Aug 10, 2005
     *
     * @param fileArray
     * @return largestFile
     */
    public static File getLargetsFile(File[] fileArray) {
        File largestFile = null;

        if (fileArray.length == 0) {
            return null;
        } else {
            largestFile = fileArray[0];
        }

        for (int i = 0; i < fileArray.length; i++) {

            if (fileArray[i].length() > largestFile.length()) {
                largestFile = fileArray[i];
            }
        }
        return largestFile;
    }

    /**
     * @author ppandya Parth Pandya. September 7, 2005
     * <p> This method changes the modified time attribute for the given File. If the Date value is null then the method returns false and the modified time stays untouched.
     *
     * @param file - the file to which the modified time has to be changed
     * @param dateTime - The java.util.Date object to specify which is the time to use for change in modified time.
     * @return - true if and only if the operation succeeded; false otherwise.
     */
    public static boolean setLastModifiedTime(File file, Date dateTime) {

        if(dateTime == null)
            return false;

        Calendar cal = GregorianCalendar.getInstance();
        cal.setTime(dateTime);

        return file.setLastModified(cal.getTimeInMillis());
    }

    /**
     * @author ppandya Parth Pandya. September 7, 2005
     * <p> This method changes the modified time attribute for the given File. The method changes the modified time attribute with the current date-time.
     *
     * @param file - the file to which the modified time has to be changed
     * @return - true if and only if the operation succeeded; false otherwise.
     */
    public static boolean setLastModifiedTime(File file) {

        Calendar cal = GregorianCalendar.getInstance();

        return file.setLastModified(cal.getTimeInMillis());
    }

    public static void close(InputStream stream) {
        if (stream != null) {
            try {
                stream.close();
            } catch (IOException ioe) {
                // ignore
            }
        }
    }

    public static void close(ZipFile zipFile) {
        if (zipFile != null) {
            try {
                zipFile.close();
            } catch (IOException ioe) {
                // ignore
            }
        }
    }

    public static void close(OutputStream stream) {
        if (stream != null) {
            try {
                stream.close();
            } catch (IOException ioe) {
                // ignore
            }
        }
    }
 
    public static void close(Writer writer) {
        if (writer != null) {
            try {
                writer.close();
            } catch (IOException ioe) {
                // ignore
            }
        }
    }

    public static void close(Reader reader) {
        if (reader != null) {
            try {
                reader.close();
            } catch (IOException ioe) {
                // ignore
            }
        }
    }

   public static byte[] toByteArray(InputStream input) throws IOException {

        ByteArrayOutputStream data = new ByteArrayOutputStream();

        if (input != null) {
            try {
                final byte[] buffer = new byte[1024];
                int length;
                while ((length = input.read(buffer)) != -1) {
                    data.write(buffer, 0, length);
                }
            } finally {
                close(data);
            }
        }

        return data.toByteArray();
    }

}

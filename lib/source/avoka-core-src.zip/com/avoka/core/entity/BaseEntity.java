/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.core.entity;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.cayenne.CayenneDataObject;
import org.apache.cayenne.ObjectId;

import com.avoka.core.util.CayenneUtils;

/**
 * Provides a base CayenneDataObject for application entity classes to extend.
 *
 * @author Malcolm Edgar
 */
public abstract class BaseEntity extends CayenneDataObject {

    private static final long serialVersionUID    = 1L;

    public static final String ID_PROPERTY = "id";

    /**
     * Return the surrogate primary key of the object.
     *
     * @return the surrogate primary key of the object
     */
    public Long getId() {
        if (getObjectId() != null) {
            String pkName = CayenneUtils.getPkName(getClass());

            Object object = getObjectId().getIdSnapshot().get(pkName);
            if (object != null) {
                String idString = object.toString();
                return Long.parseLong(idString);
            }
        }
        return null;
    }

    /**
     * Set the surrogate primary key of the object.
     *
     * @param id the surrogate primary key of the object to set
     */
    public void setId(Long id) {
        if (id != null && id.longValue() != 0) {

            ObjectId objectId = CayenneUtils.createObjectId(getClass(), id);

            setObjectId(objectId);
        }
    }

    /**
     * Return true if the object is new or transient object.
     *
     * @return true if the object is new or transient object
     */
    public boolean isNew() {
        Long id = getId();

        return (id == null || id.longValue() == 0);
    }

    /**
     * Return map of object properties values for query by example.
     *
     * @return a map of object properties
     */
    public Map getValuesMap() {
        Map mapValues = new TreeMap();

        for (Iterator i = values.keySet().iterator(); i.hasNext();) {
            String key = (String) i.next();
            Object value = values.get(key);

            if (value != null && !(value instanceof Collection)) {
                mapValues.put(key, value);
            }
        }

        return mapValues;
    }

}

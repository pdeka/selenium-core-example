package com.avoka.core.crypto;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.Validate;

/**
 * Provides an AES symetrical encryption utility.
 *
 * @author medgar@avoka.com
 */
public class AESSymetricalCipher {

    private final static Cipher AES_CIPHER_ENCRYPT;
    private final static Cipher AES_CIPHER_DECRYPT;

    static {
        try {
            AESSecretKey key = new AESSecretKey();

            AES_CIPHER_ENCRYPT = Cipher.getInstance(key.getAlgorithm());
            AES_CIPHER_DECRYPT = Cipher.getInstance(key.getAlgorithm());

            AES_CIPHER_ENCRYPT.init(Cipher.ENCRYPT_MODE, key);
            AES_CIPHER_DECRYPT.init(Cipher.DECRYPT_MODE, key);

        } catch (Exception e) {
            throw new RuntimeException("Could not initialise AES ciphers");
        }
    }

    // Public Methods ---------------------------------------------------------

    /**
     * Encrypt the given data using a symetrical AES cipher.
     *
     * @param data the data to encrypt
     * @return the AES encrypted data
     */
    public static byte[] encrypt(byte[] data) {
        Validate.notNull(data, "Null data parameter");

        try {
            return AES_CIPHER_ENCRYPT.doFinal(data);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Decrypt the given data using a symetrical AES cipher.
     *
     * @param data the encrypted data to decrypt
     * @return the decrypted data
     */
    public static byte[] decrypt(byte[] data) {
        Validate.notNull(data, "Null data parameter");

        try {
            return AES_CIPHER_DECRYPT.doFinal(data);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String encrypt(String plainText) {
        Validate.notNull(plainText, "Null plainText parameter");

        try {
            // Encode the string into bytes using utf-8
            byte[] utf8 = plainText.getBytes("UTF8");

            // Encrypt
            byte[] enc = encrypt(utf8);

            // Encode as Base64 string
            Base64 base64 = new Base64();
            byte[] byteData = base64.encode(enc);
            return new String(byteData);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String decrypt(String cypherText) {
        Validate.notNull(cypherText, "Null cypherText parameter");

        try {
            // Decode Base64 to get bytes
            Base64 base64 = new Base64();
            byte[] dec = base64.decode(cypherText.getBytes());

            // Decrypt
            byte[] utf8 = decrypt(dec);

            // Decode using UTF8
            return new String(utf8, "UTF8");

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Private Inner Classes --------------------------------------------------

    private static class AESSecretKey implements SecretKey {

        // DO NOT EDIT THIS VALUE: as it resolves to 128-bit key
        private static final long serialVersionUID = 3313785233319703L;

        public String getAlgorithm() {
            return "AES";
        }

        public byte[] getEncoded() {
            return String.valueOf(serialVersionUID).getBytes();
        }

        public String getFormat() {
            return "RAW";
        }
     }

}

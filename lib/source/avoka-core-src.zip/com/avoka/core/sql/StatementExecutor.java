package com.avoka.core.sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.util.CayenneUtils;

public class StatementExecutor {

    private Logger logger = LoggerFactory.getLogger(getClass());

    public void execute(String sqlStatement) {
        Validate.notEmpty(sqlStatement);

        Connection connection = null;
        try {
            connection = getConnection();

            Statement statement = connection.createStatement();
            statement.execute(sqlStatement);
            SqlUtils.close(statement);

        } catch (SQLException sqle) {
            throw new RuntimeException("Error with statement '" + sqlStatement + "'", sqle);

        } finally {
            SqlUtils.close(connection);
        }
    }


    public void executeQuery(String sqlStatement, ResultSetProcessor resultSetProcessor) {
        Validate.notEmpty(sqlStatement);

        Connection connection = null;
        Statement statement = null;
        try {
            connection = getConnection();

            statement = connection.createStatement();

            long start = System.currentTimeMillis();

            ResultSet resultSet = statement.executeQuery(sqlStatement);

            if (logger.isTraceEnabled()) {
                String msg = "Query executed in {}ms, sql: {}";
                logger.trace(msg, (System.currentTimeMillis() - start), sqlStatement);
            }

            start = System.currentTimeMillis();

            resultSetProcessor.processResultSet(resultSet);

            if (logger.isTraceEnabled()) {
                String msg = "ResultSet processed in {}ms, sql: {}";
                logger.trace(msg, (System.currentTimeMillis() - start), sqlStatement);
            }

        } catch (SQLException sqle) {
            throw new RuntimeException(sqle);

        } finally {
            SqlUtils.close(statement);
            SqlUtils.close(connection);
        }
    }

    private Connection getConnection() {
        try {
            return CayenneUtils.getConnection();
        } catch (SQLException sqle) {
            throw new RuntimeException(sqle);
        }
    }
}

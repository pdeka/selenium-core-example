package com.avoka.core.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.util.CayenneUtils;

public class PreparedStatementExecutor {

    private Logger logger = LoggerFactory.getLogger(getClass());

    public void executeQuery(String sqlStatement, String[] args, ResultSetProcessor resultSetProcessor) {
        Validate.notEmpty(sqlStatement);

        long start = System.currentTimeMillis();

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = getConnection();

            preparedStatement = connection.prepareStatement(sqlStatement);

            if (args != null) {
                for (int i = 0; i < args.length; i++) {
                    preparedStatement.setString(i + 1, args[i]);
                }
            }


            ResultSet resultSet = preparedStatement.executeQuery();

            resultSetProcessor.processResultSet(resultSet);

            if (logger.isTraceEnabled()) {
                List<String> paramList = new ArrayList<String>();
                for (int i = 0; i < args.length; i++) {
                    paramList.add(args[i]);
                }
                Object[] arguments = new Object[] {
                    (System.currentTimeMillis() - start),
                    sqlStatement,
                    paramList
                };
                String msg = MessageFormat.format("executed in {0,number,integer}ms, sql: {1}, params: {2}", arguments);
                logger.trace(msg);
            }

        } catch (SQLException sqle) {
            throw new RuntimeException(sqle);

        } finally {
            SqlUtils.close(preparedStatement);
            SqlUtils.close(connection);
        }
    }

    private Connection getConnection() {
        try {
            return CayenneUtils.getConnection();
        } catch (SQLException sqle) {
            throw new RuntimeException(sqle);
        }
    }
}

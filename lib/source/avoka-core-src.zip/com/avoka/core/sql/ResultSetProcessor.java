package com.avoka.core.sql;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResultSetProcessor {

    public void processResultSet(ResultSet resultSet) throws SQLException;
}

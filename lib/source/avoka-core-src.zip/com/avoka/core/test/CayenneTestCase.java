package com.avoka.core.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import junit.framework.ComparisonFailure;
import junit.framework.TestCase;

import org.apache.cayenne.access.DataContext;

/**
 * Provides a Cayenne JUnit TestCase which will initialize a new thread local
 * DataContext for each executed test.
 *
 * @author Malcolm Edgar
 */
public class CayenneTestCase extends TestCase {

    /**
     * Return the thread local DataContext.
     *
     * @return the thread local DataContexts
     */
    @SuppressWarnings("deprecation")
    public DataContext getDataContext() {
        return DataContext.getThreadDataContext();
    }

    /**
     * This method is called before a test is executed, creating a DataContext
     * and associating it to the current Thread.
     *
     * @see TestCase#setUp()
     */
    @SuppressWarnings("deprecation")
    protected void setUp() throws Exception {
        DataContext dataContext = DataContext.createDataContext(false);
        DataContext.bindThreadDataContext(dataContext);
    }

    /**
     * This method is called after a test is executed, removing the DataContext
     * from the Thread.
     *
     * @see TestCase#tearDown()
     */
    @SuppressWarnings("deprecation")
    protected void tearDown() throws Exception {
        DataContext.bindThreadDataContext(null);
    }

    /**
     * Assert the dates are equal ignoring any time differences.
     *
     * @param expected the expected date
     * @param actual the actual date
     */
    public void assertDateEquals(Date expected, Date actual) {
        if (expected == null && actual == null)
            return;

        if (expected != null && actual == null) {
            throw new ComparisonFailure(null, expected.toString(), "null");
        }

        GregorianCalendar expectedCal = new GregorianCalendar();
        expectedCal.setTime(expected);

        GregorianCalendar actualCal = new GregorianCalendar();
        actualCal.setTime(actual);

        if (expectedCal.get(Calendar.YEAR) != actualCal.get(Calendar.YEAR)) {
            throw new ComparisonFailure(null, expected.toString(), actualCal.toString());
        }
        if (expectedCal.get(Calendar.MONTH) != actualCal.get(Calendar.MONTH)) {
            throw new ComparisonFailure(null, expected.toString(), actualCal.toString());
        }
        if (expectedCal.get(Calendar.DATE) != actualCal.get(Calendar.DATE)) {
            throw new ComparisonFailure(null, expected.toString(), actualCal.toString());
        }
    }


}

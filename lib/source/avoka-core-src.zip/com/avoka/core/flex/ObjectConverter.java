/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.core.flex;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;

import ognl.Ognl;
import ognl.OgnlException;

import org.apache.cayenne.DataObject;
import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.core.util.CayenneUtils;
import com.avoka.core.util.ValueObject;

/**
 * Provides a utility object to covert between DataObject and ValueObject
 * objects. <p/> DataObject classes extends CayenneDataObject and are used for
 * server side persistence operations, while ValueObject objects are used by
 * Adobe Flex to convert between Java objects and Flex ActionScript objects.
 * <p/> The ValueObject support Flex serialization and deserialization of object
 * graphs, providing an intermediary between Cayenne DataObjects and Flex
 * ActionScript objects. <p/> An example useage of the ObjectCoverter is
 * provided below:
 *
 * <pre>
 * public UserVO updateUser(UserVO userVO) {
 *
 *     User user = (User) ObjectConverter.toDataObject(userVO);
 *
 *     getDataContext().commitChanges();
 *
 *     return (UserVO) ObjectConverter.toValueObject(user, &quot;*&quot;);
 * }
 * </pre>
 *
 * @see com.avoka.core.entity.DataObject
 * @see com.avoka.core.util.ValueObject
 *
 * @author Malcolm Edgar
 */
public class ObjectConverter {

    // -------------------------------------------------------------- Constants

    /** The DataObject id property name. */
    private static final String ID_PROPERTY = "id";

    /** The maximum recursion depth: 10 */
    private static final int MAX_RECURSION_DEPTH = 10;

    /** The reserved data object names to be excluded from properties. */
    private static final Set RESERVED_DO_NAMES = new HashSet();

    /** The reserved value object names to be excluded from properties. */
    private static final Set RESERVED_VO_NAMES = new HashSet();

    static {
        RESERVED_DO_NAMES.add("class");
        RESERVED_DO_NAMES.add("dataContext");
        RESERVED_DO_NAMES.add("objectContext");
        RESERVED_DO_NAMES.add("objectId");
        RESERVED_DO_NAMES.add("objEntity");
        RESERVED_DO_NAMES.add("persistenceState");
        RESERVED_DO_NAMES.add("pkColumn");
        RESERVED_DO_NAMES.add("snapshotVersion");
        RESERVED_DO_NAMES.add("valuesMap");

        RESERVED_VO_NAMES.add("class");
        RESERVED_VO_NAMES.add("deleted");
    }

    // ----------------------------------------------------- Instance Variables

    private static Logger logger = LoggerFactory.getLogger(ObjectConverter.class);

    // --------------------------------------------------------- Public Methods

    /**
     * Convert the given value object into a Cayenne data object. <p/> Please
     * note this method will not delete the data object corresponding to the
     * given value object parameter. This method will however delete child data
     * objects in one to many relationships. <p/> IMPORTANT NOTE: this method
     * will not resolve circular dependencies between objects. You must ensure
     * object graphs passed do not include circular dependencies beyond simple
     * Cayenne bi-directional relationships.
     *
     * @param valueObject
     *            the value object to convert
     * @return the Cayenne data object
     */
    public static DataObject toDataObject(ValueObject valueObject) {
        return toDataObject(valueObject, null, 1);
    }

    // /**
    // * Convert the given Cayenne data object into a value object.
    // * <p/>
    // * Please not this method will not resolve unresolved object relationships
    // * such as unfetched one-to-many and one-to-one object relationsthips.
    // *
    // * @deprecated dont use this method
    // *
    // * @param dataObject the data object to convert
    // * @return the value object
    // */
    // public static ValueObject toValueObject(DataObject dataObject) {
    // return toValueObject(dataObject, "*");
    // }
    //
    /**
     * Convert the given Cayenne data object into a value object, including the
     * specified paths for object relationships. <p/> An example useage of the
     * ObjectCoverter is provided below:
     *
     * <pre>
     * public UserVO updateUser(UserVO userVO) {
     *
     *     User user = (User) ObjectConverter.toDataObject(userVO);
     *
     *     getDataContext().commitChanges();
     *
     *     return (UserVO) ObjectConverter.toValueObject(user, &quot;contact, submissions&quot;);
     * }
     * </pre>
     *
     * @param dataObject
     *            the data object to convert
     * @param pathIncludes
     *            the data object property paths to include in the conversion
     * @return the value object
     */
    public static ValueObject toValueObject(DataObject dataObject, String pathIncludes) {
        Set pathSet = getPropertyPathSet(pathIncludes);

        return toValueObject(dataObject, null, 1, pathSet);
    }

    /**
     * Convert the given Cayenne data object into a value object, including the
     * specified paths for object relationships. <p/> An example useage of the
     * ObjectCoverter is provided below:
     *
     * <pre>
     * public UserVO updateUser(UserVO userVO) {
     *
     *     User user = (User) ObjectConverter.toDataObject(userVO);
     *
     *     getDataContext().commitChanges();
     *
     *     Set includes = new HashSet();
     *     includes.add(&quot;contact&quot;);
     *     includes.add(&quot;submissions.groupMember.contact&quot;);
     *     includes.add(&quot;submissions.groupMember.secondaryContact&quot;);
     *
     *     return (UserVO) ObjectConverter.toValueObject(user, includes);
     * }
     * </pre>
     *
     * If a null set of pathIncludes is specified no object relationships will
     * be converted.
     *
     * @param dataObject
     *            the data object to convert
     * @param pathIncludes
     *            the data object property paths to include in the conversion
     * @return the value object
     */
    public static ValueObject toValueObject(DataObject dataObject, Set pathIncludes) {
        if (pathIncludes == null) {
            pathIncludes = Collections.EMPTY_SET;
        }

        return toValueObject(dataObject, null, 1, pathIncludes);
    }

    /**
     * Takes a list of <code>DataObject</code> instances and creates a
     * corresponding list of equivalent <code>ValueObject</code> instances.
     *
     * @param dataObjects
     *            List of <code>DataObject</code> instances.
     * @param pathIncludes
     * @return List of ValueObject instances. n'th element is the value object
     *         equivalent of the n'th element of <code>dataObjects</code>.
     */
    public static List toValueObjects(List dataObjects, String pathIncludes) {
        Validate.notNull(dataObjects, "Can't convert null list of data objects to value objects");
        Validate.allElementsOfType(dataObjects, DataObject.class,
                "All elements in data objects list must implement DataObject");

        LinkedList valueObjects = new LinkedList();

        for (Iterator i = dataObjects.iterator(); i.hasNext();) {
            DataObject dataObject = (DataObject) i.next();
            ValueObject valueObject = toValueObject(dataObject, pathIncludes);
            valueObjects.add(valueObject);
        }

        Validate.notNull(valueObjects, "Failed to construct list of ValueObject instances");
        Validate.allElementsOfType(valueObjects, ValueObject.class,
                "Failed to construct valid list of ValueObject instances");
        Validate.isTrue(dataObjects.size() == valueObjects.size(), "Created wrong number of value objects");

        return valueObjects;
    }

    public static List toDataObjects(List valueObjects) {
        Validate.notNull(valueObjects, "Can't convert null list of value objects to data objects");
        Validate.allElementsOfType(valueObjects, ValueObject.class, "List element not an instance of ValueObject");

        LinkedList dataObjects = new LinkedList();
        for (Iterator i = valueObjects.iterator(); i.hasNext();) {
            ValueObject valueObject = (ValueObject) i.next();
            DataObject dataObject = toDataObject(valueObject);
            dataObjects.add(dataObject);
        }

        Validate.notNull(dataObjects, "Failed to construct list of DataObject instances");
        Validate.allElementsOfType(dataObjects, DataObject.class, "List element not an instance of DataObject");
        Validate.isTrue(valueObjects.size() == dataObjects.size(), "Created wrong number of data objects");

        return dataObjects;
    }

    // ------------------------------------------------------ Protected Methods

    /**
     * Convert the given value object into a Cayenne data object. <p/> Please
     * note this method will not delete the data object corresponding to the
     * given value object parameter. This method will however delete child data
     * objects in one to many relationships. <p/> IMPORTANT NOTE: this method
     * will not resolve circular dependencies between objects. You must ensure
     * object graphs passed do not include circular dependencies beyond simple
     * Cayenne bi-directional relationships.
     *
     * @param valueObject
     *            the value object to convert
     * @param parentDO
     *            the resolved parent data object
     * @param depth
     *            the current recursion depth
     * @return the Cayenne data object
     */
    @SuppressWarnings("deprecation")
    protected static DataObject toDataObject(ValueObject valueObject, DataObject parentDO, int depth) {
        if (getLogger().isDebugEnabled()) {
            String msg = "invoke with: " + valueObject;
            getLogger().debug(msg);
        }

        depth++;

        if (depth >= MAX_RECURSION_DEPTH) {
            String msg = "maximum recurion depth reached of " + depth + " reached processing: " + valueObject + ", "
                    + parentDO;
            getLogger().error(msg);
            throw new RuntimeException(msg);
        }

        if (valueObject == null) {
            return null;
        }
        Class doClass = getDOClass(valueObject.getClass());

        DataObject dataObject = null;

        if (valueObject.isNew()) {
            dataObject = (DataObject) getDataContext().createAndRegisterNewObject(doClass);

        } else {
            dataObject = (DataObject) DataObjectUtils.objectForPK(getDataContext(), doClass, valueObject.getId());
        }

        Map voPropertiesMap = getValueObjectProperties(valueObject);
        Map doPropertiesMap = getDataObjectProperties(dataObject, Collections.EMPTY_SET);

        for (Iterator i = voPropertiesMap.values().iterator(); i.hasNext();) {
            Property property = (Property) i.next();

            if (property.getValue() == null) {
                continue;
            }

            if (property.isSimpleType()) {

                if (!doPropertiesMap.containsKey(property.name)) {
                    continue;
                }

                property.setValue(dataObject, property.getValue());

            } else if (property.isComplexType()) {

                ValueObject propertyVO = (ValueObject) property.getValue();

                if (propertyVO.getDeleted()) {
                    property.setValue(dataObject, null);

                } else {

                    DataObject propertyDO = null;

                    if (matching(propertyVO, parentDO)) {
                        propertyDO = parentDO;

                    } else {
                        propertyDO = toDataObject(propertyVO, dataObject, depth);
                    }

                    property.setValue(dataObject, propertyDO);
                }

            } else if (property.isToManyType()) {

                List list = (List) property.getValue();

                for (int j = 0; j < list.size(); j++) {
                    Object object = list.get(j);

                    ValueObject propertyVO = (ValueObject) object;

                    DataObject propertyDO = null;

                    if (matching(propertyVO, parentDO)) {
                        propertyDO = parentDO;

                    } else {
                        propertyDO = toDataObject(propertyVO, dataObject, depth);
                    }

                    if (valueObject.isNew()) {
                        if (propertyVO.getDeleted() == false) {

                            property.addToList(dataObject, propertyDO);
                        }

                    } else {
                        if (propertyVO.getDeleted()) {
                            getDataContext().deleteObject(propertyDO);

                            property.removeFromList(dataObject, propertyDO);

                        } else {
                            if (propertyVO.isNew()) {
                                property.addToList(dataObject, propertyDO);

                            } else {
                                // Update will be written by data context as
                                // object has already been loaded
                            }
                        }

                    }
                }

            } else {
                String msg = "unhandled property type: " + property.getType();
                throw new RuntimeException(msg);
            }
        }

        if (getLogger().isDebugEnabled()) {
            String msg = "returned: " + dataObject;
            getLogger().debug(msg);
        }

        return dataObject;
    }

    /**
     * Convert the given Cayenne data object into a Cayenne value object.
     *
     * @param dataObject
     *            the data object to convert
     * @param parentVO
     *            the resolved parent value object
     * @param depth
     *            the current recursion depth
     * @param includeProperties
     *            the complex properties to be included
     * @return the value object
     */
    protected static ValueObject toValueObject(DataObject dataObject, ValueObject parentVO, int depth,
            Set includeProperties) {
        if (getLogger().isDebugEnabled()) {
            String msg = "invoke with: " + dataObject + ", " + parentVO + "," + depth + ", " + includeProperties;
            getLogger().debug(msg);
        }

        depth++;

        if (depth >= MAX_RECURSION_DEPTH) {
            String msg = "maximum recurion depth reached of " + depth + " reached processing: " + dataObject + ", "
                    + parentVO;
            getLogger().error(msg);
            throw new RuntimeException(msg);
        }

        if (dataObject == null) {
            return null;
        }
        Class voClass = getVOClass(dataObject.getClass());

        try {
            ValueObject valueObject = (ValueObject) voClass.newInstance();

            Set classPropertyIncludes = getClassPropertyIncludes(includeProperties);

            Map doPropertyMap = getDataObjectProperties(dataObject, classPropertyIncludes);
            Map voPropertyMap = getValueObjectProperties(valueObject);

            // First set id property to enable bi-directional relationships to
            // be resolved
            Property idProperty = (Property) doPropertyMap.get(ID_PROPERTY);
            idProperty.setValue(valueObject, idProperty.getValue());

            for (Iterator i = doPropertyMap.values().iterator(); i.hasNext();) {
                Property property = (Property) i.next();

                if (!voPropertyMap.containsKey(property.name)) {
                    continue;
                }

                /*
                 * // Lazy load check if (property.getValue() == null) {
                 * continue; }
                 */

                if (property.isSimpleType()) {

                    property.setValue(valueObject, property.getValue());

                } else if (property.isComplexType()) {

                    DataObject propertyDO = (DataObject) property.getValue();

                    ValueObject propertyVO = null;

                    if (matching(propertyDO, parentVO)) {
                        propertyVO = parentVO;

                    } else {
                        Set childPropertyIncludes = getChildPropertyIncludes(property.name, includeProperties);

                        propertyVO = toValueObject(propertyDO, valueObject, depth, childPropertyIncludes);
                    }

                    property.setValue(valueObject, propertyVO);

                } else if (property.isToManyType()) {

                    List list = (List) property.getValue();

                    for (Iterator j = list.iterator(); j.hasNext();) {
                        DataObject propertyDO = (DataObject) j.next();

                        ValueObject propertyVO = null;

                        if (matching(propertyDO, parentVO)) {
                            propertyVO = parentVO;

                        } else {
                            Set childPropertyIncludes = getChildPropertyIncludes(property.name, includeProperties);

                            propertyVO = toValueObject(propertyDO, valueObject, depth, childPropertyIncludes);
                        }

                        property.addToList(valueObject, propertyVO);
                    }

                } else {
                    String msg = "unhandled property type: " + property.getType();
                    throw new RuntimeException(msg);
                }
            }

            if (getLogger().isDebugEnabled()) {
                String msg = "returned: " + dataObject;
                getLogger().debug(msg);
            }

            return valueObject;

        } catch (Exception e) {
            getLogger().error(e.toString(), e);
            String msg = "Unknown Error: " + e.toString();
            throw new RuntimeException(msg, e);
        }
    }

    /**
     * Return the matching value object class for the given data object class.
     *
     * @param doClass
     *            the data object class to determine the VO for
     * @return the matching value object class for the given data object class
     */
    protected static Class getVOClass(Class doClass) {
        if (doClass == null) {
            throw new IllegalArgumentException("Null aClass parameter");
        }

        if (!DataObject.class.isAssignableFrom(doClass)) {
            String msg = "specified class does not subclass DataObject " + doClass.getName();
            throw new IllegalArgumentException(msg);
        }

        String classname = doClass.getName();
        try {
            Class voClass = Class.forName(classname + "VO");

            if (ValueObject.class.isAssignableFrom(voClass)) {
                return voClass;

            } else {
                String msg = "value object does not subclass ValueObject";
                throw new IllegalArgumentException(msg);
            }

        } catch (Exception e) {
            String msg = "could not find matching VO class for " + classname;
            throw new RuntimeException(msg, e);
        }
    }

    /**
     * Return the matching data object class for the given value object class.
     *
     * @param voClass
     *            the value object class to determine the data object for
     * @return the matching data object class for the given value object class
     */
    protected static Class getDOClass(Class voClass) {
        if (voClass == null) {
            throw new IllegalArgumentException("Null aClass parameter");
        }

        if (!ValueObject.class.isAssignableFrom(voClass)) {
            String msg = "specified class does not subclass ValueObject " + voClass.getName();
            throw new IllegalArgumentException(msg);
        }

        String classname = voClass.getName();
        classname = classname.substring(0, classname.length() - 2);
        try {
            Class doClass = Class.forName(classname);

            if (DataObject.class.isAssignableFrom(doClass)) {
                return doClass;

            } else {
                String msg = "data object does not subclass DataObject";
                throw new IllegalArgumentException(msg);
            }

        } catch (Exception e) {
            String msg = "could not find matching DO class for " + classname;
            throw new RuntimeException(msg, e);
        }
    }

    /**
     * Return the thread local data context.
     *
     * @return the thread local data context
     */
    @SuppressWarnings("deprecation")
    protected static DataContext getDataContext() {
        return DataContext.getThreadDataContext();
    }

    /**
     * Return the set of value object properties.
     *
     * @param dataObject
     *            the data object to get the properties of
     * @return the set of data object include properties
     */
    protected static Map getDataObjectProperties(DataObject dataObject, Set includeProperties) {
        if (dataObject == null) {
            throw new IllegalArgumentException("Null dataObject parameter");
        }
        if (includeProperties == null) {
            throw new IllegalArgumentException("Null includeProperties parameter");
        }

        Map map = new TreeMap();

        Method[] methods = dataObject.getClass().getMethods();

        for (int i = 0; i < methods.length; i++) {

            String methodName = methods[i].getName();
            Class returnClass = methods[i].getReturnType();

            if (methodName.startsWith("get") && methodName.length() > 3) {
                String propertyName = "" + Character.toLowerCase(methodName.charAt(3)) + methodName.substring(4);

                if (!RESERVED_DO_NAMES.contains(propertyName)) {

                    Property property = new Property(propertyName, returnClass, dataObject);

                    if (property.isSimpleType()) {
                        map.put(propertyName, property);

                    } else {
                        if (includeProperties.isEmpty()) {
                            continue;

                        } else if (includeProperties.contains("*")) {
                            map.put(propertyName, property);

                        } else {
                            if (includeProperties.contains(propertyName)) {
                                map.put(propertyName, property);

                            } else {
                                // Search through propertys looking for a path
                                // match
                                Iterator itr = includeProperties.iterator();
                                while (itr.hasNext()) {
                                    String prop = itr.next().toString();

                                    if (prop.startsWith(propertyName)) {
                                        map.put(propertyName, property);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return map;
    }

    /**
     * Return the set of value object properties.
     *
     * @param valueObject
     *            the value object to get the properties of
     * @return the set of value object properties
     */
    protected static Map getValueObjectProperties(ValueObject valueObject) {

        Map map = new TreeMap();

        Method[] methods = valueObject.getClass().getMethods();

        for (int i = 0; i < methods.length; i++) {

            String methodName = methods[i].getName();
            Class returnClass = methods[i].getReturnType();

            if (methodName.startsWith("get") && methodName.length() > 3) {
                String propertyName = "" + Character.toLowerCase(methodName.charAt(3)) + methodName.substring(4);

                if (!RESERVED_VO_NAMES.contains(propertyName)) {

                    Property property = new Property(propertyName, returnClass, valueObject);

                    map.put(property.name, property);
                }
            }
        }

        // Flex will not serialize List properties, so they have to be exposed
        // as public fields
        Field[] fields = valueObject.getClass().getFields();
        for (int i = 0; i < fields.length; i++) {

            String fieldName = fields[i].getName();
            Class fieldType = fields[i].getType();

            if (List.class.isAssignableFrom(fieldType)) {
                Property property = new Property(fieldName, fieldType, valueObject);

                map.put(property.name, property);
            }
        }

        return map;
    }

    /**
     * Return true if the dataObject and valueObject have equivalent classes and
     * matching ids.
     *
     * @param propertyDO
     *            the property data object to test
     * @param parentVO
     *            the parent value object to test
     * @return true if the data object and value object match class and id
     */
    protected static boolean matching(DataObject propertyDO, ValueObject parentVO) {
        if (propertyDO == null || parentVO == null) {
            return false;

        } else {
            String classname = parentVO.getClass().getName();
            classname = classname.substring(0, classname.length() - 2);

            if (propertyDO.getClass().getName().equals(classname)) {
                if (!isNewDo(propertyDO) && getDoId(propertyDO).equals(parentVO.getId())) {

                    return true;

                } else {
                    return false;
                }

            } else {
                return false;
            }
        }
    }

    /**
     * Return true if the property value object and parent dataObject have
     * equivalent classes and matching ids.
     *
     * @param propertyVO
     *            the property value object to test
     * @param parentDO
     *            the parent data object to test
     * @return true if the data object and value object match class and id
     */
    protected static boolean matching(ValueObject propertyVO, DataObject parentDO) {
        if (propertyVO == null || parentDO == null) {
            return false;

        } else {

            String classname = propertyVO.getClass().getName();
            classname = classname.substring(0, classname.length() - 2);

            if (parentDO.getClass().getName().equals(classname)) {
                if (!propertyVO.isNew() && propertyVO.getId().equals(getDoId(parentDO))) {

                    return true;

                } else {
                    return false;
                }

            } else {
                return false;
            }
        }
    }

    /**
     * Return the class property includes stripping the extended path of child
     * properties. For example: "submission.groupMember" -> "submission"
     *
     * @param pathIncludes
     *            the property path includes
     * @return the class's immediate property includes
     */
    protected static Set getClassPropertyIncludes(Set pathIncludes) {
        if (pathIncludes == null) {
            throw new IllegalArgumentException("Null pathIncludes parameter");
        }

        if (pathIncludes.isEmpty()) {
            return Collections.EMPTY_SET;
        }

        Set returnSet = new HashSet(pathIncludes.size());

        for (Iterator i = pathIncludes.iterator(); i.hasNext();) {
            String path = (String) i.next().toString();

            if (path.indexOf(" ") != -1) {
                String msg = "Invalid property path secified containing whitespace: '" + path + "'";
                throw new IllegalArgumentException(msg);
            }

            if (path.length() == 0) {
                continue;
            }

            int index = path.indexOf(".");
            if (index != -1 && index < path.length()) {
                path = path.substring(0, index);

                if (path.length() == 0) {
                    // ignore

                } else if (path.length() == 1 && path.equals(".")) {
                    // ignore

                } else {
                    returnSet.add(path);
                }

            } else {
                returnSet.add(path);
            }
        }

        return returnSet;
    }

    /**
     * Return the child class property includes stripping the first node of the
     * property path. For example: "submission.groupMember" -> "groupMember"
     *
     * @param pathIncludes
     *            the property path includes
     * @return the class's immediate property includes
     */
    protected static Set getChildPropertyIncludes(String childName, Set pathIncludes) {
        if (childName == null) {
            throw new IllegalArgumentException("Null childName parameter");
        }
        if (pathIncludes == null) {
            throw new IllegalArgumentException("Null pathIncludes parameter");
        }

        if (pathIncludes.isEmpty()) {
            return Collections.EMPTY_SET;
        }

        Set returnSet = new HashSet(pathIncludes.size());

        for (Iterator i = pathIncludes.iterator(); i.hasNext();) {
            String path = (String) i.next().toString();

            if (path.indexOf(" ") != -1) {
                String msg = "Invalid property path secified containing whitespace: '" + path + "'";
                throw new IllegalArgumentException(msg);
            }

            if (path.length() == 0) {
                continue;
            }

            if (path.startsWith(childName)) {
                int index = path.indexOf(".");

                if (index < path.length() - 1) {
                    path = path.substring(index + 1);

                    returnSet.add(path);
                }

            } else if (path.equals("*")) {
                returnSet.add(path);
            }
        }

        return returnSet;
    }

    /**
     * Return the property path set for the given path includes string.
     *
     * @param pathIncludes
     *            the property path includes string
     * @return the property paths
     */
    protected static Set getPropertyPathSet(String pathIncludes) {
        if (StringUtils.isEmpty(pathIncludes)) {
            return Collections.EMPTY_SET;
        }

        HashSet returnSet = new HashSet();

        StringTokenizer tokenizer = new StringTokenizer(pathIncludes, ",");

        while (tokenizer.hasMoreElements()) {
            String path = tokenizer.nextElement().toString().trim();
            if (path.indexOf(" ") != -1) {
                String msg = "pathIncludes contains invalid path element: '" + path + "'";
                throw new IllegalArgumentException(msg);
            }
            returnSet.add(path);
        }

        return returnSet;
    }

    /**
     * Return the logger.
     *
     * @return the logger
     */
    protected static Logger getLogger() {
        return logger;
    }

    /**
     * Return the surrogate primary key of the data object.
     *
     * @return the surrogate primary key of the data object
     */
    protected static Long getDoId(DataObject dataObject) {
        Validate.notNull(dataObject, "Null dataObject parameter");

        if (dataObject.getObjectId() != null) {
            String pkName = CayenneUtils.getPkName(dataObject.getClass());

            Object object = dataObject.getObjectId().getIdSnapshot().get(pkName);
            if (object != null && object.getClass() == Integer.class) {
                Integer id = (Integer) object;
                return new Long(id.longValue());
            }
            return (Long) object;

        } else {
            return null;
        }
    }

    /**
     * Return true if the object is new or transient object.
     *
     * @return true if the object is new or transient object
     */
    public static boolean isNewDo(DataObject dataObject) {
        Long id = getDoId(dataObject);

        return (id == null || id.longValue() == 0);
    }

    // ---------------------------------------------------------- Inner Classes

    /**
     * Provides property value and meta data.
     *
     * @author Malcolm Edgar
     */
    protected static class Property implements Comparable {

        private final String name;

        private final Class type;

        private final Object parent;

        private Object value;

        /**
         * Create a new property with the given name, type and parent object.
         *
         * @param name
         *            the name of the property
         * @param type
         *            the property class
         * @param parent
         *            the property's parent object
         */
        public Property(String name, Class type, Object parent) {
            if (name == null) {
                throw new IllegalArgumentException("null name parameter");
            }
            if (type == null) {
                throw new IllegalArgumentException("null type parameter");
            }
            this.name = name;
            this.parent = parent;
            this.type = type;
        }

        /**
         * @see Comparable#compareTo(java.lang.Object)
         */
        public int compareTo(Object o) {
            Property property = (Property) o;
            return name.compareTo(property.name);
        }

        /**
         * @see java.lang.Object#toString()
         */
        public String toString() {
            return name + ":" + type.getName();
        }

        /**
         * Return the property value.
         *
         * @return the property value
         */
        public Object getValue() {
            if (value != null) {
                return value;
            }

            try {
                value = Ognl.getValue(name, new HashMap(), parent);

            } catch (OgnlException oe) {
                String msg = "Could not get value '" + name + "' of " + parent;
                throw new RuntimeException(msg, oe);
            }

            /*
             * if (parent instanceof DataObject) { // TODO: still performing
             * database hit: // SubmissionService.getSubmissionTypeForUser //
             * groupMember is hitting: SELECT * EEO.REPORTING_SCHEDULE t0 WHERE
             * t0.GROUP_MEMBER_ID = ? // Exclude unfetched objects if (value
             * instanceof DataObject) { DataObject entity = (DataObject) value;
             * if (entity.getPersistenceState() == PersistenceState.HOLLOW ||
             * entity.getPersistenceState() == PersistenceState.DELETED) {
             *
             * value = null; } } else if (value instanceof List) { ToManyList
             * toManyList = (ToManyList) value; List returnList = new
             * ArrayList();
             *
             * DataObject parentEntity = (DataObject) parent;
             *
             * if (parentEntity.getPersistenceState() ==
             * PersistenceState.COMMITTED) { // Exclude unfetched objects if
             * (!toManyList.isFault()) { for (Iterator i =
             * toManyList.iterator(); i.hasNext();) { returnList.add(i.next()); } } }
             * else { for (Iterator i = toManyList.iterator(); i.hasNext();) {
             * returnList.add(i.next()); } }
             *
             * value = returnList; } }
             */

            return value;
        }

        /**
         * Return the property class type.
         *
         * @return the property class type
         */
        public Class getType() {
            return type;
        }

        /**
         * Set the property value on the given target object.
         *
         * @param target
         *            the target object to set the property on
         * @param propertyValue
         *            the property value to set
         */
        public void setValue(Object target, Object propertyValue) {
            if (target == null) {
                throw new IllegalArgumentException("Null target parameter");
            }

            try {
                Ognl.setValue(name, new HashMap(), target, propertyValue);

            } catch (OgnlException oe) {
                String msg = "error occured setting property '" + name + "' on " + target.getClass().getName()
                        + " with value " + value;

                throw new RuntimeException(msg, oe);
            }
        }

        /**
         * Add the given argument to the target's toMany list property.
         *
         * @param target
         *            the object with the toMany list property
         * @param argument
         *            the argument to add to the toMany list
         */
        public void addToList(DataObject target, DataObject argument) {
            if (target == null) {
                throw new IllegalArgumentException("Null target parameter");
            }
            if (argument == null) {
                throw new IllegalArgumentException("Null argument parameter");
            }

            String methodName = "addTo" + Character.toUpperCase(name.charAt(0)) + name.substring(1);

            Class targetClass = target.getClass();

            try {
                Method addMethod = targetClass.getMethod(methodName, new Class[] { argument.getClass() });

                addMethod.invoke(target, new Object[] { argument });

            } catch (NoSuchMethodException nsme) {
                String msg = "could not find method '" + methodName + "' on class " + targetClass.getName()
                        + " with argument class " + argument.getClass().getName();

                throw new RuntimeException(msg, nsme);

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        /**
         * Add the given argument to the target's toMany list property.
         *
         * @param target
         *            the object with the toMany list property
         * @param argument
         *            the argument to add to the toMany list
         */
        public void addToList(ValueObject target, ValueObject argument) {
            if (target == null) {
                throw new IllegalArgumentException("Null target parameter");
            }
            if (argument == null) {
                throw new IllegalArgumentException("Null argument parameter");
            }

            try {
                Object object = Ognl.getValue(name, new HashMap(), target);
                List list = (List) object;

                list.add(argument);

            } catch (OgnlException e) {
                throw new RuntimeException(e);
            }
        }

        /**
         * Remove the given argument from the target's toMany list property.
         *
         * @param target
         *            the object with the toMany list property
         * @param argument
         *            the argument to remove from the toMany list property
         */
        public void removeFromList(DataObject target, Object argument) {
            if (target == null) {
                throw new IllegalArgumentException("Null target parameter");
            }
            if (argument == null) {
                throw new IllegalArgumentException("Null argument parameter");
            }

            String methodName = "removeFrom" + Character.toUpperCase(name.charAt(0)) + name.substring(1);

            Class targetClass = target.getClass();

            try {
                Method removeMethod = targetClass.getMethod(methodName, new Class[] { argument.getClass() });

                removeMethod.invoke(target, new Object[] { argument });

            } catch (NoSuchMethodException nsme) {
                String msg = "could not find method '" + methodName + "' on class " + targetClass.getName()
                        + " with argument class " + argument.getClass().getName();
                throw new RuntimeException(msg, nsme);

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        /**
         * Return true if the property if a not a complex or to many type.
         *
         * @return true if a not a complex or to many type
         */
        public boolean isSimpleType() {
            return !isComplexType() && !isToManyType();
        }

        /**
         * Return true if the property is a complex (DataObject) type.
         *
         * @return true if the property is a complex type
         */
        public boolean isComplexType() {
            return DataObject.class.isAssignableFrom(type) || ValueObject.class.isAssignableFrom(type);
        }

        /**
         * Return true if the property is a toMany (List) relationship type.
         *
         * @return true if the property is a toMany (List) type
         */
        public boolean isToManyType() {
            return List.class.isAssignableFrom(type);
        }

    }

}

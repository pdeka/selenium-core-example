package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._XmlInputVersion;

public class XmlInputVersion extends _XmlInputVersion {

    private static final long serialVersionUID = 1L;

}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._UserRole;

public class UserRole extends _UserRole {

    private static final long serialVersionUID = 1L;

}




package com.avoka.fc.core.entity;

import java.util.Date;

import com.avoka.fc.core.entity.auto._PortalResource;

public class PortalResource extends _PortalResource {

    @Override
    public void setContent(byte[] content) {
        setContentTimestamp(new Date());
        super.setContent(content);
    }

    @Override
    public void setContentBase(byte[] content) {
        setContentBaseTimestamp(new Date());
        super.setContentBase(content);
    }

    /**
     * Rollback portal page content to the content available in the webapp.
     */
    public void rollbackContent() {
        setContent(getContentBase());
    }
}

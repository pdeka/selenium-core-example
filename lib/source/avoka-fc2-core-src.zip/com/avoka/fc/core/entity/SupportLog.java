
package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._SupportLog;

public class SupportLog extends _SupportLog implements Auditable {

    private static final long serialVersionUID = 1L;

    public final static String   TYPE_ENHANCEMENT = "Enhancement";
    public final static String   TYPE_FEEDBACK    = "Feedback";
    public final static String   TYPE_SUPPORT     = "Support";

    public final static String[] TYPES            = { TYPE_ENHANCEMENT, TYPE_FEEDBACK, TYPE_SUPPORT };

    public final static String   CATEGORY_FORM    = "Form";
    public final static String   CATEGORY_GENEARL = "General";

    public final static String[] CATEGORIES       = { CATEGORY_FORM, CATEGORY_GENEARL };

    public final static String   STATUS_OPEN      = "Open";
    public final static String   STATUS_CLOSED    = "Closed";

    public final static String[] STATUS_OPTIONS   = { STATUS_OPEN, STATUS_CLOSED };

}

package com.avoka.fc.core.entity;

import com.avoka.core.crypto.AESSymetricalCipher;
import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.auto._ErrorLogData;

public class ErrorLogData extends _ErrorLogData {

    private static final long serialVersionUID = 1L;

    /**
     * Set the submission XML.
     */
    public void setErrorLogDataString(String xmlData) {
        if (xmlData != null) {
            byte[] compressedData = CoreUtils.encodeStringAsBytes(xmlData);
            byte[] encryptedCompressedData = AESSymetricalCipher.encrypt(compressedData);

            setErrorLogData(encryptedCompressedData);
        } else {
            setErrorLogData(null);
        }
    }

    /**
     * Return the submission XML.
     */
    public String getErrorLogDataString() {
        byte[] encryptedCompressedData = getErrorLogData();
        byte[] compressedData = AESSymetricalCipher.decrypt(encryptedCompressedData);

        return CoreUtils.decodeBytesAsString(compressedData);
    }
}

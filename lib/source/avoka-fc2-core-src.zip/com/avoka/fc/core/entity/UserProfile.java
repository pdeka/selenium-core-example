package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._UserProfile;

public class UserProfile extends _UserProfile {

    private static final long serialVersionUID = 1L;

    public static final String DEFAULT_PROFILE_NAME = "My Profile";
    public static final String DEFAULT_PROFILE_DESCRIPTION = "";

    public boolean isDefaultProfile() {
        Boolean value = getCurrentFlag();
        return (value != null) ? value.booleanValue() : false;
    }

}




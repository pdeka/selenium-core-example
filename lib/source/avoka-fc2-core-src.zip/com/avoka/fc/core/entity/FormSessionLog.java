package com.avoka.fc.core.entity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.auto._FormSessionLog;

public class FormSessionLog extends _FormSessionLog {

    @Override
    public void setSessionFields(String sessionFields) {
        String currentSessionFields = getSessionFields();
        if (StringUtils.isBlank(currentSessionFields)) {
            super.setSessionFields(sessionFields);
        } else {
            // append the new fields to the existing fields
            List fieldList = toList(currentSessionFields);
            List newFieldList = toList(sessionFields);
            appendUniqueFields(fieldList, newFieldList);
            super.setSessionFields(toString(fieldList));
        }
    }

    public String getSessionStatus() {
        String statusStr = super.getSessionStatus();
        SessionStatus status = SessionStatus.lookup(statusStr);
        if (status == SessionStatus.OPEN && isFormAbandoned(status)) {
            status = SessionStatus.ABANDONED;
        }

        return status.getName();
    }

    private boolean isFormAbandoned(SessionStatus status) {
        if (status == SessionStatus.ABANDONED) {
            return true;
        }

        boolean isAbandoned = false;
        if (status == SessionStatus.OPEN) {
            Date lastEventDate = getLastEventTimestamp();
            Date cutoffDate = getAbandonedCutoffDate();
            if (cutoffDate.after(lastEventDate)) {
                isAbandoned = true;
            } else {
                isAbandoned = false;
            }
        }
        return isAbandoned;
    }

    private Date getAbandonedCutoffDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, -1);
        return calendar.getTime();
    }

    private void appendUniqueFields(List<String> currFields, List<String> newFields) {
        for (String field : newFields) {
            if (!currFields.contains(field)) {
                currFields.add(field);
            }
        }
    }

    private List<String> toList(String fieldStr) {
        String[] fields = StringUtils.split(fieldStr, ',');
        List fieldList = new ArrayList();
        for (String field : fields) {
            fieldList.add(field);
        }
        return fieldList;
    }

    private String toString(List<String> fieldList) {
        return StringUtils.join(fieldList, ',');
    }

    public enum SessionStatus {
        OPEN("Open"),
        CLOSED("Closed"),
        ABANDONED("Abandoned"),
        UNKNOWN("");

        private String name;

        SessionStatus(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public static SessionStatus lookup(String type) {
            SessionStatus[] statuses = values();
            for (SessionStatus status : statuses) {
                if (status.name.equalsIgnoreCase(type)) {
                    return status;
                }
            }
            return UNKNOWN;
        }
    }

    public enum EventType {
        EVENT_TYPE_SESSION_OPEN("Session Open"),
        EVENT_TYPE_NAVIGATION("Navigation"),
        EVENT_TYPE_VALIDATION("Validation"),
        EVENT_TYPE_SESSION_CLOSE("Session Close"),
        UNKNOWN("");

        private String name;

        EventType(String name) {
            this.name = name;
        }

        public static boolean contains(String event) {
            EventType[] eventTypes = values();
            for (EventType eventType : eventTypes) {
                if (eventType.name.equalsIgnoreCase(event)) {
                    return true;
                }
            }
            return false;
        }

        public static EventType lookup(String type) {
            EventType[] eventTypes = values();
            for (EventType eventType : eventTypes) {
                if (eventType.name.equalsIgnoreCase(type)) {
                    return eventType;
                }
            }
            return UNKNOWN;
        }

        public String getName() {
            return name;
        }
    }
}

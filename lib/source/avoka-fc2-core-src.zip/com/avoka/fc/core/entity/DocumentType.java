package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._DocumentType;

public class DocumentType extends _DocumentType implements Auditable {

    private static final long serialVersionUID = 1L;

}




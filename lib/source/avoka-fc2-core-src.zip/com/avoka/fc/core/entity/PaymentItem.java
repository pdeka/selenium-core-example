package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._PaymentItem;

public class PaymentItem extends _PaymentItem {

    private static final long serialVersionUID = 1L;

}




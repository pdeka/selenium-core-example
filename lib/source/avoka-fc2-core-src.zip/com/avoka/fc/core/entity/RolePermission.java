package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._RolePermission;

public class RolePermission extends _RolePermission {

    private static final long serialVersionUID = 1L;

}




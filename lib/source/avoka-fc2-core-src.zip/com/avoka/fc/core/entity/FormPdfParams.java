package com.avoka.fc.core.entity;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.auto._FormPdfParams;

public class FormPdfParams extends _FormPdfParams {

    private static final long serialVersionUID = 1L;

    public static final String[] VIEW_VALUES = {"", "Fit", "FitH", "FitH,top", "FitV", "FitV,left", "FitB", "FitBH", "FitBH,top", "FitBV", "FitBV,left"};
    public static final String[] ZOOM_VALUES = {"", "25", "50", "75", "100", "125", "150", "200"};
    public static final String[] PAGE_MODE_VALUES = { "", "bookmarks", "thumbs" };

    public void renderParam(StringBuilder builder) {

        boolean addedParam = false;

        if (StringUtils.isNotBlank(getMessages())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("messages=");
            builder.append(getMessages());
        }

        if (StringUtils.isNotBlank(getNavpanes())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("navpanes=");
            builder.append(getNavpanes());
        }

        if (getPage() != null) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("page=");
            builder.append(getPage());
        }

        if (StringUtils.isNotBlank(getPagemode())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("pagemode=");
            builder.append(getPagemode());
        }

        if (StringUtils.isNotBlank(getScrollbar())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("scrollbar=");
            builder.append(getScrollbar());
        }

        if (StringUtils.isNotBlank(getStatusbar())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("statusbar=");
            builder.append(getStatusbar());
        }

        if (StringUtils.isNotBlank(getToolbar())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("toolbar=");
            builder.append(getToolbar());
        }

        if (StringUtils.isNotBlank(getView())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("view=");
            builder.append(getView());
        }

        if (StringUtils.isNotBlank(getZoom())) {
            if (!addedParam) {
                builder.append("#");
                addedParam = true;
            } else {
                builder.append("&");
            }

            builder.append("zoom=");
            builder.append(getZoom());
        }

    }

}

package com.avoka.fc.core.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.avoka.fc.core.entity.auto._SchemaSeed;
import com.avoka.fc.core.util.ApplicationException;

public class SchemaSeed extends _SchemaSeed implements Auditable {

    private static final long serialVersionUID = 1L;

    public static String[] FILE_EXTENSIONS = new String[] { "xml" };

    /**
     * Return the configuration mapping xpath for the given configuration mapping name or null if not defined
     *
     * @param name the configuration mapping name
     * @return the configuration mapping xpath for the given configuration mapping name
     */
    public String getConfigXPath(String name) {
        return getConfigXPaths().get(name);
    }

    /**
     * Return the configuration mapping xpath for the given configuration mapping name or null if not defined
     *
     * @param name the configuration mapping name
     * @return the configuration mapping xpath for the given configuration mapping name
     */
    public Map<String, String> getConfigXPaths() {
        Map<String, String> configXPaths = new HashMap<String, String>();

        List<SchemaSeed> parentSchemas = getParentSchemas();

        for (int i = parentSchemas.size() - 1; i >= 0; i--) {
            SchemaSeed parentSchema = parentSchemas.get(i);
            List<SchemaConfigMap> configMaps = parentSchema.getSchemaConfigMaps();

            for (SchemaConfigMap schemaConfigMap : configMaps) {
                configXPaths.put(schemaConfigMap.getName(), schemaConfigMap.getXpath());
            }
        }

        List<SchemaConfigMap> configMaps = getSchemaConfigMaps();

        for (SchemaConfigMap schemaConfigMap : configMaps) {
            configXPaths.put(schemaConfigMap.getName(), schemaConfigMap.getXpath());
        }

        return configXPaths;
    }

    /**
     * Return the seed file data for this schema object, or the first parent which has a schema file defined.
     *
     * @return the seed file data for this schema
     */
    public String getSeedFileData() {
        // Get seed file data for this instance
        if (getFileName() != null) {
            byte[] fileData = getFileData();
            if (fileData != null) {
                return new String(fileData);
            }
        }

        // If not found get seed file data from parent schemas
        for (SchemaSeed schema : getParentSchemas()) {
            if (schema.getFileName() != null) {
                byte[] fileData = schema.getFileData();
                if (fileData != null) {
                    return new String(fileData);
                }
            }
        }

        // No data found return null
        return null;
    }

    /**
     * Return the list of parent schemas for this schema.
     *
     * @return the list of parent schemas for this schema
     */
    public List<SchemaSeed> getParentSchemas() {

        int count = 0;

        List<SchemaSeed> schemaList = new ArrayList<SchemaSeed>();

        SchemaSeed parentSchema = getBaseSchema();
        while (parentSchema != null) {
            schemaList.add(parentSchema);
            parentSchema = parentSchema.getBaseSchema();

            count++;
            if (count > 10) {
                String msg = "configuration error with a circular relationship between schemas";
                String context = "Schema: " + getName() + ", ParentSchema: " + getBaseSchema().getName();
                String solution = "Edit Schema to ensure there is no circular relationship between parent schemas";
                throw new ApplicationException("SchemaError", msg, context, solution);
            }
        }

        return schemaList;
    }

}




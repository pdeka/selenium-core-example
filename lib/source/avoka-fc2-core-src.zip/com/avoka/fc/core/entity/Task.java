package com.avoka.fc.core.entity;

import com.avoka.core.crypto.AESSymetricalCipher;
import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.auto._Task;

public class Task extends _Task implements Auditable {

    private static final long serialVersionUID = 1L;

    public static final String TASK_STATUS_ASSIGNED = "Assigned";
    public static final String TASK_STATUS_EXPIRED = "Expired";
    public static final String TASK_STATUS_COMPLETED = "Completed";

    public static final String EMAIL_STATUS_READY = "Ready";
    public static final String EMAIL_STATUS_ERROR = "Error";
    public static final String EMAIL_STATUS_COMPLETED = "Completed";

    public static final String[] TASK_STATUS_VALUES = { TASK_STATUS_ASSIGNED, TASK_STATUS_COMPLETED, TASK_STATUS_EXPIRED };
    public static final String[] EMAIL_STATUS_VALUES = { EMAIL_STATUS_READY, EMAIL_STATUS_COMPLETED, EMAIL_STATUS_ERROR };

    /**
     * Set the task form XML.
     */
    public void setFormDataXmlString(String formXml){
        if (formXml != null) {
            byte[] compressedData = CoreUtils.encodeStringAsBytes(formXml);
            byte[] encryptedCompressedData = AESSymetricalCipher.encrypt(compressedData);

            setFormDataXml(encryptedCompressedData);
        } else {
            setFormDataXml(null);
        }
    }

    /**
     * Return the task form XML.
     */
    public String getFormDataXmlString(){
        byte[] encryptedCompressedData = getFormDataXml();
        if (encryptedCompressedData == null) {
            return null;
        }

        byte[] compressedData = AESSymetricalCipher.decrypt(encryptedCompressedData);

        return CoreUtils.decodeBytesAsString(compressedData);
    }

    /**
     * Set the task prefill XML.
     */
    public void setPrefillDataXmlString(String prefillXml){
        if (prefillXml != null) {
            byte[] compressedData = CoreUtils.encodeStringAsBytes(prefillXml);
            byte[] encryptedCompressedData = AESSymetricalCipher.encrypt(compressedData);

            setPrefillDataXml(encryptedCompressedData);
        } else {
            setPrefillDataXml(null);
        }
    }

    /**
     * Return the task prefill XML.
     */
    public String getPrefillDataXmlString(){
        byte[] encryptedCompressedData = getPrefillDataXml();
        if (encryptedCompressedData == null) {
            return null;
        }

        byte[] compressedData = AESSymetricalCipher.decrypt(encryptedCompressedData);

        return CoreUtils.decodeBytesAsString(compressedData);
    }

    public boolean isAssigned() {
        return Task.TASK_STATUS_ASSIGNED.equals(getTaskStatus());
    }

    public boolean isCompleted() {
        return Task.TASK_STATUS_COMPLETED.equals(getTaskStatus());
    }

    public boolean isExpired() {
        return Task.TASK_STATUS_EXPIRED.equals(getTaskStatus());
    }
}

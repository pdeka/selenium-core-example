/*
 * Copyright (c) 2007-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.entity;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.fc.core.entity.auto._PropertyType;

public class PropertyType extends _PropertyType implements Auditable {

    private static final long    serialVersionUID  = 1L;

    public static final String   DATA_TYPE_Boolean  = "Boolean";
    public static final String   DATA_TYPE_Image    = "Image";
    public static final String   DATA_TYPE_List     = "List";
    public static final String   DATA_TYPE_LongText = "Long Text";
    public static final String   DATA_TYPE_Number   = "Number";
    public static final String   DATA_TYPE_String   = "String";

    public static final String[] DATA_TYPES = { DATA_TYPE_Boolean, DATA_TYPE_Image, DATA_TYPE_List, DATA_TYPE_LongText, DATA_TYPE_Number, DATA_TYPE_String };

    public static final String   SCOPE_User        = "User";
    public static final String   SCOPE_Form        = "Form";
    public static final String   SCOPE_Client      = "Client";

    // This must be in alphabetical order so that binary searches work.
    public static final String[] SCOPES = { SCOPE_Client, SCOPE_Form, SCOPE_User };

    public static final String   CLIENT_Property_Logo                       = "Logo";
    public static final String   CLIENT_Property_URL                           = "URL";
    public static final String   CLIENT_Property_Payment_Credit_Card_Amex_Accepted
        = "Payment Credit Card Amex Accepted";
    public static final String   CLIENT_Property_Payment_Credit_Card_MasterCard_Accepted
        = "Payment Credit Card MasterCard Accepted";
    public static final String   CLIENT_Property_Payment_Credit_Card_Visa_Accepted
        = "Payment Credit Card Visa accepted";


    public static final String   FORM_Property_AttachmentsSingleSubmitMethod = "Attachments Single Submit Method";
    public static final String   FORM_Property_Additional_Services           = "Additional Services";
    public static final String   FORM_Property_Eligibility                   = "Eligibility";
    public static final String   FORM_Property_Requirements                  = "Requirements";
    public static final String   FORM_Property_Submission_Message            = "Submission Message";

    public static final String   USER_Property_Email                         = "Email";
    public static final String   USER_Property_Given_Name                    = "Given Name";
    public static final String   USER_Property_Family_Name                   = "Family Name";


    public static boolean isValid(String type, String value) {
        Validate.notNull(type, "Null type parameter");

        if (StringUtils.isNotBlank(value)) {
            value = value.trim();

            if (DATA_TYPE_String.equals(type)) {
                return true;

            } else if (DATA_TYPE_Number.equals(type)) {
                try {
                    Double.parseDouble(value);
                    return true;

                } catch (NumberFormatException nfe) {
                    return false;
                }
            } else if (DATA_TYPE_Boolean.equals(type)) {
                if ("true".equals(value)) {
                    return true;

                } else if ("false".equals(value)) {
                    return true;

                } else {
                    return false;
                }

            } else if (DATA_TYPE_Image.equals(type)) {
                return true;

            } else if (DATA_TYPE_List.equals(type)) {
                return true;

            } else if (DATA_TYPE_LongText.equals(type)) {
                return true;

            } else {
                throw new IllegalArgumentException("Invalid type parameter: " + type);
            }

        } else {
            return true;
        }
    }
}

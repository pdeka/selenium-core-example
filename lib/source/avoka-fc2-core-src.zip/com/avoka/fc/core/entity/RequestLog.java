package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._RequestLog;

public class RequestLog extends _RequestLog {

    private static final long serialVersionUID = 1L;

    public static final String MODE_FORM      = "Form";
    public static final String MODE_PDF      = "PDF";
    public static final String MODE_XML_DATA = "XML Data";

    public static final String[] MODES = { MODE_FORM, MODE_PDF, MODE_XML_DATA };

}




package com.avoka.fc.core.entity;

import com.avoka.core.crypto.AESSymetricalCipher;
import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.auto._SubmissionHistoryData;

public class SubmissionHistoryData extends _SubmissionHistoryData {

    private static final long serialVersionUID = 1L;

    /**
     * Set the submission XML.
     */
    public void setSubmissionHistoryDataString(String formXml){
        if (formXml != null) {
            byte[] compressedData = CoreUtils.encodeStringAsBytes(formXml);
            byte[] encryptedCompressedData = AESSymetricalCipher.encrypt(compressedData);
            setSubmissionHistoryData(encryptedCompressedData);
        } else {
            setSubmissionHistory(null);
        }
    }

    /**
     * Return the submission XML.
     */
    public String getSubmissionHistoryDataString(){
        byte[] encryptedCompressedData = getSubmissionHistoryData();
        byte[] compressedData = AESSymetricalCipher.decrypt(encryptedCompressedData);

        return CoreUtils.decodeBytesAsString(compressedData);
    }
}

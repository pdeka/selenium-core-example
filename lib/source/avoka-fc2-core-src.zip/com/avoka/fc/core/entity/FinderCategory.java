package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._FinderCategory;

public class FinderCategory extends _FinderCategory {

}

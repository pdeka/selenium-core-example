package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._ProcessingStatus;

public class ProcessingStatus extends _ProcessingStatus {

    private static final long serialVersionUID = 1L;

}

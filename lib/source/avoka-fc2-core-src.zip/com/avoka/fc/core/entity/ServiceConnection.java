package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._ServiceConnection;

public class ServiceConnection extends _ServiceConnection {

    private static final long serialVersionUID = 1L;

    public static final String DEFAULT_LC_ES_CONNECTION_NAME = "LiveCycle ES";

    public static final String DEFAULT_VIRUS_SCAN_CONNECTION_NAME = "Virus Scan";

}

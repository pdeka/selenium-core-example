package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._TemplateVersion;

public class TemplateVersion extends _TemplateVersion implements Auditable {

    private static final long serialVersionUID = 1L;

    public static String PUBLISH_STATUS_READY         = "Ready";
    public static String PUBLISH_STATUS_COMPLETE     = "Complete";
    public static String PUBLISH_STATUS_ERROR         = "Error";

    public static String FORM_TYPE_DYNAMIC_XML_FORM = "Dynamic XML Form";
    public static String FORM_TYPE_FORM_GUIDE         = "Form Guide";
    public static String FORM_TYPE_STATIC_PDF_FORM     = "Static PDF Form";

    public static String[] FORM_TYPES = {
        FORM_TYPE_DYNAMIC_XML_FORM,
        FORM_TYPE_FORM_GUIDE,
        FORM_TYPE_STATIC_PDF_FORM
    };

    public boolean isFormGuide() {
        return FORM_TYPE_FORM_GUIDE.equals(getFormType());
    }

    public boolean isValidateSubmission() {
        Boolean value = getValidateSubmissionFlag();
        if (value != null) {
            return value.booleanValue();
        } else {
            return false;
        }
    }

    public Long getFileSize() {
        // MAE 8/7/2008 - fixes strange Cayenne class cast exception where String value being returned
        Object value = readProperty(FILE_SIZE_PROPERTY);
        if (value != null) {
            return new Long(value.toString());
        } else {
            return null;
        }
    }

}

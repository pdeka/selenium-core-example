package com.avoka.fc.core.entity;

import java.util.Iterator;

import com.avoka.fc.core.entity.auto._Submission;
import com.avoka.fc.forms.api.utils.DataHashUtils;

public class Submission extends _Submission {

    private static final long    serialVersionUID                 = 1L;

    public static final String   STATUS_Saved                     = "Saved";
    public static final String   STATUS_Submitted                 = "Submitted";
    public static final String   STATUS_Required                  = "Required";
    public static final String   STATUS_Optional                  = "Optional";
    public static final String   STATUS_NotReady                  = "Not Ready";
    public static final String   STATUS_Ready                     = "Ready";
    public static final String   STATUS_DetailsRequired           = "Details Required";
    public static final String   STATUS_PaymentRequired           = "Payment Required";
    public static final String   STATUS_Sent_Email                = "Sent Email";
    public static final String   STATUS_Sent_WS                   = "Sent WS";
    public static final String   STATUS_Completed                 = "Completed";
    public static final String   STATUS_Undeliverable             = "Undeliverable";
    public static final String   STATUS_Error                     = "Error";
    public static final String   STATUS_Error_No_Data             = "Error - No Data";

    public static final String   PAYMENT_TYPE_Account             = "Account";
    public static final String   PAYMENT_TYPE_BPAY                = "BPAY";
    public static final String   PAYMENT_TYPE_CreditCard          = "Credit/Debit Card";
    public static final String   PAYMENT_TYPE_EFT                 = "EFT";

    public static final String[] FORM_STATUS_VALUES               = { STATUS_Saved, STATUS_Submitted, STATUS_Completed };
    public static final String[] ATTACHMENT_STATUS_VALUES         = { STATUS_Required, STATUS_Optional, STATUS_Completed };
    public static final String[] PAYMENT_STATUS_VALUES            = { STATUS_Required, STATUS_Error, STATUS_Completed };
    public static final String[] RECEIPT_STATUS_VALUES            = { STATUS_Completed, STATUS_Error, STATUS_Error_No_Data };
    public static final String[] DELIVERY_STATUS_VALUES           = { STATUS_NotReady, STATUS_Ready, STATUS_Sent_Email, STATUS_Sent_WS,
            STATUS_Completed, STATUS_Error, STATUS_Undeliverable };
    public static final String[] REMOTE_AUDIT_STATUS_VALUES       = { STATUS_Ready, STATUS_Completed, STATUS_Error, STATUS_Error_No_Data};
    public static final String[] PAYMENT_TYPE_VALUES              = { PAYMENT_TYPE_Account, PAYMENT_TYPE_BPAY,
            PAYMENT_TYPE_CreditCard, PAYMENT_TYPE_EFT            };

    public static final String DELIVERY_WEB_SERVICE_PULL             = "Web Service Pull";
    public static final String DELIVERY_WEB_SERVICE_PUSH_TYPE_2      = "Web Service Push Type 2";
    public static final String DELIVERY_WEB_SERVICE_PUSH_TYPE_1      = "Web Service Push Type 1";
    public static final String DELIVERY_EMAIL                        = "Email Delivery";
    public static final String DELIVERY_EMAIL_SECURE                 = "Email Delivery Secure";
    public static final String DELIVERY_PROCESS                      = "Delivery Process";
    public static final String DELIVERY_MANUAL                       = "Delivery Manual";

    /**
     * Calculates the form xml hash using the submitted xml string (stored in the SubmissionData entity).
     * If the SubmissionData is not set or contains no data, the form xml hash is not modified.
     */
    public void calculateFormXmlHash() {
        SubmissionData submissionData = getSubmissionData();
        if (submissionData != null) {
            String submissionDataString = submissionData.getSubmissionDataString();
            if (submissionDataString != null) {
                String formXmlHash = DataHashUtils.toSHA256Hash(submissionDataString);
                setFormXmlHash(formXmlHash);
            }
        }
    }

    /**
     * Return true if the form is in test mode.
     *
     * @return true if the form is in test mode
     */
    public boolean isTestMode(){
        Boolean testMode = getTestMode();
        if (testMode != null) {
            return testMode.booleanValue();
        } else {
            return false;
        }
    }

    /**
     * Return true if the form status is saved.
     *
     * @return true if the form status is saved
     */
    public boolean isFormSaved(){
        return STATUS_Saved.equals(getFormStatus());
    }

    /**
     * Return true if the form status is submitted.
     *
     * @return true if the form status is submitted
     */
    public boolean isFormSubmitted(){
        return STATUS_Submitted.equals(getFormStatus());
    }

    /**
     * Return true if the form status is completed.
     *
     * @return true if the form status is completed
     */
    public boolean isFormCompleted(){
        return STATUS_Completed.equals(getFormStatus());
    }

    /**
     * Return true if the receipt status is completed.
     *
     * @return true if the receipt status is completed
     */
    public boolean isReceiptCompleted(){
        return STATUS_Completed.equals(getReceiptStatus());
    }

    /**
     * Return true if the submission has a receipt error.
     *
     * @return true if the submission has a receipt error
     */
    public boolean isReceiptError(){
        return STATUS_Error.equals(getReceiptStatus());
    }

    /**
     * Return true if the submission requires registration.
     *
     * @return true if the submission requires registration
     */
    public boolean isRegistrationRequired(){
        if (getForm().isRegistrationRequired()) {
            return true;

        } else {
            return hasMandatoryRequiredAttachments();
        }
    }

    /**
     * Return true if the submission has required attachments.
     *
     * @return true if the submission has required attachments
     */
    public boolean hasRequiredAttachments(){
        return !getRequiredAttachments().isEmpty();
    }

    /**
     * Return true if the submission has mandatory required attachments.
     *
     * @return true if the submission has mandatory required attachments
     */
    public boolean hasMandatoryRequiredAttachments(){
        for (Iterator i = getRequiredAttachments().iterator(); i.hasNext();) {
            RequiredAttachment ra = (RequiredAttachment) i.next();
            if (ra.isRequired()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return true if the submission has manually submitted attachments.
     *
     * @return true if the submission has manually submitted attachments
     */
    public boolean hasManuallySubmittedAttachments(){
        for (Iterator i = getRequiredAttachments().iterator(); i.hasNext();) {
            RequiredAttachment ra = (RequiredAttachment) i.next();
            if (ra.isSubmittedManually()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return true if the submission has required payment.
     *
     * @return true if the submission has required payment
     */
    public boolean isPaymentRequired(){
        String status = getPaymentStatus();
        return STATUS_Required.equalsIgnoreCase(status);
    }

    /**
     * Return true if the submission has a payment error.
     *
     * @return true if the submission has payment error
     */
    public boolean isPaymentError(){
        String status = getPaymentStatus();
        return STATUS_Error.equalsIgnoreCase(status);
    }

    /**
     * Return true if the submission payment has been completed.
     *
     * @return true if the submission payment has been completed
     */
    public boolean isPaymentCompleted(){
        String status = getPaymentStatus();
        return STATUS_Completed.equals(status);
    }

    /**
     * Return true if the submission payment type is "Account"
     *
     * @return true if the submission payment type is "Account"
     */
    public boolean isPaymentTypeAccount(){
        String type = getPaymentType();
        return PAYMENT_TYPE_Account.equals(type);
    }

    /**
     * Return true if the submission payment type is "BPAY"
     *
     * @return true if the submission payment type is "BPAY"
     */
    public boolean isPaymentTypeBPAY(){
        String type = getPaymentType();
        return PAYMENT_TYPE_BPAY.equals(type);
    }

    /**
     * Return true if the submission payment type is "Credit/Debit Card"
     *
     * @return true if the submission payment type is "Credit/Debit Card"
     */
    public boolean isPaymentTypeCreditCard(){
        String type = getPaymentType();
        return PAYMENT_TYPE_CreditCard.equals(type);
    }

    /**
     * Return true if the submission payment type is "EFT"
     *
     * @return true if the submission payment type is "EFT"
     */
    public boolean isPaymentTypeEFT(){
        String type = getPaymentType();
        return PAYMENT_TYPE_EFT.equals(type);
    }

    /**
     * Return true if the submission delivery has been completed.
     *
     * @return true if the submission delivery has been completed
     */
    public boolean isDeliveryCompleted(){
        String status = getDeliveryStatus();
        return STATUS_Completed.equals(status);
    }

    /**
     * Return true if the submission delivery has an error.
     *
     * @return true if the submission delivery has an error.
     */
    public boolean isDeliveryError(){
        String status = getDeliveryStatus();
        return STATUS_Error.equals(status);
    }

    /**
     * Return true if the submission delivery is ready.
     *
     * @return true if the submission delivery is ready.
     */
    public boolean isDeliveryReady(){
        String status = getDeliveryStatus();
        return STATUS_Ready.equals(status);
    }

    /**
     * Return true if the submission delivery is not ready.
     *
     * @return true if the submission delivery is not ready.
     */
    public boolean isDeliveryNotReady(){
        String status = getDeliveryStatus();
        return STATUS_NotReady.equals(status);
    }

    /**
     * Return true if the submission undeliverable.
     *
     * @return true if the submission undeliverable
     */
    public boolean isUndeliverable() {
        String status = getDeliveryStatus();
        return STATUS_Undeliverable.equals(status);
    }

    /**
     * Return true if the submission attachments have been completed.
     *
     * @return true if the submission attachments have been completed
     */
    public boolean isAttachmentsCompleted(){
        String status = getAttachmentsStatus();
        return STATUS_Completed.equals(status);
    }

    public boolean isAttachmentsOptional(){
        String status = getAttachmentsStatus();
        return STATUS_Optional.equals(status);
    }

    /**
     * Return true iff the user has completed everything about the submission (i.e. everything
     * that is outstanding are tasks performed by FormCenter, such as virus scanning)
     * @return true if the submission has been completed by the user
     */
    public boolean isUserWorkCompleted() {
        return isFormCompleted() || (isFormSubmitted()
                && (getAttachmentsStatus() == null || isAttachmentsCompleted())
                && (getPaymentStatus() == null || isPaymentCompleted()));
    }

    /**
     * Return true if form signatures are required.
     *
     * @return true if form signatures are required
     */
    public boolean isSignaturesRequired(){
        Boolean flag = getSignaturesRequiredFlag();
        if (flag != null) {
            return flag.booleanValue();
        } else {
            return false;
        }
    }

    // MAE - 15/6/2007 - Work around for Cayenne coercion error, started happening, why ??
    public Boolean getTestMode(){
        Object object = readProperty(TEST_MODE_PROPERTY);
        if (object instanceof Number) {
            Number value = (Number) object;
            // if we are in here then value cannot be null
            return (value.intValue() == 1) ? Boolean.TRUE : Boolean.FALSE;

        } else {
            return (Boolean) object;
        }
    }

    public boolean isDeleted(){
        Boolean flag = super.getDeletedFlag();
        if (flag != null) {
            return flag.booleanValue();
        } else {
            return false;
        }
    }

    /**
     * Return true if the form is in test mode.
     *
     * @return true if the form is in test mode
     */
    public boolean isSubmittedOffline(){
        Boolean submittedOffline = getSubmittedOfflineFlag();
        if (submittedOffline != null) {
            return submittedOffline.booleanValue();
        } else {
            return false;
        }
    }
}

/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on 1/10/2006 Created By pcopeland
 */

/*
 * CVS History
 *
 * $Revision: 1.9 $
 *
 * $Log: Form.java,v $
 * Revision 1.9  2009/01/28 22:34:58  medgar
 * *** empty log message ***
 *
 * Revision 1.8  2008/10/31 02:01:03  medgar
 * *** empty log message ***
 *
 * Revision 1.7  2008/10/20 01:19:14  medgar
 * FCT-183
 *
 * Revision 1.6  2008/10/08 05:15:41  lpammer
 * added three flags to the form entity
 *
 * Revision 1.5  2008/06/07 02:51:22  medgar
 * *** empty log message ***
 *
 * Revision 1.4  2008/05/19 08:29:25  medgar
 * *** empty log message ***
 *
 * Revision 1.3  2008/05/18 06:13:27  pcopeland
 * Adding FormPromotion Functionality
 *
 * Revision 1.2  2008/04/23 08:41:35  medgar
 * *** empty log message ***
 *
 * Revision 1.1  2008/03/17 02:12:49  medgar
 * initial import
 *
 * Revision 1.14  2007/05/10 15:12:31  medgar
 * *** empty log message ***
 *
 * Revision 1.13  2007/04/05 02:23:44  medgar
 * *** empty log message ***
 *
 * Revision 1.12  2007/04/04 02:30:10  pcopeland
 * Changes to the FormMetaData - renamed to MetaData and relationships added to Client and Template.
 *
 * Revision 1.11  2007/03/26 06:34:13  medgar
 * *** empty log message ***
 *
 * Revision 1.10  2007/03/05 02:52:37  medgar
 * *** empty log message ***
 *
 * Revision 1.9  2007/03/01 03:34:50  medgar
 * *** empty log message ***
 *
 * Revision 1.8  2007/02/07 04:03:53  medgar
 * *** empty log message ***
 *
 * Revision 1.7  2007/01/17 23:11:38  medgar
 * *** empty log message ***
 *
 * Revision 1.6  2007/01/15 00:18:13  medgar
 * fixed warning messages
 *
 * Revision 1.5  2007/01/11 20:15:05  pcopeland
 * Created new DAO Classes - refactored code to use DAOs
 *
 * Revision 1.4  2007/01/01 09:04:18  pcopeland
 * Completed initial development of Publisher Sync. Working on getting Publihser to render template
 *
 * Revision 1.3  2006/12/26 23:37:52  pcopeland
 * Completed Synchronisation of Templates. Renamed FormServer table to Publisher.
 * Revision 1.2 2006/11/30 05:05:16 medgar *** empty log message ***
 *
 * Revision 1.1 2006/11/29 03:55:21 dfrizelle *** empty log message ***
 *
 * Revision 1.1 2006/11/29 02:32:36 dfrizelle project refactoring
 *
 * Revision 1.4 2006/11/09 04:27:08 dfrizelle changed Integer back to Boolean
 *
 * Revision 1.3 2006/11/09 00:03:45 pcopeland Developed FormServer to render customer forms
 *
 * Revision 1.2 2006/10/19 05:54:18 dfrizelle removed redundant get Boolean methods now that active
 * flags are Boolean.
 *
 * Revision 1.1 2006/10/04 06:07:36 dfrizelle Initial Version
 *
 * Revision 1.1 2006/10/01 20:45:56 pcopeland Added
 *
 *
 */

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._Form;

public class Form extends _Form implements Auditable{

    private static final long  serialVersionUID            = 1L;

    public static final String DEFAULT_RECEIPT_NUMBER_PATTERN = "${formCode}-${submissionId}-${nextSequence}";

    public boolean isReceiptWsEnabled() {
        return Boolean.TRUE.equals(getReceiptWsFlag());
    }

    public boolean isPrefillRequired() {
        return Boolean.TRUE.equals(getPrefillRequiredFlag());
    }

    public boolean isSkipConfirmationPage() {
        return Boolean.TRUE.equals(getSkipConfirmationPageFlag());
    }

    public boolean isTestEnabled(){
        Boolean test = getTestEnabledFlag();
        if (test != null) {
            return test.booleanValue();
        } else {
            return false;
        }
    }

    public Boolean getActiveFlag(){
        Boolean response = super.getActiveFlag();
        if (response == null) {
            response = Boolean.FALSE;
        }
        return response;
    }

    public boolean isActive(){
        return getActiveFlag().booleanValue();
    }

    public Boolean getRegistrationFlag(){
        Boolean response = super.getRegistrationFlag();
        if (response == null) {
            response = Boolean.FALSE;
        }
        return response;
    }

    public boolean isRegistrationRequired(){
        return getRegistrationFlag().booleanValue();
    }

    public Boolean getSaveOnlineFlag(){
        Boolean response = super.getSaveOnlineFlag();
        if (response == null) {
            response = Boolean.FALSE;
        }
        return response;
    }

    public Boolean getPrefillRequiredFlag(){
        Boolean response = super.getPrefillRequiredFlag();
        if (response == null) {
            response = Boolean.FALSE;
        }
        return response;
    }

    public Boolean getReceiptEnabledFlag(){
        Boolean response = super.getReceiptEnabledFlag();
        if (response == null) {
            response = Boolean.FALSE;
        }
        return response;
    }

    public Boolean getReceiptWsFlag(){
        Boolean response = super.getReceiptWsFlag();
        if (response == null) {
            response = Boolean.FALSE;
        }
        return response;
    }

    public Boolean getSkipLandingPageFlag(){
        Boolean response = super.getSkipLandingPageFlag();
        if (response == null) {
            response = Boolean.FALSE;
        }
        return response;
    }

}

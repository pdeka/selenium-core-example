package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._PortalUser;

public class PortalUser extends _PortalUser {

}

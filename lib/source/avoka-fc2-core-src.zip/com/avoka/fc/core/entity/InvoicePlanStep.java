package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._InvoicePlanStep;

public class InvoicePlanStep extends _InvoicePlanStep {

    private static final long serialVersionUID = 1L;

}




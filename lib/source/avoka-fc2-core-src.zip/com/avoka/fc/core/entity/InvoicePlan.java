package com.avoka.fc.core.entity;

import java.util.Collections;
import java.util.List;

import org.apache.cayenne.query.Ordering;

import com.avoka.fc.core.entity.auto._InvoicePlan;

public class InvoicePlan extends _InvoicePlan {

    public List getStepsOrdered () {

        List planStepList = this.getStep();

        Collections.sort(planStepList, new Ordering(InvoicePlanStep.STEP_START_PROPERTY, Ordering.ASC));

        return planStepList;

    }

    private static final long serialVersionUID = 1L;

}




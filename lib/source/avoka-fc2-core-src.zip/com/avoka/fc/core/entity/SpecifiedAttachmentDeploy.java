package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._SpecifiedAttachmentDeploy;

public class SpecifiedAttachmentDeploy extends _SpecifiedAttachmentDeploy {

    private static final long serialVersionUID = 1L;

    public boolean isRequired() {
        Boolean required = getRequiredFlag();
        if (required != null) {
            return required.booleanValue();
        } else {
            return false;
        }
    }
}

package com.avoka.fc.core.entity;

import java.util.List;

import org.apache.commons.lang.Validate;

import com.avoka.fc.core.entity.auto._FormDeployXml;

public class FormDeployXml extends _FormDeployXml {

    private static final long serialVersionUID = 1L;

    /**
     * Return the Schema Config Map XPath for the given name.
     *
     * @param name the name of the Schema Config Map XPat
     * @return the schema config xpath
     */
    public String getSchemaConfigXPath(String name) {
        Validate.notNull(name, "Null name parameter");

        List<SchemaDeployMap> schemaDeployMaps = getSchemaDeployMaps();
        for (SchemaDeployMap schemaDeployMap : schemaDeployMaps) {
            if (name.equals(schemaDeployMap.getName())) {
                return schemaDeployMap.getXpath();
            }
        }

        return null;
    }

}

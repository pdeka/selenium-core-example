package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._PropertyDeploy;

public class PropertyDeploy extends _PropertyDeploy {

    private static final long serialVersionUID = 1L;

}

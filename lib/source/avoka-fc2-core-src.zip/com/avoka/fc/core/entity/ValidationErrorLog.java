package com.avoka.fc.core.entity;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.entity.auto._ValidationErrorLog;

public class ValidationErrorLog extends _ValidationErrorLog {

    private static final long serialVersionUID = 1L;

    public void setValidationErrors(String validationErrors) {
        super.setValidationErrors(validationErrors);

        int errorCount = 0;

        if (StringUtils.isNotBlank(validationErrors)) {
            try {
                Document document = XmlUtils.parseDocumentFromString(validationErrors);
                NodeList nodes = document.getDocumentElement().getChildNodes();

                for (int i = 0; i < nodes.getLength(); i++) {
                    Node node = nodes.item(i);
                    if (node.hasChildNodes()) {
                        errorCount++;
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                errorCount = -1;
            }
        }

        setNumberErrors(errorCount);
    }


}

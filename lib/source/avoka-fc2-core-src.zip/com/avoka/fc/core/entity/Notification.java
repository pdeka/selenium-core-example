package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._Notification;

public class Notification extends _Notification {

    private static final long serialVersionUID = 1L;

}




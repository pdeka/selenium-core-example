package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._DeploymentProperty;

public class DeploymentProperty extends _DeploymentProperty implements Auditable{

    // MAE - PHIL DONT Reformat this class!!

    private static final long    serialVersionUID                                 = 1L;

    public static final String   TYPE_BOOLEAN                                     = "Boolean";
    public static final String   TYPE_EMAIL                                       = "Email";
    public static final String   TYPE_NUMBER                                      = "Number";
    public static final String   TYPE_LONG_TEXT                                   = "Long Text";
    public static final String   TYPE_STRING                                      = "String";

    public static final String   PROPERTY_Admin_Console_Banner_Color              = "Admin Console Banner Color";
    public static final String   PROPERTY_Attachment_MaxEmbeddedSize              = "Attachments Max Embedded Size";
    public static final String   PROPERTY_Cache_Timeout                           = "Cache Timeout";
    public static final String   PROPERTY_Context                                 = "Context";
    public static final String   PROPERTY_Config_Directory                        = "Config Directory";
    public static final String   PROPERTY_Debug_Mode                              = "Debug Mode";
    public static final String   PROPERTY_Date_Format_Long                        = "Date Format Long";
    public static final String   PROPERTY_Date_Time_Format_Long                   = "Date Time Format Long";
    public static final String   PROPERTY_Display_Submission_External_User_ID     = "Display Submission External User ID";
    public static final String   PROPERTY_Display_Submission_FormCenter_User_ID   = "Display Submission FormCenter User ID";
    public static final String   PROPERTY_Duplicate_Submission_Rejection_Delay    = "Duplicate Submission Rejection Delay";

    public static final String   PROPERTY_Email_Lost_Password_Subject             = "Email Lost Password Subject";
    public static final String   PROPERTY_Email_Lost_Password_Message             = "Email Lost Password Message";
    public static final String   PROPERTY_Email_Promotion_Subject                 = "Email Promotion Subject";
    public static final String   PROPERTY_Email_Promotion_Message                 = "Email Promition Message";
    public static final String   PROPERTY_Email_Promotion_Sender                  = "Email Promotion Sender";
    public static final String   PROPERTY_Email_Receipt_Subject                   = "Email Receipt Subject";
    public static final String   PROPERTY_Email_Receipt_Message                   = "Email Receipt Message";
    public static final String   PROPERTY_Email_Report_Message                    = "Email Report Message";
    public static final String   PROPERTY_Email_Report_Sender                     = "Email Report Sender";
    public static final String   PROPERTY_Email_Report_Subject                    = "Email Report Subject";
    public static final String   PROPERTY_Email_Submission_Update_Subject         = "Email Submission Update Subject";
    public static final String   PROPERTY_Email_Submission_Update_Message         = "Email Submission Update Message";
    public static final String   PROPERTY_Email_Support_Sender                    = "Email Support Sender";
    public static final String   PROPERTY_Email_Task_Notification_Subject         = "Email Task Notification Subject";
    public static final String   PROPERTY_Email_Task_Notification_Message         = "Email Task Notification Message";
    public static final String   PROPERTY_Email_Task_Sender                       = "Email Task Sender";
    public static final String   PROPERTY_Email_Welcome_User_Subject              = "Email Welcome User Subject";
    public static final String   PROPERTY_Email_Welcome_User_Message              = "Email Welcome User Message";

    public static final String   PROPERTY_Enable_Script_Submissions               = "Enable Script Submissions";
    public static final String   PROPERTY_Enable_PDF_Submit_Attachment_Delivery   = "Enable PDF Submit Attachment Delivery";
    public static final String   PROPERTY_Environment_Name                        = "Environment Name";
    public static final String   PROPERTY_Export_Directory                        = "Export Directory";
    public static final String   PROPERTY_FormCenter_Log_File                     = "FormCenter Log File";
    public static final String   PROPERTY_Forms_WS_IP_Address_Filtering           = "Forms WS IP Address Filtering";
    public static final String   PROPERTY_HTTPS_Port                              = "HTTPS Port";
    public static final String   PROPERTY_IP_Address_Logging                      = "IP Address Logging";
    public static final String   PROPERTY_Import_Directory                        = "Import Directory";
    public static final String   PROPERTY_LiveCycle_Log_File                      = "LiveCycle Log File";
    public static final String   PROPERTY_Online_Save_Enabled                     = "Online Save Enabled";
    public static final String   PROPERTY_Publish_Templates_Directory             = "Publish Templates Directory";
    public static final String   PROPERTY_Publish_Templates_Share                 = "Publish Templates Share";
    public static final String   PROPERTY_Report_URL                              = "Report URL";
    public static final String   PROPERTY_Report_Internal_URL                     = "Report Internal URL";
    public static final String   PROPERTY_Report_Reschedule_Delay                 = "Report Reschedule Delay";
    public static final String   PROPERTY_Operation_Status                        = "Operation Status";
    public static final String   PROPERTY_Operation_Status_Message                = "Operation Status Message";
    public static final String   PROPERTY_Payment_Module_Enabled                  = "Payment Module Enabled";
    public static final String   PROPERTY_Portal_Form_Not_Found_URL               = "Portal Form Not Found URL";
    public static final String   PROPERTY_Portal_Submission_Offline_URL           = "Portal Submission Offline URL";
    public static final String   PROPERTY_Production_Mode                         = "Production Mode";
    public static final String   PROPERTY_Render_Service_Base_Path                = "Render Service Base Path";
    public static final String   PROPERTY_SMTP_Host                               = "SMTP Host";
    public static final String   PROPERTY_SMTP_User                               = "SMTP User";
    public static final String   PROPERTY_SMTP_Password                           = "SMTP Password";
    public static final String   PROPERTY_SMTP_Port                               = "SMTP Port";
    public static final String   PROPERTY_Supported_Delivery_Methods              = "Supported Delivery Methods";
    public static final String   PROPERTY_Portal_Cache_Enabled                    = "Portal Cache Enabled";

    public static final String   OPERATION_Status_Normal                          = "Normal";
    public static final String   OPERATION_Status_Restricted                      = "Restricted";
    public static final String   OPERATION_Status_Offline                         = "Offline";

    public static final String   PRODUCTION_Mode_Production                       = "Production";
    public static final String   PRODUCTION_Mode_Non_Production                   = "Non Production";

    public static final String[] OPERATION_Status_Options                         = { OPERATION_Status_Normal,
            OPERATION_Status_Restricted, OPERATION_Status_Offline                };

    public static final String[] PRODUCTION_Mode_Options                          = { PRODUCTION_Mode_Production,
            PRODUCTION_Mode_Non_Production                                       };

    public static final String[] NAMES                                            = {
        PROPERTY_Admin_Console_Banner_Color,
        PROPERTY_Attachment_MaxEmbeddedSize,
        PROPERTY_Cache_Timeout,
        PROPERTY_Context,
        PROPERTY_Config_Directory,
        PROPERTY_Debug_Mode,
        PROPERTY_Date_Format_Long,
        PROPERTY_Date_Time_Format_Long,
        PROPERTY_Display_Submission_External_User_ID,
        PROPERTY_Display_Submission_FormCenter_User_ID,
        PROPERTY_Duplicate_Submission_Rejection_Delay,
        PROPERTY_Email_Lost_Password_Subject,
        PROPERTY_Email_Lost_Password_Message,
        PROPERTY_Email_Promotion_Subject,
        PROPERTY_Email_Promotion_Message,
        PROPERTY_Email_Promotion_Sender,
        PROPERTY_Email_Receipt_Subject,
        PROPERTY_Email_Receipt_Message,
        PROPERTY_Email_Report_Message,
        PROPERTY_Email_Report_Sender,
        PROPERTY_Email_Report_Subject,
        PROPERTY_Email_Submission_Update_Subject,
        PROPERTY_Email_Submission_Update_Message,
        PROPERTY_Email_Support_Sender,
        PROPERTY_Email_Task_Notification_Subject,
        PROPERTY_Email_Task_Notification_Message,
        PROPERTY_Email_Task_Sender,
        PROPERTY_Email_Welcome_User_Subject,
        PROPERTY_Email_Welcome_User_Message,
        PROPERTY_Enable_PDF_Submit_Attachment_Delivery,
        PROPERTY_Enable_Script_Submissions,
        PROPERTY_Environment_Name,
        PROPERTY_Export_Directory,
        PROPERTY_FormCenter_Log_File,
        PROPERTY_Forms_WS_IP_Address_Filtering,
        PROPERTY_HTTPS_Port,
        PROPERTY_Import_Directory,
        PROPERTY_IP_Address_Logging,
        PROPERTY_LiveCycle_Log_File,
        PROPERTY_Online_Save_Enabled,
        PROPERTY_Publish_Templates_Directory,
        PROPERTY_Publish_Templates_Share,
        PROPERTY_Report_URL,
        PROPERTY_Report_Internal_URL,
        PROPERTY_Report_Reschedule_Delay,
        PROPERTY_Render_Service_Base_Path,
        PROPERTY_Operation_Status,
        PROPERTY_Operation_Status_Message,
        PROPERTY_Portal_Cache_Enabled,
        PROPERTY_Portal_Form_Not_Found_URL,
        PROPERTY_Portal_Submission_Offline_URL,
        PROPERTY_Production_Mode,
        PROPERTY_Payment_Module_Enabled,
        PROPERTY_SMTP_Host,
        PROPERTY_SMTP_User,
        PROPERTY_SMTP_Password,
        PROPERTY_SMTP_Port,
        PROPERTY_Supported_Delivery_Methods
    };

}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._ReportLog;

public class ReportLog extends _ReportLog {

    private static final long serialVersionUID = 1L;

}




package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._ReportParameter;

public class ReportParameter extends _ReportParameter {

    private static final long serialVersionUID = 1L;

}




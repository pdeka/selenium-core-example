package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._PaymentAccount;

public class PaymentAccount extends _PaymentAccount implements Auditable {

    private static final long serialVersionUID = 1L;

}




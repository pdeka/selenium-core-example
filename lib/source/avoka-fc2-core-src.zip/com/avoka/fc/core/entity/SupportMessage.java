package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._SupportMessage;

public class SupportMessage extends _SupportMessage  implements Auditable {

    private static final long serialVersionUID = 1L;

}




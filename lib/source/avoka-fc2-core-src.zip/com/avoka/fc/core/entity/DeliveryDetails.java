
package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._DeliveryDetails;

public class DeliveryDetails extends _DeliveryDetails implements Auditable {

    private static final long serialVersionUID = 1L;

    public static final String METHOD_EMAIL            = "Email";
    public static final String METHOD_EMAIL_SECURE     = "Email Secure";
    public static final String METHOD_LC_PROCESS       = "LC Process";
    public static final String METHOD_WEB_SERVICE      = "Web Service";

    public static final String[]     DELIVERY_METHODS = {
        METHOD_EMAIL, METHOD_EMAIL_SECURE, METHOD_LC_PROCESS, METHOD_WEB_SERVICE
    };

    /**
     * The Web Service "Pull" delivery method. Client to server polling, followed by client to server form
     * form submission synchronization methods.
     */
    public static final String DELIVERY_WS_MODE_PULL = "Pull";

    /**
     * The Web Service "Push Type 1" delivery method. Server to client notification, followed by client to server
     * form submission synchronization methods.
     */
    public static final String DELIVERY_WS_MODE_PUSH_TYPE_1 = "Push Type 1";

    /**
     * The Web Service "Push Type 2" delivery method. Atomic server to client form submission operation.
     */
    public static final String DELIVERY_WS_MODE_PUSH_TYPE_2 = "Push Type 2";

    public static final String[] DELIVERY_WS_MODES = {
        DELIVERY_WS_MODE_PULL, DELIVERY_WS_MODE_PUSH_TYPE_1, DELIVERY_WS_MODE_PUSH_TYPE_2 };

    /**
     * Return true if PDF should be delivered.
     *
     * @return true if PDF should be delivered.
     */
    public boolean isDeliverPdf() {
        Boolean value = getDeliverPdfFlag();

        return (value != null) ? value.booleanValue() : false;
    }
    /**
     * Return true if transformed XML should be delivered.
     *
     * @return true if transformed XML should be delivered.
     */
    public boolean isDeliverTransformXml() {
        Boolean value = getDeliverTransformXmlFlag();

        return (value != null) ? value.booleanValue() : false;
    }

    /**
     * Return true if XML should be delivered.
     *
     * @return true if XML should be delivered.
     */
    public boolean isDeliverXml() {
        Boolean value = getDeliverXmlFlag();

        return (value != null) ? value.booleanValue() : false;
    }

    /**
     * Return true if delivery method is Web Service and delivery mode Push Type 1 or Push Type 2.
     *
     * @return true if delivery method is Web Service and delivery mode Push Type 1 or Push Type 2
     */
    public boolean isWebServicePushDelivery() {
        if (METHOD_WEB_SERVICE.equals(getDeliveryMethod())) {
            String mode = getDeliveryWsMode();

            return DELIVERY_WS_MODE_PUSH_TYPE_1.equals(mode) || DELIVERY_WS_MODE_PUSH_TYPE_2.equals(mode);

        } else {
            return false;
        }
    }

    public boolean isWsPushModeType1() {
        return DELIVERY_WS_MODE_PUSH_TYPE_1.equals(getDeliveryWsMode());
    }

    public boolean isWsPushModeType2() {
        return DELIVERY_WS_MODE_PUSH_TYPE_2.equals(getDeliveryWsMode());
    }

    public boolean isEmailDeliveryMethod() {
        return METHOD_EMAIL.equals(getDeliveryMethod());
    }

    public boolean isEmailSecureDeliveryMethod() {
        return METHOD_EMAIL_SECURE.equals(getDeliveryMethod());
    }

}

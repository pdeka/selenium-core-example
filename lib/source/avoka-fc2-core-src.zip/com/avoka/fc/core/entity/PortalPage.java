package com.avoka.fc.core.entity;

import java.util.Date;

import com.avoka.fc.core.entity.auto._PortalPage;

public class PortalPage extends _PortalPage {

    // constants
    private static final long serialVersionUID = 1L;

    public static final String   PAGE_Form_Error                   = "Form Error";
    public static final String   PAGE_Form_Landing                 = "Form Landing";
    public static final String   PAGE_Form_Not_Found               = "Form Not Found";
    public static final String   PAGE_Incompatible_Reader          = "Incompatible Reader Version";
    public static final String   PAGE_Offline                      = "Offline";
    public static final String   PAGE_Submission_Attachment        = "Submission Attachment";
    public static final String   PAGE_Submission_Confirmation      = "Submission Confirmation";
    public static final String   PAGE_Submission_Errors            = "Submission Errors";
    public static final String   PAGE_Submission_Expired           = "Submission Expired";
    public static final String   PAGE_Submission_Failed            = "Submission Failed";
    public static final String   PAGE_Submission_Payment           = "Submission Payment";
    public static final String   PAGE_Submission_Payment_Complete  = "Submission Payment Complete";
    public static final String   PAGE_Submission_Saved             = "Submission Saved";

    public static final String[] PAGES = { PAGE_Form_Error, PAGE_Form_Landing, PAGE_Form_Not_Found, PAGE_Incompatible_Reader, PAGE_Offline, PAGE_Submission_Attachment, PAGE_Submission_Confirmation, PAGE_Submission_Errors, PAGE_Submission_Expired, PAGE_Submission_Failed, PAGE_Submission_Payment, PAGE_Submission_Payment_Complete, PAGE_Submission_Saved };

    @Override
    public void setContent(byte[] content) {
        // Move current content to history1
        setContentHistory1(getContent());
        setContentHistory1Timestamp(getContentTimestamp());

        setContentTimestamp(new Date());
        super.setContent(content);
    }

    @Override
    public void setContentHistory1(byte[] content) {
        // Move current history1 to history2
        setContentHistory2(getContentHistory1());
        setContentHistory2Timestamp(getContentHistory1Timestamp());
        super.setContentHistory1(content);
    }

    @Override
    public void setContentHistory2(byte[] content) {
        // Move current history2 to history3
        setContentHistory3(getContentHistory2());
        setContentHistory3Timestamp(getContentHistory2Timestamp());
        super.setContentHistory2(content);
    }

    @Override
    public void setContentBase(byte[] content) {
        setContentBaseTimestamp(new Date());
        super.setContentBase(content);
    }

    /**
     * Rollback portal page content to the content available in the webapp.
     */
    public void rollbackContent() {
        setContent(getContentBase());
    }

}

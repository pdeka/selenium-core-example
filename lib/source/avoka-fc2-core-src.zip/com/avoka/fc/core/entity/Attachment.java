
package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._Attachment;

public class Attachment extends _Attachment {

    private static final long  serialVersionUID = 1L;

    public static final String STATUS_Ready     = "Ready to Delete";
    public static final String STATUS_Purged    = "Deleted";
}

package com.avoka.fc.core.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.auto._FileUpload;

public class FileUpload extends _FileUpload {

    private static final long serialVersionUID = 1L;

    public static final String VIRUS_STATUS_SCAN_ERROR    = "Scan Error";
    public static final String VIRUS_STATUS_CLEAN         = "Clean";
    public static final String VIRUS_STATUS_VIRUS         = "Virus";

    /**
     * Return the unique file stored name.
     *
     * @return the unique store filename
     */
    public String getStoreName() {
        String fileName = getFileName();
        Date timeStamp = getUploadTimestamp();
        String userId = getUser().getId().toString();

        Validate.notNull(userId);
        Validate.notNull(timeStamp);
        Validate.notNull(fileName);

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd_hh.mm");

        String plainText = fileName + format.format(timeStamp) + userId;

        return CoreUtils.toMD5Hash(plainText);
    }

    public boolean isDeleted() {
        Boolean deletedFlag = getDeletedFlag();
        if (deletedFlag != null) {
            return deletedFlag.booleanValue();
        }
        return false;
    }
}




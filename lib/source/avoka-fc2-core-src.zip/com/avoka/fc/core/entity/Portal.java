package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._Portal;

public class Portal extends _Portal {

    private static final long serialVersionUID = 1L;

    public static final String PORTAL_ADMIN_CONSOLE = "Admin Console";

    public boolean isDefault() {
        Boolean defaultFlag = super.getDefaultFlag();
        if (defaultFlag == null) {
            return false;
        }
        return defaultFlag.booleanValue();
    }

    public boolean isEditable() {
        Boolean editableFlag = super.getEditableFlag();
        if (editableFlag == null) {
            return false;
        }
        return editableFlag.booleanValue();
    }

    public boolean isForms() {
        Boolean formsFlag = super.getFormsFlag();
        if (formsFlag == null) {
            return false;
        }
        return formsFlag.booleanValue();
    }

    public boolean isAdminConsolePortal() {
        return PORTAL_ADMIN_CONSOLE.equals(getName());
    }
}

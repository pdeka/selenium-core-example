
package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._ReportSchedule;

public class ReportSchedule extends _ReportSchedule implements Auditable {

    private static final long serialVersionUID = 1L;

    public static final String   TYPE_Day         = "Day";
    public static final String   TYPE_Week        = "Week";
    public static final String   TYPE_Month       = "Month";

    public static final String   DAY_Monday       = "Monday";
    public static final String   DAY_Tuesday      = "Tuesday";
    public static final String   DAY_Wednesday    = "Wednesday";
    public static final String   DAY_Thursday     = "Thursday";
    public static final String   DAY_Friday       = "Friday";
    public static final String   DAY_Saturday     = "Saturday";
    public static final String   DAY_Sunday       = "Sunday";

    public static final String   STATUS_Scheduled = "Scheduled";
    public static final String   STATUS_Running   = "Running";

    public static final String   FORMAT_TYPE_PDF  = "PDF";
    public static final String   FORMAT_TYPE_CSV  = "CSV";

    public static final String[] SCHEDULE_TYPES   = { TYPE_Day, TYPE_Week, TYPE_Month };
    public static final String[] FORMAT_TYPES     = { FORMAT_TYPE_PDF, FORMAT_TYPE_CSV };
    public static final String[] DAYS_OF_WEEK     = { DAY_Monday, DAY_Tuesday, DAY_Wednesday, DAY_Thursday, DAY_Friday, DAY_Saturday, DAY_Sunday };

}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._MetadataValueDeploy;

public class MetadataValueDeploy extends _MetadataValueDeploy {

    private static final long serialVersionUID = 1L;

}


package com.avoka.fc.core.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.auto._UserAccount;

public class UserAccount extends _UserAccount implements Auditable {

    private static final long serialVersionUID = 1L;

    public static final String FULL_NAME_PROPERTY = "fullName";
    public static final String ADMINISTRATOR_FLAG_PROPERTY = "administrator";

    public static final String ROOT_ADMIN = "administrator";

    /**
     * Return true if the user is an administrator (i.e. associated with the Admin Console portal).
     *
     * @return true if the user is an administrator
     */
    public boolean isAdministrator() {
        List<PortalUser> portalUsers = getPortalUsers();
        for (PortalUser portalUser: portalUsers) {
            if (portalUser.getPortal().isAdminConsolePortal()) {
                return true;
            }
        }
        return false;
    }

    public boolean getReceivePromotionAlerts() {
        List<UserGroup> userGroups = getUserGroups();
        for (UserGroup userGroup : userGroups) {
            if (userGroup.getGroup().getGroupName().equals(Group.RECEIVE_PROMOTION_ALERTS)) {
                return true;
            }
        }
        return false;
    }

    public boolean getReceiveAlertsFlag() {
        List<UserGroup> userGroups = getUserGroups();
        for (UserGroup userGroup : userGroups) {
            if (userGroup.getGroup().getGroupName().equals(Group.RECEIVE_SUBMISSION_ALERTS)) {
                return true;
            }
        }
        return false;
    }

    public boolean getReceiveSubmissionUpdates() {
        List<UserGroup> userGroups = getUserGroups();
        for (UserGroup userGroup : userGroups) {
            if (userGroup.getGroup().getGroupName().equals(Group.RECEIVE_SUBMISSION_UPDATES)) {
                return true;
            }
        }
        return false;
    }

    public String getPassword() {
        return CoreUtils.decrypt(super.getPassword());
    }

    /**
     * Change the password to the given value. No validation is performed on the password.
     *
     * @param value the new password value
     */
    public void setPassword(String value) {
        String encryptedPassword = CoreUtils.encrypt(value);

        super.setPassword(encryptedPassword);
    }

    /**
     * Validate the given password return null if sufficiently complex or otherwise
     * will return an error message.
     * <p/>
     * Valid passwords must be 6 characters in length, and contain a letter and
     * a character, and does not contain the text password.
     *
     * @param password the password to test
     * @return true if the password is valid
     */
    public String validatePassword(String password) {
        if (password == null) {
            return "Password value is required";
        }

        password = password.trim();
        if (password.length() < 6) {
            return "Password value is too short. Password must be at least 6 characters";
        }
        if (password.toLowerCase().indexOf("password") != -1) {
            return "Password must not contain the text 'password'";
        }
        if (password.length() > 36) {
            return "Password value is too long. Password must be no longer than 32 characters";
        }

        boolean numFound = false;
        boolean letterFound = false;

        for (int i = 0 ; i < password.length(); i++ ) {
            char aChar = password.charAt(i);
            if (Character.isDigit(aChar)) {
                numFound = true;
            }
            if (Character.isLetter(aChar)) {
                letterFound = true;
            }
        }

        if (!numFound) {
            return "Password must contain at least one number character.";
        }

        if (!letterFound) {
            return "Password must contain at least one letter character.";
        }

        return null;
    }

    public boolean isActive() {
        return (getActiveFlag() != null) ? getActiveFlag() : false;
    }

    /**
     * Return the currently active UserProfile for user.
     *
     * @return the currently active UserProfile for user
     */
    public UserProfile getActiveProfile() {
        List list = getUserProfiles();
        for (int i = 0; i < list.size(); i++) {
            UserProfile userProfile = (UserProfile) list.get(i);
            if (userProfile.getCurrentFlag().booleanValue() == true) {
                return userProfile;
            }
        }
        return null;
    }

    /**
     * Return the user profiles ordered with the active profile at the top.
     *
     * @return the user profiles ordered with the active profile at the top
     */
    public List<UserProfile> getUserProfilesOrdered() {
        List<UserProfile> list = getUserProfiles();

        Collections.sort(list, new Ordering(UserProfile.PROFILE_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE));

        // Place default profile at the start of the list
        List<UserProfile> newList = new ArrayList();

        for (Iterator<UserProfile> i = list.iterator(); i.hasNext();) {
            UserProfile up = i.next();
            if (up.isDefaultProfile()) {
                newList.add(up);
            }
        }
        for (Iterator<UserProfile> i = list.iterator(); i.hasNext();) {
            UserProfile up = i.next();
            if (!up.isDefaultProfile()) {
                newList.add(up);
            }
        }

        return newList;
    }

    public String getFullName() {
        String givenName = getGivenName();
        String familyName = getFamilyName();

        if (StringUtils.isNotEmpty(givenName)) {
            return givenName + " " + familyName;
        } else {
            return familyName;
        }
    }
}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._Group;

public class Group extends _Group {

    private static final long serialVersionUID = 1L;

    public static final String RECEIVE_PROMOTION_ALERTS     = "Receive Promotion Alerts";
    public static final String RECEIVE_SUBMISSION_ALERTS     = "Receive Submission Alerts";
    public static final String RECEIVE_SUBMISSION_UPDATES     = "Receive Submission Updates";

    public boolean isReadOnly() {
        return (getReadonlyFlag() != null) ? getReadonlyFlag() : false;
    }

}

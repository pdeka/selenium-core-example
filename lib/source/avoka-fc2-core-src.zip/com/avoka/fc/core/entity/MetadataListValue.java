package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._MetadataListValue;

public class MetadataListValue extends _MetadataListValue {

    private static final long serialVersionUID = 1L;

}

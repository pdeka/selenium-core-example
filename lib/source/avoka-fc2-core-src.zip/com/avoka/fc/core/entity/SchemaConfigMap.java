package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._SchemaConfigMap;

public class SchemaConfigMap extends _SchemaConfigMap {

    private static final long serialVersionUID = 1L;

    public static final String NAME_ATTACHMENTS                 = "Attachments";
    public static final String NAME_PAYMENT_DETAILS             = "PaymentDetails";
    public static final String NAME_RECEIPT                     = "Receipt";
    public static final String NAME_SIGNATURES_REQUIRED         = "SignaturesRequired";
    public static final String NAME_USER_PROFILE                = "UserProfile";
    public static final String NAME_USER_PROFILE_EMAIL          = "UserProfileEmail";

    public static final String[] NAMES = { NAME_ATTACHMENTS, NAME_PAYMENT_DETAILS,
        NAME_RECEIPT, NAME_SIGNATURES_REQUIRED, NAME_USER_PROFILE, NAME_USER_PROFILE_EMAIL
    };

}

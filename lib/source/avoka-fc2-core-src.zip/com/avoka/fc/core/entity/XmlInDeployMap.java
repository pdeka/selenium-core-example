package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._XmlInDeployMap;

public class XmlInDeployMap extends _XmlInDeployMap {

    private static final long serialVersionUID = 1L;

}

package com.avoka.fc.core.entity;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.auto._RequestLogData;

public class RequestLogData extends _RequestLogData {

    private static final long serialVersionUID = 1L;

    /**
     * Set the XML Data string value.
     */
    public void setRequestLogDataString(String formXml) {
        if (formXml != null) {
            byte[] compressedData = CoreUtils.encodeStringAsBytes(formXml);
            setRequestLogData(compressedData);

        } else {
            setRequestLogData(null);
        }
    }

    /**
     * Return the XML data string value.
     */
    public String getRequestLogDataString() {
        byte[] compressedData = getRequestLogData();

        if (compressedData != null) {
            return CoreUtils.decodeBytesAsString(compressedData);

        } else {
            return null;
        }
    }

    /**
     * Set the Prefill XML Data string value.
     */
    public void setPrefillDataString(String prefillXml) {
        if (prefillXml != null) {
            byte[] compressedData = CoreUtils.encodeStringAsBytes(prefillXml);
            setPrefillData(compressedData);

        } else {
            setPrefillData(null);
        }
    }

    /**
     * Return the Prefill XML data string value.
     */
    public String getPrefillDataString() {
        byte[] compressedData = getPrefillData();

        if (compressedData != null) {
            return CoreUtils.decodeBytesAsString(compressedData);

        } else {
            return null;
        }
    }
}

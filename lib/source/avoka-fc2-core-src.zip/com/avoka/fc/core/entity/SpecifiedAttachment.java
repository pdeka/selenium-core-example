
package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._SpecifiedAttachment;

public class SpecifiedAttachment extends _SpecifiedAttachment {

    private static final long    serialVersionUID         = 1L;

    public static final String   MAX_SIZE_500KB           = "0.5 MB";
    public static final String   MAX_SIZE_1MB             = "1 MB";
    public static final String   MAX_SIZE_2MB             = "2 MB";
    public static final String   MAX_SIZE_3MB             = "3 MB";
    public static final String   MAX_SIZE_5MB             = "5 MB";
    public static final String   MAX_SIZE_10MB            = "10 MB";
    public static final String[] MAX_SIZES                = { MAX_SIZE_500KB, MAX_SIZE_1MB, MAX_SIZE_2MB, MAX_SIZE_3MB, MAX_SIZE_5MB, MAX_SIZE_10MB };

    public static final String   SUBMIT_METHOD_Electronic = "Electronic";
    public static final String   SUBMIT_METHOD_Manual     = "Manual";
    public static final String[] SUBMIT_METHODS           = { SUBMIT_METHOD_Electronic, SUBMIT_METHOD_Manual };

    public boolean isRequired() {
        Boolean required = getRequiredFlag();
        if (required != null) {
            return required.booleanValue();
        } else {
            return false;
        }
    }
}

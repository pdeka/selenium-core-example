package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._Report;

public class Report extends _Report implements Auditable {

    private static final long serialVersionUID = 1L;

}




package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._XmlInputMap;

public class XmlInputMap extends _XmlInputMap {

    private static final long serialVersionUID = 1L;

}

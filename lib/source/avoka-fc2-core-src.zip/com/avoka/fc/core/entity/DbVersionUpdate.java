package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._DbVersionUpdate;

public class DbVersionUpdate extends _DbVersionUpdate {

    private static final long serialVersionUID = 1L;

}

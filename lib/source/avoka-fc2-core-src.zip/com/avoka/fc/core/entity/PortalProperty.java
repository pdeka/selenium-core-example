package com.avoka.fc.core.entity;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.auto._PortalProperty;

public class PortalProperty extends _PortalProperty {

    public static final String   TYPE_BOOLEAN                                     = "Boolean";
    public static final String   TYPE_DATE                                        = "Date";
    public static final String   TYPE_LIST                                        = "List";
    public static final String   TYPE_NUMBER                                      = "Number";
    public static final String   TYPE_STRING                                      = "String";

    public static final String[] TYPES = { TYPE_BOOLEAN, TYPE_DATE, TYPE_LIST, TYPE_NUMBER, TYPE_STRING };

    public Map<String, String> getListValuesMap() {
        if (!TYPE_LIST.equals(getType())) {
            throw new RuntimeException("Attempted to call getListValuesMap() on a non-list parameter");
        }

        Map<String, String> result = new LinkedHashMap<String, String>();
        String listValues = getListValues();
        if (StringUtils.isEmpty(listValues)) {
            return result;
        }

        String[] values = listValues.split("\\|");

        for (String value : values) {
            result.put(value, value);
        }

        return result;
    }
}

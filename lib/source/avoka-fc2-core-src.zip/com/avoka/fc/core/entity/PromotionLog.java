package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._PromotionLog;

public class PromotionLog extends _PromotionLog{

    /**
     *
     */
    private static final long    serialVersionUID                          = 5497877539985682514L;

    public static final String   PROMOTION_STATUS_DEVELOPMENT              = "Development";
    public static final String   PROMOTION_STATUS_READY_FOR_TEST           = "Ready for Test";
    public static final String   PROMOTION_STATUS_TEST_FAILED              = "Test Failed";
    public static final String   PROMOTION_STATUS_TEST_PASSED              = "Test Passed";
    public static final String   PROMOTION_STATUS_READY_FOR_PRODUCTION     = "Ready For Production";
    public static final String   PROMOTION_STATUS_NOT_READY_FOR_PRODUCTION = "Not Ready For Production";
    public static final String   PROMOTION_STATUS_PRODUCTION               = "Production";

    public static final String[] PROMOTION_Status_Values                   = { PROMOTION_STATUS_DEVELOPMENT,
            PROMOTION_STATUS_READY_FOR_TEST, PROMOTION_STATUS_TEST_FAILED, PROMOTION_STATUS_TEST_PASSED,
            PROMOTION_STATUS_READY_FOR_PRODUCTION, PROMOTION_STATUS_NOT_READY_FOR_PRODUCTION, PROMOTION_STATUS_PRODUCTION };

}

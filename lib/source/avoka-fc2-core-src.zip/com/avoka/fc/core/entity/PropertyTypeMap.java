package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._PropertyTypeMap;

public class PropertyTypeMap extends _PropertyTypeMap {

    private static final long serialVersionUID = 1L;

}

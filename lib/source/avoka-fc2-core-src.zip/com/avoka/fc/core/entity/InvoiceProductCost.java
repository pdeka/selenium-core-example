package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._InvoiceProductCost;

public class InvoiceProductCost extends _InvoiceProductCost {

    private static final long serialVersionUID = 1L;

}




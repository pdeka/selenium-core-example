package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._MetadataValue;

public class MetadataValue extends _MetadataValue implements Auditable {

    private static final long serialVersionUID = 1L;

}




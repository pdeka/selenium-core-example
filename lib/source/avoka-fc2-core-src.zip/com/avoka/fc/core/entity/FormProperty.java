package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._FormProperty;

public class FormProperty extends _FormProperty  implements Auditable {

    private static final long serialVersionUID = 1L;

}




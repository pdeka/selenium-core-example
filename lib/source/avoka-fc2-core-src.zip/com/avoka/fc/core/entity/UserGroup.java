package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._UserGroup;

public class UserGroup extends _UserGroup {

}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._SchemaDeployMap;

public class SchemaDeployMap extends _SchemaDeployMap {

    private static final long serialVersionUID = 1L;

}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._TemplateVersionData;

public class TemplateVersionData extends _TemplateVersionData {

    private static final long serialVersionUID = 1L;

}


package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._EventLog;

public class EventLog extends _EventLog {

    private static final long    serialVersionUID    = 1L;

    public static final String    EVENT_TYPE_INFO        = "Info";
    public static final String    EVENT_TYPE_WARNING    = "Warning";
    public static final String    EVENT_TYPE_ERROR    = "Error";
    public static final String    EVENT_TYPE_SECURITY    = "Security";

    public static final String[] EVENT_TYPES = { EVENT_TYPE_INFO, EVENT_TYPE_WARNING, EVENT_TYPE_ERROR, EVENT_TYPE_SECURITY };

}

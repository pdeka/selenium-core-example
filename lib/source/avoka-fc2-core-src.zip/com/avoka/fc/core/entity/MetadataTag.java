package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._MetadataTag;

public class MetadataTag extends _MetadataTag implements Auditable {

    private static final long serialVersionUID = 1L;

    public static final String        PROPERTY_Scope_Client                    = "Client";
    public static final String      PROPERTY_Scope_Form                     = "Form";
    public static final String        PROPERTY_Scope_Template                    = "Template";

    public static final String      PROPERTY_Type_Date                      = "Date";
    public static final String      PROPERTY_Type_List                      = "List";
    public static final String      PROPERTY_Type_ListHierarchy             = "List Hierarchy";
    public static final String      PROPERTY_Type_Text                      = "Text";

    // This must be in alphabetical order so that binary searches work.
    public static final String[]    SCOPES =
        { PROPERTY_Scope_Client, PROPERTY_Scope_Form, PROPERTY_Scope_Template };

    public static final String[]    TYPES =
        { PROPERTY_Type_Date, PROPERTY_Type_List, PROPERTY_Type_ListHierarchy, PROPERTY_Type_Text };

    public boolean isRequired() {
        return Boolean.TRUE.equals(getRequiredFlag());
    }
}




package com.avoka.fc.core.entity;

import org.apache.commons.lang.WordUtils;

import com.avoka.fc.core.entity.auto._Permission;

public class Permission extends _Permission{

    private static final long    serialVersionUID                           = 1L;

    // Security Permissions used by Java code
    public final static String   PERMISSION_AUDIT_VIEW                      = "audit-view";

    public final static String   PERMISSION_ADMIN_DIRECTORY                 = "admin-directory";

    // Role Permissions
    public final static String   PERMISSION_ROLE_ASSIGN                     = "role-assign";
    public final static String   PERMISSION_ROLE_VIEW                       = "role-view";
    public final static String   PERMISSION_ROLE_EDIT                       = "role-edit";
    public final static String   PERMISSION_ROLE_REMOVE                     = "role-remove";

    // Group Permissions
    public final static String   PERMISSION_GROUP_VIEW                       = "group-view";
    public final static String   PERMISSION_GROUP_EDIT                       = "group-edit";
    public final static String   PERMISSION_GROUP_REMOVE                     = "group-remove";

    public final static String   PERMISSION_GROUP_ASSIGN                     = "group-assign";

    // Attachment Report Permissions
    public final static String   PERMISSION_ATTACHMENTMANAGEMENT_VIEW       = "attachment-management-view";
    public final static String   PERMISSION_ATTACHMENTREPORT_VIEW           = "attachment-report-view";

    // Delivery Details Permissions
    public final static String   PERMISSION_DELIVERYDETAILS_VIEW            = "delivery-details-view";
    public final static String   PERMISSION_DELIVERYDETAILS_EDIT            = "delivery-details-edit";
    public final static String   PERMISSION_DELIVERYDETAILS_REMOVE          = "delivery-details-remove";

    // Deployment Property Permissions
    public final static String   PERMISSION_DEPLOYMENTPROPERTY_VIEW         = "deployment-property-view";
    public final static String   PERMISSION_DEPLOYMENTPROPERTY_EDIT         = "deployment-property-edit";

    // Document Type Permissions
    public final static String   PERMISSION_DOCUMENTTYPE_VIEW               = "document-type-view";
    public final static String   PERMISSION_DOCUMENTTYPE_EDIT               = "document-type-edit";
    public final static String   PERMISSION_DOCUMENTTYPE_REMOVE             = "document-type-remove";

    // Finder Permission
    public final static String   PERMISSION_FINDER_VIEW                       = "finder-view";
    public final static String   PERMISSION_FINDER_EDIT                       = "finder-edit";
    public final static String   PERMISSION_FINDER_REMOVE                     = "finder-remove";

    // MetaData Tag Permissions
    public final static String   PERMISSION_METADATATAG_VIEW                = "metadata-tag-view";
    public final static String   PERMISSION_METADATATAG_EDIT                = "metadata-tag-edit";
    public final static String   PERMISSION_METADATATAG_REMOVE              = "metadata-tag-remove";

    // MetaData Value Permissions
    public final static String   PERMISSION_METADATAVALUE_VIEW              = "metadata-value-view";
    public final static String   PERMISSION_METADATAVALUE_EDIT              = "metadata-value-edit";
    public final static String   PERMISSION_METADATAVALUE_REMOVE            = "metadata-value-remove";

    // Form Permissions
    public final static String   PERMISSION_FORM_VIEW                       = "form-view";
    public final static String   PERMISSION_FORM_EDIT                       = "form-edit";
    public final static String   PERMISSION_FORM_REMOVE                     = "form-remove";
    public final static String   PERMISSION_FORM_TEST                       = "form-test";

    // Form Deploy XML Permissions
    public final static String   PERMISSION_FORMDEPLOY_VIEW                 = "form-deploy-view";

    // Client Permissions
    public final static String   PERMISSION_CLIENT_VIEW                     = "organization-view";
    public final static String   PERMISSION_CLIENT_EDIT                     = "organization-edit";
    public final static String   PERMISSION_CLIENT_REMOVE                   = "organization-remove";
    public final static String   PERMISSION_CLIENT_COPY                     = "organization-copy";

    public final static String   PERMISSION_CLIENTPAYMENT_EDIT              = "organization-payment-edit";

    public final static String   PERMISSION_PRODUCTION_MODE_VIEW            = "production-mode-view";

    // FormPropertyType Permissions
    public final static String   PERMISSION_PROPERTYTYPE_VIEW               = "property-type-view";
    public final static String   PERMISSION_PROPERTYTYPE_EDIT               = "property-type-edit";
    public final static String   PERMISSION_PROPERTYTYPE_REMOVE             = "property-type-remove";

    // Property Map Permissions
    public final static String   PERMISSION_PROPERTYMAP_VIEW                = "property-map-view";
    public final static String   PERMISSION_PROPERTYMAP_EDIT                = "property-map-edit";
    public final static String   PERMISSION_PROPERTYMAP_REMOVE              = "property-map-remove";

    // Client Property Permissions
    public final static String   PERMISSION_CLIENTPROPERTY_VIEW             = "organization-property-view";
    public final static String   PERMISSION_CLIENTPROPERTY_EDIT             = "organization-property-edit";
    public final static String   PERMISSION_CLIENTPROPERTY_REMOVE           = "organization-property-remove";

    // Client User Account Permissions
    public final static String   PERMISSION_PAYMENTACCOUNT_VIEW             = "payment-account-view";
    public final static String   PERMISSION_PAYMENTACCOUNT_EDIT             = "payment-account-edit";
    public final static String   PERMISSION_PAYMENTACCOUNT_REMOVE           = "payment-account-remove";

    // Form Property Permissions
    public final static String   PERMISSION_FORMPROPERTY_VIEW               = "form-property-view";
    public final static String   PERMISSION_FORMPROPERTY_EDIT               = "form-property-edit";
    public final static String   PERMISSION_FORMPROPERTY_REMOVE             = "form-property-remove";

    // Schema Permissions
    public final static String   PERMISSION_SCHEMA_VIEW                     = "schema-view";
    public final static String   PERMISSION_SCHEMA_EDIT                     = "schema-edit";
    public final static String   PERMISSION_SCHEMA_REMOVE                   = "schema-remove";

    // Server Log Permissions
    public final static String   PERMISSION_SERVERLOG_VIEW                  = "server-log-view";

    // Submission Permissions
    public final static String   PERMISSION_SUBMISSION_VIEW                 = "submission-view";
    public final static String   PERMISSION_SUBMISSION_EDIT                 = "submission-edit";

    // Submission Data View Permission
    public final static String   PERMISSION_SUBMISSIONDATA_VIEW             = "submission-data-view";

    // System Info Permissions
    public final static String   PERMISSION_SYSTEMINFO_VIEW                 = "system-info-view";

    // Task Permissions
    public final static String   PERMISSION_TASK_VIEW                       = "task-view";
    public final static String   PERMISSION_TASK_EDIT                       = "task-edit";
    public final static String   PERMISSION_TASK_REMOVE                     = "task-remove";
    public final static String   PERMISSION_TASKDATA_VIEW                   = "task-data-view";

    // Template Permissions
    public final static String   PERMISSION_TEMPLATE_VIEW                   = "template-view";
    public final static String   PERMISSION_TEMPLATE_EDIT                   = "template-edit";
    public final static String   PERMISSION_TEMPLATE_REMOVE                 = "template-remove";

    // Template Version Permissions
    public final static String   PERMISSION_TEMPLATEVERSION_VIEW            = "template-version-view";
    public final static String   PERMISSION_TEMPLATEVERSION_EDIT            = "template-version-edit";
    public final static String   PERMISSION_TEMPLATEVERSION_REMOVE          = "template-version-remove";

    // User Permissions
    public final static String   PERMISSION_USER_VIEW                       = "user-view";
    public final static String   PERMISSION_USER_EDIT                       = "user-edit";
    public final static String   PERMISSION_USER_REMOVE                     = "user-remove";

    // User Profile Permissions
    public final static String   PERMISSION_USERPROFILE_VIEW                = "user-profile-view";
    public final static String   PERMISSION_USERPROFILE_EDIT                = "user-profile-edit";
    public final static String   PERMISSION_USERPROFILE_REMOVE              = "user-profile-remove";

    // User Property Permissions
    public final static String   PERMISSION_USERPROPERTY_VIEW               = "user-property-view";
    public final static String   PERMISSION_USERPROPERTY_EDIT               = "user-property-edit";
    public final static String   PERMISSION_USERPROPERTY_REMOVE             = "user-property-remove";

    // Specified Attachments Permissions
    public final static String   PERMISSION_SPECIFIEDATTACHMENT_VIEW        = "specified-attachment-view";
    public final static String   PERMISSION_SPECIFIEDATTACHMENT_EDIT        = "specified-attachment-edit";
    public final static String   PERMISSION_SPECIFIEDATTACHMENT_REMOVE      = "specified-attachment-remove";

    public final static String   PERMISSION_DBVERSIONUPDATE_VIEW            = "db-version-update-view";

    // Error Log Permissions
    public final static String   PERMISSION_ERRORLOG_VIEW                   = "error-log-view";

    // Event Log Permissions
    public final static String   PERMISSION_EVENTLOG_VIEW                   = "event-log-view";

    // Import Export Log Permissions
    public final static String   PERMISSION_IMPORTEXPORTLOG_VIEW            = "import-export-log-view";

    // Payment Log Permissions
    public final static String   PERMISSION_PAYMENTLOG_VIEW                 = "payment-log-view";

    // Operation Status Permissions
    public final static String   PERMISSION_OPERATION_STATUS_VIEW           = "operation-status-view";
    public final static String   PERMISSION_OPERATION_STATUS_EDIT           = "operation-status-edit";

    // Operation Charts
    public final static String   PERMISSION_OPERATION_CHART_VIEW            = "operation-chart-view";

    // Operation Export Reports
    public final static String   PERMISSION_OPERATION_EXPORT_REPORT_VIEW    = "operation-export-report-view";

    // Operation Form Events
    public final static String   PERMISSION_OPERATION_FORM_EVENTS_VIEW      = "operation-form-events-view";

    // Notification Permissions
    public final static String   PERMISSION_NOTIFICATION_VIEW               = "notification-view";
    public final static String   PERMISSION_NOTIFICATION_EDIT               = "notification-edit";
    public final static String   PERMISSION_NOTIFICATION_REMOVE             = "notification-remove";

    // Production Mode Permissions
    public final static String   PERMISSION_PRODUCTIONMODE_VIEW             = "production-mode-view";

    // Remote Audit Log Permissions
    public final static String   PERMISSION_REMOTEAUDITLOG_VIEW             = "remote-audit-log-view";

    // Request Log Permissions
    public final static String   PERMISSION_REQUESTLOG_VIEW                 = "request-log-view";

    // Submission Data View Permission
    public final static String   PERMISSION_REQUESTDATA_VIEW                = "request-data-view";

    // Sync Log Permissions
    public final static String   PERMISSION_SUPPORTLOG_VIEW                 = "support-log-view";
    public final static String   PERMISSION_SUPPORTLOG_EDIT                 = "support-log-edit";
    public final static String   PERMISSION_SUPPORTLOG_REMOVE               = "support-log-remove";

    // Report Permissions
    public final static String   PERMISSION_REPORT_VIEW                     = "report-view";
    public final static String   PERMISSION_REPORT_EDIT                     = "report-edit";
    public final static String   PERMISSION_REPORT_REMOVE                   = "report-remove";
    public final static String   PERMISSION_REPORT_RENDER                   = "report-render";

    public final static String   PERMISSION_REPORT_SCHEDULE_VIEW            = "report-schedule-view";
    public final static String   PERMISSION_REPORT_SCHEDULE_EDIT            = "report-schedule-edit";
    public final static String   PERMISSION_REPORT_SCHEDULE_REMOVE          = "report-schedule-remove";
    public final static String   PERMISSION_REPORT_SCHEDULE_TRIGGER         = "report-schedule-trigger";

    public final static String   PERMISSION_SYSTEM_REPORT_SCHEDULE_VIEW     = "system-report-schedule-view";
    public final static String   PERMISSION_SYSTEM_REPORT_SCHEDULE_EDIT     = "system-report-schedule-edit";
    public final static String   PERMISSION_SYSTEM_REPORT_SCHEDULE_REMOVE   = "system-report-schedule-remove";
    public final static String   PERMISSION_SYSTEM_REPORT_SCHEDULE_TRIGGER  = "system-report-schedule-trigger";

    public final static String   PERMISSION_SERVICE_VIEW                    = "service-view";
    public final static String   PERMISSION_SERVICE_EDIT                    = "service-edit";
    public final static String   PERMISSION_SERVICE_REMOVE                  = "service-remove";

    // These are group level report view permissions
    public final static String   PERMISSION_REPORT_SUBMISSION               = "report-submission-view";

    // Import Export Permissions
    public final static String   PERMISSION_IMPORT_CLIENT                   = "import-organization";
    public final static String   PERMISSION_EXPORT_CLIENT                   = "export-organization";
    public final static String   PERMISSION_IMPORT_FORM                     = "import-form";
    public final static String   PERMISSION_EXPORT_FORM                     = "export-form";
    public final static String   PERMISSION_IMPORT_METADATA                 = "import-metadata";
    public final static String   PERMISSION_EXPORT_METADATA                 = "export-metadata";
    public final static String   PERMISSION_IMPORT_ROLES                    = "import-roles";
    public final static String   PERMISSION_EXPORT_ROLES                    = "export-roles";
    public final static String   PERMISSION_IMPORT_PORTAL                   = "import-portal";
    public final static String   PERMISSION_EXPORT_PORTAL                   = "export-portal";

    public final static String     PERMISSION_PORTAL_VIEW                        = "portal-view";
    public final static String     PERMISSION_PORTAL_EDIT                        = "portal-edit";
    public final static String     PERMISSION_PORTAL_REMOVE                    = "portal-remove";

    // Used in Promotion Log Screen to export a form version
    public final static String   PERMISSION_EXPORT_PromotionFormVersion     = "export-promotion-form-version";

    // Used in Promotion Log Screen to import a form version
    public final static String   PERMISSION_IMPORT_PromotionFormVersion     = "import-promotion-form-version";

    public static final String   PERMISSION_PROMOTION_L1_Development        = "Promotion-1-Developmnent";
    public static final String   PERMISSION_PROMOTION_L2_ReadyTest          = "Promotion-2-Ready for Test";
    public static final String   PERMISSION_PROMOTION_L3_TestFailed         = "Promotion-3-Test Failed";
    public static final String   PERMISSION_PROMOTION_L4_TestPassed         = "Promotion-4-Test Passed";
    public static final String   PERMISSION_PROMOTION_L5_ReadyProduction    = "Promotion-5-Ready for Production";
    public static final String   PERMISSION_PROMOTION_L6_NotReadyProduction = "Promotion-6-Not Ready for Production";
    public static final String   PERMISSION_PROMOTION_L7_Production         = "Promotion-7-Production";

    public static final String   PERMISSION_PROMOTION_VIEW                  = "promotion-view";

    public static final String   PERMISSION_EMAIL_DELIVERY_ACKNOWLEDGE     = "email-delivery-acknowledge";

    // NOTE: MAE - DONT REFORMAT THIS CLASS !!!

    // Permissions to load into database by default
    public final static String[] DEFAULT_PERMISSIONS  = {
            PERMISSION_ADMIN_DIRECTORY,
            PERMISSION_ATTACHMENTMANAGEMENT_VIEW,
            PERMISSION_ATTACHMENTREPORT_VIEW,
            PERMISSION_AUDIT_VIEW,
            PERMISSION_CLIENT_VIEW,
            PERMISSION_CLIENT_EDIT,
            PERMISSION_CLIENT_REMOVE,
            PERMISSION_CLIENT_COPY,
            PERMISSION_CLIENTPAYMENT_EDIT,
            PERMISSION_CLIENTPROPERTY_VIEW,
            PERMISSION_CLIENTPROPERTY_EDIT,
            PERMISSION_CLIENTPROPERTY_REMOVE,
            PERMISSION_DBVERSIONUPDATE_VIEW,
            PERMISSION_DELIVERYDETAILS_VIEW,
            PERMISSION_DELIVERYDETAILS_EDIT,
            PERMISSION_DELIVERYDETAILS_REMOVE,
            PERMISSION_DEPLOYMENTPROPERTY_VIEW,
            PERMISSION_DEPLOYMENTPROPERTY_EDIT,
            PERMISSION_DOCUMENTTYPE_VIEW,
            PERMISSION_DOCUMENTTYPE_EDIT,
            PERMISSION_DOCUMENTTYPE_REMOVE,
            PERMISSION_EMAIL_DELIVERY_ACKNOWLEDGE,
            PERMISSION_ERRORLOG_VIEW,
            PERMISSION_EVENTLOG_VIEW,
            PERMISSION_EXPORT_CLIENT,
            PERMISSION_EXPORT_FORM,
            PERMISSION_EXPORT_METADATA,
            PERMISSION_EXPORT_PromotionFormVersion,
            PERMISSION_EXPORT_PORTAL,
            PERMISSION_EXPORT_ROLES,
            PERMISSION_FINDER_VIEW,
            PERMISSION_FINDER_EDIT,
            PERMISSION_FINDER_REMOVE,
            PERMISSION_FORM_VIEW,
            PERMISSION_FORM_EDIT,
            PERMISSION_FORM_TEST,
            PERMISSION_FORM_REMOVE,
            PERMISSION_FORMDEPLOY_VIEW,
            PERMISSION_FORMPROPERTY_VIEW,
            PERMISSION_FORMPROPERTY_EDIT,
            PERMISSION_FORMPROPERTY_REMOVE,
            PERMISSION_GROUP_VIEW,
            PERMISSION_GROUP_EDIT,
            PERMISSION_GROUP_REMOVE,
            PERMISSION_GROUP_ASSIGN,
            PERMISSION_IMPORT_CLIENT,
            PERMISSION_IMPORT_FORM,
            PERMISSION_IMPORT_METADATA,
            PERMISSION_IMPORT_PromotionFormVersion,
            PERMISSION_IMPORT_PORTAL,
            PERMISSION_IMPORT_ROLES,
            PERMISSION_IMPORTEXPORTLOG_VIEW,
            PERMISSION_METADATATAG_VIEW,
            PERMISSION_METADATATAG_EDIT,
            PERMISSION_METADATATAG_REMOVE,
            PERMISSION_METADATAVALUE_VIEW,
            PERMISSION_METADATAVALUE_EDIT,
            PERMISSION_METADATAVALUE_REMOVE,
            PERMISSION_NOTIFICATION_VIEW,
            PERMISSION_NOTIFICATION_EDIT,
            PERMISSION_NOTIFICATION_REMOVE,
            PERMISSION_OPERATION_CHART_VIEW,
            PERMISSION_OPERATION_EXPORT_REPORT_VIEW,
            PERMISSION_OPERATION_FORM_EVENTS_VIEW,
            PERMISSION_OPERATION_STATUS_VIEW,
            PERMISSION_OPERATION_STATUS_EDIT,
            PERMISSION_PAYMENTLOG_VIEW,
            PERMISSION_PAYMENTACCOUNT_VIEW,
            PERMISSION_PAYMENTACCOUNT_EDIT,
            PERMISSION_PAYMENTACCOUNT_REMOVE,
            PERMISSION_PORTAL_VIEW,
            PERMISSION_PORTAL_EDIT,
            PERMISSION_PORTAL_REMOVE,
            PERMISSION_PRODUCTION_MODE_VIEW,
            PERMISSION_PROPERTYMAP_VIEW,
            PERMISSION_PROPERTYMAP_EDIT,
            PERMISSION_PROPERTYMAP_REMOVE,
            PERMISSION_PROPERTYTYPE_VIEW,
            PERMISSION_PROPERTYTYPE_EDIT,
            PERMISSION_PROPERTYTYPE_REMOVE,
            PERMISSION_PROMOTION_L1_Development,
            PERMISSION_PROMOTION_L2_ReadyTest,
            PERMISSION_PROMOTION_L3_TestFailed,
            PERMISSION_PROMOTION_L4_TestPassed,
            PERMISSION_PROMOTION_L5_ReadyProduction,
            PERMISSION_PROMOTION_L6_NotReadyProduction,
            PERMISSION_PROMOTION_L7_Production,
            PERMISSION_PROMOTION_VIEW,
            PERMISSION_REMOTEAUDITLOG_VIEW,
            PERMISSION_REPORT_SUBMISSION,
            PERMISSION_REPORT_VIEW,
            PERMISSION_REPORT_EDIT,
            PERMISSION_REPORT_REMOVE,
            PERMISSION_REPORT_RENDER,
            PERMISSION_REPORT_SCHEDULE_VIEW,
            PERMISSION_REPORT_SCHEDULE_EDIT,
            PERMISSION_REPORT_SCHEDULE_REMOVE,
            PERMISSION_REPORT_SCHEDULE_TRIGGER,
            PERMISSION_REQUESTLOG_VIEW,
            PERMISSION_REQUESTDATA_VIEW,
            PERMISSION_ROLE_ASSIGN,
            PERMISSION_ROLE_VIEW,
            PERMISSION_ROLE_EDIT,
            PERMISSION_ROLE_REMOVE,
            PERMISSION_SCHEMA_VIEW,
            PERMISSION_SCHEMA_EDIT,
            PERMISSION_SCHEMA_REMOVE,
            PERMISSION_SERVERLOG_VIEW,
            PERMISSION_SERVICE_VIEW,
            PERMISSION_SERVICE_EDIT,
            PERMISSION_SERVICE_REMOVE,
            PERMISSION_SPECIFIEDATTACHMENT_VIEW,
            PERMISSION_SPECIFIEDATTACHMENT_EDIT,
            PERMISSION_SPECIFIEDATTACHMENT_REMOVE,
            PERMISSION_SUBMISSION_VIEW,
            PERMISSION_SUBMISSION_EDIT,
            PERMISSION_SUBMISSIONDATA_VIEW,
            PERMISSION_SUPPORTLOG_VIEW,
            PERMISSION_SUPPORTLOG_EDIT,
            PERMISSION_SUPPORTLOG_REMOVE,
            PERMISSION_SYSTEMINFO_VIEW,
            PERMISSION_SYSTEM_REPORT_SCHEDULE_VIEW,
            PERMISSION_SYSTEM_REPORT_SCHEDULE_EDIT,
            PERMISSION_SYSTEM_REPORT_SCHEDULE_REMOVE,
            PERMISSION_SYSTEM_REPORT_SCHEDULE_TRIGGER,
            PERMISSION_TASK_VIEW,
            PERMISSION_TASK_EDIT,
            PERMISSION_TASK_REMOVE,
            PERMISSION_TASKDATA_VIEW,
            PERMISSION_TEMPLATE_VIEW,
            PERMISSION_TEMPLATE_EDIT,
            PERMISSION_TEMPLATE_REMOVE,
            PERMISSION_TEMPLATEVERSION_VIEW,
            PERMISSION_TEMPLATEVERSION_EDIT,
            PERMISSION_TEMPLATEVERSION_REMOVE,
            PERMISSION_USER_VIEW,
            PERMISSION_USER_EDIT,
            PERMISSION_USER_REMOVE,
            PERMISSION_USERPROFILE_VIEW,
            PERMISSION_USERPROFILE_EDIT,
            PERMISSION_USERPROFILE_REMOVE,
            PERMISSION_USERPROPERTY_VIEW,
            PERMISSION_USERPROPERTY_EDIT,
            PERMISSION_USERPROPERTY_REMOVE
    };

    public String getPermissionLabel(){
        String label = getPermissionName().replace('-', ' ');
        return WordUtils.capitalize(label);
    }

    public String getPermissionLabelWithPortal(){
        StringBuilder labelBuilder = new StringBuilder(getPermissionLabel());

        Portal portal = getPortal();
        labelBuilder.append(" [");
        labelBuilder.append(portal.getName());
        labelBuilder.append("]");

        return labelBuilder.toString();
    }
}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._PaymentLog;

public class PaymentLog extends _PaymentLog {

    private static final long serialVersionUID = 1L;

    public static final String   STATUS_Completed         = "Completed";
    public static final String   STATUS_Error               = "Error";

    public boolean isPaymentCompleted() {
        return STATUS_Completed.equals(getPaymentStatus());
    }

}




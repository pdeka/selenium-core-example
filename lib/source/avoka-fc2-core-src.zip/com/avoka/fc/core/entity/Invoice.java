package com.avoka.fc.core.entity;

import java.util.Collections;
import java.util.List;

import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SortOrder;

import com.avoka.fc.core.entity.auto._Invoice;

public class Invoice extends _Invoice {

public List getLineitemsOrderedDesc () {

        List lineItemList = this.getLineitem();

        Collections.sort(lineItemList, new Ordering(InvoiceLineitem.SEQUENCE_PROPERTY, SortOrder.DESCENDING_INSENSITIVE));

        return lineItemList;

    }

    private static final long serialVersionUID = 1L;

}




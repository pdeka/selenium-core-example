package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._FormReceiptSequence;

public class FormReceiptSequence extends _FormReceiptSequence {

}

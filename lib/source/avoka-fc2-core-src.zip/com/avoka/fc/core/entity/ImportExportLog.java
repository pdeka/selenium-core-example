package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._ImportExportLog;

public class ImportExportLog extends _ImportExportLog{

    private static final long    serialVersionUID    = 1L;

    public static final String   TYPE_ExportClient   = "export-client";
    public static final String   TYPE_ExportForm     = "export-form";
    public static final String   TYPE_ImportClient   = "import-client";
    public static final String   TYPE_ImportForm     = "import-form";
    public static final String   TYPE_ImportMetadata = "import-metadata";
    public static final String   TYPE_ExportMetadata = "export-metadata";
    public static final String   TYPE_ImportRoles    = "import-roles";
    public static final String   TYPE_ExportRoles    = "export-roles";
    public static final String   TYPE_ImportPortal   = "import-portal";
    public static final String   TYPE_ExportPortal   = "export-portal";

    public static final String[] IMPORT_EXPORT_TYPES = { TYPE_ExportClient, TYPE_ExportForm, TYPE_ImportClient, TYPE_ImportForm,
            TYPE_ImportRoles, TYPE_ExportRoles, TYPE_ImportMetadata, TYPE_ExportMetadata,
            TYPE_ImportPortal, TYPE_ExportPortal};

}

package com.avoka.fc.core.entity;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.auto._ServiceParameter;

public class ServiceParameter extends _ServiceParameter {

    private static final long serialVersionUID = 1L;

    public static final String   TYPE_BOOLEAN                                     = "Boolean";
    public static final String   TYPE_DATE                                        = "Date";
    public static final String   TYPE_EMAIL                                       = "Email";
    public static final String   TYPE_LIST                                        = "List";
    public static final String   TYPE_NUMBER                                      = "Number";
    public static final String   TYPE_STRING                                      = "String";

    public static final String[] TYPES = { TYPE_BOOLEAN, TYPE_DATE, TYPE_EMAIL, TYPE_LIST, TYPE_NUMBER, TYPE_STRING };

    public Map<String, String> getListValuesMap() {
        if (!TYPE_LIST.equals(getType())) {
            throw new RuntimeException("Attempted to call getListValues() on a non-list parameter");
        }

        Map<String, String> result = new LinkedHashMap<String, String>();
        String listValues = getListValues();
        if (StringUtils.isEmpty(listValues)) {
            return result;
        }

        String[] values = listValues.split("\\|");

        for (int i = 0; i < values.length; i++) {
            String[] valueLabelPair = values[i].split(":");
            if (valueLabelPair.length != 2) {
                throw new RuntimeException("Invalid value/label pair encountered: " + values[i]);
            }
            result.put(valueLabelPair[0], valueLabelPair[1]);
        }

        return result;
    }

    public boolean validateListValues() {
        if (!TYPE_LIST.equals(getType())) {
            throw new RuntimeException("Attempted to validate list values for a non-list parameter");
        }

        String listValues = getListValues();
        if (StringUtils.isEmpty(listValues)) {
            return true;
        }

        String[] values = listValues.split("\\|");

        for (int i = 0; i < values.length; i++) {
            String[] valueLabelPair = values[i].split(":");
            if (valueLabelPair.length != 2 || StringUtils.isEmpty(valueLabelPair[0]) || StringUtils.isEmpty(valueLabelPair[1])) {
                return false;
            }
        }
        return true;
    }
}

/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on 1/10/2006 Created By pcopeland
 */

package com.avoka.fc.core.entity;

import java.util.Collections;
import java.util.List;

import com.avoka.core.util.PropertyComparator;
import com.avoka.fc.core.entity.auto._Template;

public class Template extends _Template implements Auditable {

    private static final long serialVersionUID = 1L;

    /**
     * Return true if the template is active.
     */
    public boolean isActive() {
        Boolean active = getActiveFlag();
        if (active != null) {
            return active.booleanValue();

        } else {
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    public List<TemplateVersion> getVersions() {
        List versions = super.getVersions();

        Collections.sort(versions, new PropertyComparator(TemplateVersion.VERSION_NUMBER_PROPERTY));

        return versions;
    }

}

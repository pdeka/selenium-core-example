package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._AuditLog;

public class AuditLog extends _AuditLog {

    private static final long serialVersionUID = 1L;

    public static final String EVENT_TYPE_VIEW       = "View";
    public static final String EVENT_TYPE_CREATE     = "Create";
    public static final String EVENT_TYPE_UPDATE     = "Update";
    public static final String EVENT_TYPE_DELETE     = "Delete";

}




package com.avoka.fc.core.entity;

import com.avoka.core.crypto.AESSymetricalCipher;
import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.auto._SubmissionData;

public class SubmissionData extends _SubmissionData {

    private static final long serialVersionUID = 1L;

    /**
     * Set the submission XML.
     */
    public void setSubmissionDataString(String formXml){
        if (formXml != null) {
            byte[] compressedData = CoreUtils.encodeStringAsBytes(formXml);
            byte[] encryptedCompressedData = AESSymetricalCipher.encrypt(compressedData);

            setSubmissionData(encryptedCompressedData);
        } else {
            setSubmissionData(null);
        }
    }

    /**
     * Return the submission XML.
     */
    public String getSubmissionDataString(){
        byte[] encryptedCompressedData = getSubmissionData();
        byte[] compressedData = AESSymetricalCipher.decrypt(encryptedCompressedData);

        return CoreUtils.decodeBytesAsString(compressedData);
    }
}

package com.avoka.fc.core.entity;

import com.avoka.fc.core.entity.auto._RequiredAttachment;

public class RequiredAttachment extends _RequiredAttachment {

    private static final long serialVersionUID = 1L;

    public static final String   SUBMIT_METHOD_Electronic = "Electronic";
    public static final String   SUBMIT_METHOD_Manual     = "Manual";

    public boolean isRequired() {
        Boolean required = getRequiredFlag();
        return (required != null) ? required.booleanValue() : false;
    }

    public boolean isSubmitElectronic() {
        String method = getSubmitMethod();
        return (SUBMIT_METHOD_Electronic.equals(method));
    }

    public boolean isSubmitManual() {
        String method = getSubmitMethod();
        return (SUBMIT_METHOD_Manual.equals(method));
    }

    public boolean isSubmittedManually() {
        Boolean value = getSubmitManuallyFlag();
        if (value != null) {
            return value.booleanValue();
        } else {
            return false;
        }
    }

}




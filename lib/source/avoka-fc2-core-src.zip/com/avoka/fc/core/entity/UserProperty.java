package com.avoka.fc.core.entity;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.auto._UserProperty;

public class UserProperty extends _UserProperty implements Auditable {

    private static final long serialVersionUID = 1L;

    public void setValue(String value) {
        if (StringUtils.isNotBlank(value)) {
            value = StringUtils.replace(value, "&", "and");
            value = StringUtils.replace(value, ">", "");
            value = StringUtils.replace(value, "<", "");
        }
        super.setValue(value);
    }

}




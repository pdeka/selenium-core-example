package com.avoka.fc.core.entity;

import java.util.Collections;
import java.util.List;

import com.avoka.core.util.PropertyComparator;
import com.avoka.fc.core.entity.auto._ServiceDefinition;

public class ServiceDefinition extends _ServiceDefinition {

    private static final long serialVersionUID = 1L;

    public static final String SERVICE_TYPE_CARD_PAYMENT                     = "Card Payment";
    public static final String SERVICE_TYPE_DELIVERY_PROCESS                 = "Delivery Process";
    public static final String SERVICE_TYPE_FORM_EXPORT                     = "Form Export";
    public static final String SERVICE_TYPE_FORM_META_DATA                  = "Form Meta Data";
    public static final String SERVICE_TYPE_LIVECYCLE_MONITOR               = "LiveCycle Monitor";
    public static final String SERVICE_TYPE_LOG_PURGE                       = "Log Purge";
    public static final String SERVICE_TYPE_PUBLISH_TEMPLATE                 = "Publish Template";
    public static final String SERVICE_TYPE_REMOTE_AUDIT                    = "Remote Audit";
    public static final String SERVICE_TYPE_RENDER_FORM                     = "Render Form";
    public static final String SERVICE_TYPE_RENDER_OFFLINE_SUBMISSION_FORM    = "Render Offline Submission Form";
    public static final String SERVICE_TYPE_RENDER_RECEIPT                     = "Render Receipt";
    public static final String SERVICE_TYPE_SUBMISSION_DATA_EXTRACTION         = "Submission Data Extraction";
    public static final String SERVICE_TYPE_SUBMISSION_DATA_PURGE           = "Submission Data Purge";
    public static final String SERVICE_TYPE_SUBMISSION_DELIVERY             = "Submission Delivery";
    public static final String SERVICE_TYPE_SUBMISSION_RECEIPT             = "Submission Receipt";
    public static final String SERVICE_TYPE_SUMMARY_METRICS_GENERATOR       = "Summary Metrics Generator";
    public static final String SERVICE_TYPE_SUMMARY_METRICS_PUBLISHER       = "Summary Metrics Publisher";
    public static final String SERVICE_TYPE_SYNCHRONIZE_TEMPLATES            = "Synchronize Templates";
    public static final String SERVICE_TYPE_VIRUS_SCAN                         = "Virus Scan";

    public static final String[] SERVICE_TYPES = {
        SERVICE_TYPE_CARD_PAYMENT,
        SERVICE_TYPE_DELIVERY_PROCESS,
        SERVICE_TYPE_FORM_EXPORT,
        SERVICE_TYPE_FORM_META_DATA,
        SERVICE_TYPE_LIVECYCLE_MONITOR,
        SERVICE_TYPE_LOG_PURGE,
        SERVICE_TYPE_PUBLISH_TEMPLATE,
        SERVICE_TYPE_REMOTE_AUDIT,
        SERVICE_TYPE_RENDER_FORM,
        SERVICE_TYPE_RENDER_OFFLINE_SUBMISSION_FORM,
        SERVICE_TYPE_RENDER_RECEIPT,
        SERVICE_TYPE_SUBMISSION_DATA_EXTRACTION,
        SERVICE_TYPE_SUBMISSION_DATA_PURGE,
        SERVICE_TYPE_SUBMISSION_DELIVERY,
        SERVICE_TYPE_SUBMISSION_RECEIPT,
        SERVICE_TYPE_SUMMARY_METRICS_GENERATOR,
        SERVICE_TYPE_SUMMARY_METRICS_PUBLISHER,
        SERVICE_TYPE_SYNCHRONIZE_TEMPLATES,
        SERVICE_TYPE_VIRUS_SCAN
    };

    public boolean isDefaultType() {
        Boolean value = getServiceTypeDefaultFlag();
        return (value != null) ? value.booleanValue() : false;
    }

    public List<ServiceParameter> getParameters() {
        List<ServiceParameter> parameters = super.getParameters();

        Collections.sort(parameters, new PropertyComparator(ServiceParameter.NAME_PROPERTY));

        return parameters;
    }

}

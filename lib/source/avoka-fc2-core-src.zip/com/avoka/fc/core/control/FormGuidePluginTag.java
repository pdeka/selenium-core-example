package com.avoka.fc.core.control;

import java.util.HashMap;
import java.util.Map;

import org.apache.click.control.AbstractControl;
import org.apache.click.util.HtmlStringBuffer;
import org.apache.commons.lang.Validate;

import com.avoka.fc.common.Constants;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.servlet.FormRenderServlet;

/**
 * Provides a FormGuide object tag rendering control.
 * <p/>
 * Please ensure enclosing the HTML page does not include HTML transitional DOCTYPE tags otherwise this PDF will not
 * render.
 */
public class FormGuidePluginTag extends AbstractControl {

    private static final long serialVersionUID = 1L;

    private final Form form;
    private String loadingMessage = "This text is replaced by the Flash Player.";
    private String height = "100%";
    private String width = "100%";
    private String backgroundColor = "#ffffff";
    private String dataFlashVar;
    private String requestKey;

    // Constructor -------------------------------------------------------------

    public FormGuidePluginTag(String name, Form form) {
        Validate.notNull(name);
        Validate.notNull(form);

        setName(name);
        setId("flashcontent");

        this.form = form;
    }

    // Public Methods ---------------------------------------------------------

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(String backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public String getDataFlashVar() {
        return dataFlashVar;
    }

    public void setDataFlashVar(String dataFlashVar) {
        this.dataFlashVar = dataFlashVar;
    }

    public String getLoadingMessage() {
        return loadingMessage;
    }

    public void setLoadingMessage(String loadingMessage) {
        this.loadingMessage = loadingMessage;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getRequestKey() {
        return requestKey;
    }

    public void setRequestKey(String requestKey) {
        this.requestKey = requestKey;
    }

    @Override
    public String getTag() {
        return "div";
    }

    @Override
    public void render(HtmlStringBuffer buffer) {
        Map<String, String> model = new HashMap<String, String>();

        model.put("id", getId());
        model.put("loadingMessage", loadingMessage);
        model.put("url", getSourceURL());
        model.put("height", getHeight());
        model.put("width", getHeight());
        model.put("backgroundColor", getBackgroundColor());
        if (getDataFlashVar() != null) {
            model.put("dataFlashVar", getDataFlashVar());
        }

        buffer.append(getContext().renderTemplate(getClass(), model));
    }

    // Private Methods --------------------------------------------------------

    private String getSourceURL() {
        StringBuilder builder = new StringBuilder();

        builder.append(getContext().getRequest().getContextPath());
        builder.append(FormRenderServlet.SERVLET_URL);

        builder.append("?");
        builder.append(Constants.PARAM_FormCode);
        builder.append("=");
        builder.append(form.getClientFormCode());

        builder.append("&formGuideSWF=true");

        return builder.toString();
    }

}

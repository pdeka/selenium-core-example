package com.avoka.fc.core.control;

import org.apache.click.control.AbstractControl;
import org.apache.click.util.HtmlStringBuffer;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.ServletUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormPdfParams;
import com.avoka.fc.core.util.PortalUtils;

/**
 * Provides a PDF object tag rendering control.
 * <p/>
 * Please ensure enclosing the HTML page does not include HTML transitional DOCTYPE tags otherwise this PDF will not
 * render.
 */
public class PDFPluginTag extends AbstractControl {

    private static final long serialVersionUID = 1L;

    private final Form form;
    private String height = "100%";
    private String width = "100%";
    private String redirectTarget;
    private String xmlData;

    // Constructors -----------------------------------------------------------

    public PDFPluginTag(String name, Form form) {
        Validate.notNull(name);
        Validate.notNull(form);

        setName(name);
        this.form = form;

        // Ensure a session is available to support tag rendering
        getContext().getSession();
    }

    // Public Methods ---------------------------------------------------------

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getRedirectTarget() {
        return redirectTarget;
    }

    public void setRedirectTarget(String redirectTarget) {
        this.redirectTarget = redirectTarget;
    }

    public String getXmlData() {
        return xmlData;
    }

    public void setXmlData(String xmlData) {
        this.xmlData = xmlData;
    }

    @Override
    public String getTag() {
        return "object";
    }

    @Override
    public void render(HtmlStringBuffer buffer) {
        buffer.elementStart(getTag());

        buffer.appendAttribute("data", getFormPluginHref(false));
        buffer.appendAttribute("type", "application/pdf");
        if (StringUtils.isNotBlank(width)) {
            buffer.appendAttribute("width", width);
        }
        if (StringUtils.isNotBlank(height)) {
            buffer.appendAttribute("height", height);
        }


        buffer.closeTag();

        // Render alternative content, if plugin not available
        buffer.append("\n<div>\n");

        StringBuilder hrefBuilder = new StringBuilder();
        hrefBuilder.append(PortalUtils.getFormRenderURL(form));
        FormPdfParams formPdfParams = form.getPdfParams();
        if (formPdfParams != null) {
            formPdfParams.renderParam(hrefBuilder);
        }

        buffer.elementStart("a");
        buffer.appendAttribute("href", hrefBuilder.toString());
        buffer.appendAttribute("width", "100%");
        buffer.closeTag();
        buffer.append("If the form does not open in a few seconds, please click here...");
        buffer.elementEnd("a");

        buffer.append("\n</div>\n");

        buffer.elementEnd(getTag());
    }

    // Protected Methods ------------------------------------------------------

    protected String getFormPluginHref(boolean noPrefill) {
        StringBuilder builder = new StringBuilder();

        builder.append(PortalUtils.getFormRenderURL(form));

        builder.append("&uid=");
        builder.append(String.valueOf(System.currentTimeMillis()));

        if (noPrefill) {
            builder.append("&");
            builder.append(Constants.PARAM_NoUserAccountPrefill);
            builder.append("=true");
        }

        builder.append("&");
        builder.append(ServletUtils.PARAM_OBJECT_TAG);
        builder.append("=true");

        if (StringUtils.isNotBlank(getRedirectTarget())) {
            builder.append("&");
            builder.append(Constants.PARAM_RedirectTarget);
            builder.append("=");
            builder.append(getRedirectTarget());
        }

        if (xmlData != null) {
            URLCodec urlCodec = new URLCodec();
            try {
                String xmlDataEncoded = urlCodec.encode(xmlData);

                builder.append("&");
                builder.append(Constants.PARAM_XmlDataEncoded);
                builder.append("=");
                builder.append(xmlDataEncoded);

            } catch (EncoderException ee) {
                throw new RuntimeException("Could not encode XMLData: " + xmlData, ee);
            }
        }

        // do not add request parameters to the URL after these pdf parameters since they start with a '#', not with a '&'
        FormPdfParams formPdfParams = form.getPdfParams();
        if (formPdfParams != null) {
            formPdfParams.renderParam(builder);
        }

        return getContext().getResponse().encodeURL(builder.toString());
    }

}

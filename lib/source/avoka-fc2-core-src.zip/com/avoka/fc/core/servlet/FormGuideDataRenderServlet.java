package com.avoka.fc.core.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.MessageFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.click.util.ClickUtils;
import org.apache.commons.io.IOUtils;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.RequestLogData;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.FormDataService;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.InvalidParameterException;
import com.avoka.fc.forms.api.utils.DataHashUtils;

public class FormGuideDataRenderServlet extends RenderServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void executeRequest(HttpServletRequest request,
            HttpServletResponse response) throws ApplicationException,
            InvalidParameterException {

        final long start = System.currentTimeMillis();

        String formCode = request.getParameter(Constants.PARAM_FormCode);
        String xmlData = request.getParameter(Constants.PARAM_XmlData);

        FormDao formDao = DaoFactory.getFormDao();
        Form form = formDao.getFormByFormCode(formCode);
        if (form == null) {
            String msg = getClass().getSimpleName();
            String context = "formCode=" + formCode + ",xmlData=" + xmlData;
            String userMsg = "Form not found for form code: " + formCode;
            throw new ApplicationException(msg, context, userMsg, null);
        }

        TemplateVersion templateVersion = form.getTemplate().getCurrentVersion();
        RequestLog requestLog = createRequestLog(request, form, templateVersion, null, null, RequestLog.MODE_XML_DATA);

        FormDataService formDataService = (FormDataService)
            getApplicationContext().getBean("formDataService");

        final long renderStart = System.currentTimeMillis();

        String formData = formDataService.populateSeedXml(form,
                                                          request,
                                                          false,
                                                          xmlData,
                                                          null,
                                                          true,
                                                          requestLog.getRequestKey(),
                                                          requestLog.getReferer(),
                                                          null);

        // Wrap form data in XFA element
        formData = getXDPModel(formData, form, templateVersion);

        RequestLogData requestLogData = requestLog.getRequestLogData();
        if (requestLogData == null) {
            requestLogData = new RequestLogData();
            getDataContext().registerNewObject(requestLogData);
            requestLogData.setRequestLog(requestLog);
        }
        requestLogData.setRequestLogDataString(formData);

        String xmlDataHash = DataHashUtils.toSHA256Hash(formData);
        requestLog.setSeedXmlHash(xmlDataHash);

        long renderTime = System.currentTimeMillis() - renderStart;
        requestLog.setDurationRender((int) renderTime);

        getDataContext().commitChanges();

        // URL encode value
        formData = ClickUtils.encodeURL(formData);

        final long streamStart = System.currentTimeMillis();

        OutputStream outputStream = null;
        try {
            byte[] formDataBytes = formData.getBytes();

            response.setContentType("text/plain");
            response.setContentLength(formDataBytes.length);
            response.setHeader("Pragma", "no-cache");
            response.setHeader("Cache-control", "no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
            response.setHeader(Constants.PARAM_RequestKey, requestLog.getRequestKey());

            outputStream = response.getOutputStream();
            outputStream.write(formDataBytes);
            outputStream.flush();

            long streamTime = System.currentTimeMillis() - streamStart;
            long totalTime = System.currentTimeMillis() - start;
            requestLog.setDurationClientResponse((int) streamTime);
            requestLog.setDurationTotal((int) totalTime);
            requestLog.setFormRenderedLength(formDataBytes.length);
            requestLog.setFormStreamedLength(formDataBytes.length);
            getDataContext().commitChanges();

        } catch (IOException ioe) {
            String msg = getClass().getSimpleName();
            String context = "formCode=" + formCode + ",xmlData=" + xmlData;
            String userMsg = ioe.getMessage();
            throw new ApplicationException(msg, ioe, context, userMsg, null);

        } finally {
            IOUtils.closeQuietly(outputStream);
        }
    }

    private String getXDPModel(String seedXML, Form form, TemplateVersion templateVersion) {

        String seedXmlBody = seedXML.substring(seedXML.indexOf(">") + 1);

        String xfaDataXml = getXfaDataXml();

        DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();

        String sharePath = dpDao.getPropertyValue(DeploymentProperty.PROPERTY_Publish_Templates_Share);
        if (!sharePath.endsWith("\\") && !sharePath.endsWith("/")) {
            sharePath += File.separator;
        }
        String templatePath = sharePath + templateVersion.getId() + File.separator;

        Portal portal = form.getPortal();
        String contextPath = portal.getContextPath();
        if (contextPath.endsWith("/")) {
            contextPath = contextPath.substring(0, contextPath.length() - 1);
        }
        String submitPath = contextPath + SubmissionServlet.SERVLET_URL;

        Object[] args = new String[]{
            seedXmlBody,
            templateVersion.getFileName(),
            submitPath,
            contextPath,
            templatePath
        };

        xfaDataXml = MessageFormat.format(xfaDataXml, args);

        org.w3c.dom.Document xdpDocument = XmlUtils.parseDocumentFromString(xfaDataXml);

        return XmlUtils.toString(xdpDocument);
    }

    private String getXfaDataXml() {
        InputStream is = ClickUtils.getResourceAsStream("/com/avoka/fc/core/servlet/xfadata.xml", getClass());
        try {
            return IOUtils.toString(is);

        } catch (IOException ioe) {
            throw new RuntimeException(ioe);

        } finally {
            IOUtils.closeQuietly(is);
        }
    }

}

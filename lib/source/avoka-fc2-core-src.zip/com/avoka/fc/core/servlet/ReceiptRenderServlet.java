/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on 1/10/2006 Created By pcopeland
 */
package com.avoka.fc.core.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.ServletUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.RequestLogData;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ReceiptDataService;
import com.avoka.fc.core.service.RenderReceiptService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.InvalidParameterException;
import com.avoka.fc.forms.api.utils.DataHashUtils;

/**
 * The Formcenter2 PDF Receipt rendering servlet.
 *
 * @author pcopeland@avoka.com
 * @author medgar@avoka.com
 */
public class ReceiptRenderServlet extends RenderServlet{

    private static final long serialVersionUID = 1L;

    public static final String    SERVLET_URL           = "/servlet/FormReceipt.pdf";

    /**
     * Render the form receipt
     *
     * @see BaseServlet#executeRequest(HttpServletRequest, HttpServletResponse)
     */
    protected void executeRequest(HttpServletRequest request, HttpServletResponse response) throws ApplicationException,
            InvalidParameterException{

        final long executeStartTime = System.currentTimeMillis();

        // Check if the site is online.
        if (!isOperational(response, false)) {
            return;
        }

        // Prevent object tag double request being processed
        if (ServletUtils.isDoubleObjectTagRequest(request)) {
            return;
        }

        // Ensure submission key is available
        String submitKey = getParameterString(request, Constants.PARAM_SubmitKey);
        if (submitKey.length() == 0) {
            if (getDeploymentPropertyDao().isDebugMode()) {
                String msg = "Not submitKey parameter defined for render request";
                getLogger().warn(msg);
            }
            return;
        }

        Submission submission = submissionDao.getSubmissionByKey(submitKey);

        if (submission == null) {
            String msg = "ReceiptRenderServlet submission not found for submitKey: " + submitKey;

            String referer = getRequest().getHeader("referer");
            if (StringUtils.isNotBlank(referer)) {
                msg += " Referer: " + referer;
            }

            EventLogService eventLogService = new EventLogService();
            eventLogService.logInfoEvent(msg);

            String path = getFormNotFoundPath();
            sendRedirect(request, response, path);
            return;
        }

        RequestLog requestLog = createRequestLog(request,
                                                 submission.getForm(),
                                                 submission.getVersion(),
                                                 submission,
                                                 submission.getTask(),
                                                 RequestLog.MODE_PDF);

        ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
        String xmlDataString = receiptDataService.getReceiptXml(submission);

        DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
        if (!dpDao.isProductionMode()) {
            RequestLogData requestLogData = new RequestLogData();
            getDataContext().registerNewObject(requestLogData);
            requestLogData.setRequestLogDataString(xmlDataString);
            requestLogData.setRequestLog(requestLog);
        }
        String xmlDataHash = DataHashUtils.toSHA256Hash(xmlDataString);
        requestLog.setSeedXmlHash(xmlDataHash);

        TemplateVersion templateVersion = submission.getVersion();
        requestLog.setTemplateVersion(templateVersion);

        // Render the Receipt
        ServiceDefinition sd = templateVersion.getReceiptRenderService();
        RenderReceiptService renderReceiptService = (RenderReceiptService)
            ServiceLocator.getServiceForDefinitionOrType(sd, ServiceDefinition.SERVICE_TYPE_RENDER_RECEIPT);

        renderReceiptService.renderReceipt(templateVersion, submission.getForm(), xmlDataString, request, response, requestLog);

        // Complete request log info
        final int executeDuration = (int) (System.currentTimeMillis() - executeStartTime);
        requestLog.setDurationTotal(new Integer(executeDuration));

        getDataContext().commitChanges();
    }

}

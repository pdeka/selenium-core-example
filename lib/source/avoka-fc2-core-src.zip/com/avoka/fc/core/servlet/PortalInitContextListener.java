package com.avoka.fc.core.servlet;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.cayenne.BaseContext;
import org.apache.cayenne.access.DataContext;

import com.avoka.fc.core.service.DatabaseConfigService;
import com.avoka.fc.core.util.RemoteUserProvider;

/**
 * Provides a servlet context listener to initialize the portal paths.
 */
public class PortalInitContextListener implements ServletContextListener {

    /**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        RemoteUserProvider.setRemoteUser("system");

        DataContext dataContext = DataContext.createDataContext(false);
        BaseContext.bindThreadObjectContext(dataContext);

        try {
            // Load default config settings
            DatabaseConfigService databaseConfigService = new DatabaseConfigService();
            databaseConfigService.loadConfiguration(null, servletContextEvent.getServletContext());

            dataContext.commitChanges();

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);

        } finally {
            BaseContext.bindThreadObjectContext(null);
            RemoteUserProvider.setRemoteUser(null);
        }
    }

    /**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0) {
    }

}

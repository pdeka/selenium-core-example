package com.avoka.fc.core.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Element;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.RequestLogDao;
import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalPage;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.SubmissionDataBean;
import com.avoka.fc.core.util.FormUtils;
import com.avoka.fc.core.util.PortalUtils;
import com.avoka.fc.core.util.SubmissionException;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

public class SubmissionTargetResolverImpl implements SubmissionTargetResolver {

    public String resolvePath(HttpServletRequest request, SubmissionDataBean submissionData, Submission submission) {
        if (submission.isFormSaved()) {
            Portal portal = PortalUtils.getPortalForSubmission(submission);
            return PortalUtils.getSubmissionSavedPath(portal) + "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();

        } else {
            if (!submission.getRequiredAttachments().isEmpty()) {
                Portal portal = PortalUtils.getPortalForSubmission(submission);
                return PortalUtils.getSubmissionAttachmentPath(portal) + "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();

            } else if (submission.isPaymentRequired() && submission.isPaymentTypeCreditCard() && !submission.isFormSaved()) {
                Portal portal = PortalUtils.getPortalForSubmission(submission);
                return PortalUtils.getSubmissionPaymentPath(portal) + "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();

            } else {
                Portal portal = PortalUtils.getPortalForSubmission(submission);
                return PortalUtils.getSubmissionConfirmationPath(portal) + "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();
            }
        }
    }

    public String resolveFormExpiryPath(HttpServletRequest request, SubmissionDataBean submissionData) {
        SystemProfileHelper systemProfileHelper = new SystemProfileHelper(submissionData.getDocument());
        String requestLogKey = systemProfileHelper.getRequestLogKey();
        RequestLogDao requestLogDao = new RequestLogDao();
        RequestLog requestLog = requestLogDao.getRequestLogFromKey(requestLogKey);
        Portal portal = requestLog.getPortal();
        String path = PortalUtils.getSubmissionExpiredPath(portal) + "?" + Constants.PARAM_FormCode + "=" + systemProfileHelper.getFormCode();
        return path;
    }

    public String resolveErrorPath(HttpServletRequest request, SubmissionDataBean submissionData, Throwable error, ErrorLog errorLog) {
        String path = null;
        if (error instanceof SubmissionException) {
            SubmissionException submissionException = (SubmissionException) error;

            String formCode = submissionException.getFormCode();
            Form form = null;
            if (StringUtils.isNotEmpty(formCode)) {
                FormDao formDao = DaoFactory.getFormDao();
                form = formDao.getFormByFormCode(formCode);
            }
            if (form != null && form.getPortal() != null) {
                path = PortalUtils.getSubmissionFailedPath(form.getPortal());
                path += "?" + Constants.PARAM_EntityId + "=" + errorLog.getId();
                path += "&" + Constants.PARAM_FormCode + "=" + formCode;

                HttpSession session = request.getSession();
                Element rootDataElement = FormUtils.getRootDataElement(submissionException.getFormData());
                String formData = XmlUtils.toString(rootDataElement);
                session.setAttribute(Constants.SESSION_ATTRIBUTE_submissionFailureData, formData);
                return path;
            }
        }

        Portal portal = PortalUtils.getPortal(request);
        if (portal != null) {
            path = PortalUtils.getFormErrorPath(portal);

        } else {
            path = PortalUtils.getDefaultPortalPath(PortalPage.PAGE_Form_Error);
        }
        path += "?" + Constants.PARAM_EntityId + "=" + errorLog.getId();
        return path;
    }

    public String getOfflineSubmissionFormXml(Portal portal, SubmissionDataBean submissionData, Submission submission) {
        return PortalUtils.getOfflineSubmissionFormXml(portal, submission);
    }

    public String getOfflineSubmissionFormErrorXml(Portal portal, SubmissionDataBean submissionData, ErrorLog errorLog) {
        return PortalUtils.getOfflineSubmissionFormErrorXml(portal, errorLog);
    }
}

package com.avoka.fc.core.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.click.util.ClickUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.RequestLogDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.ValidationErrorLog;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.RenderOfflineSubmissionFormService;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SubmissionDataBean;
import com.avoka.fc.core.service.SubmissionDataExtractionService;
import com.avoka.fc.core.service.SubmissionService;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.FormUtils;
import com.avoka.fc.core.util.PortalUtils;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

/**
 * Form submission handling Servlet.
 *
 * @author pcopeland@avoka.com
 */
public class SubmissionServlet extends BaseServlet{

    private static final long serialVersionUID = 1L;

    public static final String SERVLET_URL = "/servlet/SubmissionServlet";

    public static final String PROPERTIES_PATH = "/click-page.properties";

    protected Properties properties;

    private DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();

    /**
     * Handle the form submission. <br/> This method is called when a form has its tag value method
     * equals to get.
     *
     * @see BaseServlet#executeRequest(HttpServletRequest, HttpServletResponse)
     *
     * @param request
     *            the request send by the client to the server
     * @param response
     *            the response send by the server to the client
     * @throws ApplicationException
     */
    @SuppressWarnings("deprecation")
    protected void executeRequest(HttpServletRequest request, HttpServletResponse response) throws ApplicationException {

        // Ensure a POST request
        if (!isValidRequest(request, response)) {
            return;
        }

        // Check if the site is online.
        if (!isOperational(response, false)) {
            return;
        }

        final long executeStartTime = System.currentTimeMillis();

        // Extract the submission data
        SubmissionDataBean submissionData = null;

        try {
            if (ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DATA_EXTRACTION)) {
                SubmissionDataExtractionService submissionDataExtractionService = (SubmissionDataExtractionService)
                    ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DATA_EXTRACTION);
                submissionData = submissionDataExtractionService.extractData(request);

            } else {
                submissionData = FormUtils.getSubmissionData(request);
            }

            assert(submissionData != null);

            if (submissionData.getValidationErrors() != null) {
                SystemProfileHelper systemProfileHelper = new SystemProfileHelper(submissionData.getDocument());

                if (!Submission.STATUS_Saved.equals(systemProfileHelper.getSubmissionType())) {
                    // Log validation errors
                    String requestLogKey = systemProfileHelper.getRequestLogKey();
                    RequestLogDao requestLogDao = new RequestLogDao();
                    RequestLog requestLog = requestLogDao.getRequestLogFromKey(requestLogKey);
                    ValidationErrorLog validationErrorLog = new ValidationErrorLog();
                    getDataContext().registerNewObject(validationErrorLog);
                    validationErrorLog.setDatetimeCreated(new Date());
                    validationErrorLog.setRequestLog(requestLog);

                    validationErrorLog.setValidationErrors(submissionData.getValidationErrors());
                    getDataContext().commitChanges();

                    Map params = new HashMap();
                    params.put(Constants.PARAM_clientFormCode, systemProfileHelper.getFormCode());
                    params.put(Constants.PARAM_submissionData, XmlUtils.toString(submissionData.getDocument()));
                    params.put(Constants.PARAM_validationErrors, submissionData.getValidationErrors());
                    params.put(Constants.PARAM_submissionRetryRequestLogKey, requestLogKey);

                    FormDao formDao = new FormDao();
                    Form form = formDao.getFormByFormCode(systemProfileHelper.getFormCode());

                    Portal portal = requestLog.getPortal();
                    if (portal == null) {
                        portal = form.getPortal();
                    }
                    ClickUtils.autoPostRedirect(request, response, PortalUtils.getSubmissionErrorsPath(portal), params, true);
                    return;
                }
            }

            try {
                // Check if anything else has been posted
                if (getLogger().isDebugEnabled()) {
                    Enumeration enumeration = request.getParameterNames();

                    while (enumeration.hasMoreElements()) {
                        String paramName = (String) enumeration.nextElement();
                        String value = request.getParameter(paramName);
                        getLogger().debug("Parameter Name = " + paramName + " = " + value);
                    }
                }

                SystemProfileHelper systemProfileHelper = new SystemProfileHelper(submissionData.getDocument());

                // Ensure the form has not expired
                String expiryDateValue = systemProfileHelper.getExpiryDate();
                String formCode = systemProfileHelper.getFormCode();
                FormDao formDao = new FormDao();
                Form form = formDao.getFormByFormCode(formCode);

                // PRC for debug and testing
                if (getLogger().isInfoEnabled()
                    && getDeploymentPropertyDao().isDebugMode()
                    && form != null
                    && form.getTestEnabledFlag()) {

                    String msg = "Submission XML for Test Form: " + form.getFormName() + "\n"
                        + XmlUtils.toFormattedString(submissionData.getDocument()) + "\n";
                    getLogger().info(msg);
                }

                if (StringUtils.isNotBlank(expiryDateValue)) {
                    String format = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Date_Format_Long);
                    SimpleDateFormat sdf = new SimpleDateFormat(format);
                    try {
                        Date expiryDate = sdf.parse(expiryDateValue);

                        Date now = new Date();
                        Date today = new Date(now.getYear(), now.getMonth(), now.getDate());

                        if (expiryDate.before(today)) {
                            SubmissionTargetResolver submissionTargetResolver = getSubmissionTargetResolver();
                            String path = submissionTargetResolver.resolveFormExpiryPath(request, submissionData);
                            sendRedirect(request, response, path);
                            return;
                        }

                    } catch (ParseException pe) {
                        String msg = "SubmissionExpiryDate parsing error: " + expiryDateValue + " with " + format;
                        throw new ApplicationException("SubmissionError", pe, msg, msg, null);
                    }
                }

                // Save the submission
                final boolean offlineSubmission = FormUtils.isOfflineSubmission(request);

                SubmissionService submissionService = (SubmissionService)
                        getApplicationContext().getBean("submissionService");

                Submission submission = submissionService.saveSubmission(submissionData, request, offlineSubmission);

                // Render the Form
                long endTime = System.currentTimeMillis();
                getLogger().info("Completed Form Submission (ID=" + submission.getId() + ") in " + (endTime - executeStartTime) + "ms" );

                if (offlineSubmission) {
                    OfflineSubmissionForm offlineSubmissionForm = null;
                    Portal portal = PortalUtils.getPortalForSubmission(submission);
                    if (portal != null) {
                        offlineSubmissionForm = portal.getOfflineSubmissionForm();
                    }
                    if (offlineSubmissionForm == null) {
                        throw new ApplicationException("Offline Submission Form not found", "Attempting to process offline submission", "Could not display the offline submission form", "Set up an offline submission form for the appropriate portal");
                    }

                    SubmissionTargetResolver submissionTargetResolver = getSubmissionTargetResolver();
                    String xmlData = submissionTargetResolver.getOfflineSubmissionFormXml(portal, submissionData, submission);

                    // Get the rendering service and render the form
                    RenderOfflineSubmissionFormService renderService = (RenderOfflineSubmissionFormService) ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_RENDER_OFFLINE_SUBMISSION_FORM);
                    renderService.renderOfflineSubmissionForm(offlineSubmissionForm, xmlData, request, response);

                } else {
                    // redirect to the appropriate page
                    SubmissionTargetResolver submissionTargetResolver = getSubmissionTargetResolver();
                    String path = submissionTargetResolver.resolvePath(request, submissionData, submission);
                    sendRedirect(request, response, path);
                }
            } catch (ApplicationException ae) {
                String xmlSubmission = XmlUtils.toString(submissionData.getDocument());
                ae.setFormXml(xmlSubmission);
                throw ae;

            } catch (Exception e) {
                String msg = "An unknown error occured: " + e.toString();
                ApplicationException ae = new ApplicationException("Submission Error", e, msg, msg, null);
                String xmlSubmission = XmlUtils.toString(submissionData.getDocument());
                ae.setFormXml(xmlSubmission);
                throw ae;
            }

        } catch (Throwable error) {
            handleException(error, null, request, response, submissionData);
        }
    }

    // Protected Methods --------------------------------------------------------

    protected boolean isValidRequest(HttpServletRequest request, HttpServletResponse response) {
        if (isWebTest()) {
            return true;
        }

        // Ensure a POST request
        if (!request.getMethod().equalsIgnoreCase("POST")) {
            StringBuilder message = new StringBuilder();
            message.append("Invalid GET request from Remote Address: " + request.getRemoteAddr());
            appendHeaders(request, message);
            message.append(". Response: " + HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            getLogger().warn(message.toString());

            response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return false;
        }

        // Ensure a valid content type
        boolean validContentType = false;
        final String contentType = (request.getContentType() != null) ? request.getContentType().toLowerCase() : "";
        for (int i = 0; i < SubmissionDataExtractionService.CONTENT_TYPES.length; i++) {
            if (contentType.startsWith(SubmissionDataExtractionService.CONTENT_TYPES[i])) {
                validContentType = true;
                break;
            }
        }
        if (!validContentType) {
            StringBuilder message = new StringBuilder();
            message.append("Invalid Content-Type from Remote Address: " + request.getRemoteAddr());
            appendHeaders(request, message);
            message.append(". Response: " + HttpServletResponse.SC_BAD_REQUEST);;
            getLogger().warn(message.toString());
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return false;
        }

        // Ensure a sensible content length
        if (request.getContentLength() > -1 && request.getContentLength() <= 50) {
            StringBuilder message = new StringBuilder();
            message.append("Invalid Content-Length request from Remote Address: " + request.getRemoteAddr());
            appendHeaders(request, message);
            message.append(". Response: " + HttpServletResponse.SC_BAD_REQUEST);
            getLogger().warn(message.toString());
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return false;
        }

        return true;
    }

    protected void handleException(Throwable error, String userName, HttpServletRequest request, HttpServletResponse response, SubmissionDataBean submissionData) {
        ErrorLogService errorLogService = new ErrorLogService();
        ErrorLog errorLog = errorLogService.logException(error, request);

        if (FormUtils.isOfflineSubmission(request)) {
            try {
                OfflineSubmissionForm offlineSubmissionForm = null;
                Portal portal = PortalUtils.getPortal(request);
                if (portal != null) {
                    offlineSubmissionForm = portal.getOfflineSubmissionForm();
                }
                SubmissionTargetResolver submissionTargetResolver = getSubmissionTargetResolver();
                String xmlData = submissionTargetResolver.getOfflineSubmissionFormErrorXml(portal, submissionData, errorLog);

                // Get the rendering service and render the form
                RenderOfflineSubmissionFormService renderService = (RenderOfflineSubmissionFormService) ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_RENDER_OFFLINE_SUBMISSION_FORM);
                renderService.renderOfflineSubmissionForm(offlineSubmissionForm, xmlData, request, response);

            } catch (ApplicationException ae) {
                SubmissionTargetResolver submissionTargetResolver = getSubmissionTargetResolver();
                String path = submissionTargetResolver.resolveErrorPath(request, submissionData, error, errorLog);
                sendRedirect(request, response, path);
            }

        } else {
            SubmissionTargetResolver submissionTargetResolver = getSubmissionTargetResolver();
            String path = submissionTargetResolver.resolveErrorPath(request, submissionData, error, errorLog);

            if (path == null) {
                // no valid form code found, hence cannot redirect to submission failed page
                super.handleException(error, userName, request, response);
                return;

            } else {
                sendRedirect(request, response, path);
            }
        }
    }

    protected void sendRedirect(HttpServletRequest request, HttpServletResponse response, String path) throws ApplicationException {
        Validate.notNull(request, "Null response parameter");
        Validate.notNull(response, "Null response parameter");
        Validate.notNull(path, "Null path parameter");

        if (path.startsWith("/")) {
            path = request.getContextPath() + path;
        }

        path = response.encodeRedirectURL(path);
        getLogger().debug("Path: " + path);

        // If IE then send back a browser redirect, rather than a HTTP redirect
        String userAgent = request.getHeader("user-agent");
        try {
            if (userAgent != null && userAgent.contains("MSIE")) {
                response.setContentType("text/html");

                PrintWriter pw = response.getWriter();
                pw.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">");
                pw.println("<html><head><meta http-equiv=\"REFRESH\" content=\"0;url=" + path + "\"></head>");
                pw.println("<body></body></html>");

            } else {
                response.sendRedirect(path);
            }

        } catch (IOException ioe){
            throw new ApplicationException("Browser Safe Redirect Error", ioe,
                                           "Attempt to redirect to location: " + path,
                                           "An error occurred while transferring you to the next page.",
                                           "Please logout and login again.");
        }
    }

    protected SubmissionTargetResolver getSubmissionTargetResolver() {
        return new SubmissionTargetResolverImpl();
    }

    protected boolean isWebTest() {
        if (getProperties().containsKey("seleniumTest")) {
            return true;
        } else {
            return false;
        }
    }

    protected Properties getProperties() {
        if (properties == null) {
            properties = new Properties();

            try {
                InputStream is = ClickUtils.getResourceAsStream(PROPERTIES_PATH, this.getClass());
                if (is != null) {
                    properties.load(is);
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return properties;
    }

    private void appendHeaders(HttpServletRequest request, StringBuilder buffer) {
        Map<String, String> headerMap = new TreeMap<String, String>();

        Enumeration headersEnumeration = request.getHeaderNames();
        while (headersEnumeration.hasMoreElements()) {
            String name = headersEnumeration.nextElement().toString();
            String value = request.getHeader(name);
            headerMap.put(name, value);
        }

        Iterator<String> i = headerMap.keySet().iterator();
        while (i.hasNext()) {
            String name = i.next();
            String value = headerMap.get(name);
            buffer.append(name + "=" + value);
            if (i.hasNext()) {
                buffer.append(", ");
            }
        }
    }

}

package com.avoka.fc.core.servlet;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.RequestLogDao;
import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.PortalUtils;

public abstract class RenderServlet extends BaseServlet {

    private static final long serialVersionUID = 1L;

    protected FormDao formDao = new FormDao();
    protected SubmissionDao submissionDao = new SubmissionDao();
    protected UserAccountDao userAccountDao = DaoFactory.getUserAccountDao();
    protected RequestLogDao requestLogDao = DaoFactory.getRequestLogDao();

    // -------------------------------------------------------- Protected Methods

    protected String getFormNotFoundPath() {
        return PortalUtils.getFormNotFoundPath(getRequest());
    }

    protected RequestLog createRequestLog(HttpServletRequest request,
                                          Form form,
                                          TemplateVersion templateVersion,
                                          Submission submission,
                                          Task task,
                                          String renderMode) {

        UserAccount userDetails = null;
        String userKey = getParameterString(request, Constants.PARAM_UserKey);
        if (StringUtils.isNotBlank(userKey)) {
            userDetails = userAccountDao.getUserAccountForUserKey(userKey);
        }

        String taskKey = null;
        if (task != null) {
            taskKey = task.getTaskKey();
        }
 
        RequestLog requestLog = requestLogDao.createRequestLog(request,
                                                               form,
                                                               templateVersion,
                                                               submission,
                                                               userDetails,
                                                               renderMode,
                                                               taskKey);
        getDataContext().commitChanges();

        return requestLog;
    }

    protected void updateRequestLog(RequestLog requestLog, HttpServletRequest request) {

        requestLog.setRequestContentLength(String.valueOf(request.getContentLength()));
        requestLog.setRequestContentType(request.getContentType());
        requestLog.setRequestMethod(request.getMethod());
        requestLog.setRequestQuery(CoreUtils.limitLength(request.getQueryString(), 2000));
        requestLog.setRequestUrl(CoreUtils.limitLength(request.getRequestURL().toString(), 1000));
        requestLog.setRequestTimestamp(new Date());

        DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
        if (dpDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_IP_Address_Logging)) {
            requestLog.setIpAddress(CoreUtils.limitLength(request.getRemoteAddr(), 20));
        }
        requestLog.setRemoteUser(CoreUtils.limitLength(request.getRemoteUser(), 20));

        requestLog.setUserAgent(CoreUtils.limitLength(request.getHeader("user-agent"), 200));

        String userKey = getParameterString(request, Constants.PARAM_UserKey);
        if (StringUtils.isNotBlank(userKey)) {
            UserAccount userAccount = userAccountDao.getUserAccountForUserKey(userKey);
            requestLog.setUser(userAccount);
        }

        getDataContext().commitChanges();
    }

}

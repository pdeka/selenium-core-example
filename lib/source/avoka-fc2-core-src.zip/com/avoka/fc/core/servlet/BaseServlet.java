/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on Sept 30, 2006 Created By pcopeland
 *
 */

package com.avoka.fc.core.servlet;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.cayenne.access.DataContext;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.avoka.core.util.FastStringBuffer;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalPage;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.InvalidParameterException;
import com.avoka.fc.core.util.PortalUtils;

public abstract class BaseServlet extends HttpServlet {

    // PAGE Names
    public final static String    PAGE_Offline                = "/user/offline.htm";
    public final static String    PAGE_InvalidRequest            = "/user/invalid-request.htm";

    private DeploymentPropertyDao deploymentPropertyDao    = new DeploymentPropertyDao();
    private Logger logger;
    private ThreadLocal requestThreadLocal = new ThreadLocal();
    private ThreadLocal responseThreadLocal = new ThreadLocal();

    // Abstract Methods -------------------------------------------------------

    /**
     * Abstract execute request method subclasses must implement. Subclasses
     * should not override the doGet or doPost methods.
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected abstract void executeRequest(HttpServletRequest request, HttpServletResponse response)
        throws ApplicationException, InvalidParameterException;


    // Protected Methods ------------------------------------------------------

    protected final void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        handleRequest(request, response);
    }

    protected final void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        handleRequest(request, response);
    }

    protected void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            long startTime = System.currentTimeMillis();

            listServletInfo(request);

            getLogger().debug("execute " + request.getMethod());

            requestThreadLocal.set(request);
            responseThreadLocal.set(response);

            // PRC - Do not get any parameters from the request object as that breaks things in
            // FormServer on submit for some weird reason.
            executeRequest(request, response);

            long endTime = System.currentTimeMillis();

            getLogger().debug("Request Time = " + (endTime - startTime));

        } catch (InvalidParameterException ipe) {

            // PRC - get rid of this with minimal fuss. Could be part of a hack attempt. I do not
            // want this logged (in the database) as it could cause too much overhead

            request.setAttribute("exception", ipe);

            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(PAGE_InvalidRequest);

            getLogger().warn("Invalid Request Parameter - Param Name=" + ipe.getParameterName() + " Param Value=" + ipe.getParameterValue());

            dispatcher.forward(request, response);

        } catch (Throwable error) {
            handleException(error, null, request, response);

        } finally {
            requestThreadLocal.set(null);
            responseThreadLocal.set(null);
        }
    }

    protected void handleException(Throwable error, String userName, HttpServletRequest request, HttpServletResponse response) {

        // 2007-02-20 PRC - Refactored - moved most of this code in the ErrorLogDao as needs to be called from multiple locations.

        ErrorLogService errorLogService = new ErrorLogService();

        ErrorLog errorLog = errorLogService.logException(error, request);

        String path = null;

        Portal portal = PortalUtils.getPortal(request);
        if (portal != null) {
            path = PortalUtils.getFormErrorPath(portal);

        } else {
            path = PortalUtils.getDefaultPortalPath(PortalPage.PAGE_Form_Error);
        }

        path += "?entityId=" + errorLog.getId();

        sendRedirect(request, response, path);
    }

    /**
     * Return the service log.
     */
    protected Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

    @SuppressWarnings("deprecation")
    protected DataContext getDataContext() {
        return DataContext.getThreadDataContext();
    }

    protected ApplicationContext getApplicationContext() {
        return WebApplicationContextUtils.getWebApplicationContext(getServletContext());
    }

    protected DeploymentPropertyDao getDeploymentPropertyDao() {
        return deploymentPropertyDao;
    }

    protected HttpServletRequest getRequest() {
        return (HttpServletRequest) requestThreadLocal.get();
    }

    protected HttpServletResponse getResponse() {
        return (HttpServletResponse) responseThreadLocal.get();
    }

    /**
     * This will return "" if there is a null value.
     */
    protected String getParameterString(HttpServletRequest request, String name) {
        return getParameterString(request, name, "");
    }

    protected String getParameterString(HttpServletRequest request, String name, String defaultValue) {
        String value = request.getParameter(name);
        if (value == null) {
            value = defaultValue;
        }
        return value;
    }

    protected int getParameterInt(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        int intValue = -1;
        if (value == null) {
            return -1;
        }
        try {
            intValue = Integer.parseInt(value);
        } catch (NumberFormatException ex) {
            return -1;
        }
        return intValue;
    }

    /**
     * Return an ordered map of request parameters from the request.
     *
     * @return the ordered map of request parameters
     */
    public Map getRequestParameters() {

        TreeMap requestParams = new TreeMap();

        Enumeration paramNames = getRequest().getParameterNames();
        while (paramNames.hasMoreElements()) {
            String name = paramNames.nextElement().toString();

            String[] values = getRequest().getParameterValues(name);
            FastStringBuffer valsBuffer = new FastStringBuffer(32);

            if (values.length == 1) {
                valsBuffer.append(values[0]);

            } else {
                for (int i = 0; i < values.length; i++) {
                    if (i == 0) {
                        valsBuffer.append("[");
                    }
                    valsBuffer.append(values[i]);
                    if (i == values.length - 1) {
                        valsBuffer.append("]");
                    } else {
                        valsBuffer.append(",");
                    }
                }
            }
            requestParams.put(name, valsBuffer.toString());
        }

        return requestParams;
    }

    /**
     * List all the servlet request information when in application is in debug
     * mode.
     */
    protected void listServletInfo(HttpServletRequest request) {

        if (getLogger().isInfoEnabled() && getDeploymentPropertyDao().isDebugMode()) {
            StringBuffer buffer = new StringBuffer(1000);

            buffer.append("\n\t ServletName: " + getServletConfig().getServletName());
            buffer.append("\n\t Method:      " + request.getMethod());
            if (request.getContentType() != null) {
                buffer.append("\n\t ContentType: " + request.getContentType());
            }
            if (request.getContentLength() > -1) {
                buffer.append("\n\t ContentLength: " + request.getContentLength());
            }
            buffer.append("\n\t RequestURL:  " + request.getRequestURL());
            if (request.getQueryString() != null) {
                buffer.append("\n\t QueryString: " + request.getQueryString());
            }
            buffer.append("\n\t RemoteAddr:  " + request.getRemoteAddr());
            if (request.getRemoteUser() != null) {
                buffer.append("\n\t RemoteUser:  " + request.getRemoteUser());
            }

            getLogger().info(buffer.toString());
        }
    }

    protected boolean isOperational(HttpServletResponse response, boolean showForm) {

        String adminOid = getRequest().getParameter(Constants.PARAM_OverrideAdminOid);

        if (StringUtils.isNotBlank(adminOid)) {
            UserAccountDao adminDetailsDao = new UserAccountDao();
            if (adminDetailsDao.getUserAccountForPK(adminOid) != null) {
                return true;
            }
        }

        String status = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Operation_Status);

        if (DeploymentProperty.OPERATION_Status_Offline.equals(status)) {

            // Don't let anything through.
            String path = getOffLinePath();
            sendRedirect(getRequest(), getResponse(), path);

            return false;

        } else if (DeploymentProperty.OPERATION_Status_Restricted.equals(status) && showForm) {

            // Don't let new requests through.
            String path = getOffLinePath();
            sendRedirect(getRequest(), getResponse(), path);

            return false;
        }

        return true;
    }

    protected void sendRedirect(HttpServletRequest request, HttpServletResponse response, String path) throws ApplicationException {
        Validate.notNull(request, "Null response parameter");
        Validate.notNull(response, "Null response parameter");
        Validate.notNull(path, "Null path parameter");

        if (path.startsWith("/")) {
            path = request.getContextPath() + path;
        }

        path = response.encodeRedirectURL(path);
        getLogger().debug("Path: " + path);

        try {
            response.sendRedirect(path);

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    protected String getOffLinePath() {
        return PortalUtils.getOffLinePath();
    }

}

/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.servlet;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.click.util.ClickUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.fc.core.dao.FileUploadDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides an Servlet to download and view attachment file
 * <p>
 * This class has dependencies on:
 * </p>
 * <ul>
 * <li>Jakarta Commons FileUpload version 1.1</li>
 * <li>Jakarta Commons IO version 1.1</li>
 * </ul>
 */
public class AttachmentGetFileServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    final static private String ERROR_FILE_NOT_FOUND = "File not found.";
    final static private String ERROR_NOT_AUTHORIZED = "You are not authorized to view this document.";
    final static private String DISPOSITION = "attachment";
    final static private String PARAMETER_FILE_ID = "fileId";
    final static private String PARAMETER_USER_ID = "userId";

    private Logger logger;

    /**
     * @see HttpServlet#doPost(HttpServletRequest, HttpServletResponse)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        getLogger().debug("doGet()");

        try {
            String fileId = request.getParameter(PARAMETER_FILE_ID);
            String userId = request.getParameter(PARAMETER_USER_ID);

               UserAccountDao userAccountDao = new UserAccountDao();
               UserAccount userAccount = (UserAccount) userAccountDao.getUserAccountForPK(userId);
            FileUpload fileUpload = (FileUpload) new FileUploadDao().getFileUpload(fileId);

            if (fileUpload != null) {
                if (!fileUpload.getUser().getId().equals(userAccount.getId())) {
                    throw new RuntimeException(ERROR_NOT_AUTHORIZED);
                }
                downloadAttachment(fileUpload, DISPOSITION, response);

            } else {
                throw new RuntimeException(ERROR_FILE_NOT_FOUND);
            }
        } catch (RuntimeException re) {
            throw re;
        }
    }

    protected Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

    private void downloadAttachment(FileUpload fileUpload, String disposition, HttpServletResponse response) {
        DataOutputStream dos = null;
        try {
            // Load file from disk.
            byte[] bytes = fileUpload.getFileUploadData().getFileUploadData();

            String filename = fileUpload.getFileName();
            String contentType = ClickUtils.getMimeType(filename);
            if (contentType == null) {
                contentType = "text/plain";
            }
            response.setContentType(contentType);

            String header = "";
            if (StringUtils.isNotBlank(disposition)
                    && disposition.equals("attachment")) {
                header += "attachment; ";
            }
            header += "filename=\"" + filename + "\"";
            response.setHeader("Content-disposition", header);
            response.setHeader("Pragma", "public");
            response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");

            // Send File
            dos = new DataOutputStream(response.getOutputStream());
            dos.write(bytes);
            dos.flush();
            dos.close();

        } catch (ApplicationException ae) {
            throw new RuntimeException(ae);

        } catch (FileNotFoundException fnfe) {
            throw new RuntimeException(fnfe);

        } catch (IOException ioe) {
            throw new RuntimeException(ioe);

        } finally {
            ClickUtils.close(dos);
        }
    }
}

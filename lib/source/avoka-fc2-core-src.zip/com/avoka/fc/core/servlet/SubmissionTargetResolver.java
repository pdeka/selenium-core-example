package com.avoka.fc.core.servlet;

import javax.servlet.http.HttpServletRequest;

import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.SubmissionDataBean;

public interface SubmissionTargetResolver {

    public String resolvePath(HttpServletRequest request, SubmissionDataBean submissionData, Submission submission);

    public String resolveFormExpiryPath(HttpServletRequest request, SubmissionDataBean submissionData);

    public String resolveErrorPath(HttpServletRequest request, SubmissionDataBean submissionData, Throwable error, ErrorLog errorLog);

    public String getOfflineSubmissionFormXml(Portal portal, SubmissionDataBean submissionData, Submission submission);

    public String getOfflineSubmissionFormErrorXml(Portal portal, SubmissionDataBean submissionData, ErrorLog errorLog);
}

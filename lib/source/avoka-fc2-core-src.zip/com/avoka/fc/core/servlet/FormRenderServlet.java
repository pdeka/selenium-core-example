/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on 1/10/2006 Created By pcopeland
 */
package com.avoka.fc.core.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;

import com.avoka.core.util.CoreUtils;
import com.avoka.core.util.ServletUtils;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.dao.TemplateVersionDao;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.RequestLogData;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.FormDataService;
import com.avoka.fc.core.service.RenderFormService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.FormUtils;
import com.avoka.fc.core.util.InvalidParameterException;
import com.avoka.fc.core.util.RemoteUserProvider;
import com.avoka.fc.core.util.xml.SystemProfileHelper;
import com.avoka.fc.forms.api.utils.DataHashUtils;

/**
 * The Formcenter2 Form Rendering servlet.
 *
 * @author pcopeland@avoka.com
 * @author medgar@avoka.com
 */
public class FormRenderServlet extends RenderServlet {

    public static final String    SERVLET_URL           = "/servlet/SmartForm.pdf";

    private static final long serialVersionUID = 1L;

    /**
     * Render the Form.
     *
     * @see BaseServlet#executeRequest(HttpServletRequest, HttpServletResponse)
     */
    protected void executeRequest(HttpServletRequest request, HttpServletResponse response) throws ApplicationException,
            InvalidParameterException {

        // Check if the site is online.
        if (!isOperational(response, true)) {
            return;
        }

        // Prevent object tag double request being processed
        if (ServletUtils.isDoubleObjectTagRequest(request)) {
            return;
        }

        final long executeStartTime = System.currentTimeMillis();

        final String formCode = request.getParameter(Constants.PARAM_FormCode);

        // Ensure form is available
        Form form = null;
        if (StringUtils.isNotBlank(formCode)) {
            form = formDao.getFormByFormCode(formCode);

        } else {
            // Get the form associated with the saved submission
            String submitKey = getParameterString(request, Constants.PARAM_SubmitKey);
            form = formDao.getFormBySubmitKey(submitKey);
        }

        if (form == null) {
            String msg = "FormRenderServlet form '" + formCode + "' not found.";

            String referer = getRequest().getHeader("referer");
            if (StringUtils.isNotBlank(referer)) {
                msg += " Referer: " + referer;
            }

            EventLogService eventLogService = ServiceFactory.getEventLogService();
            eventLogService.logInfoEvent(msg);

            String path = getFormNotFoundPath() + "?" + Constants.PARAM_FormCode + "=" + formCode;
            sendRedirect(request, response, path);
            return;
        }

        // Get form data, template version and request log.
        FormDataAndTemplateVersion fdatv = getFormDataAndTemplateVersion(request, form);

        // Get the form rendering service
        ServiceDefinition sd = fdatv.templateVersion.getFormRenderService();
        RenderFormService renderFormService = (RenderFormService)
            ServiceLocator.getServiceForDefinitionOrType(sd, ServiceDefinition.SERVICE_TYPE_RENDER_FORM);

        // Render the Form
        renderFormService.renderForm(fdatv.templateVersion,
                form,
                fdatv.formData,
                request,
                response,
                SubmissionServlet.SERVLET_URL,
                fdatv.requestLog);

        // Complete request log info
        final int executeDuration = (int) (System.currentTimeMillis() - executeStartTime);
        fdatv.requestLog.setDurationTotal(new Integer(executeDuration));

        // Determine the referrer
        String referrerUrl = null;
        if (request.getSession(false) != null) {
            referrerUrl = (String) request.getSession().getAttribute(Constants.SESSION_ATTRIBUTE_ReferringUrl);
        }

        // set the referring url for metrics data
        if (referrerUrl != null) {
            fdatv.requestLog.setReferer(CoreUtils.limitLength(referrerUrl, 1000));

        } else {
            fdatv.requestLog.setReferer(CoreUtils.limitLength(getRequest().getHeader("referer"), 1000));
        }

        getDataContext().commitChanges();
    }

    // Private Methods --------------------------------------------------------

    private FormDataAndTemplateVersion getFormDataAndTemplateVersion(HttpServletRequest request, Form form)
        throws InvalidParameterException {

        FormDataAndTemplateVersion fdatv = new FormDataAndTemplateVersion();

        final String formCode = request.getParameter(Constants.PARAM_FormCode);

        // Get XML prefill data, if not available look for encoded XML data
        String xmlPrefillData = request.getParameter(Constants.PARAM_XmlData);
        if (xmlPrefillData == null) {
            String xmlDataEncoded = request.getParameter(Constants.PARAM_XmlDataEncoded);
            if (xmlDataEncoded != null) {
                try {
                    URLCodec urlCodec = new URLCodec();
                    xmlPrefillData = urlCodec.decode(xmlDataEncoded);

                } catch (DecoderException de) {
                    String msg = "Could not decode xmlDataEncoded request parameter for " + request.getRequestURL();
                    getLogger().error(msg, de);
                }
            }
        }

        final boolean getFormPrefillData = "true".equalsIgnoreCase(request.getParameter(Constants.PARAM_GetFormPrefillData));

        final boolean formGuideSWF = "true".equalsIgnoreCase(request.getParameter(Constants.PARAM_FormGuideSWF));
        final String requestKey = request.getParameter(Constants.PARAM_RequestKey);

        // Set the remote user

        UserAccount userAccount = getUserAccountAndSetRemoteUser(request);

        final String submissionDataXml = request.getParameter(Constants.PARAM_SubmissionDataXml);
        final String submissionRetryRequestLogKey = request.getParameter(Constants.PARAM_submissionRetryRequestLogKey);

        // Attempt to get any submission failure XML Form submission data.
        String docRequestLogKey = null;
        String docDataString = null;
        HttpSession session = request.getSession(false);
        if (session != null) {
            docDataString = (String) session.getAttribute(Constants.SESSION_ATTRIBUTE_submissionFailureData);
            session.removeAttribute(Constants.SESSION_ATTRIBUTE_submissionFailureData);

            if (docDataString != null) {
                try {
                    Document document = XmlUtils.parseDocumentFromString(docDataString);
                    document = FormUtils.getSubmissionDataDocument(document);
                    docDataString = XmlUtils.toString(document);
                    SystemProfileHelper helper = new SystemProfileHelper(document);
                    docRequestLogKey = helper.getRequestLogKey();

                } catch (RuntimeException re) {
                    getLogger().error(re.toString(), re);
                    docDataString = null;
                    docRequestLogKey = null;
                }
            }
        }

        String submitKey = getParameterString(request, Constants.PARAM_SubmitKey);

        // Create request log record if not a submission retry
        if (submissionRetryRequestLogKey == null && StringUtils.isEmpty(docRequestLogKey)) {

            RequestLog requestLog = DaoFactory.getRequestLogDao().getRequestLogFromKey(requestKey);

            if (!formGuideSWF || requestLog == null) {
                // Ensure template version is up to date
                TemplateVersionDao templateVersionDao = new TemplateVersionDao();
                fdatv.templateVersion = templateVersionDao.getCurrentDeployedVersion(form.getTemplate());

                SubmissionDao submissionDao = DaoFactory.getSubmissionDao();
                Submission submission = null;
                if (StringUtils.isNotEmpty(submitKey)) {
                    submission = submissionDao.getSubmissionByKey(submitKey);
                }

                fdatv.requestLog = createRequestLog(request,
                                                    form,
                                                    fdatv.templateVersion,
                                                    submission,
                                                    null,
                                                    RequestLog.MODE_FORM);

            } else {
                fdatv.requestLog = requestLog;
            }

        } else {
            String requestLogKey = StringUtils.isEmpty(docRequestLogKey) ? submissionRetryRequestLogKey : docRequestLogKey;

            if (StringUtils.isNotBlank(submitKey)) {
                // make sure not to use the wrong key in case of saved form
                requestLogKey = submissionRetryRequestLogKey;
            }

            fdatv.requestLog = DaoFactory.getRequestLogDao().getRequestLogFromKey(requestLogKey);

            if (fdatv.requestLog != null) {
                updateRequestLog(fdatv.requestLog, request);

            } else {
                throw new ApplicationException("FormRenderServlet",
                        "RequestKey=" + submissionRetryRequestLogKey,
                        "There is no RequestLog matching the submissionRetryRequestLogKey value",
                        null);
            }
        }

        if (StringUtils.isNotBlank(submitKey)) {
            // Load saved form
            Submission submission = submissionDao.getSubmissionByKey(submitKey);

            if (submission.isFormSaved()) {
                boolean useCurrentVersion = false;
                String useCurrentVersionString = request.getParameter(Constants.PARAM_useCurrentVersion);
                if (StringUtils.isNotEmpty(useCurrentVersionString)) {
                    useCurrentVersion = "true".equalsIgnoreCase(useCurrentVersionString);
                }

                if (useCurrentVersion) {
                    TemplateVersionDao templateVersionDao = DaoFactory.getTemplateVersionDao();
                    fdatv.templateVersion = templateVersionDao.getCurrentDeployedVersion(form.getTemplate());
                } else {
                    fdatv.templateVersion = submission.getVersion();
                }

                form = submission.getForm();

                SubmissionData submissionData = submission.getSubmissionData();
                if (submissionData == null || submissionData.getSubmissionData() == null) {
                    // submission data has been lost
                    throw new ApplicationException("FormDataUnavailable", "Re-opening a saved form", "The data you saved could not be found. Please fill in the form again.", null);
                }

                fdatv.formData = submissionData.getSubmissionDataString();

            } else {
                // Should never happen
                String msg = "Attempting to open saved form, where submission status NOT saved, Submission ID: " + submission.getId();
                throw new ApplicationException("FormRenderServlet", msg, msg, null);
            }

        } else if (docDataString != null) {

            // Found submitted form data for re submission attempt
            fdatv.formData = docDataString;

            if (getLogger().isInfoEnabled()) {
                String msg = "Form data for previous submission of form '" + formCode
                    + "' detected. Using data for pre-population.";
                getLogger().info(msg);
            }

            fdatv.templateVersion = form.getTemplate().getCurrentVersion();

        } else if (StringUtils.isNotBlank(submissionDataXml)) {
            // Retry submission
            fdatv.formData = submissionDataXml;

            fdatv.templateVersion = form.getTemplate().getCurrentVersion();

        // Create a new form
        } else {
            if (formCode == null) {
                // PRC 2007-01-31 - Try to avoid logging lots of stuff in can of a denial of
                // service attack
                if (getDeploymentPropertyDao().isDebugMode()) {
                    throw new ApplicationException("NoFormIDSpecified", "Requested FormCode=" + formCode,
                            "There is no form matching this Form Code. Please check the Form Code",
                            "Please check the formCode that was specified with this request. It does not a valid formCode.");
                } else {
                    throw new InvalidParameterException(Constants.PARAM_FormCode, "" + formCode);
                }
            }

            // If a Form Guide Render SWF request then don't bother to generate Form Data XML as it has already been
            // generated using the FormGuideDataRenderServlet
            if ("true".equalsIgnoreCase(request.getParameter(Constants.PARAM_FormGuideSWF))) {
                // do nothing

            } else {
                // Determine whether user account profile prefill should be performed, handles the cases
                // when a user is authenticated, but does not elect to use prefill
                boolean userAccountPrefill = true;
                String value = getRequest().getParameter(Constants.PARAM_NoUserAccountPrefill);
                if ("true".equalsIgnoreCase(value)) {
                    userAccountPrefill = false;
                }

                FormDataService formDataService = (FormDataService)
                    getApplicationContext().getBean("formDataService");

                fdatv.formData = formDataService.populateSeedXml(form,
                                                                 request,
                                                                 getFormPrefillData,
                                                                 xmlPrefillData,
                                                                 userAccount,
                                                                 userAccountPrefill,
                                                                 fdatv.requestLog.getRequestKey(),
                                                                 fdatv.requestLog.getReferer(),
                                                                 null);
            }
        }

        if (fdatv.templateVersion == null) {
            fdatv.templateVersion = form.getTemplate().getCurrentVersion();
        }

        // Form data may be null if a FormGuide object embedded tag render request
        if (fdatv.formData != null) {
            RequestLogData requestLogData = fdatv.requestLog.getRequestLogData();
            if (requestLogData == null) {
                requestLogData = new RequestLogData();
                getDataContext().registerNewObject(requestLogData);
                requestLogData.setRequestLog(fdatv.requestLog);
            }
            requestLogData.setRequestLogDataString(fdatv.formData);

            String xmlDataHash = DataHashUtils.toSHA256Hash(fdatv.formData);
            fdatv.requestLog.setSeedXmlHash(xmlDataHash);
        }

        fdatv.requestLog.setTemplateVersion(fdatv.templateVersion);

        return fdatv;
    }

    private UserAccount getUserAccountAndSetRemoteUser(HttpServletRequest request) {

        final String userKey = getParameterString(request, Constants.PARAM_UserKey);
        // Set the remote user
        UserAccount userAccount = userAccountDao.getUserAccountForUserKey(userKey);

        // Set the remote user
        if (userAccount != null) {
            RemoteUserProvider.setRemoteUser(userAccount);

        } else if (request.getParameter(Constants.PARAM_OverrideAdminOid) != null) {
            userAccount = userAccountDao.getUserAccountForPK(request.getParameter(Constants.PARAM_OverrideAdminOid));

        } else if (request.getRemoteUser() != null) {
            userAccount = userAccountDao.getUserAccountForLogin(request.getRemoteUser());
        }

        if (userAccount != null) {
            RemoteUserProvider.setRemoteUser(userAccount);
        } else {
            RemoteUserProvider.setRemoteUser("unknown");
        }

        return userAccount;
    }

    /**
     * Record to hold Form Data XML, Form Template Version and Request Log
     */
    private static class FormDataAndTemplateVersion {
        private String formData;
        private TemplateVersion templateVersion;
        private RequestLog requestLog;
    }

}

/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.servlet;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.ClientDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.PortalPageDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalPage;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.util.PortalUtils;

public class FormNameFilter implements Filter {

    // constants
    public static final String[] EXCLUDED_PATHS = {
        "assets", "resources", "click", "css", "images", "javascript", "messagebroker", "mock", "secure", "servlet"
    };

    public static final String[] EXCLUDED_EXTS = {
        ".css", ".js", ".htm", ".html", ".jpg", ".gif", ".png", ".pdf"
    };

    private ServletContext servletContext;

    /**
     * @see Filter#init(FilterConfig)
     */
    public void init(FilterConfig filterConfig) throws ServletException {
        servletContext = filterConfig.getServletContext();
    }

    /**
     * @see Filter#destroy()
     */
    public void destroy() {
    }

    /**
     * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
     */
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain filterChain) throws IOException, ServletException {

        // check request method
        final HttpServletRequest httpRequest = (HttpServletRequest) request;
        final HttpServletResponse httpResponse = (HttpServletResponse) response;

        String method = httpRequest.getMethod();
        if (!"get".equalsIgnoreCase(method)) {
            filterChain.doFilter(request, response);
            return;
        }

        // check request path format matches <client>/<form>
        String servletPath = httpRequest.getServletPath();
        if (servletPath.startsWith("/")) {
            servletPath = servletPath.substring(1);
        }
        String[] pathElements = servletPath.split("/", 0);
        if (pathElements.length != 2 || isExcluded(pathElements[0])) {
            filterChain.doFilter(request, response);
            return;
        }

        // Ignore image renderer
        if (pathElements[1].contains("image-renderer")) {
            filterChain.doFilter(request, response);
            return;
        }

        String clientCode = pathElements[0].trim();
        String formName = pathElements[1].trim();

        Client client = getClient(clientCode);
        Form form = null;

        if (client != null) {
            form = getForm(client.getClientCode(), formName);
        }

        if (form == null) {
            httpResponse.sendRedirect(getNotFoundPath(httpRequest, httpResponse));
            return;
        }

        Portal portal = form.getPortal();
        if (portal == null) {
            EventLogService els = ServiceFactory.getEventLogService();
            els.logWarnEvent("No Portal defined for form " + form.getFormName());

            httpResponse.sendRedirect(getNotFoundPath(httpRequest, httpResponse));
            return;
        }

        PortalPageDao pagePathDao = DaoFactory.getPortalPageDao();
        PortalPage pagePath = pagePathDao.getPortalPageByName(portal.getId(), PortalPage.PAGE_Form_Landing);

        if (pagePath == null) {
            EventLogService els = ServiceFactory.getEventLogService();
            els.logWarnEvent("No " + PortalPage.PAGE_Form_Landing + " defined for portal " + portal.getName());

            httpResponse.sendRedirect(getNotFoundPath(httpRequest, httpResponse));
            return;
        }

        String path = pagePath.getPath();
        path = (path.startsWith("/")) ? path : ("/" + path);
        path += "?" + Constants.PARAM_FormCode + "=" + form.getClientFormCode();

        // Apply response compression
        if (useGzipCompression(httpRequest, path)) {

            CompressionServletResponseWrapper wrappedResponse =
                new CompressionServletResponseWrapper(httpResponse);

            try {
                servletContext.getRequestDispatcher(path).forward(httpRequest, wrappedResponse);

            } finally {
                wrappedResponse.finishResponse();
            }

        } else {
            servletContext.getRequestDispatcher(path).forward(request, response);
        }

    }

    private boolean isExcluded(String path) {
        path = path.toLowerCase();

        for (int i = 0; i < EXCLUDED_PATHS.length; i++) {
            if (EXCLUDED_PATHS[i].equals(path)) {
                return true;
            }
        }

        for (int i = 0; i < EXCLUDED_EXTS.length; i++) {
            if (path.contains(EXCLUDED_EXTS[i])) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return true if the response should be GZIP compressed.
     *
     * @param request the request to test
     * @param path the request path to test
     * @return true if the response should be GZIP compressed
     */
    private boolean useGzipCompression(HttpServletRequest request, String path) {

        Enumeration e = request.getHeaders("Accept-Encoding");

        while (e.hasMoreElements()) {
            String name = (String) e.nextElement();
            if (name.indexOf("gzip") != -1) {
                return true;
            }
        }

        return false;
    }

    private Client getClient(String clientCode) {
        String transformedClientCode = clientCode.replace('-',  ' ');

        ClientDao clientDao = DaoFactory.getClientDao();
        Client client = clientDao.getClientByCode(transformedClientCode);
        if (client != null) {
            return client;
        }

        // the client was not found
        // this may be due to the client code containing a dash ('-')
        // we will try locating the client via the original client code
        if (clientCode.contains("-")) {
            return clientDao.getClientByCode(clientCode);
        }

        return null;
    }

    private Form getForm(String clientCode, String formName) {
        String transformedFormName = formName.replace('-',  ' ');

        FormDao formDao = DaoFactory.getFormDao();
        Form form = formDao.getFormByNameIgnoreCase(clientCode, transformedFormName);
        if (form != null) {
            return form;
        }

        // the form was not found
        // this may be due to the form name containing a dash ('-')
        // we will try locating the form using a LIKE expression
        if (formName.contains("-")) {
            String likeFormName = formName.replace('-', '%');
            return formDao.getFormByNameIgnoreCase(clientCode, likeFormName);
        }

        return null;
    }

    private String getNotFoundPath(HttpServletRequest request, HttpServletResponse response) {
        String notFoundPath = PortalUtils.getFormNotFoundPath(request);
        return response.encodeRedirectURL(notFoundPath);
    }

}

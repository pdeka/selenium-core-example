/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.service.AttachmentService;
import com.avoka.fc.core.service.ServiceFactory;


/**
 * Provides an Servlet to upload file for attachment screen
 * <p>
 * This class has dependencies on:
 * </p>
 * <ul>
 * <li>Jakarta Commons FileUpload version 1.1</li>
 * <li>Jakarta Commons IO version 1.1</li>
 * </ul>
 *
 *
 */
public class AttachmentUploadServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private Logger logger;

    /**
     * @see HttpServlet#doPost(HttpServletRequest, HttpServletResponse)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        getLogger().debug("doPost()");

        try {
            Map<String, FileItem> fileItemsMap = getFileItemsMap(request);

            FileItem fileItem = fileItemsMap.get("Filedata");
            FileItem dFileItem = fileItemsMap.get("description");
            String desc = (dFileItem != null) ? (String) dFileItem.getString() : "";
            FileItem idFileItem = fileItemsMap.get("userId");
            String userId = (String) idFileItem.getString();

               AttachmentService attachmentService = ServiceFactory.getAttachmentService();
 
               UserAccount userAccount = DaoFactory.getUserAccountDao().getUserAccountForPK(userId);
              attachmentService.saveFileItemForUser(fileItem, desc, userAccount);

        } catch (FileUploadException fue) {
//            TODO: not sure why ApplicationException is always undefined;
//            String msg = "Error processing file upload: " + request.getRequestURI();
//            ApplicationException ae = new ApplicationException(msg, fue);
//            throw ae;
            throw new RuntimeException(fue);

        } catch (RuntimeException re) {
            throw re;
        }
    }

    protected Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

    @SuppressWarnings("unchecked")
    protected Map<String, FileItem> getFileItemsMap(HttpServletRequest request) throws FileUploadException {
        FileItemFactory factory = new DiskFileItemFactory();

        ServletFileUpload upload = new ServletFileUpload(factory);

        List items = upload.parseRequest(request);

        Map<String, FileItem> fileItemsMap = new HashMap<String, FileItem>();
        for (Iterator i = items.iterator(); i.hasNext();) {
            FileItem fileItem = (FileItem) i.next();
            fileItemsMap.put(fileItem.getFieldName(), fileItem);

            if (getLogger().isDebugEnabled()) {
                String msg =
                    "FileItem[fieldName=" + fileItem.getFieldName()
                    + ((fileItem.getContentType() == null) ? ",value=" + fileItem.getString() : "")
                    + ",size=" + fileItem.getSize()
                    + ",contentType=" + fileItem.getContentType()
                    + "]";
                getLogger().debug(msg);
            }
        }

        return fileItemsMap;
    }
}

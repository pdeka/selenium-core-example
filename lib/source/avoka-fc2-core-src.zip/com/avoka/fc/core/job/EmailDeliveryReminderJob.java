package com.avoka.fc.core.job;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.SubmissionDeliveryService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.impl.SubmissionDeliveryServiceImpl;

/**
 * Resends reminders for unacknowledged submissions.
 *
 * @author lpammer@avoka.com
 */
public class EmailDeliveryReminderJob extends BaseJob {

    public static final String JOB_NAME = "Delivery Reminder";

    /**
     * @see BaseJob#executeJob()
     */
    public void executeJob() {
        SubmissionDeliveryService deliveryService = (SubmissionDeliveryService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DELIVERY);

        String ageString = deliveryService.getSecureEmailReminderAgeHours();
        Calendar cutoffTime = GregorianCalendar.getInstance();
        try {
            int age = Integer.parseInt(ageString);
            cutoffTime.add(Calendar.HOUR, -age);

            SubmissionDao submissionDao = new SubmissionDao();

            List<Submission> submissionList = submissionDao.getSubmissionsDeliveredViaEmailBefore(cutoffTime.getTime(), 0);

            getLogger().debug("Delivery Reminder Job processing " + submissionList.size() + " delivered submissions");

            for (Submission submission : submissionList) {
                if (isInterrupted()) {
                    break;
                }

                deliveryService.sendEmailReminder(submission);
            }
        }
        catch (NumberFormatException nfe) {
            String msg = "Delivery Reminder Job: Invalid value for service parameter '" + SubmissionDeliveryServiceImpl.PARAM_SECURE_EMAIL_REMINDER_AGE + "'. Please change the value to a positive integer.";

            EventLogService eventLogService = new EventLogService();
            eventLogService.logWarnEvent(msg);
        }
    }
}

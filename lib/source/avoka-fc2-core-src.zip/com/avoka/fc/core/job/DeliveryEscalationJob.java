package com.avoka.fc.core.job;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.SubmissionDeliveryService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.impl.SubmissionDeliveryServiceImpl;

/**
 * Reminds client administrators of unacknowledged submissions.
 *
 * @author lpammer@avoka.com
 */
public class DeliveryEscalationJob extends BaseJob {

    public static final String JOB_NAME = "Delivery Escalation";

    /**
     * @see BaseJob#executeJob()
     */
    public void executeJob() {
        SubmissionDeliveryService deliveryService = (SubmissionDeliveryService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DELIVERY);

        String ageString = deliveryService.getDeliveryEmailEscalationAgeHours();
        Calendar cutoffTime = GregorianCalendar.getInstance();
        try {
            int age = Integer.parseInt(ageString);
            cutoffTime.add(Calendar.HOUR, -age);

            SubmissionDao submissionDao = new SubmissionDao();
            List<Submission> submissionList = submissionDao.getSubmissionsToEscalate(cutoffTime.getTime(), 0);

            getLogger().debug("Delivery Escalation Job processing " + submissionList.size() + " delivered submissions");

            for (Submission submission : submissionList) {
                if (isInterrupted()) {
                    break;
                }

                deliveryService.sendEmailEscalation(submission);
            }
        }
        catch (NumberFormatException nfe) {
            String msg = "Delivery Escalation Job: Invalid value for service parameter '" + SubmissionDeliveryServiceImpl.PARAM_EMAIL_ESCALATION_AGE + "'. Please change the value to a positive integer.";

            EventLogService eventLogService = new EventLogService();
            eventLogService.logWarnEvent(msg);
        }
    }
}

package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.FileUploadDao;
import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.RemoteAuditService;
import com.avoka.fc.core.service.ServiceLocator;

public class RemoteAuditJob extends BaseJob {

    public static final String JOB_NAME = "Remote Audit";

    @Override
    public void executeJob() {
        if (!ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_REMOTE_AUDIT)) {
            return;
        }

        RemoteAuditService remoteAuditService = (RemoteAuditService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_REMOTE_AUDIT);

        SubmissionDao submissionDao = new SubmissionDao();
        List<Submission> submissionList = submissionDao.getSubmittedSubmissionsToAudit(null);
        getLogger().debug("Remote Audit Job processing " + submissionList.size() + " submissions ready for auditing.");

        for (Submission submission : submissionList) {
            if (isInterrupted()) {
                break;
            }

            remoteAuditService.auditSubmittedSubmission(submission);
        }

        FileUploadDao fileUploadDao = new FileUploadDao();
        List<FileUpload> fileUploadList = fileUploadDao.getSubmittedFileUploadsToAudit(null);
        getLogger().debug("Remote Audit Job processing " + fileUploadList.size() + " submitted attachments ready for auditing.");

        for (FileUpload fileUpload : fileUploadList) {
            if (isInterrupted()) {
                break;
            }

            remoteAuditService.auditSubmittedAttachment(fileUpload);
        }

        submissionList = submissionDao.getDeliveredSubmissionsToAudit();
        getLogger().debug("Remote Audit Job processing " + submissionList.size() + " delivered submissions ready for auditing.");

        for (Submission submission : submissionList) {
            if (isInterrupted()) {
                break;
            }

            remoteAuditService.auditDeliveredSubmission(submission);
        }

        fileUploadList = fileUploadDao.getDeliveredFileUploadsToAudit();
        getLogger().debug("Remote Audit Job processing " + fileUploadList.size() + " delivered attachments ready for auditing.");

        for (FileUpload fileUpload : fileUploadList) {
            if (isInterrupted()) {
                break;
            }

            remoteAuditService.auditDeliveredAttachment(fileUpload);
        }
    }
}

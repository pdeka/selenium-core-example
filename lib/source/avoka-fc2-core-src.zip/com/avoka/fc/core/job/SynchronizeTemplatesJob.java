package com.avoka.fc.core.job;

import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SynchronizeTemplatesService;

public class SynchronizeTemplatesJob extends BaseJob {

    public static final String JOB_NAME = "Synchronize Templates";

    @Override
    public void executeJob() {
        getLogger().info("Execute SynchronizeTemplatesJob");

        SynchronizeTemplatesService synchronizeTemplatesService = (SynchronizeTemplatesService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SYNCHRONIZE_TEMPLATES);

        synchronizeTemplatesService.synchronizeTemplates();
        synchronizeTemplatesService.synchronizeOfflineSubmissionForms();
    }

}

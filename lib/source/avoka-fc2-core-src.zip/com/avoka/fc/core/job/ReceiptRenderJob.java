package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SubmissionReceiptService;

public class ReceiptRenderJob extends BaseJob {

    public static final String JOB_NAME = "Receipt Render";

    @Override
    public void executeJob() {
        if (!ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_RECEIPT)) {
            return;
        }

        SubmissionReceiptService submissionReceiptService = (SubmissionReceiptService)
                ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_RECEIPT);

        int fetchLimit = submissionReceiptService.getNumberSubmissionsToProcess();

        List<Submission> submissionList = DaoFactory.getSubmissionDao().getSubmissionsToReceipt(fetchLimit);

        for (Submission submission : submissionList) {
            if (isInterrupted()) {
                break;
            }

            submissionReceiptService.createReceiptPdf(submission);
        }
    }
}

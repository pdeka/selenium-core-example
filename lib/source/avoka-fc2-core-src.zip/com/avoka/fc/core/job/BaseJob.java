/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.job;

import java.text.NumberFormat;
import java.util.Collection;
import java.util.Iterator;

import org.apache.cayenne.BaseContext;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.conf.Configuration;
import org.apache.cayenne.map.LifecycleEvent;
import org.apache.cayenne.reflect.LifecycleCallbackRegistry;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;
import org.quartz.UnableToInterruptJobException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.service.AuditLogService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.util.RemoteUserProvider;

/**
 * Provides Base stateful job class for Job classes to extends. Being a stateful
 * job, only one instance will ever be running at one time.
 *
 * @author medgar@avoka.com
 */
public abstract class BaseJob implements StatefulJob, InterruptableJob {

    /** The class Logger instance. */
    private Logger logger;

    /** The job has been interrupted. */
    private boolean interrupted;

    /** The job execution context. */
    private JobExecutionContext context;

    /**
     * Subclasses should override this method to provide their functionality.
     * <p/>
     * A DataContext object will be bound to the thread executing this task.
     * Any uncommitted changes to the DataContext will be automatically rolled
     * back when this method completes.
     */
    public abstract void executeJob();

    /**
     * Return the Quartz JobExecutionContext.
     *
     * @return the Quartz JobExecutionContext
     */
    public JobExecutionContext getContext() {
        return context;
    }

    /**
     * Return the thread local DataContext.
     *
     * @return the thread local DataContext
     */
    public DataContext getDataContext() {
        return (DataContext) BaseContext.getThreadObjectContext();
    }

    /**
     * Return true if the job has been manually stopped.
     *
     * @return true if the job has been manually stopped
     */
    public boolean isInterrupted() {
        return interrupted;
    }

    /**
     * Called by the Scheduler when a user interrupts the job.
     *
     * @throws UnableToInterruptJobException if there is an exception while interrupting the job.
     */
    public void interrupt() throws UnableToInterruptJobException {
        interrupted = true;
    }

    /**
     * Return the object logger.
     *
     * @return the object logger
     */
    public Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

    /**
     * @see org.quartz.Job#execute(JobExecutionContext)
     */
    public final void execute(JobExecutionContext context) throws JobExecutionException {

        this.context = context;

        long time = System.currentTimeMillis();

        final ClassLoader threadClassLoader = Thread.currentThread().getContextClassLoader();

        DataContext dataContext = null;
        try {
            // Set Cayenne classloader to the current thread
            Thread.currentThread().setContextClassLoader(Configuration.class.getClassLoader());

            DataDomain dataDomain = Configuration.getSharedConfiguration().getDomain();
            LifecycleCallbackRegistry registry = dataDomain.getEntityResolver().getCallbackRegistry();

            if (registry.isEmpty(LifecycleEvent.POST_LOAD)) {
                registry.addDefaultListener(new AuditLogService());
            }

            dataContext = dataDomain.createDataContext(false);

            BaseContext.bindThreadObjectContext(dataContext);

            RemoteUserProvider.setRemoteUser(getClass().getSimpleName());

            executeJob();

            DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
            if (dpDao.isDebugMode()) {
                time = (System.currentTimeMillis() - time);
                String msg = "Completed {} in {} ms";
                if (isInterrupted()) {
                    msg = "Interrupted {} job";
                }
                getLogger().info(msg, getClass().getSimpleName(), NumberFormat.getInstance().format(time));
            }

        } catch (Throwable ex) {
            ServiceFactory.getErrorLogService().logException(ex);

        } finally {
            // Restore previous thread classloader
            Thread.currentThread().setContextClassLoader(threadClassLoader);

            RemoteUserProvider.setRemoteUser(null);

            BaseContext.bindThreadObjectContext(null);

            if (dataContext != null && dataContext.hasChanges()) {
                getLogger().debug("Uncommitted data objects:");

                Collection uncommitted = dataContext.uncommittedObjects();
                for (Iterator i = uncommitted.iterator(); i.hasNext();) {
                    getLogger().debug("   " + i.next());
                }

                getLogger().debug("Rolling backup uncommitted changes");
                dataContext.rollbackChanges();
            }
        }
    }

}

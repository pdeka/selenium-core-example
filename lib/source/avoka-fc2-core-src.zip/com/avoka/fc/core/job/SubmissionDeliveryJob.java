package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.SubmissionDeliveryService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ServiceLocator;

/**
 * Deliver "Ready" delivery status submissions to their clients.
 *
 * @author pcopeland@avoka.com
 * @author medgar@avoka.com
 */
public class SubmissionDeliveryJob extends BaseJob {

    public static final String JOB_NAME = "Submission Delivery";

    private static final int MAX_ROWS = 500;

    /**
     * @see BaseJob#executeJob()
     */
    public void executeJob() {

        SubmissionDao submissionDao = new SubmissionDao();

        List<Submission> submissionList = submissionDao.getSubmissionsReadyForDelivery(MAX_ROWS);

        getLogger().debug("Delivery Job processing " + submissionList.size() + " ready submissions");

        // Log waring message if returned max number of rows
        if (submissionList.size() == MAX_ROWS) {
            int numberReady = submissionDao.getSubmissionsReadyForDelivery(0).size();

            String msg = "Delivery Job processing max number of submissions (" + MAX_ROWS + ") of " + numberReady
                         + " delivery ready submissions. Possible processing backlog exists. ";

            EventLogService eventLogService = new EventLogService();
            eventLogService.logWarnEvent(msg);
        }

        SubmissionDeliveryService deliveryService = (SubmissionDeliveryService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DELIVERY);

        for (Submission submission : submissionList) {
            if (isInterrupted()) {
                break;
            }

            deliveryService.deliverSubmission(submission);
        }
    }

}

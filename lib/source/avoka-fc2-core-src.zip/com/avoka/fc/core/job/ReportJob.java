/***************************************************************************************************
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system except as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on Apr 27, 2007
 **************************************************************************************************/

package com.avoka.fc.core.job;

import java.io.IOException;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.ReportScheduleDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Report;
import com.avoka.fc.core.entity.ReportSchedule;
import com.avoka.fc.core.service.ReportService;
import com.avoka.fc.core.util.ApplicationException;

public class ReportJob extends BaseJob {

    public static final String JOB_NAME = "Run Reports";

    @Override
    public void executeJob() {

        final Date now = new Date();

        ReportScheduleDao reportScheduleDao = new ReportScheduleDao();

        for (ReportSchedule reportSchedule : reportScheduleDao.getAllReports()) {

            boolean active = reportSchedule.getActiveFlag().booleanValue();
            boolean due = now.after(reportSchedule.getNextRunTimestamp());

            if (active && due) {

                String status = reportSchedule.getRunStatus();
                if (!ReportSchedule.STATUS_Running.equals(status)) {
                    executeReport(reportSchedule);

                } else {
                    GregorianCalendar calendar = new GregorianCalendar();
                    DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
                    int delay = dpDao.getPropertyValueInt(DeploymentProperty.PROPERTY_Report_Reschedule_Delay);
                    calendar.add(GregorianCalendar.MINUTE, -delay);

                    if (calendar.getTime().after(reportSchedule.getNextRunTimestamp())) {
                        executeReport(reportSchedule);
                    }
                }
            }
        }
    }

    private void executeReport(ReportSchedule schedule) {
        Report report = schedule.getSystemReport();
        if (report == null) {
            report = schedule.getReportClient().getReport();
        }

        String reportName = report.getName();
        String scheduleId = schedule.getId().toString();

        // Use HTTP Client to connect to and run report.
        ReportService reportService = new ReportService();
        String reportUrl = reportService.getInternalExecuteReportUrl(scheduleId);

        HttpClient client = new HttpClient();
        GetMethod getMethod = new GetMethod(reportUrl);
        try {
            int response = client.executeMethod(getMethod);
            getLogger().debug("Generate Report URL response was: " + response);

        } catch (IOException ioe) {
            String context = "ReportSchedule.ID=" + schedule.getId() + ",Report.ID=" + report.getId()
                + ",Report.Name=" + report.getName() + ",reportUrl=" + reportUrl;
            String userMsg = "Error generating report: " + reportName;
            getLogger().error(userMsg, ioe);
            throw new ApplicationException("ReportJob", ioe, context, userMsg, null);

        } finally {
            getMethod.releaseConnection();
        }
    }

}

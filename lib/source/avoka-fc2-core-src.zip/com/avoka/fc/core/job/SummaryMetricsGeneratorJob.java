/***************************************************************************************************
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system except as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on Apr 27, 2007
 **************************************************************************************************/

package com.avoka.fc.core.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;

import com.avoka.fc.core.dao.DailySummaryReportDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.entity.DailySummaryReport;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.SummaryMetricsGeneratorService;

public class SummaryMetricsGeneratorJob extends BaseJob {

    public static final String JOB_NAME = "Calculate Summary Metrics";

    // Public Methods ---------------------------------------------------------

    public void executeJob() {

        getLogger().debug(JOB_NAME + " processing");

        // get yesterday's date for the most recent report
        Date yesterday = yesterdaysDate();
        Date commenceDate = null;

        // we can have a commence date set from a service parameter
        SummaryMetricsGeneratorService summaryMetricsGeneratorService
            = ServiceFactory.getSummaryMetricsReportingService();

        String startCalcDate =  summaryMetricsGeneratorService.getStartCalcDate();
        if (StringUtils.isNotBlank(startCalcDate)) {
            try {
                SimpleDateFormat sdfInput = new SimpleDateFormat("yyyy-MM-dd");
                commenceDate = sdfInput.parse(startCalcDate);

            } catch (ParseException pe) {
                commenceDate = getAndUpdateStartDate(summaryMetricsGeneratorService);
            }
        } else {
            commenceDate = getAndUpdateStartDate(summaryMetricsGeneratorService);
        }

        // check if we have already successfully run the daily metric report
        DailySummaryReportDao dailySummaryReportDao = DaoFactory.getDailySummaryReportDao();

        DailySummaryReport dailySummaryReport = dailySummaryReportDao.getDailySummaryReportByDate(yesterday);
        if (dailySummaryReport == null) {
            // first run for yesterday's data
            ServiceFactory.getSummaryMetricsReportingService().calculateMetrics(yesterday);
        }

        Date effectiveDate = commenceDate;

        // run through and create dsrs for days that don't have them at all
        while (effectiveDate.before(yesterday)) {

            if (dailySummaryReportDao.getDailySummaryReportByDate(effectiveDate)==null) {
                ServiceFactory.getSummaryMetricsReportingService().calculateMetrics(effectiveDate);
            }
            effectiveDate = addOneDayToDate(effectiveDate);
        }

        // now let's run through and try to re execute any outstanding incomplete daily summary reports.
        List <DailySummaryReport> incompleteList = dailySummaryReportDao.getIncompleteDailySummaryReports();
        for (DailySummaryReport dsr : incompleteList) {
            ServiceFactory.getSummaryMetricsReportingService().calculateMetrics(dsr.getEffectiveDate());
        }
    }

    // Private Methods --------------------------------------------------------

    private Date yesterdaysDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        calendar = DateUtils.truncate(calendar, Calendar.DATE);

        return calendar.getTime();
    }

    private Date addOneDayToDate(Date effectiveDate) {
        Calendar calendar = Calendar.getInstance();;
        calendar.setTime(effectiveDate);
        calendar.add(Calendar.DAY_OF_MONTH, 1);

        return calendar.getTime();
    }

    private Date getAndUpdateStartDate(SummaryMetricsGeneratorService summaryMetricsGeneratorService) {
        // set the start date to today
        Date curDate = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String newStartDate = simpleDateFormat.format(curDate);
        summaryMetricsGeneratorService.setStartCalcDate(newStartDate);
        getDataContext().commitChanges();

        return curDate;
    }


}

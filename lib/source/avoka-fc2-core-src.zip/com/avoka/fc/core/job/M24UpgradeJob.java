package com.avoka.fc.core.job;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.w3c.dom.Document;

import com.avoka.core.util.CayenneUtils;
import com.avoka.core.util.CoreUtils;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.RequestLogDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

public class M24UpgradeJob extends BaseJob {

    public static final String JOB_NAME = "M24 Upgrade Job";
    public static final String SQL_CREATE_KEY_INDEX = "create unique index ui_user_account_key on user_account (user_key);";

    @Override
    public void executeJob() {
        getLogger().info("Execute " + JOB_NAME);

        // Update submission to set their portals
        List<Submission> submissions = DaoFactory.getSubmissionDao().getSubmissionList();
        for (Submission submission : submissions) {
            if (submission.getPortal() == null) {
                String xmlDataString = null;
                SubmissionData submissionData = submission.getSubmissionData();
                if (submissionData != null) {
                    xmlDataString = submissionData.getSubmissionDataString();
                }

                if (xmlDataString != null) {
                    Document document = XmlUtils.parseDocumentFromString(xmlDataString, false, false);
                    SystemProfileHelper systemProfileHelper = new SystemProfileHelper(document);
                    String requestLogKey = systemProfileHelper.getRequestLogKey();
                    RequestLogDao requestLogDao = new RequestLogDao();
                    RequestLog requestLog = requestLogDao.getRequestLogFromKey(requestLogKey);

                    if (requestLog != null && requestLog.getPortal() != null) {
                        submission.setPortal(requestLog.getPortal());
                        requestLog.getPortal();

                    } else if (submission.getForm().getPortal() != null) {
                        submission.setPortal(submission.getForm().getPortal());
                    }
                }
            }
        }
        getDataContext().commitChanges();

        // create a user key for all users with null user keys
        UserAccountDao userAccountDao = DaoFactory.getUserAccountDao();
        List<UserAccount> userAccounts = userAccountDao.getUsersWithoutUserkey();

        for (UserAccount curUserAccount : userAccounts) {
            curUserAccount.setUserKey(CoreUtils.createAltKey());
            getDataContext().commitChanges();

            getLogger().info("AssignUserKeysJob created user keys for " + userAccounts.size() + "users.");
        }

        // attempt to set a unique constraint on user_account.user_key
        Connection connection = null;
        Statement statement = null;
        try {
            connection = CayenneUtils.getConnection();
            statement = connection.createStatement();
            statement.execute(SQL_CREATE_KEY_INDEX);
            if (!connection.getAutoCommit()) {
                connection.commit();
            }
            getLogger().info("AssignUserKeysJob created unique user key constraint.");

        } catch (SQLException sqle) {
            // ignore, we'll just not create the index

        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException sqle) {
                // ignore
            }
        }
    }

}

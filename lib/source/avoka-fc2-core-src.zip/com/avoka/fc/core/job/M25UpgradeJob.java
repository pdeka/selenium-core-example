package com.avoka.fc.core.job;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SummaryMetricsGeneratorService;
import com.avoka.fc.core.service.impl.SummaryMetricsGeneratorServiceImpl;

public class M25UpgradeJob extends BaseJob {

    public static final String JOB_NAME = "M25 Upgrade Job";

    @Override
    public void executeJob() {
        getLogger().info("Execute " + JOB_NAME);

        if (!ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUMMARY_METRICS_GENERATOR)) {
            return;
        }

        SummaryMetricsGeneratorService summaryMetricsService = (SummaryMetricsGeneratorService) ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUMMARY_METRICS_GENERATOR);
        if (summaryMetricsService instanceof SummaryMetricsGeneratorServiceImpl) {
            SummaryMetricsGeneratorServiceImpl summaryMetricsServiceImpl = (SummaryMetricsGeneratorServiceImpl) summaryMetricsService;
            String startDate = summaryMetricsServiceImpl.getStartCalcDate();
            if (StringUtils.isEmpty(startDate)) {
                // set the start date to today
                Date curDate = new Date();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String newStartDate = simpleDateFormat.format(curDate);
                summaryMetricsServiceImpl.setStartCalcDate(newStartDate);
                getDataContext().commitChanges();
                getLogger().info("M25 Upgrade Job set summary metrics start date to " + newStartDate);
            }
        }
    }
}

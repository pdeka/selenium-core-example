package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.TaskDao;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.service.EmailService;
import com.avoka.fc.core.service.ServiceFactory;

/**
 * Sends notifications for new tasks.
 */
public class TaskNotificationJob extends BaseJob {

    public static final String JOB_NAME = "Task Notification";

    /**
     * @see BaseJob#executeJob()
     */
    public void executeJob() {
        TaskDao taskDao = DaoFactory.getTaskDao();

        List<Task> tasksReadyForNotification = taskDao.getTasksReadyForNotification();
        if (tasksReadyForNotification.size() > 0) {
            getLogger().info("Task Notification Job processing " + tasksReadyForNotification.size()
                    + " tasks.");

            int notificationCount = 0;
            EmailService emailService = ServiceFactory.getEmailService();

            for (Task task: tasksReadyForNotification) {
                try {
                    if (emailService.sendTaskNotification(task)) {
                        task.setEmailStatus(Task.EMAIL_STATUS_COMPLETED);
                        ++notificationCount;
                    } else {
                        // no emails could be sent
                        task.setEmailStatus(Task.EMAIL_STATUS_ERROR);
                        getLogger().debug("Task Notification Job: No emails could be sent out for task "
                                + task.getTaskKey() + ". Make sure the task has at least one assignee with a valid email address.");
                    }
                } catch (Exception e) {
                    task.setEmailStatus(Task.EMAIL_STATUS_ERROR);
                    getLogger().debug("Task Notification Job: Notification failed.", e);
                }
                getDataContext().commitChanges();
            }

            getLogger().info("Task Notification Job: " + notificationCount + " notifications sent, "
                    + (tasksReadyForNotification.size() - notificationCount) + " notifications failed.");
        }
    }
}

/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.ServiceDefinitionDao;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.service.CardPaymentService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides a job to resolve any outstanding payments. This job inturn calls
 * the <tt>CreditCardPaymentService</tt> method <tt>resolveOutstandingPayments</tt>.
 *
 * @author medgar@avoka.com
 */
public class ResolveOutstandingPaymentsJob extends BaseJob {

    /**
     * @see BaseJob#executeJob()
     */
    public void executeJob() {
        getLogger().info("Execute Resolve Outstanding Payments Job");

        ServiceDefinitionDao serviceDefinitionDao = DaoFactory.getServiceDefinitionDao();
        List<ServiceDefinition> cardPaymentServices = serviceDefinitionDao.getServiceDefinitionList(null, ServiceDefinition.SERVICE_TYPE_CARD_PAYMENT);

        for (int i = 0; i < cardPaymentServices.size(); i++) {
            ServiceDefinition curServiceDefinition = cardPaymentServices.get(i);
            CardPaymentService curService = (CardPaymentService) ServiceLocator.getServiceForDefinition(curServiceDefinition);

            try {
                curService.resolveOutstandingPayments();
            }
            catch (ApplicationException ae) {
                ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
                errorLogService.logException(ae, false);
            }
        }
    }

}

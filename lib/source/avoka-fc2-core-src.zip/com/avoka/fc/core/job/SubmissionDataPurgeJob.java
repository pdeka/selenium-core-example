package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SubmissionDataPurgeService;

public class SubmissionDataPurgeJob extends BaseJob {

    public static final String JOB_NAME = "Submission Data Purge";

    @Override
    public void executeJob() {

        if (ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DATA_PURGE)) {

            SubmissionDataPurgeService purgeService = (SubmissionDataPurgeService)
                ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DATA_PURGE);

            SubmissionDao submissionDao = new SubmissionDao();
            List<Submission> submissionList = submissionDao.getUnpurgedSubmissions();
            getLogger().debug("Purge Job processing " + submissionList.size() + " unpurged submissions");

            for (Submission submission : submissionList) {
                if (isInterrupted()) {
                    break;
                }

                purgeService.purgeSubmissionData(submission);
            }
        }

    }

}

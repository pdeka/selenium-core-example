package com.avoka.fc.core.job;

import java.text.NumberFormat;

import com.avoka.fc.core.service.ServiceFactory;

public class HealthMonitorJob extends BaseJob {

    public static final String JOB_NAME = "Health Monitor";

    public void executeJob() {
        getLogger().debug("Execute Health Monitor Job");
        long start = System.currentTimeMillis();

        ServiceFactory.getHealthMonitorService().collectFullSystemHealth();
        getDataContext().commitChanges();

        if (getLogger().isDebugEnabled()) {
            long time = System.currentTimeMillis() - start;
            getLogger().debug("Performed Health Monitor Job in {} ms", NumberFormat.getInstance().format(time));
        }
    }
}

package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.TaskDao;
import com.avoka.fc.core.entity.Task;

/**
 * Expires tasks which are past their expiry date, but have not been completed.
 */
public class TaskExpiryJob extends BaseJob {

    public static final String JOB_NAME = "Task Expiry";

    /**
     * @see BaseJob#executeJob()
     */
    public void executeJob() {
        TaskDao taskDao = DaoFactory.getTaskDao();

        List<Task> tasksToExpire = taskDao.getTasksToExpire();
        if (tasksToExpire.size() > 0) {
            for (Task task: tasksToExpire) {
                task.setTaskStatus(Task.TASK_STATUS_EXPIRED);
            }
            getDataContext().commitChanges();

            getLogger().info("Task Expiry Job set " + tasksToExpire.size() + " tasks to Expired.");
        }
    }
}

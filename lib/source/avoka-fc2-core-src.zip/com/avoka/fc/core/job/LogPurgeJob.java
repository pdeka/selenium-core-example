/***************************************************************************************************
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system except as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on Apr 27, 2007
 **************************************************************************************************/

package com.avoka.fc.core.job;

import com.avoka.fc.core.service.ServiceFactory;

public class LogPurgeJob extends BaseJob {

    public static final String JOB_NAME = "Log Purge";

    public void executeJob() {
        getLogger().info("Execute Log Purge Job");
        ServiceFactory.getLogPurgeService().purgeDatabaseRecords();
    }
}

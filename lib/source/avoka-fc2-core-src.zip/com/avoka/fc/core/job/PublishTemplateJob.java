package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.OfflineSubmissionFormDao;
import com.avoka.fc.core.dao.TemplateVersionDao;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.PublishTemplateService;
import com.avoka.fc.core.service.ServiceLocator;

public class PublishTemplateJob extends BaseJob {

    public static final String JOB_NAME = "Publish Templates";

    @Override
    public void executeJob() {
        getLogger().info("Execute PublishTemplateJob");

        PublishTemplateService publishService = (PublishTemplateService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_PUBLISH_TEMPLATE);

        TemplateVersionDao templateVersionDao = new TemplateVersionDao();

        List<TemplateVersion> publishTemplates = templateVersionDao.getTemplateVersionsToPublish();

        for (TemplateVersion templateVersion : publishTemplates) {
            publishService.publishTemplate(templateVersion);
        }

        OfflineSubmissionFormDao offlineSubmissionFormDao = new OfflineSubmissionFormDao();
        List<OfflineSubmissionForm> publishOfflineSubmissionForms = offlineSubmissionFormDao.getOfflineSubmissionFormsToPublish();
        for (OfflineSubmissionForm offlineSubmissionForm: publishOfflineSubmissionForms) {
            publishService.publishOfflineSubmissionForm(offlineSubmissionForm);
        }
    }

}

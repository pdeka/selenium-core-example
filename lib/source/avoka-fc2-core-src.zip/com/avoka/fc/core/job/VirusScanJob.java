package com.avoka.fc.core.job;

import java.util.List;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FileUploadDao;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.FileUploadData;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.VirusScanException;
import com.avoka.fc.core.service.VirusScanService;

public class VirusScanJob extends BaseJob {

    public static final String JOB_NAME = "Virus Scan";

    @Override
    public void executeJob() {
        if (!ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN)) {
            return;
        }

        VirusScanService virusScanService = (VirusScanService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN);

        FileUploadDao fileUploadDao = DaoFactory.getFileUploadDao();
        List<FileUpload> fileUploadList = fileUploadDao.getFileUploadsForVirusScan();
        getLogger().info("Virus Scan Job processing " + fileUploadList.size() + " files.");

        int cleanCount = 0;
        int infectedCount = 0;
        int errorCount = 0;
        for (FileUpload fileUpload : fileUploadList) {
            if (isInterrupted()) {
                break;
            }

            // do not scan if there is no data
            FileUploadData fileUploadData = fileUpload.getFileUploadData();
            if (fileUpload.isDeleted() || fileUploadData == null || fileUploadData.getFileUploadData() == null) {
                continue;
            }

            try {
                if (virusScanService.isFileVirusFree(fileUpload.getFileName(), fileUploadData.getFileUploadData())) {
                    fileUpload.setVirusStatus(FileUpload.VIRUS_STATUS_CLEAN);
                    ++cleanCount;
                } else {
                    fileUpload.setVirusStatus(FileUpload.VIRUS_STATUS_VIRUS);
                    getDataContext().deleteObject(fileUploadData);
                    ++infectedCount;
                }
            } catch (VirusScanException vse) {
                fileUpload.setVirusStatus(FileUpload.VIRUS_STATUS_SCAN_ERROR);
                ++errorCount;
            }
            getDataContext().commitChanges();
        }

        if (errorCount == 0) {
            getLogger().info("Virus scan job completed successfully. Clean files: " + cleanCount + " Infected files: " +  infectedCount);
        } else {
            getLogger().warn("Virus scan job completed with errors. Clean files: " + cleanCount + " Infected files: " +  infectedCount + " Errors: " + errorCount);
        }

    }
}

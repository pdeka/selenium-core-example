package com.avoka.fc.core.task;

import java.text.NumberFormat;
import java.util.Collection;
import java.util.Iterator;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.conf.Configuration;
import org.apache.cayenne.map.LifecycleEvent;
import org.apache.cayenne.reflect.LifecycleCallbackRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.fc.core.service.AuditLogService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.util.RemoteUserProvider;

/**
 * Provides a base Task class which implements runnable, subclasses should extend the abstract execute task method.
 *
 * @author medgar@avoka.com
 */
public abstract class BaseTask implements Runnable {

    /** The class Logger instance. */
    private Logger logger;

    /**
     * Execute the task.
     */
    public abstract void executeTask();

    /**
     * @see Runnable#run()
     */
    @SuppressWarnings("deprecation")
    public final void run() {
        DataContext dataContext = null;
        try {
            long time = System.currentTimeMillis();

            DataDomain dataDomain = Configuration.getSharedConfiguration().getDomain();
            LifecycleCallbackRegistry registry = dataDomain.getEntityResolver().getCallbackRegistry();

            if (registry.isEmpty(LifecycleEvent.POST_LOAD)) {
                registry.addDefaultListener(new AuditLogService());
            }

            dataContext = dataDomain.createDataContext(false);

            DataContext.bindThreadDataContext(dataContext);

            RemoteUserProvider.setRemoteUser(getClass().getSimpleName());

            executeTask();

            if (getLogger().isDebugEnabled()) {
                time = (System.currentTimeMillis() - time);
                String msg = "job executed in " + NumberFormat.getInstance().format(time) + " ms";
                getLogger().debug(msg);
            }

        } catch (Throwable ex) {
            ErrorLogService errorLogService = new ErrorLogService();
            errorLogService.logException(ex);

        } finally {
            RemoteUserProvider.setRemoteUser(null);

            DataContext.bindThreadDataContext(null);

            if (dataContext != null && dataContext.hasChanges()) {
                getLogger().debug("Uncommitted data objects:");

                Collection uncommitted = dataContext.uncommittedObjects();
                for (Iterator i = uncommitted.iterator(); i.hasNext();) {
                    getLogger().debug("   " + i.next());
                }

                getLogger().debug("Rolling backup uncommitted changes");
                dataContext.rollbackChanges();
            }
        }
    }

    /**
     * Return the object logger.
     *
     * @return the object logger
     */
    public Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

}


package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.NamedQuery;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.UserProperty;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides a FormPropetyType DAO.
 *
 * @author medgar@avoka.com
 */
public class PropertyTypeDao extends BaseDao {

    public PropertyType createPropertyType() {
        return (PropertyType) createAndRegisterNewObject(PropertyType.class);
    }

    public PropertyType getPropertyType(String propertyTypeId) {
        return (PropertyType) getObjectForPK(PropertyType.class, propertyTypeId);
    }

    /**
     * Get a query that will return FormPropertyTypes of a given scope. Returns all
     * formPropertyTypes if the given scope is null.
     *
     * @param scope
     * @param nameLike
     * @return
     */
    public SelectQuery getPropertyTypeQuery(String scope, String nameLike) {
        SelectQuery query = new SelectQuery(PropertyType.class);

        if (StringUtils.isNotEmpty(scope)) {
            query.andQualifier(ExpressionFactory.matchExp(PropertyType.SCOPE_PROPERTY, scope));
        }

        if (StringUtils.isNotEmpty(nameLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(PropertyType.NAME_PROPERTY, "%" + nameLike + "%"));
        }

        query.addOrdering(PropertyType.SCOPE_PROPERTY, Ordering.ASC);
        query.addOrdering(PropertyType.SEQUENCE_PROPERTY, Ordering.ASC);
        query.addOrdering(PropertyType.NAME_PROPERTY, Ordering.ASC);

        return query;
    }

    public List<PropertyType> getPropertyTypesByScope(String scope) {
        return performQuery(getPropertyTypeQuery(scope, null));
    }

    /**
     * Return the PropertyType for the given name and scope.
     *
     * @param clientId the client identifier
     * @param name the name of the property
     * @param scope the scope of the property
     * @return the FormPropertyType for the given name and scope
     */
    public List getPropertyTypeList(String clientId, String name, String scope, String dataType, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(PropertyType.class);

        if (StringUtils.isNotBlank(clientId)) {
            andQueryMatchExp(query, PropertyType.CLIENT_PROPERTY, clientId);
        }
        if (StringUtils.isNotBlank(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(PropertyType.NAME_PROPERTY, "%" + name + "%"));
        }
        if (StringUtils.isNotBlank(scope)) {
            query.andQualifier(ExpressionFactory.matchExp(PropertyType.SCOPE_PROPERTY, scope));
        }
        if (StringUtils.isNotBlank(dataType)) {
            query.andQualifier(ExpressionFactory.matchExp(PropertyType.DATA_TYPE_PROPERTY, dataType));
        }

        query.addPrefetch(PropertyType.CLIENT_PROPERTY);

        boolean sortedByScope = false;
        boolean sortedByName = false;
        boolean sortedBySequence = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(PropertyType.SCOPE_PROPERTY)) {
                sortedByScope = true;
            }
            if (sortBy.equals(PropertyType.NAME_PROPERTY)) {
                sortedByName = true;
            }
            if (sortBy.equals(PropertyType.SEQUENCE_PROPERTY)) {
                sortedBySequence = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByScope) {
            query.addOrdering(PropertyType.SCOPE_PROPERTY, Ordering.ASC);
        }
        if (!sortedByName) {
            query.addOrdering(PropertyType.NAME_PROPERTY, Ordering.ASC);
        }
        if (!sortedBySequence) {
            query.addOrdering(PropertyType.SEQUENCE_PROPERTY, Ordering.ASC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    /**
     * Return the PropertyType for the given name and scope.
     *
     * @param clientId the client identifier
     * @param name the name of theproperty
     * @param scope the scope of the property
     * @return the FormPropertyType for the given name and scope
     */
    public List<PropertyType> getPropertyTypeAndSharedList(String clientId, String name, String scope, String dataType) {
        SelectQuery query = new SelectQuery(PropertyType.class);

        if (StringUtils.isNotBlank(clientId)) {
            andQueryMatchExp(query, PropertyType.CLIENT_PROPERTY, clientId);
            orQueryMatchExp(query, PropertyType.CLIENT_PROPERTY, null);
        }
        if (StringUtils.isNotBlank(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(PropertyType.NAME_PROPERTY, "%" + name + "%"));
        }
        if (StringUtils.isNotBlank(scope)) {
            query.andQualifier(ExpressionFactory.matchExp(PropertyType.SCOPE_PROPERTY, scope));
        }
        if (StringUtils.isNotBlank(dataType)) {
            query.andQualifier(ExpressionFactory.matchExp(PropertyType.DATA_TYPE_PROPERTY, dataType));
        }

        query.addOrdering(PropertyType.SCOPE_PROPERTY, Ordering.ASC);
        query.addOrdering(PropertyType.NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(PropertyType.SEQUENCE_PROPERTY, Ordering.ASC);

        query.addPrefetch(PropertyType.CLIENT_PROPERTY);
        return performQuery(query);
    }

    /**
     * Return the PropertyType for the given name and scope.
     *
     * @param name the name of the property
     * @param scope the scope of the property
     * @return the FormPropertyType for the given name and scope
     */
    public PropertyType getPropertyByName(String name, String scope) {
        return getPropertyByName(name, scope, null);
    }

    /**
     * Return the PropertyType for the given name and scope.
     *
     * @param name the name of the property
     * @param scope the scope of the property
     * @param clientId the client the property type belongs to
     * @return the FormPropertyType for the given name and scope
     */
    public PropertyType getPropertyByName(String name, String scope, String clientId) {
        Validate.notEmpty(name, "Blank name parameter");
        Validate.notEmpty(scope, "Blank scope parameter");

        SelectQuery query = new SelectQuery(PropertyType.class);

        andQueryMatchExp(query, PropertyType.NAME_PROPERTY, name);
        andQueryMatchExp(query, PropertyType.SCOPE_PROPERTY, scope);
        andQueryMatchExp(query, PropertyType.CLIENT_PROPERTY, clientId);

        List list = performQuery(query);

        if (list == null || list.isEmpty()) {
            return null;

        } else if (list.size() == 1) {
            return (PropertyType) list.get(0);

        } else {
            String context = "Multiple FormPropertyTypes are defined for name=" + name + ", scope=" + scope + ". Number of value returned "
                    + list.size();

            throw new ApplicationException("Configuration Error", context, "Configuration Error please contact you system administrator",
                    "Fix configuration in DatabaseLoader, or Admin screens");
        }
    }

    /**
     * Get a query to return Client PropertyTypes that haven't already been set by the given
     * client.
     *
     * @param scope
     * @param clientId
     * @return
     */
    public NamedQuery getUnsetClientPropertyTypesQuery(String clientId) {
        if (clientId != null) {
            Map queryParams = new HashMap();
            queryParams.put("clientOid", clientId);
            NamedQuery query = new NamedQuery(NamedQueries.UNSET_CLIENT_PROPERTY_TYPES, queryParams);
            return query;
        }
        return null;
    }

    /**
     * Returns Client PropertyTypes that haven't already been set by the given
     * client.
     *
     * @param clientId
     * @return the list of all unset client properties
     */
    public List getUnsetClientPropertyTypes(String clientId) {
        if (StringUtils.isNotBlank(clientId)) {
            Map queryParams = new HashMap();
            queryParams.put("clientOid", clientId);
            NamedQuery query = new NamedQuery(NamedQueries.UNSET_CLIENT_PROPERTY_TYPES, queryParams);
            return getDataContext().performQuery(query);
        }
        return new ArrayList();
    }

    /**
     * Get a query to return Form PropertyTypes that haven't already been set by the given
     * form.
     *
     * @param scope
     * @param formId
     * @return
     */
    public NamedQuery getUnsetFormPropertyTypesQuery(String formId) {
        if (formId != null) {
            Map queryParams = new HashMap();
            queryParams.put("formOid", formId);
            NamedQuery query = new NamedQuery(NamedQueries.UNSET_FORM_PROPERTY_TYPES, queryParams);
            return query;
        }
        return null;
    }

    /**
     * Returns Form PropertyTypes that haven't already been set by the given
     * client.
     *
     * @param formId
     * @return the list of all unset form properties
     */
    public List getUnsetFormPropertyTypes(String formId, String clientId) {
        if (StringUtils.isNotBlank(formId) && StringUtils.isNotBlank(clientId)) {
            Map queryParams = new HashMap();
            queryParams.put("formOid", formId);
            queryParams.put("clientOid", clientId);
            NamedQuery query = new NamedQuery(NamedQueries.UNSET_FORM_PROPERTY_TYPES, queryParams);
            return getDataContext().performQuery(query);
        }
        return new ArrayList();
    }

    /**
     * Return the true if a form property type for the given name and scope exists.
     *
     * @param name the name of the form property type
     * @param scope the scope of the form property type
     * @return the form property type for the given name and scope
     */
    public boolean hasProperty(String name, String scope) {
        return (getPropertyByName(name, scope) != null);
    }

    public List<UserProperty> getProfilePropertiesWithPrefetchedPropertyTypes(Long profileId) {
        Validate.notNull(profileId, "Null profile id");

        SelectQuery propertiesForProfileQuery = new SelectQuery(UserProperty.class);

        propertiesForProfileQuery.andQualifier(ExpressionFactory.matchDbExp("profile_oid", profileId));
        propertiesForProfileQuery.addOrdering(UserProperty.PROPERTY_TYPE_PROPERTY + "." + PropertyType.SEQUENCE_PROPERTY, true);
        propertiesForProfileQuery.addOrdering(UserProperty.PROPERTY_TYPE_PROPERTY + "." + PropertyType.NAME_PROPERTY, true);
        propertiesForProfileQuery.addPrefetch("propertyType");

        return performQuery(propertiesForProfileQuery);
    }

    /**
     * Load the default property types.
     */
    public void loadDefaultProperties() {

        int index = 1;

        // Load User Properties

        registerFormPropertyType(PropertyType.USER_Property_Given_Name,
                PropertyType.SCOPE_User,
                "First or given name",
                PropertyType.DATA_TYPE_String,
                index++);

        registerFormPropertyType(PropertyType.USER_Property_Family_Name,
                PropertyType.SCOPE_User,
                "Surname or family name",
                PropertyType.DATA_TYPE_String,
                index++);

        registerFormPropertyType(PropertyType.USER_Property_Email,
                PropertyType.SCOPE_User,
                "Email address",
                PropertyType.DATA_TYPE_String,
                index++);

        // Load Client Properties

        registerFormPropertyType(PropertyType.CLIENT_Property_Logo,
                PropertyType.SCOPE_Client,
                "Organisation Logo Image",
                PropertyType.DATA_TYPE_Image,
                null);

        registerFormPropertyType(PropertyType.CLIENT_Property_URL,
                PropertyType.SCOPE_Client,
                "Organisation Website URL",
                PropertyType.DATA_TYPE_String,
                null);

        DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
        if (deploymentPropertyDao.isPaymentModuleEnabled()) {

            registerFormPropertyType(PropertyType.CLIENT_Property_Payment_Credit_Card_Amex_Accepted,
                    PropertyType.SCOPE_Client,
                    "Organisation accepts payment American Express credit card",
                    PropertyType.DATA_TYPE_Boolean,
                    null);

            registerFormPropertyType(PropertyType.CLIENT_Property_Payment_Credit_Card_MasterCard_Accepted,
                    PropertyType.SCOPE_Client,
                    "Organisation accepts payment with MasterCard credit card",
                    PropertyType.DATA_TYPE_Boolean,
                    null);

            registerFormPropertyType(PropertyType.CLIENT_Property_Payment_Credit_Card_Visa_Accepted,
                    PropertyType.SCOPE_Client,
                    "Organisation accepts payment with VISA credit card",
                    PropertyType.DATA_TYPE_Boolean,
                    null);
        }

//        // Load Form Properties
//
//        registerFormPropertyType(PropertyType.FORM_Property_AttachmentsSingleSubmitMethod,
//                PropertyType.SCOPE_Form,
//                "If true, all attachments must be either electronic or manual but not both.",
//                PropertyType.DATA_TYPE_Boolean,
//                null);
    }

    protected void registerFormPropertyType(String name, String scope, String description, String dataType, int sequence) {
        registerFormPropertyType(name, scope, description, dataType, true, null, new Integer(sequence));
    }

    protected void registerFormPropertyType(String name, String scope, String description, String dataType, Integer length) {
        registerFormPropertyType(name, scope, description, dataType, true, length, null);
    }

    protected void registerFormPropertyType(String name, String scope, String description, String dataType, boolean readonly, Integer length, Integer sequence) {
        Validate.notEmpty(name, "Blank name parameter");
        Validate.notEmpty(scope, "Blank scope parameter");
        Validate.notEmpty(description, "Blank description parameter");
        Validate.notEmpty(dataType, "Blank dataType parameter");

        if (!hasProperty(name, scope)) {
            PropertyType pt = createPropertyType();

            pt.setName(name);
            pt.setScope(scope);
            pt.setDescription(description);
            pt.setDataType(dataType);
            pt.setReadonlyFlag(new Boolean(readonly));
            if (length != null) {
                pt.setLength(length);
            }
            if (sequence != null) {
                pt.setSequence(sequence);
            }

            getLogger().debug("added FormPropertyType: " + name + ":" + scope + ":" + dataType);
        }
    }
}

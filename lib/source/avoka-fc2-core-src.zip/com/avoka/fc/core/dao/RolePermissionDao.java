package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.RolePermission;


public class RolePermissionDao extends BaseDao {

    public List<RolePermission> getRolePermissionsForPortal(String roleId, String portalId) {
        SelectQuery query = new SelectQuery(RolePermission.class);

        andQueryMatchExp(query, RolePermission.ROLE_PROPERTY, roleId);
        andQueryMatchExp(query, RolePermission.PERMISSION_PROPERTY + "."
                + Permission.PORTAL_PROPERTY, portalId);

        return performQuery(query);
    }
}

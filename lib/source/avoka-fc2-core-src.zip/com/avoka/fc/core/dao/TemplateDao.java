/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.EventLogService;

/**
 * Provides a Template DAO.
 *
 * @author pcopeland@avoka.com
 */
public class TemplateDao extends BaseDao {

    public Template getTemplate(String templateId) {
        return (Template) getObjectForPK(Template.class, templateId);
    }

    /**
     * Returns true if a new version is made current.
     *
     * @param template
     * @return
     */
    public boolean setCurrentDeployVersion(Template template)  {

        TemplateVersion currentTemplateVersion = template.getCurrentVersion();
        Date currentDeployDate = new Date(0);
        String currentVersionNumber = "0";

        boolean deployFlag = false;

        currentDeployDate = currentTemplateVersion.getDatetimeDeploy();
        currentVersionNumber = currentTemplateVersion.getVersionNumber();

        String newVersionNumber = currentVersionNumber;
        Date newDeployDate = currentDeployDate;
        TemplateVersion newTemplateVersion = null;
        Date now = new Date();

        List templateVersionList = getTemplateVersionsByDates(template, currentDeployDate, now);
        TemplateVersion templateVersion = null;

        // Run through the list and get the last one.
        if (templateVersionList != null) {
            Iterator itr = templateVersionList.iterator();
            while (itr.hasNext()) {
                templateVersion = (TemplateVersion) itr.next();
                Date deployDate = templateVersion.getDatetimeDeploy();
                if (deployDate != null) {
                    if (deployDate.after(newDeployDate) && deployDate.before(now)) {
                        // Got new version
                        newVersionNumber = templateVersion.getVersionNumber();
                        newDeployDate = deployDate;
                        newTemplateVersion = templateVersion;

                        EventLogService eventService = new EventLogService ();
                        eventService.logInfoEvent("Template Name=" + template.getTemplateName() + ", new template version number = " + newVersionNumber);
                    }
                }

            }
        }

        if (!newVersionNumber.equals(currentVersionNumber)) {
            if (currentTemplateVersion != null) {
                currentTemplateVersion.setDatetimeUndeploy(new Date());
            }
            template.setCurrentVersion(newTemplateVersion);
            deployFlag = true;
        }

        return deployFlag;
    }

    /**
     * Get a list of Template versions sorted by date for the given template,
     * start date and end date.
     *
     * @param template the template
     * @param startDate the start date of the search
     * @param endDate the end date of the search
     * @return the lsit of Template vesion objects for the given template
     */
    public List<TemplateVersion> getTemplateVersionsByDates(Template template, Date startDate, Date endDate) {

        Expression expression = ExpressionFactory.matchExp(TemplateVersion.TEMPLATE_PROPERTY, template);
        expression = expression.andExp(ExpressionFactory.betweenExp(TemplateVersion.DATETIME_DEPLOY_PROPERTY, startDate, endDate));

        SelectQuery query = new SelectQuery(TemplateVersion.class, expression);
        query.addOrdering(TemplateVersion.DATETIME_DEPLOY_PROPERTY, true);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List versionList = performQuery(query);

        if (!versionList.isEmpty()) {
            return versionList;

        } else {
            return null;
        }
    }

    public List getTemplateVersions (Template template) {

        SelectQuery query = getTemplateVersionsQuery(template);

        return performQuery(query);
    }

    /**
     * Get a query that returns the list of Template versions for the given template
     *
     * @param template the template
     * @return a query to retrieve the list of Template version objects for the given template
     */
    public SelectQuery getTemplateVersionsQuery(Template template) {
        Expression expression = ExpressionFactory.matchExp(TemplateVersion.TEMPLATE_PROPERTY, template);

        SelectQuery query = new SelectQuery(TemplateVersion.class, expression);
        query.addOrdering(TemplateVersion.VERSION_NUMBER_PROPERTY, true);

        return query;
    }

    public List getSpecifiedAttachments(Object templateId) {

        SelectQuery query = new SelectQuery(SpecifiedAttachment.class, ExpressionFactory.matchExp(SpecifiedAttachment.TEMPLATE_PROPERTY, templateId));
        query.addOrdering(SpecifiedAttachment.ATTACHMENT_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List getTemplateList(String clientId, String nameLike, boolean shared, int pageSize) {
        SelectQuery query = new SelectQuery(Template.class);

        if (StringUtils.isNotEmpty(clientId)) {
            andQueryMatchExp(query, Template.CLIENT_PROPERTY, clientId);
        }
        if (StringUtils.isNotEmpty(nameLike)) {
            andQueryLikeIgnoreCaseExp(query, Template.TEMPLATE_NAME_PROPERTY, "%" + nameLike + "%");
        }
        andQueryMatchExp(query, Template.SHARED_FLAG_PROPERTY, true);

        query.addPrefetch(Template.CURRENT_VERSION_PROPERTY);
        query.addPrefetch(Template.CLIENT_PROPERTY);

        query.addOrdering(Template.TEMPLATE_NAME_PROPERTY, Ordering.ASC);

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public SelectQuery getSharedTemplateQuery(String clientId) {
        SelectQuery query = new SelectQuery(Template.class);

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(Template.CLIENT_PROPERTY, clientId));
            query.orQualifier(ExpressionFactory.matchExp(Template.CLIENT_PROPERTY, null));
        }

        andQueryMatchExp(query, Template.SHARED_FLAG_PROPERTY, Boolean.TRUE);

        query.addOrdering(Template.TEMPLATE_NAME_PROPERTY, Ordering.ASC);

        return query;
    }

    public List<Template> getSharedTemplatesForClient(String clientId) {
        SelectQuery query = new SelectQuery(Template.class);

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(Template.CLIENT_PROPERTY, clientId));
        }

        query.andQualifier(ExpressionFactory.matchExp(Template.SHARED_FLAG_PROPERTY, Boolean.TRUE));

        return performQuery(query);
    }

    public List getAllTemplates() {
        SelectQuery query = new SelectQuery(Template.class);

        query.addPrefetch(Template.CURRENT_VERSION_PROPERTY);
        query.addPrefetch(Template.CLIENT_PROPERTY);

        query.addOrdering(Template.TEMPLATE_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public Template getTemplateByName(String name) {
        SelectQuery query = new SelectQuery(Template.class);

        if (StringUtils.isNotEmpty(name)) {
            query.andQualifier(ExpressionFactory.matchExp(Template.TEMPLATE_NAME_PROPERTY, name));
        }
        List templates = performQuery(query);

        if (templates.size() > 0) {
            return (Template) templates.get(0);

        } else {
            return null;
        }
    }
}

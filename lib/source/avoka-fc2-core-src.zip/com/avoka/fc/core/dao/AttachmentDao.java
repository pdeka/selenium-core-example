package com.avoka.fc.core.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Submission;

public class AttachmentDao extends BaseDao {

    public List getAttachmentsForSubmissionKey(String submissionId) {
        if (StringUtils.isNotBlank(submissionId)) {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("submissionId", submissionId);

            return performNamedQuery(NamedQueries.ATTACHMENTS_FOR_SUBMISSION, params, true);
        }
        return null;
    }

    public Attachment getAttachmentForAttachmentKey(String clientKey, String attachmentKey) {
        SelectQuery query = new SelectQuery(Attachment.class);

        String path = Attachment.SUBMISSION_PROPERTY + "." + Submission.CLIENT_PROPERTY + "." + Client.CLIENT_KEY_PROPERTY;
        andQueryMatchExp(query, path, clientKey);
        andQueryMatchExp(query, Attachment.ATTACHMENT_KEY_PROPERTY, attachmentKey);

        query.addPrefetch(Attachment.FILE_UPLOAD_PROPERTY);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (Attachment) list.get(0);

        } else {
            return null;
        }
    }

    public List<Attachment> getSubmissionFileAttachments(Submission submission) {
        SelectQuery query = new SelectQuery(Attachment.class);

        andQueryMatchExp(query, Attachment.SUBMISSION_PROPERTY, submission);

        query.addPrefetch(Attachment.FILE_UPLOAD_PROPERTY);

        return performQuery(query);
    }

    /**
     * Return the data of all the electronic attachments associated with the given submission.
     * @param submissionId
     * @return
     */
    public List getSubmissionElectronicAttachments(String submissionId) {
        if (StringUtils.isNotBlank(submissionId)) {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("submissionId", submissionId);

            return performNamedQuery(NamedQueries.ELECTRONIC_ATTACHMENTS_FOR_SUBMISSION, params, true);
        }
        return null;
    }

}

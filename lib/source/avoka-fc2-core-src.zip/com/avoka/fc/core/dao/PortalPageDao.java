package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.AuditLog;
import com.avoka.fc.core.entity.PortalPage;


public class PortalPageDao extends BaseDao {

    public PortalPage getObjectForPK(Object object) {
        return (PortalPage) super.getObjectForPK(PortalPage.class, object);
    }

    public PortalPage getPortalPageByName(Object portalId, String name) {
        Validate.notNull(portalId, "Null portalId parameter");
        Validate.notNull(name, "Null name parameter");

        SelectQuery query = new SelectQuery(PortalPage.class);

        andQueryMatchExp(query, PortalPage.PORTAL_PROPERTY, portalId);
        andQueryMatchExp(query, PortalPage.NAME_PROPERTY, name);

        query.setCacheStrategy(QueryCacheStrategy.SHARED_CACHE);

        List<PortalPage> pageList = performQuery(query);

        if (!pageList.isEmpty()) {
            return pageList.get(0);

        } else {
            return null;
        }
    }

    public List getPortalPageList(Object portalId, Object[] portalPageIds) {
        Validate.notNull(portalId, "Null portalId parameter");
        Validate.notNull(portalPageIds, "Null portalPageIds parameter");

        SelectQuery query = new SelectQuery(PortalPage.class);

        andQueryMatchExp(query, PortalPage.PORTAL_PROPERTY, portalId);
        query.andQualifier(ExpressionFactory.inDbExp("portal_page_oid", portalPageIds));
        query.addOrdering(new Ordering(PortalPage.NAME_PROPERTY, SortOrder.ASCENDING));

        return performQuery(query);
    }

    public List getPortalPageList(Object portalId) {
        Validate.notNull(portalId, "Null portalId parameter");

        SelectQuery query = new SelectQuery(PortalPage.class);

        andQueryMatchExp(query, PortalPage.PORTAL_PROPERTY, portalId);
        query.addOrdering(new Ordering(PortalPage.NAME_PROPERTY, SortOrder.ASCENDING));

        return performQuery(query);
    }

    public void commitChanges() {
        getDataContext().commitChanges();
    }
}

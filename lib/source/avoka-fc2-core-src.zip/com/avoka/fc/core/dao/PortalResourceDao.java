package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.PortalResource;


public class PortalResourceDao extends BaseDao {

    public PortalResource getObjectForPK(Object object) {
        return (PortalResource) super.getObjectForPK(PortalResource.class, object);
    }

    public PortalResource getPortalResourceByPath(Object portalId, String path) {
        Validate.notNull(portalId, "Null portalId parameter");
        Validate.notNull(path, "Null path parameter");

        SelectQuery query = new SelectQuery(PortalResource.class);

        andQueryMatchExp(query, PortalResource.PORTAL_PROPERTY, portalId);
        andQueryMatchExp(query, PortalResource.PATH_PROPERTY, path);

        query.setCacheStrategy(QueryCacheStrategy.SHARED_CACHE);

        List<PortalResource> pageList = performQuery(query);

        if (!pageList.isEmpty()) {
            return pageList.get(0);

        } else {
            return null;
        }
    }

    public List getPortalResourceList(Object portalId, Object[] portalResourceIds) {
        Validate.notNull(portalId, "Null portalId parameter");
        Validate.notNull(portalResourceIds, "Null portalResourceIds parameter");

        SelectQuery query = new SelectQuery(PortalResource.class);

        andQueryMatchExp(query, PortalResource.PORTAL_PROPERTY, portalId);
        query.andQualifier(ExpressionFactory.inDbExp("portal_resource_oid", portalResourceIds));

        return performQuery(query);
    }

    public List getPortalResourceList(Object portalId) {
        Validate.notNull(portalId, "Null portalId parameter");

        SelectQuery query = new SelectQuery(PortalResource.class);

        andQueryMatchExp(query, PortalResource.PORTAL_PROPERTY, portalId);
        query.addOrdering(new Ordering(PortalResource.PATH_PROPERTY,SortOrder.ASCENDING));

        return performQuery(query);
    }

    public void commitChanges() {
        getDataContext().commitChanges();
    }
}


package com.avoka.fc.core.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Invoice;
import com.avoka.fc.core.entity.InvoiceLineitem;
import com.avoka.fc.core.entity.InvoicePlan;
import com.avoka.fc.core.entity.InvoicePlanStep;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.util.ApplicationException;

public class InvoiceDao extends BaseDao {

    public Invoice getInvoice(Client client, Date submissionDate) {
        SelectQuery query = new SelectQuery(Invoice.class);

        // PRC Note. End date will be 1st of next month. so 1 Apr to 1 May
        query.andQualifier(ExpressionFactory.matchExp(Invoice.CLIENT_PROPERTY, client));
        query.andQualifier(ExpressionFactory.greaterOrEqualExp(Invoice.START_DATE_PROPERTY, submissionDate));
        query.andQualifier(ExpressionFactory.lessExp(Invoice.END_DATE_PROPERTY, submissionDate));

        List list = performQuery(query);

        if (list.isEmpty()) {
            return null;
        }

        return (Invoice) list.get(0);
    }

    /**
     * Create an invoice for a specific client and covering a given date.
     *
     *
     * @param client
     * @param submissionDate
     * @param invoicePlan
     * @return
     */
    public Invoice createInvoice(Client client, Date submissionDate, InvoicePlan invoicePlan) {
        Invoice invoice = (Invoice) createAndRegisterNewObject(Invoice.class);
        invoice.setClient(client);
        invoice.setPlan(invoicePlan);

        /*
         * Start Day will be a specific day of the month ie 1 to 28.
         * The edit screen will need to limit this to numbers under 28.
         * Normally this will all default to 1.
         */
        int startDay = invoicePlan.getDefaultStartDay().intValue();

        int clientStartDay = client.getInvoiceStartDay().intValue();

        if (startDay != clientStartDay) {
            startDay = clientStartDay;
        }

        Date startDate = computeStartDate(startDay);
        Date endDate = computeEndDate(startDate);

        invoice.setEndDate(endDate);
        invoice.setStartDate(startDate);

        return invoice;
    }

    /**
     *
     * @param invoice
     * @param invoicePlan
     * @param startItem - The Next item number to be invoiced.
     * @return
     */
    public InvoiceLineitem createLineItem(Invoice invoice, InvoicePlan invoicePlan, int startItem, Submission submission) {
        InvoiceLineitem invoiceLineItem = (InvoiceLineitem) createAndRegisterNewObject(InvoiceLineitem.class);

        invoiceLineItem.setInvoice(invoice);


        /*
         * PRC. Need to get the plan steps and ensure that we have the correct step associated with
         * this line item. Each Line item represents a single step in the invoice plan.
         *
         * The first item will always be 1 (not 0).
         */
        List planStepList = invoicePlan.getStepsOrdered();

        for (Iterator iter = planStepList.iterator(); iter.hasNext();) {
            InvoicePlanStep step = (InvoicePlanStep) iter.next();
            if (startItem >= step.getStepStart().intValue()) {
                // This is the one.
                invoiceLineItem.setStep(step);
                // Must be 1 less than the start as this will be incremented later.
                invoiceLineItem.setItemCount(new Integer (step.getStepStart().intValue() - 1));
                return invoiceLineItem;
            }
        }

        String msg = "Invoice = " + invoice.getId() + " InvoicePlan = " + invoicePlan.getId() + " Start Item No = " + startItem + " Submission = " + submission.getId();

        throw new ApplicationException ("NoInvoicePlanSteps", msg, "Cannot locate a Invoice Plan Step", "Check that the step end number is null for the last invoice plan step.");

    }

    /**
     * Calculate the invoice start date using the correct start day. It must be before the current
     * date.
     *
     * @param startDay
     * @return
     */
    private Date computeStartDate(int startDay) {
        GregorianCalendar gCalnow = new GregorianCalendar();

        GregorianCalendar gCalStartDate = new GregorianCalendar();
        gCalStartDate.set(Calendar.DAY_OF_MONTH, startDay);

        // Set the time to midnight.
        gCalStartDate.set(Calendar.HOUR_OF_DAY, 0);
        gCalStartDate.set(Calendar.MINUTE, 0);
        gCalStartDate.set(Calendar.SECOND, 0);
        gCalStartDate.set(Calendar.MILLISECOND, 0);

        if (gCalStartDate.after(gCalnow)) {
            // Subtract a month.
            gCalStartDate.add(Calendar.MONTH, -1);
        }

        return gCalStartDate.getTime();

    }

    private Date computeEndDate(Date startDate) {

        GregorianCalendar gCalEndDate = new GregorianCalendar();
        gCalEndDate.setTime(startDate);
        gCalEndDate.add(Calendar.MONTH, -1);

        return gCalEndDate.getTime();

    }

}

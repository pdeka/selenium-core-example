package com.avoka.fc.core.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.Submission;

public class ErrorLogDao extends BaseDao {

    /**
     * Return the error log object for the given id.
     */
    public ErrorLog getErrorLogForId(Object id) {
        if (StringUtils.isNumeric(String.valueOf(id))) {
            return (ErrorLog) getObjectForPK(ErrorLog.class, id);
        } else {
            return null;
        }
    }

    public List getErrorLogList(String clientId, String errorId, String submissionId, String message, Date startDate, Date endDate, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(ErrorLog.class);

        if (StringUtils.isNotBlank(clientId)) {
            Expression clientExpression = ExpressionFactory.matchExp(ErrorLog.CLIENT_PROPERTY, clientId);
            query.andQualifier(clientExpression);
        }
        if (StringUtils.isNotBlank(errorId)) {
            andQueryMatchDbExp(query, ErrorLog.ERROR_OID_PK_COLUMN, errorId);
        }
        if (StringUtils.isNotBlank(submissionId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(ErrorLog.SUBMISSION_PROPERTY + "." + Submission.SUBMISSION_OID_PK_COLUMN, submissionId));
        }
        if (StringUtils.isNotBlank(message)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(ErrorLog.MESSAGE_PROPERTY, "%" + message + "%"));
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(ErrorLog.ERROR_TIME_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(ErrorLog.ERROR_TIME_PROPERTY, endDate));
        }

        boolean sortedByErrorTime = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(ErrorLog.ERROR_TIME_PROPERTY)) {
                sortedByErrorTime = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByErrorTime) {
            query.addOrdering(ErrorLog.ERROR_TIME_PROPERTY, Ordering.DESC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public void purgeErrorLog(int maxAgeDays) {
        if (maxAgeDays > 0) {
            Calendar calendar = new GregorianCalendar();
            calendar.add(Calendar.DATE, -1 * maxAgeDays);
            java.sql.Date cutoffDate = new java.sql.Date(calendar.getTime().getTime());
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("cutoffTime", cutoffDate);

            performNamedQuery(NamedQueries.PURGE_ERROR_LOG, params, true);
        }
    }
}

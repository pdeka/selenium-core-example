/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserRole;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.Role;
import com.avoka.fc.core.entity.RolePermission;

/**
 * Provides an Role DAO.
 *
 * @author medgar@avoka.com
 */
public class RoleDao extends BaseDao {

    /**
     * Return the role for the given id.
     *
     * @param id the role primary key
     * @return the role for the given id
     */
    public Role getRole(Object id) {
        return (Role) getObjectForPK(Role.class, id);
    }

    public List getRoleList(UserAccount adminDetails, String name, String description, int pageSize) {
        SelectQuery query = new SelectQuery(Role.class);

        if (adminDetails.getClient() != null) {
            andQueryMatchExp(query, Role.CLIENT_ASSIGNABLE_FLAG_PROPERTY, true);
        }
        if (StringUtils.isNotEmpty(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Role.ROLE_NAME_PROPERTY, "%" + name + "%"));
        }
        if (StringUtils.isNotEmpty(description)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Role.ROLE_DESCRIPTION_PROPERTY, "%" + description + "%"));
        }

        query.addOrdering(new Ordering(Role.ROLE_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE));

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public Role getRoleForName(String name) {
        return (Role) findObject(Role.class, Role.ROLE_NAME_PROPERTY, name);
    }

    /**
     * Return all the roles.
     *
     * @return all the roles
     */
    public List<Role> getRoles() {
        SelectQuery query = new SelectQuery(Role.class);

        query.addOrdering(Role.ROLE_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    /**
     * Return all the roles.
     *
     * @return all the roles
     */
    public List<Role> getAssignableRolesForAdmin(UserAccount adminDetails) {
        SelectQuery query = new SelectQuery(Role.class);

        if (adminDetails.getClient() != null) {
            andQueryMatchExp(query, Role.CLIENT_ASSIGNABLE_FLAG_PROPERTY, true);
        }

        query.addOrdering(Role.ROLE_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    public List<UserRole> getGlobalRolesForAdmin(String adminId) {
        SelectQuery query = new SelectQuery(UserRole.class);

        query.andQualifier(ExpressionFactory.matchExp(UserRole.ADMIN_PROPERTY, adminId));

        String clientAssignablePath = UserRole.ROLE_PROPERTY + "." + Role.CLIENT_ASSIGNABLE_FLAG_PROPERTY;
        Expression assignableFlagExpression = ExpressionFactory.matchExp(clientAssignablePath, null);
        query.andQualifier(assignableFlagExpression.orExp(ExpressionFactory.matchExp(clientAssignablePath, false)));

        return performQuery(query);
    }

    public void assignDefaultPermissions() {
        // find root admin role
        Role role = getRoleForName(Role.ADMINISTRATOR_ROLE);

        if (role == null) {
            role = new Role();
            role.setRoleName(Role.ADMINISTRATOR_ROLE);
            role.setRoleDescription("Root System Administrator");
            getDataContext().registerNewObject(role);
        }

        // list existing permissions
        List<RolePermission> rolePermissions = role.getRolePermissions();
        Set<String> currentPermissionNames = new HashSet<String>(rolePermissions.size());
        for (RolePermission rolePermission: rolePermissions) {
            currentPermissionNames.add(rolePermission.getPermission().getPermissionName());
        }

        // assign all permissions to the root administrator
        PermissionDao permissionDao = new PermissionDao();
        List <Permission> permissions = permissionDao.getPermissionList();
        for (Permission permission: permissions) {
            if (!currentPermissionNames.contains(permission.getPermissionName())) {
                RolePermission newRolePermission = new RolePermission();
                registerNewObject(newRolePermission);
                newRolePermission.setPermission(permission);
                newRolePermission.setRole(role);
            }
        }
    }
}

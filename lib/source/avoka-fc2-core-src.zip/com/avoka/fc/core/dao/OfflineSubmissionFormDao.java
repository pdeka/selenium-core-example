package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.TemplateVersion;

public class OfflineSubmissionFormDao extends BaseDao {
    public List<OfflineSubmissionForm> getAll() {
        SelectQuery query = new SelectQuery(OfflineSubmissionForm.class);

        return performQuery(query);
    }

    public List<OfflineSubmissionForm> getOfflineSubmissionFormsToPublish() {
        SelectQuery query = new SelectQuery(OfflineSubmissionForm.class);

        andQueryMatchExp(query, OfflineSubmissionForm.PUBLISH_STATUS_PROPERTY, TemplateVersion.PUBLISH_STATUS_READY);

        return performQuery(query);
    }
}

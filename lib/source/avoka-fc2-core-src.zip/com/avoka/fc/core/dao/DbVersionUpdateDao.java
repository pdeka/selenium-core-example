
package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.DbVersionUpdate;

public class DbVersionUpdateDao extends BaseDao {

    public List<DbVersionUpdate> getDbVersionUpdateList() {
        SelectQuery query = new SelectQuery(DbVersionUpdate.class);

        query.addOrdering(DbVersionUpdate.DB_VERSION_PROPERTY, true);

        return performQuery(query);
    }

    public List<DbVersionUpdate> getDbVersionUpdateList(Integer version, String releaseLike, Date startDate, Date endDate, int pageSize) {
        SelectQuery query = new SelectQuery(DbVersionUpdate.class);

        if (version != null) {
            query.andQualifier(ExpressionFactory.matchExp(DbVersionUpdate.DB_VERSION_PROPERTY, version.intValue()));
        }
        if (StringUtils.isNotEmpty(releaseLike)) {
            query.andQualifier(ExpressionFactory.likeExp(DbVersionUpdate.RELEASE_VERSION_PROPERTY, "%" + releaseLike + "%"));
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(DbVersionUpdate.UPDATE_TIMESTAMP_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessExp(DbVersionUpdate.UPDATE_TIMESTAMP_PROPERTY, endDate));
        }

        query.setPageSize(pageSize);
        query.addOrdering(DbVersionUpdate.DB_VERSION_PROPERTY, true);

        return performQuery(query);
    }
}

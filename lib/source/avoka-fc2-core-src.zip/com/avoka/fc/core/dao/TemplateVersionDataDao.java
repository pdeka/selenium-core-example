package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.TemplateVersionData;

public class TemplateVersionDataDao extends BaseDao {

    public List<TemplateVersionData> getAll() {
        SelectQuery query = new SelectQuery(TemplateVersionData.class);

        query.setPageSize(5);
//        query.setFetchLimit(5);


//        return performQuery(query);

        return getDataContext().performQuery(query);
    }

    public TemplateVersionData getDataForTemplateVersion(TemplateVersion templateVersion) {
        SelectQuery query = new SelectQuery(TemplateVersionData.class);

        andQueryMatchExp(query, TemplateVersionData.TEMPLATE_VERSION_PROPERTY, templateVersion);

        List<TemplateVersionData> result = performQuery(query);
        if (result == null || result.size() == 0) {
            return null;
        }
        else {
            return result.get(0);
        }
    }

}

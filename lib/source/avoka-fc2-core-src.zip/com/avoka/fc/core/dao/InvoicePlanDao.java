package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.InvoicePlan;


public class InvoicePlanDao extends BaseDao {

    public InvoicePlan getDetaultPlan () {
        Expression expression = ExpressionFactory.matchExp(InvoicePlan.DEFAULT_PLAN_FLAG_PROPERTY, "1");
        SelectQuery query = new SelectQuery(InvoicePlan.class, expression);

        List list = performQuery(query);

        if (list.isEmpty()) {
            return null;
        }

        return (InvoicePlan) list.get(0);
    }

}

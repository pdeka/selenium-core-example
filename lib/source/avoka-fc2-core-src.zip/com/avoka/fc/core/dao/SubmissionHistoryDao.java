/*
 * Copyright (c) 2007-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionHistory;

/**
 * Provides a Submission History entity DAO.
 *
 * @author lpammer@avoka.com
 */
public class SubmissionHistoryDao extends BaseDao {

    /**
     * Return the submission for the given primary key.
     *
     * @param id
     *            the submission primary key
     * @return the submission for the given primary key
     */
    public SubmissionHistory getSubmissionHistory(Object id) {
        return (SubmissionHistory) getObjectForPK(SubmissionHistory.class, id);
    }

    public List<SubmissionHistory> getSubmissionHistoryByForm(String formName) {

        SelectQuery query = new SelectQuery(SubmissionHistory.class);

        Expression e =

        ExpressionFactory.matchExp(SubmissionHistory.SUBMISSION_PROPERTY + "."
                + Submission.FORM_PROPERTY + "."+Form.FORM_NAME_PROPERTY, formName);

        query.andQualifier(e);
        query.andQualifier(ExpressionFactory.matchExp(
                SubmissionHistory.FORM_STATUS_PROPERTY,Submission.STATUS_Saved ));

        return performQuery(query);

    }

    public List<SubmissionHistory> getSubmissionHistoryByFormAndDate(String formName, Date startDate, Date endDate) {

        SelectQuery query = new SelectQuery(SubmissionHistory.class);

        Expression e = ExpressionFactory.matchExp(SubmissionHistory.SUBMISSION_PROPERTY + "."
                + Submission.FORM_PROPERTY + "."+Form.FORM_NAME_PROPERTY, formName);
        query.andQualifier(e);

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(
                    SubmissionHistory.DATETIME_CREATED_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessExp(
                    SubmissionHistory.DATETIME_CREATED_PROPERTY, endDate));
        }

        query.andQualifier(ExpressionFactory.matchExp(
                SubmissionHistory.FORM_STATUS_PROPERTY,Submission.STATUS_Saved ));

        return performQuery(query);

    }


}

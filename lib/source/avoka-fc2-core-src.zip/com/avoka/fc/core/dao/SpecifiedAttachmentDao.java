package com.avoka.fc.core.dao;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.SpecifiedAttachment;

public class SpecifiedAttachmentDao extends BaseDao {

    public SpecifiedAttachment getAttachment(String attachmentId) {
        return (SpecifiedAttachment) getObjectForPK(SpecifiedAttachment.class, attachmentId);
    }
}

/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.dao;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.core.util.FileUtils;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.util.ApplicationException;

public class TemplateVersionDao extends BaseDao{

    private DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();

    public TemplateVersion getTemplateVersionFromPK(Object primaryKeyId){
        return (TemplateVersion) getObjectForPK(TemplateVersion.class, primaryKeyId);
    }

    /**
     * Fetches all template versions defined in the system, with no fetch limit and a limited page size
     */
    public List<TemplateVersion> getAll(){
        SelectQuery query = new SelectQuery(TemplateVersion.class);

        query.setFetchLimit(0);
        query.setPageSize(100);

        // we do not call the inherited method because that would set the default fetch limit
        return getDataContext().performQuery(query);
    }

    /**
     * Fetches all template versions that are missing the file size, with no fetch limit and a limited page size
     */
    public List<TemplateVersion> getTemplateVersionsWithNullFileSize() {
        SelectQuery query = new SelectQuery(TemplateVersion.class);

        andQueryMatchExp(query, TemplateVersion.FILE_SIZE_PROPERTY, null);

        query.setFetchLimit(0);
        query.setPageSize(100);

        // we do not call the inherited method because that would set the default fetch limit
        return getDataContext().performQuery(query);
    }

    /**
     * Returns the full path and file name for a Template Version
     *
     * @return
     * @throws ApplicationException
     */
    public String getTemplateVersionDirectory(TemplateVersion version) throws ApplicationException{
        Validate.notNull(version, "Null version parameter");

        return getTemplateVersionDirectory(version.getId().toString());
    }

    /**
     * Return the Template Version upload directory given a templateVersionId.
     *
     * @param schemaId
     * @return
     */
    public String getTemplateVersionDirectory(final String templateVersionId){
        Validate.notNull(templateVersionId, "Null templateVersionId parameter");

        String path = "templates" + File.separator + templateVersionId;

        return deploymentPropertyDao.getConfigSubDirectory(path);
    }

    /**
     * Returns the full path and file name for a Template Version
     *
     * @return
     * @throws ApplicationException
     */
    public String getTemplateFileFullName(TemplateVersion version) throws ApplicationException{
        Validate.notNull(version, "Null version parameter");

        return getTemplateVersionDirectory(version) + version.getFileName();
    }

    /**
     * Returns the full path and file name for a Template Version
     *
     * @return
     * @throws ApplicationException
     */
    public String getTemplateReaderFileFullName(TemplateVersion version) throws ApplicationException{
        // TODO: review where used
        return getTemplateVersionDirectory(version) + version.getReaderExtendedFileName();
    }

    /**
     * This does not work for PDF/Binary Files. PRC
     *
     * @param directory
     * @return
     * @throws ApplicationException
     */
    public String getTemplateFileAsString(TemplateVersion version, String directory) throws ApplicationException{
        String fileName = directory + version.getFileName();

        File seedFile = new File(directory + version.getFileName());

        try {
            getLogger().debug("Loading Template File " + fileName);

            StringBuffer buf = FileUtils.readFileAsString(seedFile);
            return buf.toString();

        } catch (IOException ex) {
            String context = "TemplateVersion OID = " + version.getId() + " File Name = " + seedFile;
            throw new ApplicationException("ExceptionReadingTemplateFile", ex, context, "",
                    "Check that the file exists, or that directory path has been configured correctly in the DeployProperties");
        }
    }

    public byte[] getTemplateFileBytes(TemplateVersion version) throws ApplicationException{

        File seedFile = new File(getTemplateFileFullName(version));

        try {
            getLogger().debug("Loading Template File " + getTemplateFileFullName(version));

            return FileUtils.readFileAsByteArray(seedFile);

        } catch (IOException ex) {
            String context = "TemplateVersion OID = " + version.getId() + " File Name = " + seedFile;
            throw new ApplicationException("ExceptionReadingTemplateFile", ex, context, "",
                    "Check that the file exists, or that directory path has been configured correctly in the DeployProperties");
        }
    }

    public String getTemplateFileMD5(TemplateVersion version) throws ApplicationException{

        File file = new File(getTemplateFileFullName(version));

        if (file.isFile() && file.canRead()) {
            try {
                return FileUtils.getFileMD5(file);

            } catch (IOException ex) {
                String context = "TemplateVersion OID = " + version.getId() + " File Name = " + file;
                throw new ApplicationException("ExceptionReadingTemplateFile", ex, context, "",
                        "Check that the file exists, or that directory path has been configured correctly in the DeployProperties");
            }
        } else {
            return null;
        }
    }

    public byte[] getTemplateReaderFileBytes(TemplateVersion version) throws ApplicationException{

        File seedFile = new File(getTemplateReaderFileFullName(version));

        try {
            getLogger().debug("Loading Template File " + getTemplateReaderFileFullName(version));

            return FileUtils.readFileAsByteArray(seedFile);

        } catch (IOException ex) {
            String context = "TemplateVersion OID = " + version.getId() + " File Name = " + seedFile;
            throw new ApplicationException("ExceptionReadingTemplateFile", ex, context, "",
                    "Check that the file exists, or that directory path has been configured correctly in the DeployProperties");
        }
    }

    public String getTemplateReaderFileMD5(TemplateVersion version) throws ApplicationException{

        File file = new File(getTemplateReaderFileFullName(version));

        if (file.isFile() && file.canRead()) {
            try {
                return FileUtils.getFileMD5(file);

            } catch (IOException ex) {
                String context = "TemplateVersion OID = " + version.getId() + " File Name = " + file;
                throw new ApplicationException("ExceptionReadingTemplateFile", ex, context, "",
                        "Check that the file exists, or that directory path has been configured correctly in the DeployProperties");
            }

        } else {
            return null;
        }
    }

    public List<TemplateVersion> getTemplateVersionsToPublish(){
        SelectQuery query = new SelectQuery(TemplateVersion.class);

        andQueryMatchExp(query, TemplateVersion.PUBLISH_STATUS_PROPERTY, TemplateVersion.PUBLISH_STATUS_READY);

        return performQuery(query);
    }

    public List<TemplateVersion> getTemplateVersionsSearch(String clientId, String value){
        SelectQuery query = new SelectQuery(TemplateVersion.class);

        if (StringUtils.isNotEmpty(value)) {
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(TemplateVersion.TEMPLATE_PROPERTY + "."
                    + Template.TEMPLATE_NAME_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(TemplateVersion.FILE_NAME_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(TemplateVersion.VERSION_NUMBER_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(TemplateVersion.NOTES_PROPERTY, "%" + value + "%"));
            if (NumberUtils.isNumber(value)) {
                query.orQualifier(ExpressionFactory.matchDbExp(TemplateVersion.VERSION_OID_PK_COLUMN, value));
            }
        }
        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(TemplateVersion.TEMPLATE_PROPERTY + "." + Template.CLIENT_PROPERTY
                    + "." + Client.CLIENT_OID_PK_COLUMN, clientId));
        }

        query.addOrdering(TemplateVersion.VERSION_NUMBER_PROPERTY, true);

        return performQuery(query);
    }

    /**
     * Returns a list of templateVersion that have no promotionLog records.
     *
     * @return
     */
    public List getVersionsForPromotion(Form form){

        Map<String, Object> params = new HashMap<String, Object>();

        params.put("formOid", form.getId());

        return performNamedQuery(NamedQueries.VERSIONS_FOR_PROMOTION, params, true);
    }

    public TemplateVersion getCurrentDeployedVersion(Template template) {
        Date currentDate = new Date();

        List<TemplateVersion> versions = template.getVersions();
        if (versions.isEmpty()) {
            return null;
        }

        // If not current version search for last effective date version
        TemplateVersion currentVersion = template.getCurrentVersion();
        if (currentVersion == null) {
            for (TemplateVersion templateVersion : versions) {
                if (templateVersion.getDatetimeDeploy() != null && templateVersion.getDatetimeDeploy().before(currentDate)) {
                    currentVersion = templateVersion;
                }
            }

            // If none found then get first template which is not set to be undeployed after this time
            if (currentVersion == null) {
                TemplateVersion templateVersion = versions.get(0);
                if (templateVersion.getDatetimeUndeploy() == null) {
                    currentVersion = templateVersion;
                } else if (templateVersion.getDatetimeUndeploy().after(currentDate)) {
                    currentVersion = templateVersion;
                }
            }

        } else {
            // Search for next version to be deployed.
            TemplateVersion nextVersion = null;
            for (TemplateVersion templateVersion : versions) {
                if (templateVersion.getDatetimeDeploy() != null && templateVersion.getDatetimeDeploy().before(currentDate)) {
                    nextVersion = templateVersion;
                }
            }

            // If found then ensure template version not due to be undeployed after this time
            if (nextVersion != null) {
                if (nextVersion.getDatetimeUndeploy() == null) {
                    currentVersion = nextVersion;
                } else if (nextVersion.getDatetimeUndeploy().after(currentDate)) {
                    currentVersion = nextVersion;
                }
            }
        }

        template.setCurrentVersion(currentVersion);

        return currentVersion;
    }

}

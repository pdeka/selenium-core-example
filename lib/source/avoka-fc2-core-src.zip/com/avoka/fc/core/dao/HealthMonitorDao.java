
package com.avoka.fc.core.dao;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import com.avoka.core.dao.BaseDao;

public class HealthMonitorDao extends BaseDao {

    public void purgeSystemHealthLog(int maxAgeDays) {
        if (maxAgeDays > 0) {
            Calendar calendar = new GregorianCalendar();
            calendar.add(Calendar.DATE, -1 * maxAgeDays);
            java.sql.Date cutoffDate = new java.sql.Date(calendar.getTime().getTime());
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("cutoffTime", cutoffDate);

            performNamedQuery(NamedQueries.PURGE_SYSTEM_HEALTH_LOG, params, true);
        }
    }
}

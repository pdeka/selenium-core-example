package com.avoka.fc.core.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.core.entity.BaseEntity;
import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.AuditLog;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.RemoteUserProvider;

public class AuditLogDao extends BaseDao {

    /**
     * Create an audit log record.
     *
     * @param entity - the entity to log
     * @param message - the audit message
     * @param type - the audit type "View", "Create", "Update", "Delete"
     */
    public void createAuditLogRecord(BaseEntity entity, String message, String type) {
        Validate.notNull(entity);
        Validate.notEmpty(message);
        Validate.notEmpty(type);

        // Create audit log record
        AuditLog auditLog = (AuditLog) getDataContext().newObject(AuditLog.class);
        auditLog.setAuditDatetime(new Date());
        auditLog.setEventType(type);
        auditLog.setEntityName(entity.getClass().getSimpleName());
        auditLog.setEntityOid(entity.getId());
        auditLog.setMessage(CoreUtils.limitLength(message, 1000));
        auditLog.setChangedBy(RemoteUserProvider.getRemoteUser());
        if (NumberUtils.isNumber(RemoteUserProvider.getClientId())) {
            auditLog.setClientOid(new Long(RemoteUserProvider.getClientId()));
        }
    }

    @SuppressWarnings("deprecation")
    public List getAuditLogList(String clientId, String changedBy, String entityName, String entityId, Date startDate, Date endDate, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(AuditLog.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(AuditLog.CLIENT_OID_PROPERTY, clientId));
        }
        if (StringUtils.isNotBlank(changedBy)) {
            andQueryLikeIgnoreCaseExp(query, AuditLog.CHANGED_BY_PROPERTY, changedBy);
        }
        if (StringUtils.isNotBlank(entityName)) {
            query.andQualifier(ExpressionFactory.matchExp(AuditLog.ENTITY_NAME_PROPERTY, entityName));
        }
        if (StringUtils.isNotBlank(entityId)) {
            query.andQualifier(ExpressionFactory.matchExp(AuditLog.ENTITY_OID_PROPERTY, entityId));
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(AuditLog.AUDIT_DATETIME_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(AuditLog.AUDIT_DATETIME_PROPERTY, endDate));
        }

        boolean sortedByAuditTime = false;
        boolean sortedByChangedBy = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(AuditLog.AUDIT_DATETIME_PROPERTY)) {
                sortedByAuditTime = true;
            }
            if (sortBy.equals(AuditLog.CHANGED_BY_PROPERTY)) {
                sortedByChangedBy = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByAuditTime) {
            query.addOrdering(AuditLog.AUDIT_DATETIME_PROPERTY, Ordering.DESC);
        }
        if (!sortedByChangedBy) {
            query.addOrdering(AuditLog.CHANGED_BY_PROPERTY, Ordering.DESC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public void purgeAuditLog(int maxAgeDays) {
        if (maxAgeDays > 0) {
            Calendar calendar = new GregorianCalendar();
            calendar.add(Calendar.DATE, -1 * maxAgeDays);
            java.sql.Date cutoffDate = new java.sql.Date(calendar.getTime().getTime());
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("cutoffTime", cutoffDate);

            performNamedQuery(NamedQueries.PURGE_AUDIT_LOG, params, true);
        }
    }
}

package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.util.ApplicationException;

public class ServiceDefinitionDao extends BaseDao {

    /**
     * Return the service definition object for the given id, or null if not
     * found.
     *
     * @param id the service definition id
     * @return the service definition object for the given id, or null if not found
     */
    public ServiceDefinition getServiceDefinitionForPK(Object id) {
        return (ServiceDefinition) getObjectForPK(ServiceDefinition.class, id);
    }

    /**
     * Return the ServiceDefinition for the given service name.
     *
     * @param serviceName the service name to lookup
     * @return the ServiceDefinition for the given name
     */
    public ServiceDefinition getServiceDefinitionForName(String serviceName) {
        Validate.notNull(serviceName, "Null serviceName parameter");

        SelectQuery query = new SelectQuery(ServiceDefinition.class);

        andQueryMatchExp(query, ServiceDefinition.SERVICE_NAME_PROPERTY,
                serviceName);

        List list = performQuery(query);

        if (list.isEmpty()) {
            String context = "ServiceDefinition not found for serviceName: " + serviceName;
            String solution = "Configure ServiceDefinition for serviceName: " + serviceName;
            throw new ApplicationException("ServiceLocator", context, context, solution);

        } else {
            return (ServiceDefinition) list.get(0);
        }
    }

    /**
     * Return the default ServiceDefinition for the given service type.
     *
     * @param serviceType the service name to lookup
     * @return the ServiceDefinition for the given name
     */
    public ServiceDefinition getServiceDefinitionDefaultForType(
            String serviceType) {
        Validate.notNull(serviceType, "Null serviceType parameter");

        SelectQuery query = new SelectQuery(ServiceDefinition.class);

        andQueryMatchExp(query, ServiceDefinition.SERVICE_TYPE_PROPERTY, serviceType);
        andQueryMatchExp(query, ServiceDefinition.SERVICE_TYPE_DEFAULT_FLAG_PROPERTY, Boolean.TRUE);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List list = performQuery(query);

        if (list.isEmpty()) {
            String context = "ServiceDefinition not found for serviceType: " + serviceType;
            String solution = "Configure ServiceDefinition for serviceType: " + serviceType;
            throw new ApplicationException("ServiceLocator", context, context, solution);

        } else if (list.size() == 1) {
            return (ServiceDefinition) list.get(0);

        } else {
            String context = "Multiple default ServiceDefinition found for serviceType: " + serviceType;
            String solution = "Configure single default ServiceDefinition for serviceType: " + serviceType;
            throw new ApplicationException("ServiceLocator", context, context,
                    solution);
        }
    }

    /**
     * Return true if there is a ServiceDefinition for the given service type.
     *
     * @param serviceType the service name to lookup
     * @return true if there is a ServiceDefinition for the given service type
     */
    public boolean hasServiceDefinitionForType(String serviceType) {
        Validate.notNull(serviceType, "Null serviceType parameter");

        SelectQuery query = new SelectQuery(ServiceDefinition.class);

        andQueryMatchExp(query, ServiceDefinition.SERVICE_TYPE_PROPERTY, serviceType);

        List list = performQuery(query);

        return !list.isEmpty();
    }

    /**
     * Return true if there is a ServiceDefinition for the given service type.
     *
     * @param serviceType the service name to lookup
     * @return true if there is a ServiceDefinition for the given service type
     */
    public boolean hasDefaultServiceDefinitionForType(String serviceType) {
        Validate.notNull(serviceType, "Null serviceType parameter");

        SelectQuery query = new SelectQuery(ServiceDefinition.class);

        andQueryMatchExp(query, ServiceDefinition.SERVICE_TYPE_PROPERTY, serviceType);
        andQueryMatchExp(query, ServiceDefinition.SERVICE_TYPE_DEFAULT_FLAG_PROPERTY, Boolean.TRUE);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List list = performQuery(query);

        return !list.isEmpty();
    }

    /**
     * Return true if there is a ServiceDefinition for the given service name.
     *
     * @param serviceName
     *            the service name to lookup
     * @return true if there is a ServiceDefinition for the given service name
     */
    public boolean hasServiceDefinitionForName(String serviceName) {
        Validate.notNull(serviceName, "Null serviceName parameter");

        SelectQuery query = new SelectQuery(ServiceDefinition.class);

        andQueryMatchExp(query, ServiceDefinition.SERVICE_NAME_PROPERTY, serviceName);

        List list = performQuery(query);

        return !list.isEmpty();
    }

    /**
     * Return the service definitions for the given name and type.
     *
     * @param name the service name
     * @param type the service type
     * @return the list of service definitions for the given name and type
     */
    public List<ServiceDefinition> getServiceDefinitionList(String name, String type) {

        SelectQuery query = new SelectQuery(ServiceDefinition.class);

        if (StringUtils.isNotEmpty(name)) {
            andQueryLikeIgnoreCaseExp(query, ServiceDefinition.SERVICE_NAME_PROPERTY, name);
        }

        if (StringUtils.isNotEmpty(type)) {
            andQueryLikeIgnoreCaseExp(query, ServiceDefinition.SERVICE_TYPE_PROPERTY, type);
        }

        query.addOrdering(ServiceDefinition.SERVICE_TYPE_PROPERTY, true);
        query.addOrdering(ServiceDefinition.SERVICE_NAME_PROPERTY, true);

        return performQuery(query);
    }

    public void setDefaultType(ServiceDefinition sd) {
        sd.setServiceTypeDefaultFlag(true);

        ArrayList<ServiceDefinition> serviceDefinitionList =
            (ArrayList<ServiceDefinition>) getServiceDefinitionList("", sd.getServiceType());

        // If there are existing definitions with default value set unset the values
        for (ServiceDefinition serviceDefinition : serviceDefinitionList) {
            if (!(serviceDefinition.getServiceName().equals(sd.getServiceName()))) {
                if (serviceDefinition.isDefaultType()) {
                    serviceDefinition.setServiceTypeDefaultFlag(false);
                }
            }
        }
    }

}

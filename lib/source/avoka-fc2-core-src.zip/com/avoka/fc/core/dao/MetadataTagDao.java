
package com.avoka.fc.core.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.NamedQuery;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.MetadataTag;

/**
 * Provides a FormPropetyType DAO.
 *
 * @author medgar@avoka.com
 */
public class MetadataTagDao extends BaseDao {

    public MetadataTag getMetadataTag(String tagId) {
        return (MetadataTag) getObjectForPK(MetadataTag.class, tagId);
    }

    public MetadataTag createMetadataTag() {
        return (MetadataTag) createAndRegisterNewObject(MetadataTag.class);
    }

    public List<MetadataTag> getMetadataTagList(String clientId, String name, String scope, String scheme, int pageSize) {
        SelectQuery query = new SelectQuery(MetadataTag.class);

        if (StringUtils.isNotEmpty(clientId)) {
            andQueryMatchExp(query, MetadataTag.CLIENT_PROPERTY, clientId);
        }
        if (StringUtils.isNotEmpty(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(MetadataTag.NAME_PROPERTY, "%" + name + "%"));
        }
        if (StringUtils.isNotEmpty(scope)) {
            query.andQualifier(ExpressionFactory.matchExp(MetadataTag.SCOPE_PROPERTY, scope));
        }
        if (StringUtils.isNotEmpty(scheme)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(MetadataTag.SCHEME_PROPERTY, "%" + scheme + "%"));
        }

        query.addOrdering(MetadataTag.NAME_PROPERTY, Ordering.ASC);
        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List<MetadataTag> getMetadataTagListForClient(Client client) {
        SelectQuery query = new SelectQuery(MetadataTag.class);

        andQueryMatchExp(query, MetadataTag.CLIENT_PROPERTY, client);

        query.addOrdering(MetadataTag.NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<MetadataTag> getMetadataTagListForForm(Form form) {
        Validate.notNull(form, "Null form parameter");

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("clientId", form.getClient().getId());

        return performNamedQuery(NamedQueries.FORM_METADATA_TAGS, params, true);
    }

    /**
     * Get a query that will return MetadataTags assignable to a client and belonging to a certain scope (client, form, template).
     * If no scope is specified, all assignable metadata tags are returned.
     * If no client is specified, only global metadata tags are returned.
     *
     * @param scope
     * @param clientOid
     * @return
     */
    public SelectQuery getTagQueryForClient(String scope, String clientOid) {
        SelectQuery query = new SelectQuery(MetadataTag.class);

        Expression clientExpression = ExpressionFactory.matchExp(MetadataTag.CLIENT_PROPERTY, null);
        if (StringUtils.isNotEmpty(clientOid)) {
            clientExpression = clientExpression.orExp(ExpressionFactory.matchExp(MetadataTag.CLIENT_PROPERTY, clientOid));
        }
        query.andQualifier(clientExpression);

        query.andQualifier(ExpressionFactory.matchExp(MetadataTag.SCOPE_PROPERTY, scope));
        query.addOrdering(MetadataTag.NAME_PROPERTY, Ordering.ASC);
        return query;
    }

    public NamedQuery getUnsetTemplateTagsQuery(String templateId) {
        if (StringUtils.isNotBlank(templateId)) {
            Map queryParams = new HashMap();
            queryParams.put("templateOid", templateId);
            NamedQuery query = new NamedQuery(NamedQueries.UNSET_TEMPLATE_METADATA, queryParams);
            return query;
        }
        return null;
    }

    public NamedQuery getUnsetClientTagsQuery(String clientId) {
        if (StringUtils.isNotBlank(clientId)) {
            Map queryParams = new HashMap();
            queryParams.put("clientOid", clientId);
            NamedQuery query = new NamedQuery(NamedQueries.UNSET_CLIENT_METADATA, queryParams);
            return query;
        }
        return null;
    }
}

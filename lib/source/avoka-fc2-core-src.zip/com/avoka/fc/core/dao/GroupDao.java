package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Group;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserGroup;

public class GroupDao extends BaseDao {

    /**
     * Package private constructor to enforce factory pattern.
     */
    GroupDao() {
    }

    public void loadDefaultGroups() {
        if (getGroupForName(Group.RECEIVE_PROMOTION_ALERTS) == null) {
            Group group = new Group();
            registerNewObject(group);
            group.setGroupName(Group.RECEIVE_PROMOTION_ALERTS);
            group.setGroupDescription("Receive form promotion alert emails");
            group.setReadonlyFlag(true);
        }

        if (getGroupForName(Group.RECEIVE_SUBMISSION_ALERTS) == null) {
            Group group = new Group();
            registerNewObject(group);
            group.setGroupName(Group.RECEIVE_SUBMISSION_ALERTS);
            group.setGroupDescription("Receive submission warning and escalation alert emails");
            group.setReadonlyFlag(true);
        }

        if (getGroupForName(Group.RECEIVE_SUBMISSION_UPDATES) == null) {
            Group group = new Group();
            registerNewObject(group);
            group.setGroupName(Group.RECEIVE_SUBMISSION_UPDATES);
            group.setGroupDescription("Receive submission status update notification emails");
            group.setReadonlyFlag(true);
        }
    }

    public Group getGroupForPK(Object id) {
        return (Group) getObjectForPK(Group.class, id);
    }

    public Group getGroupForName(String name) {
        return (Group) findObject(Group.class, Group.GROUP_NAME_PROPERTY, name);
    }

    public List<Group> getGroupList(String name, String description, int pageSize) {
        SelectQuery query = new SelectQuery(Group.class);

        if (StringUtils.isNotBlank(name)) {
            andQueryLikeIgnoreCaseExp(query, Group.GROUP_NAME_PROPERTY, name);
        }

        if (StringUtils.isNotBlank(description)) {
            andQueryLikeIgnoreCaseExp(query, Group.GROUP_DESCRIPTION_PROPERTY, description);
        }

        query.addOrdering(Group.GROUP_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List<Group> getGroupList() {
        SelectQuery query = new SelectQuery(Group.class);

        query.addOrdering(Group.GROUP_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    public List<Group> getGroupsForUser(UserAccount userAccount) {
        Validate.notNull(userAccount, "Null userAccount parameter");

        SelectQuery query = new SelectQuery(Group.class);

        andQueryMatchExp(query, Group.USER_GROUPS_PROPERTY + "." + UserGroup.USER_PROPERTY, userAccount);

        query.addOrdering(Group.GROUP_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }
}

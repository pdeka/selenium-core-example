package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.UserProperty;

/**
 * Provides a UserProperty DAO.
 *
 * @author medgar@avoka.com
 */
public class UserPropertyDao extends BaseDao {

    public List getUserPropertyForProfile(String profileId) {
        Expression qual = ExpressionFactory.matchDbExp("profile_oid", profileId);

        SelectQuery query = new SelectQuery(UserProperty.class, qual);

        query.addOrdering(UserProperty.PROPERTY_TYPE_PROPERTY + "." + PropertyType.SEQUENCE_PROPERTY, true);
        query.addOrdering(UserProperty.PROPERTY_TYPE_PROPERTY + "." + PropertyType.NAME_PROPERTY, true);
        query.addPrefetch(UserProperty.PROPERTY_TYPE_PROPERTY);

        return performQuery(query);
    }

    public UserProperty getUserPropertyForPK(Object id) {
        return (UserProperty) getObjectForPK(UserProperty.class, id);
    }

}

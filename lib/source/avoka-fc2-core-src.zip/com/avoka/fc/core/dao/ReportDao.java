/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Report;

/**
 * Provides the Form DAO.
 *
 * @author medgar@avoka.com
 * @author pcopeland@avoka.com
 */
public class ReportDao extends BaseDao {

    public Report getReportFromPK(Integer primaryKeyId) {
        return (Report) getObjectForPK(Report.class, primaryKeyId);
    }

    public List getAllActiveReports() {
        return getActiveReports(null);
    }

    public List getActiveReports(Boolean clientAssignable) {
        SelectQuery query = new SelectQuery(Report.class);

        if (clientAssignable != null) {
            if (Boolean.TRUE.equals(clientAssignable)) {
                query.andQualifier(ExpressionFactory.matchExp(Report.CLIENT_ASSIGNABLE_FLAG_PROPERTY, clientAssignable));
            }
            else {
                Expression notNullExpr = ExpressionFactory.matchExp(Report.CLIENT_ASSIGNABLE_FLAG_PROPERTY, null);
                query.andQualifier(notNullExpr.orExp(ExpressionFactory.noMatchExp(Report.CLIENT_ASSIGNABLE_FLAG_PROPERTY, Boolean.TRUE)));
            }
        }


        query.andQualifier(ExpressionFactory.matchExp(Report.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));
        query.addOrdering(Report.NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List getReportList(String nameLike, Boolean active, int pageSize) {
        SelectQuery query = new SelectQuery(Report.class);

        if (StringUtils.isNotEmpty(nameLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Report.NAME_PROPERTY, "%" + nameLike + "%"));
        }
        if (active != null && active.equals(Boolean.TRUE)) {
            query.andQualifier(ExpressionFactory.matchExp(Report.ACTIVE_FLAG_PROPERTY, active));
        }
        query.addOrdering(Report.NAME_PROPERTY, Ordering.ASC);
        query.addPrefetch(Report.REPORT_CLIENT_PROPERTY);

        query.setPageSize(pageSize);

        return performQuery(query);
    }

}

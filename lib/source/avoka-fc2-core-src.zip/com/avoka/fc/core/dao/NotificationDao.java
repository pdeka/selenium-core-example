
package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Notification;

public class NotificationDao extends BaseDao {

    public List getAdminNotificationList() {
        SelectQuery query = new SelectQuery(Notification.class);

        query.andQualifier(ExpressionFactory.matchExp(Notification.ADMIN_FLAG_PROPERTY, Boolean.TRUE));
        query.addOrdering(Notification.NOTIFY_TIMESTAMP_PROPERTY, Ordering.DESC);

        return performQuery(query);
    }

    public List<Notification> getNotificationList(String subject, String message, Boolean admin, Boolean user, Date startDate, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(Notification.class);

        if (StringUtils.isNotEmpty(subject)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Notification.SUBJECT_PROPERTY, "%" + subject + "%"));
        }
        if (StringUtils.isNotEmpty(message)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Notification.MESSAGE_PROPERTY, "%" + message + "%"));
        }

        query.andQualifier(ExpressionFactory.matchExp(Notification.ADMIN_FLAG_PROPERTY, admin));
        query.andQualifier(ExpressionFactory.matchExp(Notification.USER_FLAG_PROPERTY, user));

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(Notification.NOTIFY_TIMESTAMP_PROPERTY, startDate));
        }

        boolean sortedByNotificationTime = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(Notification.NOTIFY_TIMESTAMP_PROPERTY)) {
                sortedByNotificationTime = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByNotificationTime) {
            query.addOrdering(Notification.NOTIFY_TIMESTAMP_PROPERTY, Ordering.DESC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

}

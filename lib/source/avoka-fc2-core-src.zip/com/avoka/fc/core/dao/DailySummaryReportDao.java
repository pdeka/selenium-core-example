package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.DailySummaryReport;
import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.Submission;

public class DailySummaryReportDao extends BaseDao {


    /**
     * Package private constructor to enforce factory pattern.
     */
    DailySummaryReportDao() {
    }

    /**
     * Get unpublished reports that have been calculated completely. We don't want unpublished reports that
     * haven't been fully calculated.
     * @return
     */
    public List<DailySummaryReport> getUnPublishedDailySummaryReports() {

        SelectQuery query = new SelectQuery(DailySummaryReport.class);

        Expression expression = ExpressionFactory.noMatchExp(DailySummaryReport.PUBLISH_STATUS_PROPERTY,Submission.STATUS_Completed);
        expression = expression.orExp(ExpressionFactory.matchExp(DailySummaryReport.PUBLISH_STATUS_PROPERTY, null));

        query.andQualifier(expression);

        query.andQualifier(ExpressionFactory.matchExp(DailySummaryReport.CALC_STATUS_PROPERTY, Submission.STATUS_Completed));

        query.addOrdering(DailySummaryReport.EFFECTIVE_DATE_PROPERTY, false);

        return performQuery(query);
    }

    /**
     * Return any failed summary reports
     * @return
     */
    public List<DailySummaryReport> getIncompleteDailySummaryReports(){

        SelectQuery query = new SelectQuery(DailySummaryReport.class);
        query.andQualifier(ExpressionFactory.noMatchExp(DailySummaryReport.CALC_STATUS_PROPERTY,Submission.STATUS_Completed));

        return performQuery(query);

    }


    /**
     * @param id
     * @return
     */
    public DailySummaryReport getDailySummaryReportForPK(Object id) {
        return (DailySummaryReport) getObjectForPK(DailySummaryReport.class, id);
    }

    /**
     * Set the daily summary calculations to complete
     * @param effectiveDate
     */
    public void setDailySummaryCalcStatus(Date effectiveDate, String status) {
        SelectQuery query = new SelectQuery(DailySummaryReport.class);

        query.andQualifier(ExpressionFactory.matchExp(DailySummaryReport.EFFECTIVE_DATE_PROPERTY, effectiveDate));
        DailySummaryReport dailySummaryReport;
        List<DailySummaryReport> list = performQuery(query);

        if (!list.isEmpty()) {
            dailySummaryReport = list.get(0);
            dailySummaryReport.setCalcStatus(status);

        } else {
            getLogger().error("daily summary report not found!");
        }

    }

    public void setDailySummaryPublishStatusCompleted(Date effectiveDate) {
        Validate.notNull(effectiveDate);

        SelectQuery query = new SelectQuery(DailySummaryReport.class);

        query.andQualifier(ExpressionFactory.matchExp(DailySummaryReport.EFFECTIVE_DATE_PROPERTY, effectiveDate));
        DailySummaryReport dailySummaryReport;
        List list = performQuery(query);

        if (!list.isEmpty()) {
            dailySummaryReport = (DailySummaryReport) list.get(0);
            dailySummaryReport.setPublishStatus(Submission.STATUS_Completed);
        }
    }

    public void setDailySummaryPublishStatusError(Date effectiveDate, ErrorLog errorLog ) {
        Validate.notNull(effectiveDate);

        SelectQuery query = new SelectQuery(DailySummaryReport.class);

        query.andQualifier(ExpressionFactory.matchExp(DailySummaryReport.EFFECTIVE_DATE_PROPERTY, effectiveDate));
        DailySummaryReport dailySummaryReport;
        List list = performQuery(query);

        if (!list.isEmpty()) {
            dailySummaryReport = (DailySummaryReport) list.get(0);
            dailySummaryReport.setPublishStatus(Submission.STATUS_Error);

            if (errorLog != null) {
                errorLog = DaoFactory.getErrorLogDao().getErrorLogForId(errorLog.getId());
                dailySummaryReport.setErrorLog(errorLog);
            }
        }
    }

    /**
     * Update the submission summary metrics
     *
     * @param effectiveDate
     * @param authSmartformSubs
     * @param unauthSmartformSubs
     * @param offlineSmartformSubs
     * @return
     */
    public DailySummaryReport setDailySummaryReportSummaryMetrics(Date effectiveDate,Integer authSmartformSubs,Integer unauthSmartformSubs, Integer offlineSmartformSubs ) {

        SelectQuery query = new SelectQuery(DailySummaryReport.class);

        getLogger().debug("sett: "+authSmartformSubs+" "+unauthSmartformSubs+" "+offlineSmartformSubs+ "......");

        query.andQualifier(ExpressionFactory.matchExp(DailySummaryReport.EFFECTIVE_DATE_PROPERTY, effectiveDate));
        DailySummaryReport dailySummaryReport;
        List list = performQuery(query);

        if (list.isEmpty()) {
            getLogger().error("could not find a dsr to update summary metrics that matches "+effectiveDate+"  ");
            dailySummaryReport = null;

        } else {
            dailySummaryReport = (DailySummaryReport) list.get(0);

            if (authSmartformSubs!=null) {
                dailySummaryReport.setAuthSmartformSubs(authSmartformSubs);

            } else {
                dailySummaryReport.setAuthSmartformSubs(0);
            }

            if (unauthSmartformSubs!=null) {
                dailySummaryReport.setUnauthSmartformSubs(unauthSmartformSubs);

            } else{
                dailySummaryReport.setUnauthSmartformSubs(0);

            }

            if (offlineSmartformSubs!=null) {
                dailySummaryReport.setOfflineSmartformSubs(offlineSmartformSubs);

            } else {
                dailySummaryReport.setOfflineSmartformSubs(0);

            }

        }
        return dailySummaryReport;

    }

    /**
     * @param effectiveDate
     * @return
     */
    public DailySummaryReport getDailySummaryReportByDate(Date effectiveDate)
    {
        SelectQuery query = new SelectQuery(DailySummaryReport.class);

        query.andQualifier(ExpressionFactory.matchExp(DailySummaryReport.EFFECTIVE_DATE_PROPERTY, effectiveDate));
        DailySummaryReport dailySummaryReport;
        List<DailySummaryReport> list = performQuery(query);

        if (list.isEmpty()) {
            dailySummaryReport = null;

        } else {
            dailySummaryReport = list.get(0);
        }

        return dailySummaryReport;
    }


    /**
     * @return
     */
    public DailySummaryReport getMostRecentDailySummaryReport()
    {
        SelectQuery query = new SelectQuery(DailySummaryReport.class);
        query.addOrdering(DailySummaryReport.FILE_SEQUENCE_NUMBER_PROPERTY, Ordering.DESC);
        List list = performQuery(query);

        DailySummaryReport dailySummaryReport;

        if (list.isEmpty()) {
            dailySummaryReport = null;

        } else {
            dailySummaryReport = (DailySummaryReport) list.get(0);
        }
        return dailySummaryReport;
    }



    /**
     * @param effectiveDate
     * @param errorLog
     * @return
     */
    public DailySummaryReport getOrCreateDailySummaryReport(Date effectiveDate, Integer fileSequenceNumber) {
        DailySummaryReport dailySummaryReport = null;
        SelectQuery query = new SelectQuery(DailySummaryReport.class);

        query.andQualifier(ExpressionFactory.matchExp(DailySummaryReport.EFFECTIVE_DATE_PROPERTY, effectiveDate));

        query.andQualifier(ExpressionFactory.noMatchExp(DailySummaryReport.CALC_STATUS_PROPERTY, Submission.STATUS_Completed));

        List<DailySummaryReport> list = performQuery(query);

        if (list.isEmpty()) {
            dailySummaryReport = (DailySummaryReport) createAndRegisterNewObject(DailySummaryReport.class);
            dailySummaryReport.setEffectiveDate(effectiveDate);
            dailySummaryReport.setAuthSmartformSubs(0);
            dailySummaryReport.setOfflineSmartformSubs(0);
            dailySummaryReport.setUnauthSmartformSubs(0);

            if (fileSequenceNumber != null && fileSequenceNumber.intValue() >  0) {
                dailySummaryReport.setFileSequenceNumber(fileSequenceNumber);

            } else {
                dailySummaryReport.setFileSequenceNumber(1);
            }

        } else {
            dailySummaryReport = list.get(0);
        }
        return dailySummaryReport;

    }

}

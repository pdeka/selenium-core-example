/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserAccount;

/**
 * Provides a Submission entity DAO.
 *
 * @author medgar@avoka.com
 */
public class RequestLogDao extends BaseDao {

    /**
     * Return the submission for the given primary key.
     *
     * @param id the submission primary key
     * @return the submission for the given primary key
     */
    public RequestLog getRequestLog(Object id) {
        return (RequestLog) getObjectForPK(RequestLog.class, id);
    }

    public RequestLog getRequestLogFromKey(String requestLogKey) {
        if (StringUtils.isEmpty(requestLogKey)) {
            return null;
        }

        SelectQuery query = new SelectQuery(RequestLog.class);
        query.andQualifier(ExpressionFactory.matchExp(RequestLog.REQUEST_KEY_PROPERTY, requestLogKey));

        query.addPrefetch(RequestLog.TEMPLATE_VERSION_PROPERTY);

        List<RequestLog> queryList = performQuery(query);

        if (queryList.isEmpty()) {
            return null;
        }

        return (RequestLog) queryList.get(0);
    }

    public List<RequestLog> getNonTestRequestLogList(String formName,
                                                     String renderMode,
                                                     Date startDate,
                                                     Date endDate,
                                                     boolean sortedAscending,
                                                     Boolean prefilled,
                                                     int pageSize) {

        SelectQuery query = new SelectQuery(RequestLog.class);

        if (StringUtils.isNotEmpty(formName)) {
            query.andQualifier(ExpressionFactory.matchExp(RequestLog.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY, formName ));
        }
        if (StringUtils.isNotEmpty(renderMode)) {
            query.andQualifier(ExpressionFactory.matchExp(RequestLog.RENDER_MODE_PROPERTY, renderMode));
        }

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(RequestLog.REQUEST_TIMESTAMP_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(RequestLog.REQUEST_TIMESTAMP_PROPERTY, endDate));
        }

        if (prefilled!=null) {
            query.andQualifier(ExpressionFactory.matchExp(RequestLog.PREFILL_DATA_FLAG_PROPERTY, true));
        }

        query.andQualifier(ExpressionFactory.noMatchExp(RequestLog.FORM_TEST_FLAG_PROPERTY, true));

        query.addPrefetch(RequestLog.CLIENT_PROPERTY);
        query.addPrefetch(RequestLog.FORM_PROPERTY);
        query.addPrefetch(RequestLog.TEMPLATE_VERSION_PROPERTY);

        boolean defaultSortColumnSorted = false;

        if (!defaultSortColumnSorted) {
            query.addOrdering(RequestLog.REQUEST_TIMESTAMP_PROPERTY, SortOrder.DESCENDING_INSENSITIVE);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List getRequestLogList(String clientId,
                                 String formCode,
                                  String version,
                                  String renderMode,
                                  Date startDate,
                                  Date endDate,
                                  String sortedColumn,
                                  boolean sortedAscending) {

        SelectQuery query = new SelectQuery(RequestLog.class);
        if (StringUtils.isNotEmpty(clientId)) {
            andQueryMatchExp(query, RequestLog.CLIENT_PROPERTY, clientId);
        }
        if (StringUtils.isNotEmpty(version)) {
            andQueryMatchExp(query, RequestLog.TEMPLATE_VERSION_PROPERTY + "." + TemplateVersion.VERSION_NUMBER_PROPERTY, version);
        }
        if (StringUtils.isNotEmpty(formCode)) {
            andQueryMatchExp(query, RequestLog.FORM_PROPERTY + "." + Form.CLIENT_FORM_CODE_PROPERTY, formCode);
        }
        if (StringUtils.isNotEmpty(renderMode)) {
            andQueryMatchExp(query, RequestLog.RENDER_MODE_PROPERTY, renderMode);
        }

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(RequestLog.REQUEST_TIMESTAMP_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(RequestLog.REQUEST_TIMESTAMP_PROPERTY, endDate));
        }

        query.addPrefetch(RequestLog.CLIENT_PROPERTY);
        query.addPrefetch(RequestLog.FORM_PROPERTY);
        query.addPrefetch(RequestLog.TEMPLATE_VERSION_PROPERTY);

        boolean defaultSortColumnSorted = false;
        if (StringUtils.isNotBlank(sortedColumn)) {
            if (sortedColumn.equals(RequestLog.REQUEST_TIMESTAMP_PROPERTY)) {
                defaultSortColumnSorted = true;
            }
            SortOrder sortOrder = (sortedAscending) ? SortOrder.ASCENDING_INSENSITIVE : SortOrder.DESCENDING_INSENSITIVE;
            query.addOrdering(sortedColumn, sortOrder);
        }

        if (!defaultSortColumnSorted) {
            query.addOrdering("db:" +RequestLog.REQUEST_OID_PK_COLUMN, SortOrder.DESCENDING);
        }

        return performQuery(query);
    }

    public List getRequestsByMonth(String clientId, String formId, Date startDate, Date endDate) {
        Validate.notNull(startDate);
        Validate.notNull(endDate);

        java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());
        java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());

        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotEmpty(clientId)) {
            params.put("clientId", clientId);
        }
        if (StringUtils.isNotEmpty(formId)) {
            params.put("formId", formId);
        }
        params.put("startDate", sqlStartDate);
        params.put("endDate", sqlEndDate);

        return getDataContext().performQuery(NamedQueries.REQUEST_MONTHLY_TREND, params, true);
    }

    public RequestLog createRequestLog(HttpServletRequest request,
                                          Form form,
                                          TemplateVersion templateVersion,
                                          Submission submission,
                                          UserAccount userAccount,
                                          String renderMode,
                                          String taskKey) {

        // Create request log record
        RequestLog requestLog = new RequestLog();
        getDataContext().registerNewObject(requestLog);

        requestLog.setDatetimeCreated(new Date());
        requestLog.setForm(form);
        requestLog.setPortal(form.getPortal());
        requestLog.setFormTestFlag(form.getTestEnabledFlag());
        requestLog.setClient(form.getClient());
        requestLog.setFormType(templateVersion.getFormType());
        requestLog.setTemplateVersion(templateVersion);

        requestLog.setRequestKey(CoreUtils.createAltKey());

        // Used to prevent a person from submitting more than once
        requestLog.setSubmissionCount(new Integer (0));
        requestLog.setSubmission(submission);

        // TODO: use session referrer
        requestLog.setReferer(CoreUtils.limitLength(request.getHeader("referer"), 1000));

        // Needed for debugging bad render requests.
        requestLog.setRequestContentLength(String.valueOf(request.getContentLength()));
        requestLog.setRequestContentType(request.getContentType());
        requestLog.setRequestMethod(request.getMethod());
        requestLog.setRequestQuery(CoreUtils.limitLength(request.getQueryString(), 2000));
        requestLog.setRequestUrl(CoreUtils.limitLength(request.getRequestURL().toString(), 1000));
        requestLog.setRequestTimestamp(new Date());

        DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
        if (dpDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_IP_Address_Logging)) {
            requestLog.setIpAddress(CoreUtils.limitLength(request.getRemoteAddr(), 20));
        }
        requestLog.setRemoteUser(CoreUtils.limitLength(request.getRemoteUser(), 20));

        requestLog.setUserAgent(CoreUtils.limitLength(request.getHeader("user-agent"), 200));

        if (userAccount != null) {
            requestLog.setUser(userAccount);
        }

        requestLog.setRenderMode(renderMode);

        if (StringUtils.isNotEmpty(taskKey)) {
            TaskDao taskDao = DaoFactory.getTaskDao();
            Task task = taskDao.getTaskByKey(taskKey);
            requestLog.setTask(task);
        }

        return requestLog;
    }
}

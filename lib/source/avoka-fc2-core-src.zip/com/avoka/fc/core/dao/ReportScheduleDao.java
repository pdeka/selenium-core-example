/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Report;
import com.avoka.fc.core.entity.ReportClient;
import com.avoka.fc.core.entity.ReportSchedule;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides the Report Schedule DAO.
 *
 * @author pcopeland@avoka.com
 */
public class ReportScheduleDao extends BaseDao {

    public ReportSchedule getReportFromPK(Object primaryKeyId) {
        return (ReportSchedule) getObjectForPK(ReportSchedule.class, primaryKeyId);
    }

    public Report getReport(ReportSchedule schedule) {
        Report result = schedule.getSystemReport();
        if (result == null) {
            result = schedule.getReportClient().getReport();
        }
        return result;
    }

    public List<ReportSchedule> getAllReports() {
        SelectQuery query = new SelectQuery(ReportSchedule.class);

        return performQuery(query);
    }

    public List<ReportSchedule> getReportList(String clientId, String nameLike, Boolean active) {
        return getScheduleList(clientId, nameLike, null, null, active);
    }

    public List<ReportSchedule> getScheduleList(String clientId, String nameLike, Boolean clientAssignable, Boolean active) {
        return getScheduleList(clientId, nameLike, null, clientAssignable, active);
    }

    public List<ReportSchedule> getScheduleList(String clientId, String nameLike, String scheduleType, Boolean clientAssignable, Boolean active) {
        if (clientAssignable == null) {
            List systemReportScheduleList = getSystemReportScheduleList(nameLike, scheduleType, active, null, true, 100);
            List clientReportScheduleList = getClientReportScheduleList(clientId, nameLike, scheduleType, active);
            systemReportScheduleList.addAll(clientReportScheduleList);
            return systemReportScheduleList;
        }
        else if (clientAssignable.booleanValue()) {
            return getClientReportScheduleList(clientId, nameLike, scheduleType, active);
        }
        else {
            return getSystemReportScheduleList(nameLike, scheduleType, active, null, true, 100);
        }
    }

    public List<ReportSchedule> getClientReportScheduleList(String clientId, String nameLike, String scheduleType, Boolean active) {
        SelectQuery query = new SelectQuery(ReportSchedule.class);
        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(ReportSchedule.REPORT_CLIENT_PROPERTY + "." + ReportClient.CLIENT_PROPERTY,
                    clientId));
        }
        if (StringUtils.isNotEmpty(nameLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(ReportSchedule.REPORT_CLIENT_PROPERTY + "."
                    + ReportClient.REPORT_PROPERTY + "." + Report.NAME_PROPERTY, "%" + nameLike + "%"));
        }
        if (StringUtils.isNotEmpty(scheduleType)) {
            query.andQualifier(ExpressionFactory.matchExp(ReportSchedule.SCHEDULE_TYPE_PROPERTY, scheduleType));
        }

        query.andQualifier(ExpressionFactory.matchExp(ReportSchedule.REPORT_CLIENT_PROPERTY + "."
                + ReportClient.REPORT_PROPERTY + "." + Report.CLIENT_ASSIGNABLE_FLAG_PROPERTY, Boolean.TRUE));

        if (active != null && active.equals(Boolean.TRUE)) {
            query.andQualifier(ExpressionFactory.matchExp(ReportSchedule.ACTIVE_FLAG_PROPERTY, active));
        }

        query.addOrdering(ReportSchedule.REPORT_CLIENT_PROPERTY + "." + ReportClient.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY,
                Ordering.ASC);
        query.addPrefetch(ReportSchedule.REPORT_CLIENT_PROPERTY);
        query.addOrdering(ReportSchedule.REPORT_CLIENT_PROPERTY + "." + ReportClient.REPORT_PROPERTY + "." + Report.NAME_PROPERTY,
                Ordering.ASC);
        query.addPrefetch(ReportSchedule.REPORT_CLIENT_PROPERTY + "." + ReportClient.REPORT_PROPERTY);

        return performQuery(query);
    }

    public List<ReportSchedule> getSystemReportScheduleList(String nameLike, String scheduleType, Boolean active, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(ReportSchedule.class);
        if (StringUtils.isNotEmpty(nameLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(ReportSchedule.SYSTEM_REPORT_PROPERTY + "."
                    + Report.NAME_PROPERTY, "%" + nameLike + "%"));
        }
        if (StringUtils.isNotEmpty(scheduleType)) {
            query.andQualifier(ExpressionFactory.matchExp(ReportSchedule.SCHEDULE_TYPE_PROPERTY, scheduleType));
        }

        Expression notNullExpr = ExpressionFactory.matchExp(ReportSchedule.SYSTEM_REPORT_PROPERTY + "."
                + Report.CLIENT_ASSIGNABLE_FLAG_PROPERTY, null);
        query.andQualifier(notNullExpr.orExp(ExpressionFactory.noMatchExp(ReportSchedule.SYSTEM_REPORT_PROPERTY + "."
                + Report.CLIENT_ASSIGNABLE_FLAG_PROPERTY, Boolean.TRUE)));

        if (active != null && active.equals(Boolean.TRUE)) {
            query.andQualifier(ExpressionFactory.matchExp(ReportSchedule.ACTIVE_FLAG_PROPERTY, active));
        }

        boolean sortedByReportName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(ReportSchedule.SYSTEM_REPORT_PROPERTY + "." + Report.NAME_PROPERTY)) {
                sortedByReportName = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByReportName) {
            query.addOrdering(ReportSchedule.SYSTEM_REPORT_PROPERTY + "." + Report.NAME_PROPERTY, Ordering.ASC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public void calculateTimes(ReportSchedule schedule) {
        calculateNextRunTime(schedule);
        calculatePeriodTimes(schedule);
    }

    private void calculateNextRunTime(ReportSchedule schedule) {

        GregorianCalendar gCalnow = new GregorianCalendar();
        GregorianCalendar gCalRuntime = new GregorianCalendar();
        if (schedule.getScheduleType().equalsIgnoreCase(ReportSchedule.TYPE_Day)) {

            gCalRuntime = constructDayTime(gCalnow.getTime(), schedule.getScheduleTime());

            if (gCalRuntime.before(gCalnow)) {
                // Add 1 day
                gCalRuntime.add(GregorianCalendar.DAY_OF_MONTH, 1);
            }
            schedule.setNextRunTimestamp(gCalRuntime.getTime());

        } else if (schedule.getScheduleType().equalsIgnoreCase(ReportSchedule.TYPE_Week)) {

            // Sunday is 1
            int nowWeekDay = gCalnow.get(Calendar.DAY_OF_WEEK);

            // range between 1 to 7
            int targetWeekDay = getScheduleWeekDay(schedule);

            if (targetWeekDay == -1) {
                throw new ApplicationException("InvalidWeekDay", "No day selected", "Please select a week day", "Incorrect user input.");
            }

            // See See the ScheduleTimeTestCases.xls in the docs directory
            // for some examples.

            if (nowWeekDay > targetWeekDay) {
                // ie its Wed and the target is Sunday
                gCalRuntime.add(GregorianCalendar.DAY_OF_MONTH, (7 - nowWeekDay + targetWeekDay));

            } else {
                gCalRuntime.add(GregorianCalendar.DAY_OF_MONTH, (targetWeekDay - nowWeekDay));
            }

            // Apply the time of day
            gCalRuntime = constructDayTime(gCalRuntime.getTime(), schedule.getScheduleTime());

            if (gCalRuntime.before(gCalnow)) {
                // Add 1 Week
                gCalRuntime.add(GregorianCalendar.DAY_OF_MONTH, 7);
            }
            schedule.setNextRunTimestamp(gCalRuntime.getTime());

        } else if (schedule.getScheduleType().equalsIgnoreCase(ReportSchedule.TYPE_Month)) {
            int scheduledMonthDay = schedule.getMonthDay().intValue();
            int normalisedMonthDay = scheduledMonthDay;
            if (scheduledMonthDay <= 0) {
                normalisedMonthDay += 31;
            }

            gCalRuntime.set(Calendar.DAY_OF_MONTH, scheduledMonthDay);

            // Apply the time of day
            gCalRuntime = constructDayTime(gCalRuntime.getTime(), schedule.getScheduleTime());

            while (gCalRuntime.before(gCalnow)) {
                // Add 1 month
                gCalRuntime.add(GregorianCalendar.MONTH, 1);
                if (scheduledMonthDay <= 0) {
                    int actualMonthDay = normalisedMonthDay;
                    actualMonthDay = actualMonthDay - (31 - gCalRuntime.getActualMaximum(GregorianCalendar.DAY_OF_MONTH));
                    gCalRuntime.set(GregorianCalendar.DAY_OF_MONTH, actualMonthDay);
                }
            }
            schedule.setNextRunTimestamp(gCalRuntime.getTime());

        }

        getLogger().debug("Schedule Type = " + schedule.getScheduleType());
        getLogger().debug("Current time = " + gCalnow.getTime() + " Next Scheduled Time = " + gCalRuntime.getTime());
    }

    private int getScheduleWeekDay(ReportSchedule schedule) {

        if (Boolean.TRUE.equals(schedule.getWeekSundayFlag())) {
            return 1;
        } else if (Boolean.TRUE.equals(schedule.getWeekMondayFlag())) {
            return 2;
        } else if (Boolean.TRUE.equals(schedule.getWeekTuesdayFlag())) {
            return 3;
        } else if (Boolean.TRUE.equals(schedule.getWeekWednesdayFlag())) {
            return 4;
        } else if (Boolean.TRUE.equals(schedule.getWeekThursdayFlag())) {
            return 5;
        } else if (Boolean.TRUE.equals(schedule.getWeekFridayFlag())) {
            return 6;
        } else if (Boolean.TRUE.equals(schedule.getWeekSaturdayFlag())) {
            return 7;
        }

        return -1;
    }

    /**
     * This will calculate the start & end datetimes that will be used by the report (passed in as
     * parameters). It asumes that the next run date has been computed and will make the endtime as
     * close to the run time as permissable. See the ScheduleTimeTestCases.xls in the docs directory
     * for some examples.
     *
     * @author pcopeland
     * @param schedule
     */
    private void calculatePeriodTimes(ReportSchedule schedule) {

        GregorianCalendar gCalRuntime = new GregorianCalendar();
        GregorianCalendar gCalnow = new GregorianCalendar();

        gCalRuntime.setTime(schedule.getNextRunTimestamp());

        GregorianCalendar gCalPeriodEndTime = new GregorianCalendar();

        if (schedule.getScheduleType().equalsIgnoreCase(ReportSchedule.TYPE_Day)) {

            if (schedule.getPeriodEndTime() == null) {
                throw new ApplicationException("InvalidPeriodEndTime", "Null period end time", "Please specify a valid period end time.",
                        "Incorrect user input.");
            }

            gCalPeriodEndTime = constructDayTime(new Date(), schedule.getPeriodEndTime());

            if (gCalPeriodEndTime.after(gCalRuntime)) {
                // Subtract 1 day
                gCalPeriodEndTime.add(GregorianCalendar.DAY_OF_MONTH, -1);
            }
            schedule.setCalcEndDate(gCalPeriodEndTime.getTime());

            // Start time - 1 day less than end time
            gCalPeriodEndTime.add(GregorianCalendar.DAY_OF_MONTH, -1);
            schedule.setCalcStartDate(gCalPeriodEndTime.getTime());
        } else if (schedule.getScheduleType().equalsIgnoreCase(ReportSchedule.TYPE_Week)) {

            if (schedule.getPeriodEndDay() == null) {
                throw new ApplicationException("InvalidPeriodEndDay", "Null period end day", "Please specify a valid period end day.",
                        "Incorrect user input.");
            }

            if (schedule.getPeriodEndTime() == null) {
                throw new ApplicationException("InvalidPeriodEndTime", "Null period end time", "Please specify a valid period end time.",
                        "Incorrect user input.");
            }

            // Sunday is 1
            int nowWeekDay = gCalnow.get(Calendar.DAY_OF_WEEK);

            // range between 1 to 7
            int periodEndDay = schedule.getPeriodEndDay().intValue();

            if (periodEndDay == -1) {
                throw new ApplicationException("InvalidWeekDay", "No day selected", "Please select a week day", "Incorrect user input.");
            }

            // See See the ScheduleTimeTestCases.xls in the docs directory
            // for some examples.

            if (nowWeekDay > periodEndDay) {
                // ie its Wed and the target is Sunday
                gCalPeriodEndTime.add(GregorianCalendar.DAY_OF_MONTH, (7 - nowWeekDay + periodEndDay));

            } else {
                gCalPeriodEndTime.add(GregorianCalendar.DAY_OF_MONTH, (periodEndDay - nowWeekDay));
            }

            // Apply the time of day
            gCalPeriodEndTime = constructDayTime(gCalPeriodEndTime.getTime(), schedule.getPeriodEndTime());

            if (gCalPeriodEndTime.after(gCalRuntime)) {
                // Subtract 1 day
                gCalPeriodEndTime.add(GregorianCalendar.DAY_OF_MONTH, -7);
            }
            schedule.setCalcEndDate(gCalPeriodEndTime.getTime());

            // Start time - 1 day less than end time
            gCalPeriodEndTime.add(GregorianCalendar.DAY_OF_MONTH, -7);
            schedule.setCalcStartDate(gCalPeriodEndTime.getTime());

        } else if (schedule.getScheduleType().equalsIgnoreCase(ReportSchedule.TYPE_Month)) {

            // Need to set the end time to the next run time as it may have rolled into the next
            // month and we need the end date as close as possible to the run date.
            gCalPeriodEndTime.setTime(schedule.getNextRunTimestamp());

            if (schedule.getPeriodEndDay() == null) {
                throw new ApplicationException("InvalidPeriodEndDay", "Null period end day", "Please specify a valid period end day.",
                        "Incorrect user input.");
            }

            if (schedule.getPeriodEndTime() == null) {
                throw new ApplicationException("InvalidPeriodEndTime", "Null period end time", "Please specify a valid period end time.",
                        "Incorrect user input.");
            }

            if (schedule.getPeriodEndDay().intValue() <= 0) {
                // fix up the day of month in case the period end day was negative
                int dayOfMonth = gCalPeriodEndTime.getActualMaximum(Calendar.DAY_OF_MONTH) + schedule.getPeriodEndDay().intValue();
                gCalPeriodEndTime.set(GregorianCalendar.DAY_OF_MONTH, dayOfMonth);
            }
            else {
                gCalPeriodEndTime.set(GregorianCalendar.DAY_OF_MONTH, schedule.getPeriodEndDay().intValue());
            }

            // Apply the time of day
            gCalPeriodEndTime = constructDayTime(gCalPeriodEndTime.getTime(), schedule.getPeriodEndTime());

            if (gCalPeriodEndTime.after(gCalRuntime)) {
                // Subtract 1 month
                gCalPeriodEndTime.add(GregorianCalendar.MONTH, -1);
                if (schedule.getPeriodEndDay().intValue() <= 0) {
                    // fix up the day of month in case the period end day was negative
                    int dayOfMonth = gCalPeriodEndTime.getActualMaximum(Calendar.DAY_OF_MONTH) + schedule.getPeriodEndDay().intValue();
                    gCalPeriodEndTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                }
            }
            schedule.setCalcEndDate(gCalPeriodEndTime.getTime());

            // Start time - 1 month less than end time
            gCalPeriodEndTime.add(GregorianCalendar.MONTH, -1);
            if (schedule.getPeriodEndDay().intValue() <= 0) {
                // fix up the day of month in case the period end day was negative
                int dayOfMonth = gCalPeriodEndTime.getActualMaximum(Calendar.DAY_OF_MONTH) + schedule.getPeriodEndDay().intValue();
                gCalPeriodEndTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            }
            schedule.setCalcStartDate(gCalPeriodEndTime.getTime());

        }

        getLogger().debug("Schedule Type = " + schedule.getScheduleType());
        getLogger().debug("Period start Time = " + schedule.getCalcStartDate() + " Period End Time = " + schedule.getCalcEndDate());
    }

    /**
     * Appends time to today. - Format for time is "HH:mm:ss"
     *
     * @param timeString
     * @return
     */
    public GregorianCalendar constructDayTime(Date dayDate, String timeString) {
        GregorianCalendar gCalResult = new GregorianCalendar();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String currentDayString = sdf.format(dayDate);

        getLogger().debug("currentDayString = " + currentDayString);

        if (timeString == null) {
            timeString = "00:00:00";

        } else if (timeString.length() == 5) {
            timeString += ":00";
        }

        // Now add the scheduled time of day.
        String runTimeString = currentDayString + " " + timeString;
        sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            gCalResult.setTime(sdf.parse(runTimeString));
        } catch (ParseException e) {
            throw new ApplicationException("DateParseException", e, "runTimeString= " + runTimeString,
                    "Please enter a schedule time in HH:mm:ss format.", "Incorrect user input.");
        }

        return gCalResult;
    }
}

package com.avoka.fc.core.dao;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.MetadataValue;

public class MetadataValueDao extends BaseDao {

    public MetadataValue getMetadataValue(String valueId) {
        return (MetadataValue) getObjectForPK(MetadataValue.class, valueId);
    }
}

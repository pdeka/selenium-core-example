package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.MetadataValueDeploy;

public class MetadataValueDeployDao extends BaseDao {

    public List<MetadataValueDeploy> getMetadataValueDeployList(FormDeployXml formDeployXml) {
        SelectQuery query = new SelectQuery(MetadataValueDeploy.class);

        andQueryMatchExp(query, MetadataValueDeploy.FORM_DEPLOY_PROPERTY, formDeployXml);

        addOrdering(query, MetadataValueDeploy.NAME_PROPERTY);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        return performQuery(query);
    }

}

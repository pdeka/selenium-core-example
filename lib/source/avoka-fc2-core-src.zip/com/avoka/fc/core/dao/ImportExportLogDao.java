
package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.ImportExportLog;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.RemoteUserProvider;

public class ImportExportLogDao extends BaseDao {


    public ImportExportLog create (String fileName, String type) {

        ImportExportLog ieLog = new ImportExportLog ();
        getDataContext().registerNewObject(ieLog);

        UserAccountDao adminDao = new UserAccountDao();

        UserAccount adminUser = adminDao.getUserAccountForPK(RemoteUserProvider.getAdminId());
        ieLog.setAdminDetails(adminUser);

        ieLog.setFileName(fileName);
        ieLog.setIeTimestamp(new Date ());
        ieLog.setIeType(type);
        ieLog.setPurgedFlag(false);

        return ieLog;
    }

    public List getImportExportLogList(String type, String fileName, String adminName, Date startDate, Date endDate, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(ImportExportLog.class);

        if (StringUtils.isNotBlank(type)) {
            query.andQualifier(ExpressionFactory.matchExp(ImportExportLog.IE_TYPE_PROPERTY, type));
        }
        if (StringUtils.isNotBlank(fileName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(ImportExportLog.FILE_NAME_PROPERTY, "%" + fileName + "%"));
        }
        if (StringUtils.isNotBlank(adminName)) {
            andQueryLikeIgnoreCaseExp(query, ImportExportLog.ADMIN_DETAILS_PROPERTY + "." + UserAccount.LOGIN_NAME_PROPERTY, adminName);
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(ImportExportLog.IE_TIMESTAMP_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(ImportExportLog.IE_TIMESTAMP_PROPERTY, endDate));
        }
        query.addPrefetch(ImportExportLog.ADMIN_DETAILS_PROPERTY);

        boolean sortedByImportExportTime = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(ImportExportLog.IE_TIMESTAMP_PROPERTY)) {
                sortedByImportExportTime = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByImportExportTime) {
            query.addOrdering(ImportExportLog.IE_TIMESTAMP_PROPERTY, Ordering.DESC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }
}

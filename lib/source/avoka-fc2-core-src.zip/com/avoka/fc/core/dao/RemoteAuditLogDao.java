package com.avoka.fc.core.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Submission;

public class RemoteAuditLogDao extends BaseDao {

    public List getAllAuditsForSubmission(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        Map<String, Object> params = new HashMap<String, Object>();

        params.put("submissionOid", submission.getId());

        return performNamedQuery(NamedQueries.REMOTE_AUDITS_FOR_SUBMISSION, params, true);
    }
}

/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.util.ApplicationException;

public class SchemaSeedDao extends BaseDao {

    protected DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();

    public SchemaSeed getSchemaForId(Object id) {
        return (SchemaSeed) getObjectForPK(SchemaSeed.class, id);
    }

    public List<SchemaSeed> getSchemasForName(String clientId, String name) {
        Validate.notNull(name, "Null name parameter");

        SelectQuery query = new SelectQuery(SchemaSeed.class);

        query.andQualifier(ExpressionFactory.matchExp(SchemaSeed.NAME_PROPERTY, name));
        query.andQualifier(ExpressionFactory.matchExp(SchemaSeed.CLIENT_PROPERTY, clientId));

        query.addOrdering(SchemaSeed.NAME_PROPERTY, Ordering.ASC);

        query.addPrefetch(SchemaSeed.CLIENT_PROPERTY);
        return performQuery(query);
    }

    /**
     * Return a query that when run would return all scemas except the given one. This is used to
     * avoid pointing a schema to itself.
     *
     * @param schemaId the id of the schema not to include in the query.
     * @return query
     */
    public SelectQuery getBaseSchemas(String schemaId) {
        SelectQuery query = new SelectQuery(SchemaSeed.class);
        if (StringUtils.isNotBlank(schemaId)) {
            query.andQualifier(ExpressionFactory.noMatchDbExp(SchemaSeed.SCHEMA_OID_PK_COLUMN, schemaId));
        }
        query.addOrdering(SchemaSeed.NAME_PROPERTY, Ordering.ASC);
        return query;
    }

    /**
     * Given a form schema create a list of all parent schema - include the original child Schema in
     * the list as well.
     *
     * @param templateSchema
     * @return
     */
    public List getParentSchemas(SchemaSeed templateSchema) {

        ArrayList schemaList = new ArrayList();

        schemaList.add(templateSchema);
        SchemaSeed parentSchema = null;

        while (templateSchema != null) {
            parentSchema = templateSchema.getBaseSchema();

            if (parentSchema != null) {
                if (parentSchema.getId().equals(templateSchema.getId())) {
                    String message = "Circular SchemaSeed reference in: " + templateSchema.getName();
                    String context = "SchemaSeed.ID=" + templateSchema.getId();
                    String solution = "Configure SchemaSeed " + templateSchema.getName() + " not to use itself as the parent SchemaSeed.";
                    throw new ApplicationException("SchemaDao", context, message, solution);
                }

                schemaList.add(parentSchema);
            }
            templateSchema = parentSchema;
        }

        return schemaList;
    }

    public List<SchemaSeed> getSchemasList(String clientId, String nameLike) {
        SelectQuery query = new SelectQuery(SchemaSeed.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(SchemaSeed.CLIENT_PROPERTY + "." + Client.CLIENT_OID_PK_COLUMN, clientId));
        }
        if (StringUtils.isNotBlank(nameLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(SchemaSeed.NAME_PROPERTY, "%" + nameLike + "%"));
        }

        query.addOrdering(SchemaSeed.NAME_PROPERTY, Ordering.ASC);

        query.addPrefetch(SchemaSeed.CLIENT_PROPERTY);
        return performQuery(query);
    }

    public List<SchemaSeed> getSchemasList(String clientId, String nameLike, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(SchemaSeed.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(SchemaSeed.CLIENT_PROPERTY + "." + Client.CLIENT_OID_PK_COLUMN, clientId));
        }
        if (StringUtils.isNotBlank(nameLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(SchemaSeed.NAME_PROPERTY, "%" + nameLike + "%"));
        }

        query.addPrefetch(SchemaSeed.CLIENT_PROPERTY);

        boolean sortedBySchemaName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(SchemaSeed.NAME_PROPERTY)) {
                sortedBySchemaName = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedBySchemaName) {
            query.addOrdering(SchemaSeed.NAME_PROPERTY, Ordering.ASC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List<SchemaSeed> getSchemasList() {
        SelectQuery query = new SelectQuery(SchemaSeed.class);

        query.addOrdering(SchemaSeed.NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<SchemaSeed> getSchemasList(String clientId) {
        SelectQuery query = new SelectQuery(SchemaSeed.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(SchemaSeed.CLIENT_PROPERTY + "." + Client.CLIENT_OID_PK_COLUMN, clientId));
            query.orQualifier(ExpressionFactory.matchExp(SchemaSeed.CLIENT_PROPERTY, null));
        }

        query.addOrdering(SchemaSeed.NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public String getSchemaDirectory(SchemaSeed schema) {
        Validate.notNull(schema, "Null schema parameter");
        return getSchemaDirectory(schema.getId().toString());
    }

    public String getSchemaDirectory(final String schemaId) {
        Validate.notNull(schemaId, "Null schemaId parameter");

        String schemaDirectory = deploymentPropertyDao.getConfigSubDirectory("schemas");

        return schemaDirectory + schemaId + File.separator;
    }

    public List getSchemaPropertyTypeMap(SchemaSeed schema, String scopeType) {
        Validate.notNull(schema, "Null schema parameter");
        Validate.notNull(scopeType, "Null scopeType parameter");

        Map parameters = new HashMap();
        parameters.put("SchemaOid", schema.getId());
        parameters.put("Scope", scopeType);

        return performNamedQuery(NamedQueries.SCHEMA_PROPERTY_MAP, parameters, true);
    }

    /**
     * Given a form schema, walk up the parent tree until it find one with a seed file associated.
     *
     * @param templateSchema
     * @return (Schema) with Seed schema associated.
     */
    public SchemaSeed getInheritedSchemaWithSeedFile(SchemaSeed templateSchema) {

        SchemaSeed parentSchema = null;
        while (templateSchema.getFileData() == null) {
            parentSchema = templateSchema.getBaseSchema();
            if (parentSchema == null) {
                return null;
            } else if (parentSchema.getFileData() != null) {
                return parentSchema;
            }
            templateSchema = parentSchema;
        }

        return templateSchema;
    }

    /**
     * Append a version number starting at 2 on the name if a schema already exists for the given
     * client with the given name. I.e try 2, then 3 until it's unique.
     *
     */
    public String getUniqueSchemaName(Client client, String name, int maxLength) {
        if (name.length() > maxLength) {
            name = CoreUtils.limitLength(name, maxLength, "");
        }
        String uniqueName = name;
        String clientId = (client == null? null : client.getId().toString());
        for (int i = 1;; i++) {
            // figure out how long the index is
            int postFixLength = ((int) Math.log10(i)) + 1;
            if (name.length() + postFixLength + 1 > maxLength) {
                // truncate the name
                name = CoreUtils.limitLength(name, (maxLength - (postFixLength + 1)), "");

            }
            uniqueName = name + " " + i;

            List<SchemaSeed> existingSchemas = getSchemasForName(clientId, uniqueName);
            if (existingSchemas == null || existingSchemas.isEmpty()) {
                return uniqueName;
            }
        }
    }
}

package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.XmlInputVersion;

public class XmlInputVersionDao extends BaseDao {

    public XmlInputVersion getXmlInputVersionForId(String id) {
        return (XmlInputVersion) getObjectForPK(XmlInputVersion.class, id);
    }

    public XmlInputVersion getXmlInputVersionById(String id) {
        Validate.notNull(id, "Null xml id parameter");

        SelectQuery query = new SelectQuery(XmlInputVersion.class);

        query.andQualifier(ExpressionFactory.matchDbExp(XmlInputVersion.XML_INPUT_VERSION_OID_PK_COLUMN, id));
        query.addPrefetch(XmlInputVersion.SCHEMA_PROPERTY);
        query.addPrefetch(XmlInputVersion.XML_INPUT_MAP_PROPERTY);

        List results = performQuery(query);
        if (!results.isEmpty()) {
            return (XmlInputVersion) results.get(0);

        } else {
            return null;
        }

    }

}

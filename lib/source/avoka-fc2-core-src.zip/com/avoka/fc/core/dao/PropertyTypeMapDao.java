package com.avoka.fc.core.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.PropertyTypeMap;
import com.avoka.fc.core.entity.SchemaSeed;

public class PropertyTypeMapDao extends BaseDao {

    public List getPropertyMapListForSchema(SchemaSeed schema) {
        Validate.notNull(schema, "Null schema parameter");

        SelectQuery query = new SelectQuery(PropertyTypeMap.class);

        query.andQualifier(ExpressionFactory.matchExp(PropertyTypeMap.SCHEMA_PROPERTY, schema));

        query.addPrefetch(PropertyTypeMap.PROPERTY_TYPE_PROPERTY);

        query.addOrdering(PropertyTypeMap.PROPERTY_TYPE_PROPERTY, true);

        return performQuery(query);
    }

    public Map getPropertyPathsForSchema(SchemaSeed schema, String scope) {
        Validate.notNull(schema, "Null schema parameter");

        SchemaSeedDao schemaDao = new SchemaSeedDao();
        List schemaList = schemaDao.getParentSchemas(schema);

        Map resultMap = new HashMap();

        int size = schemaList.size() - 1;

        for (int i = size; i >= 0; i--) {
            SchemaSeed aSchema = (SchemaSeed) schemaList.get(i);

            Map nameXPathMap = getPropertyPathsForSpecificSchema(aSchema, scope);

            resultMap.putAll(nameXPathMap);
        }

        return Collections.unmodifiableMap(resultMap);
    }

    public Map getPropertyPathsForSpecificSchema(SchemaSeed schema, String scope) {
        Validate.notNull(schema, "Null schema parameter");

        // Get list of schema, for each schema get the properties

        SelectQuery query = new SelectQuery(PropertyTypeMap.class);

        query.andQualifier(ExpressionFactory.matchExp(PropertyTypeMap.PROPERTY_TYPE_PROPERTY + "." + PropertyType.SCOPE_PROPERTY,
                                                      scope));

        query.andQualifier(ExpressionFactory.matchExp(PropertyTypeMap.SCHEMA_PROPERTY, schema));

        query.addPrefetch(PropertyTypeMap.PROPERTY_TYPE_PROPERTY);

        Map map = new HashMap();

        List results = performQuery(query);
        for (Iterator i = results.iterator(); i.hasNext();) {
            PropertyTypeMap propertyMap = (PropertyTypeMap) i.next();

            String propertyName = propertyMap.getPropertyType().getName();
            String xpath = propertyMap.getXpath();

            map.put(propertyName, xpath);
        }

        return map;
    }

    //this return a list of propertyTypeMap object of a given schema
    //include all its parents.
    public Map getFullPropertyTypeMapsForSchema(SchemaSeed schema) {
        Validate.notNull(schema, "Null schema parameter");

        SchemaSeedDao schemaDao = new SchemaSeedDao();
        List schemaList = schemaDao.getParentSchemas(schema);

        Map resultMap = new HashMap();
        int size = schemaList.size() - 1;
        for (int i = size; i >= 0; i--) {
            SchemaSeed aSchema = (SchemaSeed) schemaList.get(i);
            Map nameXPathMap = getPropertyTypeMapsForSpecificSchema(aSchema);
            resultMap.putAll(nameXPathMap);
        }


        return resultMap;
    }

    public Map getPropertyTypeMapsForSpecificSchema(SchemaSeed schema) {
        Validate.notNull(schema, "Null schema parameter");

        // Get list of schema, for each schema get the properties
        SelectQuery query = new SelectQuery(PropertyTypeMap.class);
        query.andQualifier(ExpressionFactory.matchExp(PropertyTypeMap.SCHEMA_PROPERTY, schema));
        query.addPrefetch(PropertyTypeMap.PROPERTY_TYPE_PROPERTY);
        query.addPrefetch(PropertyTypeMap.SCHEMA_PROPERTY);

        Map map = new HashMap();

        List<PropertyTypeMap> results = performQuery(query);
        for (PropertyTypeMap propertyTypeMap : results) {

            String propertyName = propertyTypeMap.getPropertyType().getName();
            map.put(propertyName, propertyTypeMap);
        }

        return map;
    }
}

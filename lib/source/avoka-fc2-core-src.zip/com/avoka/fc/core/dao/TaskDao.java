package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Group;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.entity.UserAccount;

public class TaskDao extends BaseDao {

    public Task getTaskById(String taskId) {
        SelectQuery query = new SelectQuery(Task.class);

        andQueryMatchDbExp(query, Task.TASK_OID_PK_COLUMN, taskId);

        List<Task> list = performQuery(query);

        if (!list.isEmpty()) {
            return (Task) list.get(0);
        } else {
            return null;
        }
    }

    public Task getTaskByKey(String taskKey) {
        SelectQuery query = new SelectQuery(Task.class);

        andQueryMatchExp(query, Task.TASK_KEY_PROPERTY, taskKey);

        List<Task> list = performQuery(query);

        if (!list.isEmpty()) {
            return (Task) list.get(0);
        } else {
            return null;
        }
    }

    public List<Task> getTaskList(String taskKey, String taskMessage, Date startDate, Date endDate,
            String sortBy, boolean ascending, int pageSize) {

        SelectQuery query = new SelectQuery(Task.class);

        if (StringUtils.isNotEmpty(taskKey)) {
            andQueryMatchExp(query, Task.TASK_KEY_PROPERTY, taskKey);
        }
        if (StringUtils.isNotEmpty(taskMessage)) {
            andQueryLikeIgnoreCaseExp(query, Task.TASK_MESSAGE_PROPERTY, "%" + taskMessage + "%");
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(Task.DATETIME_CREATED_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(Task.DATETIME_CREATED_PROPERTY, endDate));
        }

        query.addPrefetch(Task.FORM_PROPERTY);
        query.addPrefetch(Task.USER_PROPERTY);
        query.addPrefetch(Task.GROUP_PROPERTY);

        boolean defaultSortColumnSorted = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(Task.DATETIME_CREATED_PROPERTY)) {
                defaultSortColumnSorted = true;
            }
            if (ascending) {
                query.addOrdering(sortBy, SortOrder.ASCENDING_INSENSITIVE);
            } else {
                query.addOrdering(sortBy, SortOrder.DESCENDING_INSENSITIVE);
            }
        }

        if (!defaultSortColumnSorted) {
            query.addOrdering(Task.DATETIME_CREATED_PROPERTY, SortOrder.DESCENDING);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List<Task> getTasksToExpire() {
        SelectQuery query = new SelectQuery(Task.class);

        andQueryMatchExp(query, Task.TASK_STATUS_PROPERTY, Task.TASK_STATUS_ASSIGNED);

        query.andQualifier(ExpressionFactory.lessExp(Task.DATETIME_EXPIRY_PROPERTY, new Date()));

        return performQuery(query);
    }

    public List<Task> getTasksReadyForNotification() {
        SelectQuery query = new SelectQuery(Task.class);

        Expression emailStatusExpression = ExpressionFactory.matchExp(Task.EMAIL_STATUS_PROPERTY, Task.EMAIL_STATUS_READY);
        emailStatusExpression = emailStatusExpression.orExp(ExpressionFactory.matchExp(Task.EMAIL_STATUS_PROPERTY,
                Task.EMAIL_STATUS_ERROR));
        query.andQualifier(emailStatusExpression);

        andQueryMatchExp(query, Task.TASK_STATUS_PROPERTY, Task.TASK_STATUS_ASSIGNED);

        return performQuery(query);
    }

    public List<Task> getToDoTasksForUser(UserAccount userAccount, String groupName, String keywordLike,
            String clientName, List<String> statusList, Portal portal) {
        Validate.notNull(userAccount, "Null userAccount parameter");
        Validate.notNull(portal, "Null portal parameter");

        GroupDao groupDao = DaoFactory.getGroupDao();
        List<Group> groupsForUser = groupDao.getGroupsForUser(userAccount);

        SelectQuery query = new SelectQuery(Task.class);

        Expression assigneeExpression = ExpressionFactory.matchExp(Task.USER_PROPERTY, userAccount);
        assigneeExpression = assigneeExpression.orExp(ExpressionFactory.inExp(Task.GROUP_PROPERTY, groupsForUser));
        query.andQualifier(assigneeExpression);

        andQueryMatchExp(query, Task.PORTAL_PROPERTY, portal);
        andQueryMatchExp(query, Task.FORM_PROPERTY + "." + Form.PORTAL_PROPERTY, portal);

        if (StringUtils.isNotEmpty(groupName)){
            andQueryMatchExp(query, Task.GROUP_PROPERTY + "." + Group.GROUP_NAME_PROPERTY, groupName);
        }

        if (StringUtils.isNotEmpty(keywordLike)) {
            // search form name and task message
            Expression keywordExpression = ExpressionFactory.likeIgnoreCaseExp(Task.FORM_PROPERTY + "."
                    + Form.FORM_NAME_PROPERTY, "%" + keywordLike + "%");
            keywordExpression = keywordExpression.orExp(ExpressionFactory.likeIgnoreCaseExp(Task.TASK_MESSAGE_PROPERTY,
                    "%" + keywordLike + "%"));
            query.andQualifier(keywordExpression);
        }

        if (StringUtils.isNotEmpty(clientName)) {
            andQueryMatchExp(query, Task.FORM_PROPERTY + "." + Form.CLIENT_PROPERTY
                    + "." + Client.CLIENT_NAME_PROPERTY, clientName);
        }

        if (statusList != null && statusList.size() > 0) {
            query.andQualifier(ExpressionFactory.inExp(Task.TASK_STATUS_PROPERTY, statusList));
        }

        query.addPrefetch(Task.FORM_PROPERTY);
        query.addPrefetch(Task.FORM_PROPERTY + "." + Form.CLIENT_PROPERTY);

        query.addOrdering(Task.DATETIME_CREATED_PROPERTY, SortOrder.ASCENDING);

        return performQuery(query);
    }
}

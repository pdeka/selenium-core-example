
package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;

public class DeliveryDetailsDao extends BaseDao {

    public List getDeliveryDetailsList(String clientId, String name) {
        SelectQuery query = new SelectQuery(DeliveryDetails.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.orQualifier(ExpressionFactory.matchDbExp("client_oid", clientId));
        }

        if (StringUtils.isNotBlank(name)) {
            query.orQualifier(ExpressionFactory.matchExp(DeliveryDetails.NAME_PROPERTY, name));
        }

        query.addOrdering(DeliveryDetails.CLIENT_PROPERTY, true);
        query.addOrdering(DeliveryDetails.NAME_PROPERTY, true);

        return performQuery(query);
    }

    public DeliveryDetails getDeliveryDetailForClientAndName(Client client, String name) {
        Validate.notNull(client);
        Validate.notEmpty(name);

        SelectQuery query = new SelectQuery(DeliveryDetails.class);

        andQueryMatchExp(query, DeliveryDetails.CLIENT_PROPERTY, client);
        andQueryMatchExp(query, DeliveryDetails.NAME_PROPERTY, name);

        List values = performQuery(query);

        if (!values.isEmpty()) {
            return (DeliveryDetails) values.get(0);

        } else {
            return null;
        }
    }

    public List getClientWSDeliveryDetailsList(Client client) {
        SelectQuery query = new SelectQuery(DeliveryDetails.class);

        andQueryMatchExp(query, DeliveryDetails.CLIENT_PROPERTY, client);
        andQueryMatchExp(query, DeliveryDetails.DELIVERY_METHOD_PROPERTY, DeliveryDetails.METHOD_WEB_SERVICE);

        return performQuery(query);
    }

    public List getDeliveryDetailsList(String clientId) {
        if (StringUtils.isBlank(clientId)) {
            return new ArrayList<DeliveryDetails>();
        }

        SelectQuery query = new SelectQuery(DeliveryDetails.class);

        andQueryMatchExp(query, DeliveryDetails.CLIENT_PROPERTY, clientId);

        addOrdering(query, DeliveryDetails.NAME_PROPERTY);

        return performQuery(query);
    }

    public SelectQuery getPotentialDeliveryDetailsQueryForForm(String formId) {
        SelectQuery query = new SelectQuery(DeliveryDetails.class);
        if (StringUtils.isNotBlank(formId)) {
            Form form = (Form) getObjectForPK(Form.class, formId);
            if (form != null) {
                query.andQualifier(ExpressionFactory.matchExp(DeliveryDetails.CLIENT_PROPERTY, form.getClient().getId().toString()));
                query.orQualifier(ExpressionFactory.matchExp(DeliveryDetails.CLIENT_PROPERTY, null));
            }
        }
        return query;
    }

    public String[] getAvailableDeliveryMethods() {
        DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
        String emailDeliveryMethods = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Supported_Delivery_Methods);

        if (StringUtils.isBlank(emailDeliveryMethods)) {
            return DeliveryDetails.DELIVERY_METHODS;
        }
        else {
            String[] parsedMethods = emailDeliveryMethods.split(",");
            ArrayList<String> result = new ArrayList<String>(parsedMethods.length);
            for (int i = 0; i < parsedMethods.length; i++) {
                String curMethod = parsedMethods[i].trim();
                if (ArrayUtils.contains(DeliveryDetails.DELIVERY_METHODS, curMethod)) {
                    result.add(curMethod);
                }
            }

            String[] resultArray = new String[result.size()];
            for (int i = 0; i < result.size(); i++) {
                resultArray[i] = result.get(i);
            }
            return resultArray;
        }
    }

    public String getAllDeliveryMethodsString() {
        return StringUtils.join(DeliveryDetails.DELIVERY_METHODS, ',');
    }
}

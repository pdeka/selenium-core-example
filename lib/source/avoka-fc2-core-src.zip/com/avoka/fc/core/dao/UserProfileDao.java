package com.avoka.fc.core.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserProfile;
import com.avoka.fc.core.entity.UserProperty;

public class UserProfileDao extends BaseDao {

    /**
     * Return the user profiles for the given user details ordered by profile name.
     *
     * @param user
     *            the user details to get the profiles for
     * @return the user profiles for the given username ordered by profile name
     */
    public List getProfilesForUser(UserAccount user){
        Validate.notNull(user, "Null user parameter");
        Expression qual = ExpressionFactory.matchExp(UserProfile.USER_PROPERTY, user);

        SelectQuery query = new SelectQuery(UserProfile.class, qual);
        query.addOrdering(UserProfile.PROFILE_NAME_PROPERTY, true);

        return performQuery(query);
    }

    public UserProfile getCurrentUserProfileForUser(UserAccount userAccount){
        if (userAccount == null) {
            return null;
        }

        Expression qual = ExpressionFactory.matchExp(UserProfile.USER_PROPERTY, userAccount);
        qual = qual.andExp(ExpressionFactory.matchExp(UserProfile.CURRENT_FLAG_PROPERTY, Boolean.TRUE));

        SelectQuery query = new SelectQuery(UserProfile.class, qual);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (UserProfile) list.get(0);

        } else {
            return null;
        }
    }

    public List getCurrentUserProfilesForEmail(String email){
        Expression qual = ExpressionFactory.matchExp(UserProfile.USER_PROPERTY + "." + UserAccount.EMAIL_PROPERTY, email);
        qual = qual.andExp(ExpressionFactory.matchExp(UserProfile.CURRENT_FLAG_PROPERTY, Boolean.TRUE));

        SelectQuery query = new SelectQuery(UserProfile.class, qual);
        query.addPrefetch(UserProfile.USER_PROPERTIES_PROPERTY);

        return performQuery(query);
    }

    public UserProfile getProfileForPK(Object id){
        return (UserProfile) getObjectForPK(UserProfile.class, id);
    }

    public void makeCurrentProfile(UserProfile userProfile){
        Validate.notNull(userProfile, "Null userProfile parameter");

        UserAccount userAccount = userProfile.getUser();
        for (Iterator i = userAccount.getUserProfiles().iterator(); i.hasNext();) {
            UserProfile up = (UserProfile) i.next();
            up.setCurrentFlag(Boolean.FALSE);
        }

        userProfile.setCurrentFlag(Boolean.TRUE);
    }

    /**
     * Delete the given user profile, and return the next user profile. If the profile is the last
     * profile for the user an new default user profile will be created.
     *
     * @param userProfile
     *            the user profile to delete
     * @return the next profile for the user
     */
    public UserProfile deleteProfile(UserProfile userProfile){
        Validate.notNull(userProfile, "Null userProfile parameter");

        getLogger().debug("delete profile: " + userProfile.getId());

        UserAccount userAccount = userProfile.getUser();

        boolean setNewDefault = userProfile.isDefaultProfile();

        userAccount.removeFromUserProfiles(userProfile);

        deleteObject(userProfile);

        List userProfiles = userAccount.getUserProfiles();

        if (userProfiles.isEmpty()) {
            // Create new user profile
            UserProfile newUserProfile = (UserProfile) createAndRegisterNewObject(UserProfile.class);

            newUserProfile.setProfileName(UserProfile.DEFAULT_PROFILE_NAME);
            newUserProfile.setProfileDescription(UserProfile.DEFAULT_PROFILE_DESCRIPTION);
            newUserProfile.setCurrentFlag(Boolean.TRUE);
            newUserProfile.setUser(userAccount);

            PropertyTypeDao propertyTypeDao = new PropertyTypeDao();

            List properties = propertyTypeDao.getPropertyTypesByScope(PropertyType.SCOPE_User);

            for (Iterator iter = properties.iterator(); iter.hasNext();) {
                PropertyType fpt = (PropertyType) iter.next();

                UserProperty up = new UserProperty();
                registerNewObject(up);

                up.setPropertyType(fpt);
                up.setProfile(newUserProfile);
            }

            getLogger().debug("#1");
            getLogger().debug("old profile: " + newUserProfile);
            getLogger().debug("new profile: " + newUserProfile);

            getLogger().debug("created new profile: " + newUserProfile.getId());

            return newUserProfile;

        } else {
            UserProfile newUserProfile = (UserProfile) userProfiles.get(0);

            if (setNewDefault || userProfiles.size() == 1) {
                newUserProfile.setCurrentFlag(Boolean.TRUE);
            }

            getLogger().debug("#2");
            getLogger().debug("old profile: " + newUserProfile);
            getLogger().debug("new profile: " + newUserProfile);

            getLogger().debug("created user profile: " + newUserProfile.getId());

            return newUserProfile;
        }
    }

    public List<Map> getUserProfilePropertyValues(FormDeployXml formDeployXml, UserProfile userProfile){
        Validate.notNull(formDeployXml, "Null formDeployXml parameter");
        Validate.notNull(userProfile, "Null userProfile parameter");

        Map parameters = new HashMap();
        parameters.put("formDeployOid", formDeployXml.getId());
        parameters.put("userProfileOid", userProfile.getId());

        return performNamedQuery(NamedQueries.USER_Profile_FormDeploy_Map, parameters, true);
    }

    /**
     * Delete the given user profile, and return the next user profile. If the profile is the last
     * profile for the user an new default user profile will be created.
     *
     * @param userId
     *            the user for the new profile
     * @return the new profile
     */
    public UserProfile createProfile(Long userId, String profileName, String profileDescription){
        Validate.notNull(userId, "Null userId parameter");
        Validate.notNull(profileName, "Null profileName parameter");
        Validate.notNull(profileDescription, "Null profileDescription parameter");

        UserAccount userAccount = DaoFactory.getUserAccountDao().getUserAccountForPK(userId);

        // Create new user profile
        UserProfile newUserProfile = (UserProfile) createAndRegisterNewObject(UserProfile.class);

        newUserProfile.setProfileName(profileName);
        newUserProfile.setProfileDescription(profileDescription);
        newUserProfile.setCurrentFlag(Boolean.FALSE);
        newUserProfile.setUser(userAccount);

        PropertyTypeDao propertyTypeDao = new PropertyTypeDao();

        List properties = propertyTypeDao.getPropertyTypesByScope(PropertyType.SCOPE_User);

        for (Iterator iter = properties.iterator(); iter.hasNext();) {
            PropertyType fpt = (PropertyType) iter.next();

            UserProperty up = new UserProperty();
            registerNewObject(up);

            up.setPropertyType(fpt);
            up.setProfile(newUserProfile);
        }

        getLogger().debug("#1");
        getLogger().debug("old profile: " + newUserProfile);
        getLogger().debug("new profile: " + newUserProfile);
        getLogger().debug("created new profile: " + newUserProfile.getId());

        return newUserProfile;
    }

    /**
     * Update profile
     *
     * @param profileId the profile id
     * @param profileName name of the profile to be update
     * @param profileDescription description of the profile to be update
     * @return the updated profile
     */
    public UserProfile updateProfile(String profileId, String profileName, String profileDescription){
        Validate.notNull(profileId, "Null profileId parameter");
        Validate.notNull(profileName, "Null profileName parameter");
        Validate.notNull(profileDescription, "Null profileDescription parameter");

        UserProfile profile = getProfileForPK(profileId);
        profile.setProfileDescription(profileDescription);
        profile.setProfileName(profileName);

        return profile;
    }
}

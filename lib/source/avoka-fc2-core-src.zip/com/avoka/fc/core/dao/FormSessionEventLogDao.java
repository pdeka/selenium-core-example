package com.avoka.fc.core.dao;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.FormSessionEventLog;

public class FormSessionEventLogDao extends BaseDao {

    public FormSessionEventLog getFormSessionEventLog(Object entityId) {
        return (FormSessionEventLog) getObjectForPK(FormSessionEventLog.class, entityId);
    }
}

package com.avoka.fc.core.dao;


public class DaoFactory {

    public static AttachmentDao getAttachmentDao() {
        return new AttachmentDao();
    }

    public static AuditLogDao getAuditLogDao() {
        return new AuditLogDao();
    }

    public static ClientDao getClientDao() {
        return new ClientDao();
    }

    public static ClientPropertyDao getClientPropertyDao() {
        return new ClientPropertyDao();
    }

    public static DailySummaryReportDao getDailySummaryReportDao() {
        return new DailySummaryReportDao();
    }

    public static DbVersionUpdateDao getDbVersionUpdateDao() {
        return new DbVersionUpdateDao();
    }

    public static DeliveryDetailsDao getDeliveryDetailsDao() {
        return new DeliveryDetailsDao();
    }

    public static DeploymentPropertyDao getDeploymentPropertyDao() {
        return new DeploymentPropertyDao();
    }

    public static DocumentTypeDao getDocumentTypeDao() {
        return new DocumentTypeDao();
    }

    public static ErrorLogDao getErrorLogDao() {
        return new ErrorLogDao();
    }

    public static EventLogDao getEventLogDao() {
        return new EventLogDao();
    }

    public static FileUploadDao getFileUploadDao() {
        return new FileUploadDao();
    }

    public static FinderCategoryDao  getFinderCategoryDao () {
        return new FinderCategoryDao ();
    }

    public static FormDao getFormDao() {
        return new FormDao();
    }

    public static FormDeployXmlDao getFormDeployXmlDao() {
        return new FormDeployXmlDao();
    }

    public static FormPropertyDao getFormPropertyDao() {
        return new FormPropertyDao();
    }

    public static FormReceiptSequenceDao getFormReceiptSequenceDao() {
        return new FormReceiptSequenceDao();
    }

    public static FormSessionEventLogDao getFormSessionEventLogDao() {
        return new FormSessionEventLogDao();
    }

    public static FormSessionLogDao getFormSessionLogDao() {
        return new FormSessionLogDao();
    }

    public static GroupDao getGroupDao() {
        return new GroupDao();
    }

    public static HealthMonitorDao getHealthMonitorDao() {
        return new HealthMonitorDao();
    }

    public static MetadataTagDao getMetadataTagDao() {
        return new MetadataTagDao();
    }

    public static MetadataValueDao getMetadataValueDao() {
        return new MetadataValueDao();
    }

    public static MetadataValueDeployDao getMetadataValueDeployDao() {
        return new MetadataValueDeployDao();
    }

    public static MetadataListValueDao getMetadataListValueDao() {
        return new MetadataListValueDao();
    }

    public static NotificationDao getNotificationDao() {
        return new NotificationDao();
    }

    public static OfflineSubmissionFormDao getOfflineSubmissionFormDao() {
        return new OfflineSubmissionFormDao();
    }

    public static PortalPageDao getPortalPageDao() {
        return new PortalPageDao();
    }

    public static PortalResourceDao getPortalResourceDao() {
        return new PortalResourceDao();
    }

    public static PortalPropertyDao getPortalPropertyDao() {
        return new PortalPropertyDao();
    }

    public static PaymentLogDao getPaymentLogDao() {
        return new PaymentLogDao();
    }

    public static PermissionDao getPermissionDao() {
        return new PermissionDao();
    }

    public static PortalDao getPortalDao() {
        return new PortalDao();
    }

    public static PromotionDao getPromotionDao() {
        return new PromotionDao();
    }

    public static PropertyDeployDao getPropertyDeployDao() {
        return new PropertyDeployDao();
    }

    public static PropertyTypeDao getPropertyTypeDao() {
        return new PropertyTypeDao();
    }

    public static PropertyTypeMapDao getPropertyTypeMapDao() {
        return new PropertyTypeMapDao();
    }

    public static ReportDao getReportDao() {
        return new ReportDao();
    }

    public static ReportScheduleDao getReportScheduleDao() {
        return new ReportScheduleDao();
    }

    public static RequiredAttachmentDao getRequiredAttachmentDao() {
        return new RequiredAttachmentDao();
    }

    public static RequestLogDao getRequestLogDao() {
        return new RequestLogDao();
    }

    public static RoleDao getRoleDao() {
        return new RoleDao();
    }

    public static RolePermissionDao getRolePermissionDao() {
        return new RolePermissionDao();
    }

    public static SchemaSeedDao getSchemaSeedDao() {
        return new SchemaSeedDao();
    }

    public static ServiceConnectionDao getServiceConnectionDao() {
        return new ServiceConnectionDao();
    }

    public static ServiceDefinitionDao getServiceDefinitionDao() {
        return new ServiceDefinitionDao();
    }

    public static SubmissionDao getSubmissionDao() {
        return new SubmissionDao();
    }

    public static SubmissionHistoryDao getSubmissionHistoryDao() {
        return new SubmissionHistoryDao();
    }

    public static SupportLogDao getSupportLogDao() {
        return new SupportLogDao();
    }

    public static TaskDao getTaskDao() {
        return new TaskDao();
    }

    public static TemplateDao getTemplateDao() {
        return new TemplateDao();
    }

    public static TemplateVersionDao getTemplateVersionDao() {
        return new TemplateVersionDao();
    }

    public static TemplateVersionDataDao getTemplateVersionDataDao() {
        return new TemplateVersionDataDao();
    }

    public static UserAccountDao getUserAccountDao() {
        return new UserAccountDao();
    }

    public static UserProfileDao getUserProfileDao() {
        return new UserProfileDao();
    }

    public static UserPropertyDao getUserPropertyDao() {
        return new UserPropertyDao();
    }

    public static XmlInputVersionDao getXmlInputVersionDao() {
        return new XmlInputVersionDao();
    }

    public static XmlInputMapDao getXmlInputMapDao() {
        return new XmlInputMapDao();
    }

}

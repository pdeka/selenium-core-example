package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.FinderCategory;

@SuppressWarnings("unchecked")
public class FinderCategoryDao extends BaseDao {

    public FinderCategory getCategoryForPK(Object id) {
        return (FinderCategory) getObjectForPK(FinderCategory.class, id);
    }

    public FinderCategory getCategoryForName(String name) {
        return (FinderCategory) findObject(FinderCategory.class, FinderCategory.CATEGORY_NAME_PROPERTY, name);
    }

    public FinderCategory getCategoryForCode(String code) {
        return (FinderCategory) findObject(FinderCategory.class, FinderCategory.CATEGORY_CODE_PROPERTY, code);
    }

    public List<FinderCategory> getCategoryList(String name, String clientId) {
        SelectQuery query = new SelectQuery(FinderCategory.class);

        andQueryLikeIgnoreCaseExp(query, FinderCategory.CATEGORY_NAME_PROPERTY, name);

        if (StringUtils.isNotBlank(clientId)) {
            andQueryMatchExp(query, FinderCategory.CLIENT_PROPERTY, clientId);
        }

        query.addOrdering(FinderCategory.CATEGORY_NAME_PROPERTY, true);

        return performQuery(query);
    }

}

package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.XmlInputMap;
import com.avoka.fc.core.entity.XmlInputVersion;

public class XmlInputMapDao extends BaseDao {

    public XmlInputMap getXmlInputMapForId(String id) {
        return (XmlInputMap) getObjectForPK(XmlInputMap.class, id);
    }

    public List getXmlInputMapListForXmlInputVersion(XmlInputVersion xmlInputVersion) {
        Validate.notNull(xmlInputVersion, "Null xml input version parameter");

        SelectQuery query = new SelectQuery(XmlInputMap.class);

        query.andQualifier(ExpressionFactory.matchExp(XmlInputMap.XML_INPUT_VERSION_PROPERTY, xmlInputVersion));
        query.addPrefetch(XmlInputMap.XML_INPUT_VERSION_PROPERTY);

//        query.addOrdering(XmlInputMap.XML_INPUT_MAP_OID_PK_COLUMN, true);

        return performQuery(query);
    }
}

/*
 * Copyright (c) 2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.DocumentType;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.MetadataTag;
import com.avoka.fc.core.entity.MetadataValue;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;

/**
 * Provides the Form DAO.
 *
 * @author medgar@avoka.com
 * @author pcopeland@avoka.com
 */
public class FormDao extends BaseDao {

    public Form getFormFromPK(Object id) {
        SelectQuery query = new SelectQuery(Form.class);

        andQueryMatchDbExp(query, Form.FORM_OID_PK_COLUMN, id);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (Form) list.get(0);

        } else {
            return null;
        }
    }

    public Form getFormByFormCode(String formCode) {
        SelectQuery query = new SelectQuery(Form.class);

        andQueryMatchExp(query, Form.CLIENT_FORM_CODE_PROPERTY, formCode);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
        query.addPrefetch(Form.TEMPLATE_PROPERTY);
        query.addPrefetch(Form.TEMPLATE_PROPERTY + "." + Template.CURRENT_VERSION_PROPERTY);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (Form) list.get(0);

        } else {
            return null;
        }
    }

    public Form getActiveProductionFormByFormCode(String formCode) {
        SelectQuery query = new SelectQuery(Form.class);

        andQueryMatchExp(query, Form.CLIENT_FORM_CODE_PROPERTY, formCode);
        andQueryMatchExp(query, Form.ACTIVE_FLAG_PROPERTY, Boolean.TRUE);
        andQueryMatchExp(query, Form.TEST_ENABLED_FLAG_PROPERTY, Boolean.FALSE);

        query.addPrefetch(Form.CLIENT_PROPERTY);

        List formList = performQuery(query);

        if (!formList.isEmpty()) {
            return (Form) formList.get(0);

        } else {
            return null;
        }
    }

    public List<String> getFormCodesLike(String pattern, String clientId) {
        SelectQuery query = new SelectQuery(Form.class);
        query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.CLIENT_FORM_CODE_PROPERTY, pattern + "%"));

        if (StringUtils.isNotEmpty(clientId)) {
            andQueryMatchExp(query, Form.CLIENT_PROPERTY, clientId);
        }

        query.addOrdering(Form.CLIENT_FORM_CODE_PROPERTY, true);

        List<Form> forms = performQuery(query);
        List<String> codes = new ArrayList<String>();
        for (Form form : forms) {
            codes.add(form.getClientFormCode());
        }

        return codes;
    }

    public Form getFormBySubmitKey(String submitKey) {
        Expression expression = ExpressionFactory.matchExp("submissions.submitKey", submitKey);

        SelectQuery query = new SelectQuery(Form.class, expression);
        query.addPrefetch(Form.CLIENT_PROPERTY);
        query.addPrefetch(Form.TEMPLATE_PROPERTY + "." + Template.CURRENT_VERSION_PROPERTY);

        List formList = performQuery(query);

        if (formList.isEmpty()) {
            return null;
        }

        return (Form) formList.get(0);
    }

    public List<Form> getAllForms() {
        SelectQuery query = new SelectQuery(Form.class);

        query.addOrdering(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);
        query.addPrefetch(Form.CLIENT_PROPERTY);

        return performQuery(query);
    }

    public List<Form> getActiveAndProductionFormList() {
        SelectQuery query = new SelectQuery(Form.class);

        andQueryMatchExp(query, Form.ACTIVE_FLAG_PROPERTY, Boolean.TRUE);
        andQueryMatchExp(query, Form.TEST_ENABLED_FLAG_PROPERTY, Boolean.FALSE);
        andQueryMatchExp(query, Form.CLIENT_PROPERTY + "." + Client.ACTIVE_FLAG_PROPERTY, Boolean.TRUE);

        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<Form> getActiveFormList() {
        SelectQuery query = new SelectQuery(Form.class);

        andQueryMatchExp(query, Form.ACTIVE_FLAG_PROPERTY, Boolean.TRUE);
        andQueryMatchExp(query, Form.CLIENT_PROPERTY + "." + Client.ACTIVE_FLAG_PROPERTY, Boolean.TRUE);

        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<Form> getActiveFormListByDateAndClient(Date eventDate, Client client) {

        SelectQuery query = new SelectQuery(Form.class);

        query.andQualifier(ExpressionFactory.matchExp(Form.CLIENT_PROPERTY, client));

        Expression activateTimestampExp = ExpressionFactory.greaterOrEqualExp(Form.ACTIVATE_TIMESTAMP_PROPERTY, eventDate);
        activateTimestampExp = activateTimestampExp.orExp(ExpressionFactory.matchExp(Form.ACTIVATE_TIMESTAMP_PROPERTY, null));
        query.andQualifier(activateTimestampExp);

        Expression deactiveTimeStampExp = ExpressionFactory.lessExp(Form.DEACTIVATE_TIMESTAMP_PROPERTY, eventDate);
        deactiveTimeStampExp = deactiveTimeStampExp.orExp(ExpressionFactory.matchExp(Form.DEACTIVATE_TIMESTAMP_PROPERTY, null));
        query.andQualifier(deactiveTimeStampExp);

        return performQuery(query);
    }

    public List<Form> getActiveFormListForClient(String clientId) {

        SelectQuery query = new SelectQuery(Form.class);

        if (StringUtils.isNotBlank(clientId)) {
            andQueryMatchDbExp(query, "client_oid", clientId);
        }

        andQueryMatchExp(query, Form.ACTIVE_FLAG_PROPERTY, true);

        query.addOrdering(Form.FORM_NAME_PROPERTY, true);

        return performQuery(query);
    }

    public List<Form> getActiveFormSearch(String clientFormId, String clientName, String formName, String formDescription) {
        SelectQuery query = new SelectQuery(Form.class);

        andQueryMatchExp(query, Form.ACTIVE_FLAG_PROPERTY, Boolean.TRUE);
        andQueryMatchExp(query, Form.TEST_ENABLED_FLAG_PROPERTY, Boolean.FALSE);

        if (StringUtils.isNotBlank(clientFormId)) {
            andQueryMatchExp(query, Form.CLIENT_FORM_ID_PROPERTY, clientFormId);
        }

        if (StringUtils.isNotBlank(clientName)) {
            andQueryLikeIgnoreCaseExp(query, Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, clientName);
        }

        if (StringUtils.isNotBlank(formName)) {
            andQueryLikeIgnoreCaseExp(query, Form.FORM_NAME_PROPERTY, formName);
        }

        if (StringUtils.isNotBlank(formDescription)) {
            andQueryLikeIgnoreCaseExp(query, Form.FORM_DESCRIPTION_PROPERTY, formDescription);
        }

        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<Form> getFormListForNameAndClientLike(String formName, String clientName) {
        SelectQuery query = new SelectQuery(Form.class);

        if (StringUtils.isNotBlank(formName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.FORM_NAME_PROPERTY, "%" + formName + "%"));
        }
        if (StringUtils.isNotBlank(clientName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, "%" + clientName + "%"));
        }
        query.andQualifier(ExpressionFactory.matchExp(Form.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));

        query.addOrdering(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);
        query.addPrefetch(Form.CLIENT_PROPERTY);

        return performQuery(query);
    }

    public List<String> getFormNamesLike(String formName, String clientName) {
        SelectQuery query = new SelectQuery(Form.class);

        if (StringUtils.isNotBlank(formName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.FORM_NAME_PROPERTY, formName + "%"));
        }
        if (StringUtils.isNotBlank(clientName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, "%" + clientName + "%"));
        }

        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);

        List<Form> forms = performQuery(query);
        List<String> names = new ArrayList<String>();
        for (Form form : forms) {
            names.add(form.getFormName());
        }

        return names;
    }

    public List getFormListForClient(Object clientId, boolean testMode) {
        if (clientId == null || clientId.toString().length() == 0) {
            return Collections.EMPTY_LIST;
        }

        SelectQuery query = new SelectQuery(Form.class);
        query.andQualifier(ExpressionFactory.matchDbExp("client.client_oid", clientId));
        query.andQualifier(ExpressionFactory.matchExp(Form.CLIENT_PROPERTY + "." + Client.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));
        query.andQualifier(ExpressionFactory.matchExp(Form.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));

        if (!testMode) {
            query.andQualifier(ExpressionFactory.matchExp(Form.TEST_ENABLED_FLAG_PROPERTY, Boolean.FALSE));
        }

        query.addOrdering(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);
        query.addPrefetch(Form.CLIENT_PROPERTY);

        return performQuery(query);
    }

    public List getFormList(String clientId, String portalId, String nameLike, String codeLike, String templateFileName, Boolean active, Boolean test, String sortBy, boolean ascending) {
        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotEmpty(clientId)) {
            params.put("clientId", clientId);
        }
        if (StringUtils.isNotEmpty(portalId)) {
            params.put("portalId", portalId);
        }
        if (StringUtils.isNotEmpty(nameLike)) {
            params.put("formName", nameLike);
        }
        if (StringUtils.isNotEmpty(codeLike)) {
            params.put("clientFormCode", codeLike);
        }
        if (StringUtils.isNotEmpty(templateFileName)) {
            params.put("templateFileName", templateFileName);
        }
        if (Boolean.TRUE.equals(active)) {
            params.put("activeFlag", active);
        }
        if (!Boolean.TRUE.equals(test)) {
            params.put("notTestEnabled", true);
        }

        StringBuilder orderByString = new StringBuilder();

        boolean sortedByClient = false;
        boolean sortedByFormName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if ("client_name".equals(sortBy)) {
                sortedByClient = true;
            }
            else if ("form_name".equals(sortBy)) {
                sortedByFormName = true;
            }
            orderByString.append(sortBy);
            orderByString.append(" ");
            orderByString.append(ascending ? "ASC" : "DESC");
        }

        if (!sortedByClient) {
            if (orderByString.length() > 0) {
                orderByString.append(", ");
            }
            orderByString.append("client_name ASC");
        }
        if (!sortedByFormName) {
            if (orderByString.length() > 0) {
                orderByString.append(", ");
            }
            orderByString.append("form_name ASC");
        }
        params.put("orderBy", orderByString.toString());

        return performNamedQuery(NamedQueries.FORM_SEARCH, params, true);
    }

    public List getFormsByName(String clientId, String name) {
        SelectQuery query = new SelectQuery(Form.class);

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(Form.CLIENT_PROPERTY, clientId));
        }
        if (StringUtils.isNotEmpty(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.FORM_NAME_PROPERTY, name));
        }

        query.addOrdering(Form.FORM_NAME_PROPERTY, true);

        return performQuery(query);
    }

    public Form getFormByName(Client client, String name) {
        SelectQuery query = new SelectQuery(Form.class);

        if (client != null) {
            query.andQualifier(ExpressionFactory.matchExp(Form.CLIENT_PROPERTY, client.getId().toString()));
        }
        if (StringUtils.isNotEmpty(name)) {
            query.andQualifier(ExpressionFactory.matchExp(Form.FORM_NAME_PROPERTY, name));
        }

        query.addOrdering(Form.FORM_NAME_PROPERTY, true);

        List forms = performQuery(query);

        if (forms != null && forms.size() > 0) {
            return (Form) forms.get(0);
        }
        return null;
    }

    public Form getFormByNameIgnoreCase(String clientCode, String formName) {

        SelectQuery query = new SelectQuery(Form.class);

        Expression clientCodeExp =
            ExpressionFactory.likeIgnoreCaseExp(Form.CLIENT_PROPERTY + "." + Client.CLIENT_CODE_PROPERTY, clientCode);
        query.andQualifier(clientCodeExp);

        Expression formNameExp = ExpressionFactory.likeIgnoreCaseExp(Form.FORM_NAME_PROPERTY, formName);
        query.andQualifier(formNameExp);

        List<Form> forms = performQuery(query);

        if (!forms.isEmpty()) {
            return forms.get(0);

        } else {
            return null;
        }
    }

    public List<Form> getFormListForKeywordAndClientLike(String keyword, String clientName, Portal portal) {
        Validate.notNull(portal, "Null portal parameter");

        SelectQuery query = new SelectQuery(Form.class);

        andQueryMatchExp(query, Form.PORTAL_PROPERTY, portal);
        andQueryMatchExp(query, Form.ACTIVE_FLAG_PROPERTY, Boolean.TRUE);
        andQueryNoMatchExp(query, Form.TEST_ENABLED_FLAG_PROPERTY, Boolean.TRUE);

        if (StringUtils.isNotBlank(keyword)) {
            Expression keywordExpression = ExpressionFactory.likeIgnoreCaseExp(Form.FORM_NAME_PROPERTY, "%" + keyword + "%");
            keywordExpression = keywordExpression.orExp(ExpressionFactory.likeIgnoreCaseExp(Form.FORM_DESCRIPTION_PROPERTY, "%" + keyword + "%"));
            query.andQualifier(keywordExpression);
        }
        if (StringUtils.isNotBlank(clientName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, "%" + clientName + "%"));
        }

        query.addOrdering(Form.FORM_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(Form.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);
        query.addPrefetch(Form.CLIENT_PROPERTY);

        return performQuery(query);
    }

    public List<Form> getFormsSearch(String clientId, String value) {
        SelectQuery query = new SelectQuery(Form.class);

        if (StringUtils.isNotEmpty(value)) {
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.FORM_NAME_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.CLIENT_FORM_CODE_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(Form.FORM_DESCRIPTION_PROPERTY, "%" + value + "%"));
            if (NumberUtils.isNumber(value)) {
                query.orQualifier(ExpressionFactory.matchDbExp(Form.FORM_OID_PK_COLUMN, value));
            }
        }
        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(Form.CLIENT_PROPERTY + "." + Client.CLIENT_OID_PK_COLUMN, clientId));
        }

        query.addOrdering(Form.FORM_NAME_PROPERTY, true);

        return performQuery(query);
    }

    public List<MetadataValue> getAllFormMetadataValues(Form form) {
        Validate.notNull(form);

        List<MetadataValue> resultList = new ArrayList<MetadataValue>();

        List<MetadataValue> results = getFormAndTemplateMetadataValues(form);
        resultList.addAll(results);

        // Load client meta data
        SelectQuery query = new SelectQuery(MetadataValue.class);
        andQueryMatchExp(query, MetadataValue.CLIENT_PROPERTY, form.getClient());
        query.addPrefetch(MetadataValue.METADATA_TAG_PROPERTY);
        query.addOrdering(MetadataValue.METADATA_TAG_PROPERTY + "." + MetadataTag.NAME_PROPERTY, true);

        results = (List<MetadataValue>) performQuery(query);
        resultList.addAll(results);

        return resultList;
    }

    public List<MetadataValue> getFormAndTemplateMetadataValues(Form form) {
        Validate.notNull(form);

        List<MetadataValue> resultList = new ArrayList<MetadataValue>();

        // Load form meta data
        SelectQuery query = new SelectQuery(MetadataValue.class);
        andQueryMatchExp(query, MetadataValue.FORM_PROPERTY, form);
        query.addPrefetch(MetadataValue.METADATA_TAG_PROPERTY);
        query.addOrdering(MetadataValue.METADATA_TAG_PROPERTY + "." + MetadataTag.NAME_PROPERTY, true);

        List results = (List<MetadataValue>) performQuery(query);
        resultList.addAll(results);

        // Load template meta data
        query = new SelectQuery(MetadataValue.class);
        andQueryMatchExp(query, MetadataValue.TEMPLATE_PROPERTY, form.getTemplate());
        query.addPrefetch(MetadataValue.METADATA_TAG_PROPERTY);
        query.addOrdering(MetadataValue.METADATA_TAG_PROPERTY + "." + MetadataTag.NAME_PROPERTY, true);

        results = (List<MetadataValue>) performQuery(query);
        resultList.addAll(results);

        return resultList;
    }

    public List<Form> getFormsUsingDocumentType(DocumentType documentType) {
        SelectQuery query = new SelectQuery(SpecifiedAttachment.class);

        query.andQualifier(ExpressionFactory.matchExp(SpecifiedAttachment.DOCUMENT_TYPE_PROPERTY, documentType));
        query.andQualifier(ExpressionFactory.noMatchExp(SpecifiedAttachment.FORM_PROPERTY, null));
        query.addPrefetch(SpecifiedAttachment.FORM_PROPERTY);

        List<SpecifiedAttachment> specifiedAttachments = performQuery(query);
        List<Form> result = new ArrayList<Form>();
        List<Long> formIds = new ArrayList<Long>();

        for (SpecifiedAttachment attachment: specifiedAttachments) {
            Form form = attachment.getForm();
            if (!formIds.contains(form.getId())) {
                result.add(attachment.getForm());
                formIds.add(form.getId());
            }
        }

        return result;
    }

    public Set getFormsWsAddresses() {
        // Find delivery details
        SelectQuery query = new SelectQuery(DeliveryDetails.class);

        andQueryMatchExp(query, DeliveryDetails.DELIVERY_METHOD_PROPERTY, DeliveryDetails.METHOD_WEB_SERVICE);

        List<DeliveryDetails> deliveryDetails = performQuery(query);

        Set addressSet = new HashSet();

        for (DeliveryDetails dd : deliveryDetails) {
            String deliveryWsMode = dd.getDeliveryWsMode();
            if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_1.equals(deliveryWsMode)) {
                String value = getIPAddress(dd.getDeliveryWsAddress());

                addressSet.add(value);

            } else if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_2.equals(deliveryWsMode)) {
                String value = getIPAddress(dd.getDeliveryWsAddress());

                addressSet.add(value);

            } else {
                addressSet.add(dd.getDeliveryWsAddress());
            }
        }

        // Find forms
        query = new SelectQuery(Form.class);
        andQueryMatchExp(query, Form.ACTIVE_FLAG_PROPERTY, true);
        query.andQualifier(ExpressionFactory.noMatchExp(Form.FORMS_CLIENT_WS_ADDRESS_PROPERTY, null));
        List<Form> forms = performQuery(query);

        for (Form form : forms) {
            String value = getIPAddress(form.getFormsClientWsAddress());
            addressSet.add(value);
        }

        return addressSet;
    }

    // Private Methods --------------------------------------------------------

    private String getIPAddress(String wsUrl) {
        String value = wsUrl;

        // Remote https:// prefix
        if (value.indexOf('/') != -1) {
            value = value.substring(value.indexOf('/') + 2);
        }
        // Remove remaining URL suffix
        if (value.indexOf('/') != -1) {
            value = value.substring(0, value.indexOf('/'));
        }

        if (value.indexOf(':') != -1) {
            value = value.substring(0, value.indexOf(':'));
        }

        return value;
    }

    public List getFormListForExportService(String clientId) {
        SelectQuery query = new SelectQuery(Form.class);

        String path = Form.TEMPLATE_PROPERTY + "." + Template.CURRENT_VERSION_PROPERTY + "."
            + TemplateVersion.FORM_EXPORT_SERVICE_PROPERTY;

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(Form.CLIENT_PROPERTY, clientId));
        }

        andQueryNoMatchExp(query, path, null);

        addOrdering(query, Form.FORM_NAME_PROPERTY);
        return performQuery(query);
    }
}

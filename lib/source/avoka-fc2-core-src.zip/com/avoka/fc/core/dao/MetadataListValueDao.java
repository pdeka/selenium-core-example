package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.MetadataListValue;
import com.avoka.fc.core.entity.MetadataTag;

public class MetadataListValueDao extends BaseDao {

    public MetadataListValue getMetadataListValue(String listValueId) {
        return (MetadataListValue) getObjectForPK(MetadataListValue.class, listValueId);
    }

    public MetadataListValue createMetadataListValue(String value, Integer sequence, MetadataTag tag) {
        MetadataListValue result = (MetadataListValue) createAndRegisterNewObject(MetadataListValue.class);
        result.setValue(value);
        result.setSequence(sequence);
        result.setMetadataTag(tag);
        return result;
    }

    public MetadataListValue getMetadataListValue(String value, String tagId) {
        SelectQuery query = new SelectQuery(MetadataListValue.class);

        andQueryMatchExp(query, MetadataListValue.METADATA_TAG_PROPERTY, tagId);
        andQueryMatchExp(query, MetadataListValue.VALUE_PROPERTY, value);

        List<MetadataListValue> result = performQuery(query);
        if (result == null || result.size() == 0) {
            return null;
        }
        return result.get(0);
    }

    public List<MetadataListValue> getListValuesForTag(String tagId) {
        SelectQuery query = new SelectQuery(MetadataListValue.class);

        andQueryMatchExp(query, MetadataListValue.METADATA_TAG_PROPERTY, tagId);

        query.addOrdering(MetadataListValue.SEQUENCE_PROPERTY, Ordering.ASC);
        query.addOrdering(MetadataListValue.VALUE_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<MetadataListValue> getValueTree(String listValueId) {
        List<MetadataListValue> result = new ArrayList<MetadataListValue>();
        if (StringUtils.isNotEmpty(listValueId)) {
            result.add(getMetadataListValue(listValueId));

            List<MetadataListValue> children = getChildValues(result);
            while (children != null && children.size() > 0) {
                result.addAll(children);
                children = getChildValues(children);
            }
        }
        return result;
    }

    public void deleteCascading(String listValueId) {
        List<MetadataListValue> valuesToDelete = getValueTree(listValueId);
        deleteObjects(valuesToDelete);
        getDataContext().commitChanges();
    }

    public List<MetadataListValue> getChildValues(String parentId) {
        SelectQuery query = new SelectQuery(MetadataListValue.class);

        query.andQualifier(ExpressionFactory.matchExp(MetadataListValue.PARENT_VALUE_PROPERTY, parentId));

        query.addOrdering(MetadataListValue.SEQUENCE_PROPERTY, Ordering.ASC);
        query.addOrdering(MetadataListValue.VALUE_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<MetadataListValue> getChildValues(List<MetadataListValue> parentValues) {
        SelectQuery query = new SelectQuery(MetadataListValue.class);

        query.andQualifier(ExpressionFactory.inExp(MetadataListValue.PARENT_VALUE_PROPERTY, parentValues));

        query.addOrdering(MetadataListValue.SEQUENCE_PROPERTY, Ordering.ASC);
        query.addOrdering(MetadataListValue.VALUE_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<MetadataListValue> getRootValues(String tagId) {
        SelectQuery query = new SelectQuery(MetadataListValue.class);

        query.andQualifier(ExpressionFactory.matchExp(MetadataListValue.METADATA_TAG_PROPERTY, tagId));
        query.andQualifier(ExpressionFactory.matchExp(MetadataListValue.PARENT_VALUE_PROPERTY, null));

        query.addOrdering(MetadataListValue.SEQUENCE_PROPERTY, Ordering.ASC);
        query.addOrdering(MetadataListValue.VALUE_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }
}

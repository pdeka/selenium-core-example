package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.query.NamedQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.ClientProperty;

/**
 * Provides a ClientProperty DAO.
 *
 * @author lpammer@avoka.com
 */
public class ClientPropertyDao extends BaseDao {

    public ClientProperty getClientProperty(Object entityId) {
        return (ClientProperty) getObjectForPK(ClientProperty.class, entityId);
    }

    @SuppressWarnings("deprecation")
    public List getPropertiesByClient(String clientId){
        if (StringUtils.isNotBlank(clientId)) {
            Map queryParams = new HashMap();
            queryParams.put("clientOid", clientId);
            NamedQuery query = new NamedQuery(NamedQueries.CLIENT_PROPERTIES, queryParams);
            return DataContext.getThreadDataContext().performQuery(query);

        } else {
            return new ArrayList();
        }
    }
}

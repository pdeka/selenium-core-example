/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.query.NamedQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.FormProperty;

/**
 * Provides the Form DAO.
 *
 * @author dfrizelle@avoka.com
 */
public class FormPropertyDao extends BaseDao {

    public FormProperty getFormProperty(Object entityId) {
        return (FormProperty) getObjectForPK(FormProperty.class, entityId);
    }

    @SuppressWarnings("deprecation")
    public FormProperty getFormProperty(String formId, String name) {
        Map queryParams = new HashMap();
        queryParams.put("formOid", formId);
        queryParams.put("name", name);
        NamedQuery query = new NamedQuery(NamedQueries.FORM_PROPERTY_BY_NAME, queryParams);
        List results = DataContext.getThreadDataContext().performQuery(query);
        if (results != null && results.size() > 0) {
            return (FormProperty) results.get(0);
        }
        return null;
    }

    public Boolean getBooleanValueOfFormProperty(String formId, String name) {
        FormProperty formProperty = getFormProperty(formId , name);
        String value = formProperty.getValue();
        getLogger().debug("form property: " + name + " value is: " + value);
        return Boolean.valueOf(value);
    }

    @SuppressWarnings("deprecation")
    public List getPropertiesByForm(String formId, String clientId){
        if (StringUtils.isNotBlank(formId) && StringUtils.isNotBlank(clientId)) {
            Map queryParams = new HashMap();
            queryParams.put("formOid", formId);
            queryParams.put("clientOid", clientId);
            NamedQuery query = new NamedQuery(NamedQueries.FORM_PROPERTIES, queryParams);
            return DataContext.getThreadDataContext().performQuery(query);
        }
        return new ArrayList();
    }
}

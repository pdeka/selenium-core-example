package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormReceiptSequence;

public class FormReceiptSequenceDao extends BaseDao {

    public FormReceiptSequence getFormReceiptSequenceForPk(Object sequenceId) {
        return (FormReceiptSequence) getObjectForPK(FormReceiptSequence.class, sequenceId);
    }

    public FormReceiptSequence getFormReceiptSequence(Form form) {
        SelectQuery query = new SelectQuery(FormReceiptSequence.class);
        query.andQualifier(ExpressionFactory.matchExp(FormReceiptSequence.FORM_PROPERTY, form));

        List<FormReceiptSequence> result = performQuery(query);
        if (result.size() > 0) {
            return result.get(0);
        }
        else {
            return null;
        }
    }

    /**
     * Returns the current sequence number for the specified form. The sequence number is used during receipt generation.
     *
     * @param form
     * @return The current receipt sequence number for the form, or 1 if no receipt sequence exists
     */
    public int getCurrentReceiptSequenceNumber(Form form) {
        FormReceiptSequence sequence = getFormReceiptSequence(form);
        int value = 1;
        if (sequence != null) {
            value = sequence.getSequenceNumber();
        }
        if (value <= 0) {
            return 1;
        }
        else {
            return value;
        }
    }
}

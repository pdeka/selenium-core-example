/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.Portal;

/**
 * Provides an Permission DAO.
 *
 * @author medgar@avoka.com
 */
public class PermissionDao extends BaseDao {

    /**
     * Return the permission for the given id.
     *
     * @param id the permission primary key
     * @return the permission for the given id
     */
    public Permission getPermission(Object id) {
        return (Permission) getObjectForPK(Permission.class, id);
    }

    /**
     * Return all the permissions.
     *
     * @return all the permissions
     */
    public List<Permission> getPermissionList() {
        SelectQuery query = new SelectQuery(Permission.class);
        query.addOrdering(Permission.PERMISSION_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);
        return performQuery(query);
    }

    /**
     * Return all the permissions like the given name
     *
     * @param name the name qualifier
     * @return all the permissions
     */
    public List<Permission> getPermissionList(String name) {
        SelectQuery query = new SelectQuery(Permission.class);

        if (StringUtils.isNotBlank(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Permission.PERMISSION_NAME_PROPERTY, "%" + name + "%"));
        }

        query.addOrdering(Permission.PERMISSION_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    /**
     * Find the permission for the given name.
     *
     * @param name the name of the permission
     * @return the permission object for the given name
     */
    public Permission getPermissionByName(String name) {
        return (Permission) findObject(Permission.class, Permission.PERMISSION_NAME_PROPERTY, name);
    }

    /**
     * Return all permissions for a specific portal
     */
    public List<Permission> getPermissionsForPortal(String portalId) {
        SelectQuery query = new SelectQuery(Permission.class);

        if (StringUtils.isNotEmpty(portalId)) {
            andQueryMatchExp(query, Permission.PORTAL_PROPERTY, portalId);
        }

        query.addOrdering(Permission.PERMISSION_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);
        return performQuery(query);
    }

    /**
     * Load the default system permissions.
     */
    public void loadDefaultPermissions() {
        PortalDao portalDao = DaoFactory.getPortalDao();
        Portal adminConsolePortal = portalDao.getAdminConsolePortal();

        for (int i = 0; i < Permission.DEFAULT_PERMISSIONS.length; i++) {
            Permission permission = getPermissionByName(Permission.DEFAULT_PERMISSIONS[i]);

            if (permission == null) {
                permission = (Permission) createAndRegisterNewObject(Permission.class);
                permission.setPermissionName(Permission.DEFAULT_PERMISSIONS[i]);
                permission.setPortal(adminConsolePortal);
                getLogger().debug("Created Permission: " + permission.getPermissionName());
            }
        }
    }

    public void purgeObsoleteValues() {
        // Purge old properties
        SelectQuery query = new SelectQuery(Permission.class);
        List<Permission> permissions = performQuery(query);
        for (Permission permission : permissions) {
            String permissionName = permission.getPermissionName();
            boolean found = false;
            for (String validName : Permission.DEFAULT_PERMISSIONS) {
                if (permissionName.equals(validName) || permissionName.startsWith("diisr")) {
                    found = true;
                    break;
                }
            }

            if (!found) {
                getLogger().info("Deleting obsolete Permission: " + permission.getPermissionName());
                getDataContext().deleteObject(permission);
            }
        }
    }

}

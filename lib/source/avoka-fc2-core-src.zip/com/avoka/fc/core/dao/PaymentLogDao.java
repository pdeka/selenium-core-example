/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.PaymentLog;
import com.avoka.fc.core.entity.Submission;

/**
 * Provides the PaymentLog DAO.
 *
 * @author medgar@avoka.com
 */
public class PaymentLogDao extends BaseDao {

    public PaymentLog getPaymentLogById(Object id) {
        return (PaymentLog) getObjectForPK(PaymentLog.class, id);
    }

    public String getLatestPaymentId(String submissionId) {
        SelectQuery query = new SelectQuery(PaymentLog.class);

        if (StringUtils.isNotBlank(submissionId)) {
            query.andQualifier(ExpressionFactory.matchExp(PaymentLog.SUBMISSION_PROPERTY, submissionId));
        }
        query.addOrdering(PaymentLog.DR_TIMESTAMP_PROPERTY, Ordering.DESC);
        query.setPageSize(1);

        List payments = performQuery(query);
        if (payments != null && payments.size() > 0) {
            PaymentLog paymentLog = (PaymentLog) payments.get(0);
            return paymentLog.getId().toString();
        }

        return null;
    }

    public PaymentLog getLatestPayment(Object submissionId) {
        SelectQuery query = new SelectQuery(PaymentLog.class);

        query.andQualifier(ExpressionFactory.matchExp(PaymentLog.SUBMISSION_PROPERTY, submissionId));
        query.addOrdering(PaymentLog.DR_TIMESTAMP_PROPERTY, Ordering.DESC);

        query.setPageSize(1);
        List payments = performQuery(query);

        if (payments != null && payments.size() > 0) {
            return (PaymentLog) payments.get(0);
        }

        return null;
    }

    public List<PaymentLog> getPaymentLogList(String clientId, String submissionId, String serviceCode,
            Date startDate, Date endDate, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(PaymentLog.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(PaymentLog.SUBMISSION_PROPERTY + "." + Submission.CLIENT_PROPERTY, clientId));
        }
        if (StringUtils.isNotBlank(submissionId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(PaymentLog.SUBMISSION_PROPERTY + "." + Submission.SUBMISSION_OID_PK_COLUMN, submissionId));
        }
        if (StringUtils.isNotBlank(serviceCode)) {
            query.andQualifier(ExpressionFactory.matchExp(PaymentLog.PAYMENT_SERVICE_CODE_PROPERTY, serviceCode));
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(PaymentLog.DO_TIMESTAMP_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(PaymentLog.DO_TIMESTAMP_PROPERTY, endDate));
        }

        boolean sortedByPaymentTime = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(PaymentLog.DO_TIMESTAMP_PROPERTY)) {
                sortedByPaymentTime = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByPaymentTime) {
            query.addOrdering(PaymentLog.DO_TIMESTAMP_PROPERTY, Ordering.DESC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List<PaymentLog> getOutstandingTransactions(int timeout, String serviceDefinitionCode) {
        SelectQuery query = new SelectQuery(PaymentLog.class);

        Calendar calendar = new GregorianCalendar();
        calendar.add(Calendar.MINUTE, -1 * timeout);
        Date expiredTime = calendar.getTime();

        query.andQualifier(ExpressionFactory.matchExp(PaymentLog.DR_TIMESTAMP_PROPERTY, null));
        query.andQualifier(ExpressionFactory.lessOrEqualExp(PaymentLog.DO_TIMESTAMP_PROPERTY, expiredTime));

        if (serviceDefinitionCode != null) {
            query.andQualifier(ExpressionFactory.matchExp(PaymentLog.PAYMENT_SERVICE_CODE_PROPERTY, serviceDefinitionCode));
        }

        query.addPrefetch(PaymentLog.SUBMISSION_PROPERTY + "." + Submission.CLIENT_PROPERTY);

        query.setFetchLimit(100);

        return performQuery(query);
    }

}

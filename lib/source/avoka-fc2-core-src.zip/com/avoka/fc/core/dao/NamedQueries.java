package com.avoka.fc.core.dao;

/**
 * Provides the available Cayenne Named Queries.
 *
 * @author Malcolm Edgar
 */
public interface NamedQueries{

    static final String ADMIN_PROMOTION_LEVEL                                = "AdminPromotionLevel";

    static final String ATTACHMENTS_FOR_SUBMISSION                           = "AttachmentsForSubmission";

    static final String CLIENT_PROPERTIES                                    = "ClientProperties";

    static final String CLIENTS                                              = "Clients";

    static final String DATABASE_DIALECT                                     = "DatabaseDialect";

    static final String ELECTRONIC_ATTACHMENTS_FOR_SUBMISSION                = "ElectronicAttachmentsForSubmission";

    static final String FORM_METADATA_TAGS                                   = "FormMetadataTags";

    static final String FORM_PROPERTIES                                      = "FormProperties";

    static final String FORM_PROPERTY_BY_NAME                                = "FormPropertyByName";

    static final String FORM_SCHEMA_MAP                                      = "FormSchemaMap";

    static final String FORM_SEARCH                                          = "FormSearch";

    static final String HEALTH_MON_DELIVERY_COMPLETED_COUNT                  = "HealthMonDeliveryCompletedCount";

    static final String HEALTH_MON_RECEIPT_RENDER_COUNT                      = "HealthMonReceiptRenderCount";

    static final String HEALTH_MON_FORM_RENDER_COUNT                         = "HealthMonFormRenderCount";

    static final String HEALTH_MON_EVENT_COUNT                               = "HealthMonEventCount";

    static final String HEALTH_MON_ERROR_COUNT                               = "HealthMonErrorCount";

    static final String HEALTH_MON_SUBMISSION_COUNT                          = "HealthMonSubmissionCount";

    static final String PURGE_AUDIT_LOG                                      = "PurgeAuditLog";

    static final String PURGE_ERROR_LOG                                      = "PurgeErrorLog";

    static final String PURGE_EVENT_LOG                                      = "PurgeEventLog";

    static final String PURGE_SYSTEM_HEALTH_LOG                              = "PurgeSystemHealthLog";

    static final String PORTALS                                              = "Portals";

    static final String PURGABLE_SUBMISSIONS                                 = "PurgableSubmissions";

    static final String REMOTE_AUDITS_FOR_SUBMISSION                         = "RemoteAuditsForSubmission";

    static final String REQUEST_MONTHLY_TREND                                = "RequestMonthlyTrend";

    static final String SERVICE_DEFINITION_EXPORT_FORM                       = "ServiceDefinitionExportForm";

    static final String SERVICE_DEFINITION_RENDER_FORM                       = "ServiceDefinitionRenderForm";

    static final String SERVICE_DEFINITION_RENDER_RECEIPT                    = "ServiceDefinitionRenderReceipt";

    static final String SERVICE_DEFINITION_DELIVERY_PROCESS                  = "ServiceDefinitionDeliveryProcess";

    static final String SCHEMA_MAP                                           = "SchemaMap";

    static final String SUBMISSIONS_BY_FORM                                  = "SubmissionsByForm";

    static final String SUBMISSIONS_BY_MONTH                                 = "SubmissionsByMonth";

    static final String SUBMISSIONS_TO_ESCALATE                              = "SubmissionsToEscalate";

    static final String SUBMISSIONS_FOR_WS_DELIVERY                          = "SubmissionsForWSDelivery";

    static final String UNSET_CLIENT_PROPERTY_TYPES                          = "UnsetClientPropertyTypes";

    static final String UNSET_CLIENT_METADATA                                = "UnsetClientMetadata";

    static final String UNSET_FORM_PROPERTY_TYPES                            = "UnsetFormPropertyTypes";

    static final String UNSET_TEMPLATE_METADATA                              = "UnsetTemplateMetadata";

    static final String USER_PORTAL_PERMISSION_NAMES                         = "UserPermissionNames";

    static final String USER_PROPERTY_LIST_FOR_SCHEMA_AND_PROFILE            = "UserPropertyListForSchemaAndProfile";

    static final String USER_Profile_FormDeploy_Map                          = "UserProfileFormDeployMap";

    static final String SCHEMA_PROPERTY_MAP                                  = "SchemaPropertyMap";

    static final String USER_PROPERTY_TYPES                                  = "UserPropertyTypes";

    static final String VERSIONS_FOR_PROMOTION                               = "VersionForPromotion";
}

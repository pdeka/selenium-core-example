/*
 * Copyright (c) 2007-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.ProcessingStatus;
import com.avoka.fc.core.entity.RequiredAttachment;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.UserAccount;

/**
 * Provides a Submission entity DAO.
 *
 * @author medgar@avoka.com
 */
public class SubmissionDao extends BaseDao {

    /**
     * Return the submission for the given primary key.
     *
     * @param id the submission primary key
     * @return the submission for the given primary key
     */
    public Submission getSubmission(Object id) {
        SelectQuery query = new SelectQuery(Submission.class);

        andQueryMatchDbExp(query, Submission.SUBMISSION_OID_PK_COLUMN, id);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (Submission) list.get(0);

        } else {
            return null;
        }
    }

    public List<Submission> getSubmissionsForPortalUserId(String portalUserId) {
        SelectQuery query = new SelectQuery(Submission.class);

        andQueryMatchExp(query, Submission.EXTERNAL_USER_ID_PROPERTY,
                portalUserId);

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);

        return performQuery(query);
    }

    /**
     * Return all submission records.
     *
     * @return all submission records.
     */
    public List<Submission> getSubmissionList() {
        SelectQuery query = new SelectQuery(Submission.class);

        return performQuery(query);
    }

    public List<Submission> getSubmissionsReadyForDelivery(int maxRows) {
        SelectQuery query = new SelectQuery(Submission.class);

        query.andQualifier(ExpressionFactory.matchExp(Submission.DELIVERY_STATUS_PROPERTY, Submission.STATUS_Ready));

        query.addPrefetch(Submission.FORM_PROPERTY + "." + Form.DELIVERY_PROD_PROPERTY);
        query.addPrefetch(Submission.FORM_PROPERTY + "." + Form.DELIVERY_TEST_PROPERTY);

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);

        if (maxRows > 0) {
            query.setFetchLimit(maxRows);
        }

        return performQuery(query);
    }

    public List<Submission> getSubmissionsDeliveredViaEmailBefore(Date cutoffTime, int maxRows) {

        SelectQuery query = new SelectQuery(Submission.class);

        query.andQualifier(ExpressionFactory.matchExp(Submission.DELIVERY_STATUS_PROPERTY, Submission.STATUS_Sent_Email));
        query.andQualifier(ExpressionFactory.lessExp(Submission.DELIVERY_TIME_PROPERTY, cutoffTime));

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);

        if (maxRows > 0) {
            query.setFetchLimit(maxRows);
        }

        return performQuery(query);
    }

    public List<Submission> getSubmissionsToEscalate(Date cutoffTime,
            int maxRows) {
        Map<String, Object> params = new HashMap<String, Object>();

        if (cutoffTime != null) {
            params.put("cutoffTime", cutoffTime);
        }

        return performNamedQuery(NamedQueries.SUBMISSIONS_TO_ESCALATE, params, true);
    }

    public List<Submission> getUnpurgedSubmissions() {
        return performNamedQuery(NamedQueries.PURGABLE_SUBMISSIONS, true);
    }

    /**
     * Get a submission using the submission key
     *
     * @param submissionKey
     *            for the given key
     * @return the submission for the given key
     */
    public Submission getSubmissionByKey(String submitKey) {

        Expression expression = ExpressionFactory.matchExp(Submission.SUBMIT_KEY_PROPERTY, submitKey);
        SelectQuery query = new SelectQuery(Submission.class, expression);

        query.addPrefetch(Submission.FORM_PROPERTY);
        query.addPrefetch(Submission.CLIENT_PROPERTY);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List list = performQuery(query);

        if (list.isEmpty()) {
            return null;
        }

        return (Submission) list.get(0);
    }

    /**
     * Get a submission using the client key and submission key
     *
     * @param clientKey
     *            for the client key
     * @param submissionKey
     *            for the given key
     * @return the submission for the given key
     */
    public Submission getSubmissionByClientAndKey(String clientKey,
            String submitKey) {
        SelectQuery query = new SelectQuery(Submission.class);

        andQueryMatchExp(query, Submission.SUBMIT_KEY_PROPERTY, submitKey);
        andQueryMatchExp(query, Submission.CLIENT_PROPERTY + "." + Client.CLIENT_KEY_PROPERTY, clientKey);

        List list = performQuery(query);

        if (list.isEmpty()) {
            return null;
        }

        return (Submission) list.get(0);
    }

    /**
     * Get a submission using the submission key and client key. Its important
     * to use both keys from a security perspective
     *
     * @param clientKey
     * @param submissionKey
     *            for the given key
     * @return the submission for the given key
     */
    public Submission getSubmissionByKeyAndClient(String clientKey,
            String submitKey) {
        SelectQuery query = new SelectQuery(Submission.class);

        andQueryMatchExp(query, Submission.SUBMIT_KEY_PROPERTY, submitKey);
        andQueryMatchExp(query, Submission.CLIENT_PROPERTY + "." + Client.CLIENT_KEY_PROPERTY, clientKey);

        query.addPrefetch(Submission.VERSION_PROPERTY);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (Submission) list.get(0);

        } else {
            return null;
        }

    }

    /**
     * Return the list of submission for the given user.
     *
     * @param user
     *            the login user
     * @return the list of submission for the given user
     */
    public List<Submission> getCompletedSubmissionsForUser(UserAccount user, String keyword,
            String clientName, Portal portal, String sortBy, boolean ascending) {

        Validate.notNull(user, "Null user parameter");
        Validate.notNull(portal, "Null portal parameter");

        SelectQuery query = new SelectQuery(Submission.class);

        query.andQualifier(ExpressionFactory.matchExp(Submission.USER_PROPERTY, user));
        query.andQualifier(ExpressionFactory.matchExp(Submission.PORTAL_PROPERTY, portal));

        if (StringUtils.isNotBlank(keyword)) {
            Expression keywordExpression =
                ExpressionFactory.likeIgnoreCaseExp(
                    Submission.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY,
                    "%" + keyword + "%");

            keywordExpression =
                keywordExpression.orExp(ExpressionFactory.likeIgnoreCaseExp(
                        Submission.RECEIPT_NUMBER_PROPERTY, "%" + keyword + "%"));

            query.andQualifier(keywordExpression);
        }
        if (StringUtils.isNotBlank(clientName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(
                    Submission.FORM_PROPERTY + "." + Form.CLIENT_PROPERTY + "."
                            + Client.CLIENT_NAME_PROPERTY, "%" + clientName
                            + "%"));
        }

        query.andQualifier(ExpressionFactory.matchExp(
                Submission.FORM_STATUS_PROPERTY, Submission.STATUS_Completed));

        query.addPrefetch(Submission.FORM_PROPERTY);
        query.addPrefetch(Submission.CLIENT_PROPERTY);

        if (StringUtils.isNotBlank(sortBy)) {
            if (ascending) {
                query.addOrdering(sortBy, SortOrder.ASCENDING_INSENSITIVE);
            } else {
                query.addOrdering(sortBy, SortOrder.DESCENDING_INSENSITIVE);
            }
        }
        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);

        return performQuery(query);
    }

    /**
     * Return the list of required attachments for the given submission.
     *
     * @param submission
     *            the submission to get the attachments
     * @return the list of required attachments for the given submission
     */
    public List getRequiredAttachments(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        Expression qual = ExpressionFactory.matchExp("submission", submission);
        SelectQuery query = new SelectQuery(RequiredAttachment.class, qual);
        query.addPrefetch("attachments.fileUpload");
        query.addOrdering("requiredFlag", SortOrder.DESCENDING_INSENSITIVE);
        query.addOrdering("attachmentName", SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    /**
     * Return the list of mandatory required attachments for the given
     * submission.
     *
     * @param submission
     *            the submission to get the attachments
     * @return the list of required attachments for the given submission
     */
    public List<RequiredAttachment> getMandatoryRequiredAttachments(
            Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        SelectQuery query = new SelectQuery(RequiredAttachment.class);

        query.andQualifier(ExpressionFactory.matchExp(RequiredAttachment.SUBMISSION_PROPERTY, submission));
        query.andQualifier(ExpressionFactory.matchExp(RequiredAttachment.REQUIRED_FLAG_PROPERTY, Boolean.TRUE));

        query.addPrefetch(RequiredAttachment.ATTACHMENTS_PROPERTY + "." + Attachment.FILE_UPLOAD_PROPERTY);
        query.addOrdering(RequiredAttachment.ATTACHMENT_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    /**
     * Return the list of optional required attachments for the given
     * submission.
     *
     * @param submission
     *            the submission to get the attachments
     * @return the list of required attachments for the given submission
     */
    public List<RequiredAttachment> getOptionalRequiredAttachments(
            Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        SelectQuery query = new SelectQuery(RequiredAttachment.class);

        query.andQualifier(ExpressionFactory.matchExp("submission", submission));
        query.andQualifier(ExpressionFactory.matchExp(RequiredAttachment.REQUIRED_FLAG_PROPERTY, Boolean.FALSE));

        query.addPrefetch("attachments.fileUpload");
        query.addOrdering("attachmentName", SortOrder.ASCENDING);

        return performQuery(query);
    }

    public List<Submission> getOfflineSubmissions(Date startDate, Date endDate) {
        List<String> statusList = new ArrayList<String>(2);
        statusList.add(Submission.STATUS_Completed);
        statusList.add(Submission.STATUS_Submitted);

        SelectQuery query = new SelectQuery(Submission.class);

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, endDate));
        }

        Expression e = ExpressionFactory.matchExp(Submission.TEST_MODE_PROPERTY, null);

        e = e.orExp(ExpressionFactory.noMatchExp(Submission.TEST_MODE_PROPERTY, Boolean.TRUE));

        query.andQualifier(e);

        query.andQualifier(ExpressionFactory.inExp(Submission.FORM_STATUS_PROPERTY, statusList));

        query.andQualifier(ExpressionFactory.matchExp(Submission.SUBMITTED_OFFLINE_FLAG_PROPERTY, Boolean.TRUE));

        return performQuery(query);

    }

    /**
     * @param startDate
     * @param endDate
     * @return
     */
    public List<Submission> getActiveSubmissions(Date startDate, Date endDate, String formName, Boolean authenticated) {

        List<String> statusList = new ArrayList<String>(2);
        statusList.add(Submission.STATUS_Completed);
        statusList.add(Submission.STATUS_Submitted);

        SelectQuery query = new SelectQuery(Submission.class);

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, endDate));
        }

        if (formName != null) {
            Expression nameExpression =
                ExpressionFactory.matchExp(Submission.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY, formName);
            query.andQualifier(nameExpression);
        }

        Expression e = ExpressionFactory.matchExp(Submission.TEST_MODE_PROPERTY, null);

        e = e.orExp(ExpressionFactory.noMatchExp(Submission.TEST_MODE_PROPERTY, Boolean.TRUE));

        query.andQualifier(e);

        if (authenticated != null) {
            if (authenticated) {
                query.andQualifier(ExpressionFactory.noMatchExp(Submission.EXTERNAL_USER_ID_PROPERTY, null));
            } else {
                query.andQualifier(ExpressionFactory.matchExp(Submission.EXTERNAL_USER_ID_PROPERTY, null));
            }
        }
        query.andQualifier(ExpressionFactory.inExp(
                Submission.FORM_STATUS_PROPERTY, statusList));

        return performQuery(query);
    }

    public List<Submission> getActiveSubmissionsByDeliveryMethod(Date startDate, Date endDate, String formName, Boolean authenticated, String deliveryMethod) {

        List<String> statusList = new ArrayList<String>(2);
        statusList.add(Submission.STATUS_Completed);
        statusList.add(Submission.STATUS_Submitted);

        SelectQuery query = new SelectQuery(Submission.class);

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, endDate));
        }

        if (formName != null) {
            Expression nameExpression =
                ExpressionFactory.matchExp(Submission.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY, formName);
            query.andQualifier(nameExpression);
        }

        if(deliveryMethod!=null){
            query.andQualifier(ExpressionFactory.matchExp(Submission.DELIVERY_METHOD_PROPERTY, deliveryMethod));
        }

        Expression e = ExpressionFactory.matchExp(Submission.TEST_MODE_PROPERTY, null);

        e = e.orExp(ExpressionFactory.noMatchExp(Submission.TEST_MODE_PROPERTY, Boolean.TRUE));

        query.andQualifier(e);

        if (authenticated != null) {
            if (authenticated) {
                query.andQualifier(ExpressionFactory.noMatchExp(Submission.EXTERNAL_USER_ID_PROPERTY, null));
            } else {
                query.andQualifier(ExpressionFactory.matchExp(Submission.EXTERNAL_USER_ID_PROPERTY, null));
            }
        }
        query.andQualifier(ExpressionFactory.inExp(
                Submission.FORM_STATUS_PROPERTY, statusList));

        return performQuery(query);
    }


    /**
     * Get a list of Submissions potentially given a client, template, email
     * adddress and/or date range.
     *
     * @param clientId
     * @param formName
     * @param email
     * @param startDate
     * @param endDate
     * @return
     */
    public List getSubmissionList(
            String clientId,
            String submitKey,
            String formName,
            String receiptNumber,
            Date startDate,
            Date endDate,
            String formStatus,
            String deliveryStatus,
            String sortBy,
            boolean ascending,
            int pageSize) {

        SelectQuery query = new SelectQuery(Submission.class);
        if (StringUtils.isNotEmpty(submitKey)) {
            andQueryMatchExp(query, Submission.SUBMIT_KEY_PROPERTY, submitKey);
        }
        if (StringUtils.isNotEmpty(clientId)) {
            andQueryMatchExp(query, Submission.CLIENT_PROPERTY, clientId);
        }
        if (StringUtils.isNotBlank(formName)) {
            andQueryLikeIgnoreCaseExp(query, Submission.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY, formName);
        }
        if (StringUtils.isNotEmpty(receiptNumber)) {
            andQueryMatchExp(query, Submission.RECEIPT_NUMBER_PROPERTY, receiptNumber);
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(Submission.TIME_SUBMISSION_PROPERTY, endDate));
        }
        if (StringUtils.isNotEmpty(formStatus)) {
            andQueryMatchExp(query, Submission.FORM_STATUS_PROPERTY, formStatus);
        }
        if (StringUtils.isNotEmpty(deliveryStatus)) {
            andQueryMatchExp(query, Submission.DELIVERY_STATUS_PROPERTY, deliveryStatus);
        }

        query.addPrefetch(Submission.FORM_PROPERTY);
        query.addPrefetch(Submission.USER_PROPERTY);
        query.addPrefetch(Submission.REQUIRED_ATTACHMENTS_PROPERTY);

        boolean defaultSortColumnSorted = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(Submission.TIME_SUBMISSION_PROPERTY)) {
                defaultSortColumnSorted = true;
            }
            if (ascending) {
                query.addOrdering(sortBy, SortOrder.ASCENDING_INSENSITIVE);
            } else {
                query.addOrdering(sortBy, SortOrder.DESCENDING_INSENSITIVE);
            }
        }

        if (!defaultSortColumnSorted) {
            query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    /**
     * Get a list of Submissions potentially given a client, template, email
     * adddress and/or date range.
     */
    public List<Submission> getSubmissionsReadyForDelivery(Client client) {
        Validate.notNull(client, "Null client parameter");

        SelectQuery query = new SelectQuery(Submission.class);

        query.andQualifier(ExpressionFactory.matchExp(Submission.CLIENT_PROPERTY, client));
        query.andQualifier(ExpressionFactory.matchExp(Submission.DELIVERY_STATUS_PROPERTY, Submission.STATUS_Ready));

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);

        return performQuery(query);
    }

    public List<Submission> getSubmissionsReadyForWSDelivery(Client client) {
        Validate.notNull(client, "Null client parameter");

        Map params = Collections.singletonMap("clientOid", client.getId());

        List<Submission> clientSubmissions = performNamedQuery(
                NamedQueries.SUBMISSIONS_FOR_WS_DELIVERY, params, true);

        List<Submission> resultSubmissions = new ArrayList<Submission>();

        for (Submission submission : clientSubmissions) {
            Form form = submission.getForm();

            // Get the appropriate delivery details
            DeliveryDetails deliveryDetails = null;
            if (submission.isTestMode()) {
                deliveryDetails = form.getDeliveryTest();

            } else {
                deliveryDetails = form.getDeliveryProd();
            }

            // Ensure delivery details available
            if (deliveryDetails != null) {
                String deliveryMethod = deliveryDetails.getDeliveryMethod();

                // Ensure WS delivery method and has correct delivery status
                if (DeliveryDetails.METHOD_WEB_SERVICE.equals(deliveryMethod)
                    && (!submission.isDeliveryNotReady()
                        && !submission.isDeliveryCompleted())) {

                    resultSubmissions.add(submission);
                }
            }
        }

        return resultSubmissions;
    }

    public List<Submission> getSubmissionsReadyForWSPushDelivery(Client client) {
        Validate.notNull(client, "Null client parameter");

        SelectQuery query = new SelectQuery(Submission.class);

        query.andQualifier(ExpressionFactory.matchExp(Submission.CLIENT_PROPERTY, client));
        query.andQualifier(ExpressionFactory.matchExp(Submission.DELIVERY_STATUS_PROPERTY, Submission.STATUS_Ready));

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);

        List<Submission> clientSubmissions = performQuery(query);

        List<Submission> resultSubmissions = new ArrayList<Submission>();

        for (Submission submission : clientSubmissions) {
            Form form = submission.getForm();

            // Get the appropriate delivery details
            DeliveryDetails deliveryDetails = null;
            if (submission.isTestMode()) {
                deliveryDetails = form.getDeliveryTest();
            } else {
                deliveryDetails = form.getDeliveryProd();
            }

            String deliveryMethod = deliveryDetails.getDeliveryMethod();
            String deliveryWsMode = deliveryDetails.getDeliveryWsMode();

            if (DeliveryDetails.METHOD_WEB_SERVICE.equals(deliveryMethod)) {
                if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_1.equals(deliveryWsMode)) {
                    resultSubmissions.add(submission);

                } else if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_2.equals(deliveryWsMode)) {
                    resultSubmissions.add(submission);
                }
            }
        }

        return resultSubmissions;
    }

    public List<Submission> getSubmittedSubmissionsToAudit(Date submittedBefore) {
        SelectQuery query = new SelectQuery(Submission.class);

        Expression statusExpression =
            ExpressionFactory.matchExp(Submission.SUBMISSION_AUDIT_STATUS_PROPERTY, Submission.STATUS_Ready);

        query.andQualifier(statusExpression.orExp(ExpressionFactory.matchExp(
                Submission.SUBMISSION_AUDIT_STATUS_PROPERTY, Submission.STATUS_Error)));

        if (submittedBefore != null) {
            query.andQualifier(ExpressionFactory.lessExp(Submission.TIME_SUBMISSION_PROPERTY, submittedBefore));
        }

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.DESCENDING);

        return performQuery(query);
    }

    public List<Submission> getDeliveredSubmissionsToAudit() {
        SelectQuery query = new SelectQuery(Submission.class);

        Expression statusExpression =
            ExpressionFactory.matchExp(Submission.DELIVERY_AUDIT_STATUS_PROPERTY, Submission.STATUS_Ready);

        query.andQualifier(statusExpression.orExp(ExpressionFactory.matchExp(Submission.DELIVERY_AUDIT_STATUS_PROPERTY, Submission.STATUS_Error)));

        query.addOrdering(Submission.DELIVERY_TIME_PROPERTY, SortOrder.DESCENDING);

        return performQuery(query);
    }

    public List<Submission> getSubmissionsToReceipt(int fetchLimit) {
        SelectQuery query = new SelectQuery(Submission.class);

        Expression receiptStatusExp =
            ExpressionFactory.matchExp(Submission.RECEIPT_STATUS_PROPERTY, Submission.STATUS_Ready);
        receiptStatusExp = receiptStatusExp.orExp(ExpressionFactory.matchExp(Submission.RECEIPT_STATUS_PROPERTY, Submission.STATUS_Error));
        query.andQualifier(receiptStatusExp);

        Expression deliveryStatusExp =
            ExpressionFactory.noMatchExp(Submission.DELIVERY_STATUS_PROPERTY, Submission.STATUS_Undeliverable);
        query.andQualifier(deliveryStatusExp);

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.ASCENDING);

        query.setFetchLimit(fetchLimit);

        return performQuery(query);
    }

    public List getSubmissionsNotInvoiced(int noToGet) {
        // TODO PRC - This does not seem correct. Mal Can yuou check
        List list = new ArrayList();
        return list;
    }

    public List<Submission> getToDoSubmissionsForUser(UserAccount userAccount, String formNameLike,
            String clientName, List<String> statusList, Portal portal) {
        Validate.notNull(userAccount, "Null userAccount parameter");
        Validate.notNull(portal, "Null portal parameter");

        SelectQuery query = new SelectQuery(Submission.class);

        andQueryMatchExp(query, Submission.USER_PROPERTY, userAccount);
        andQueryMatchExp(query, Submission.PORTAL_PROPERTY, portal);
        andQueryNoMatchExp(query, Submission.FORM_STATUS_PROPERTY, Submission.STATUS_Completed);

        if (StringUtils.isNotEmpty(formNameLike)) {
            andQueryLikeIgnoreCaseExp(query, Submission.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY,
                    formNameLike);
        }

        if (StringUtils.isNotEmpty(clientName)) {
            andQueryMatchExp(query, Submission.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, clientName);
        }

        if (statusList != null && statusList.size() > 0) {
            query.andQualifier(ExpressionFactory.inExp(Submission.FORM_STATUS_PROPERTY, statusList));
        }

        query.addPrefetch(Submission.CLIENT_PROPERTY);
        query.addPrefetch(Submission.FORM_PROPERTY);

        query.addOrdering(Submission.TIME_SUBMISSION_PROPERTY, SortOrder.ASCENDING);

        List<Submission> toDoSubmissions = performQuery(query);
        List<Submission> result = new ArrayList<Submission>(toDoSubmissions.size());
        for (Submission toDoSubmission: toDoSubmissions) {
            // exclude submissions where the user has done everything, but the submission is still on Submitted
            // this can occur if virus scanning is enabled
            if (!toDoSubmission.isUserWorkCompleted()) {
                result.add(toDoSubmission);
            }
        }

        return result;
    }

    public List getSubmissionsSearch(String clientId, String value) {
        SelectQuery query = new SelectQuery(Submission.class);

        if (StringUtils.isNotEmpty(value)) {
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(Submission.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY, "%" + value + "%"));
            if (NumberUtils.isNumber(value)) {
                query.orQualifier(ExpressionFactory.matchDbExp("form_oid", value));
                query.orQualifier(ExpressionFactory.matchDbExp("user_oid", value));
                query.orQualifier(ExpressionFactory.matchDbExp(Submission.SUBMISSION_OID_PK_COLUMN, value));
            }
        }
        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(Submission.CLIENT_PROPERTY + "." + Client.CLIENT_OID_PK_COLUMN, clientId));
        }

        query.setFetchLimit(50);

        return performQuery(query);
    }

    public void addProcessingStatus(Submission submission, String status, UserAccount user) {

        ProcessingStatus processingStatus = new ProcessingStatus();
        processingStatus.setDatetimeCreated(new Date());
        processingStatus.setProcessingStatus(status);
        processingStatus.setUser(user);

        submission.addToProcessingStatuses(processingStatus);

        submission.setProcessingStatus(status);
    }

    public List getSubmissionsByForm(String clientId, Date startDate, Date endDate) {
        Validate.notNull(startDate);
        Validate.notNull(endDate);

        java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());
        java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("startDate", sqlStartDate);
        params.put("endDate", sqlEndDate);

        if (StringUtils.isNotEmpty(clientId)) {
            params.put("clientId", clientId);
        }
        return getDataContext().performQuery(NamedQueries.SUBMISSIONS_BY_FORM, params, true);
    }

    public List getSubmissionsByMonth(String clientId, String formId, Date startDate, Date endDate) {
        Validate.notNull(startDate);
        Validate.notNull(endDate);

        java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());
        java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());

        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotEmpty(clientId)) {
            params.put("clientId", clientId);
        }
        if (StringUtils.isNotEmpty(formId)) {
            params.put("formId", formId);
        }
        params.put("startDate", sqlStartDate);
        params.put("endDate", sqlEndDate);

        return getDataContext().performQuery(NamedQueries.SUBMISSIONS_BY_MONTH, params, true);
    }
}

package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.PrefetchTreeNode;
import org.apache.cayenne.query.SelectQuery;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.FormSessionLog;
import com.avoka.fc.core.entity.RequestLog;

public class FormSessionLogDao extends BaseDao {

    public FormSessionLog getFormSessionLog(Object entityId) {
        return (FormSessionLog) getObjectForPK(FormSessionLog.class, entityId);
    }

    public FormSessionLog getFormSessionLogByRequestLog(RequestLog requestLog) {
        return (FormSessionLog) findObject(FormSessionLog.class, FormSessionLog.REQUEST_LOG_PROPERTY, requestLog);
    }

    public List<FormSessionLog> getFormSessionList(Date startDate, Date endDate) {
        SelectQuery query = new SelectQuery(FormSessionLog.class);

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(FormSessionLog.SESSION_OPEN_TIMESTAMP_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(FormSessionLog.SESSION_OPEN_TIMESTAMP_PROPERTY, endDate));
        }
        query.addOrdering(FormSessionLog.SESSION_OPEN_TIMESTAMP_PROPERTY, Ordering.DESC);

        query.addPrefetch(FormSessionLog.REQUEST_LOG_PROPERTY);//.setSemantics(PrefetchTreeNode.JOINT_PREFETCH_SEMANTICS);
        query.addPrefetch(FormSessionLog.REQUEST_LOG_PROPERTY + '.' + RequestLog.FORM_PROPERTY);//.setSemantics(PrefetchTreeNode.JOINT_PREFETCH_SEMANTICS);
        query.addPrefetch(FormSessionLog.REQUEST_LOG_PROPERTY + '.' + RequestLog.SUBMISSION_PROPERTY);//.setSemantics(PrefetchTreeNode.JOINT_PREFETCH_SEMANTICS);

        return performQuery(query);
    }
}

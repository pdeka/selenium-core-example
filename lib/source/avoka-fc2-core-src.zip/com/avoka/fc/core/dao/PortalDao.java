package com.avoka.fc.core.dao;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalUser;
import com.avoka.fc.core.entity.UserAccount;

public class PortalDao extends BaseDao {

    public Portal getObjectForPK(Object object) {
        return (Portal) super.getObjectForPK(Portal.class, object);
    }

    public List<Portal> getPortalList(String name, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(Portal.class);

        if (StringUtils.isNotBlank(name)) {
            andQueryLikeIgnoreCaseExp(query, Portal.NAME_PROPERTY, name);
        }

        boolean sortedByName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(Portal.NAME_PROPERTY)) {
                sortedByName = true;
            }
            if (ascending) {
                query.addOrdering(sortBy, SortOrder.ASCENDING_INSENSITIVE);
            } else {
                query.addOrdering(sortBy, SortOrder.DESCENDING_INSENSITIVE);
            }
        }

        if (!sortedByName) {
            query.addOrdering(Portal.NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List<Portal> getPortalList() {
        SelectQuery query = new SelectQuery(Portal.class);

        query.addOrdering(Portal.NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    public Portal getPortalByName(String name) {
        Validate.notNull(name, "Null name parameter");

        SelectQuery query = new SelectQuery(Portal.class);

        andQueryMatchExp(query, Portal.NAME_PROPERTY, name);

        List<Portal> result = performQuery(query);
        if (result == null || result.size() == 0) {
            return null;
        }
        else {
            return result.get(0);
        }
    }

    public Portal getAdminConsolePortal() {
        return getPortalByName(Portal.PORTAL_ADMIN_CONSOLE);
    }

    public boolean isPortalEditable(String contextPath) {
        Validate.notNull(contextPath, "Null contextPath parameter");
        Portal portal = getPortalByContextPath(contextPath);
        return portal.getEditableFlag();
    }

    public Portal getPortalByContextPath(String contextPath) {
        Validate.notNull(contextPath, "Null contextPath parameter");

        // Strip leading http:// & https://
        int index = contextPath.indexOf(":");
        if (index != -1) {
            contextPath = contextPath.substring(index + 2);
        }

        SelectQuery query = new SelectQuery(Portal.class);

        query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Portal.CONTEXT_PATH_PROPERTY, "%" + contextPath + "%"));

        List<Portal> result = performQuery(query);
        if (result == null || result.size() == 0) {
            return null;
        }
        else {
            return result.get(0);
        }
    }

    public Portal getDefaultPortal() {
        SelectQuery query = new SelectQuery(Portal.class);

        andQueryMatchExp(query, Portal.DEFAULT_FLAG_PROPERTY, Boolean.TRUE);

        List<Portal> result = performQuery(query);
        if (result == null || result.size() == 0) {
            return null;
        }
        else {
            return result.get(0);
        }
    }

    public void setDefaultPortal(Portal newDefaultPortal) {
        Validate.notNull(newDefaultPortal, "Null newDefaultPortal parameter");

        if (!newDefaultPortal.isDefault()) {
            newDefaultPortal.setDefaultFlag(Boolean.TRUE);
        }

        SelectQuery query = new SelectQuery(Portal.class);
        query.andQualifier(ExpressionFactory.noMatchExp(Portal.NAME_PROPERTY, newDefaultPortal.getName()));
        query.andQualifier(ExpressionFactory.matchExp(Portal.DEFAULT_FLAG_PROPERTY, Boolean.TRUE));

        List<Portal> result = performQuery(query);
        for (Portal portal: result) {
            portal.setDefaultFlag(Boolean.FALSE);
        }
        getDataContext().commitChanges();
    }

    public void unsetDefaultPortal(Portal oldDefaultPortal) {
        Validate.notNull(oldDefaultPortal, "Null oldDefaultPortal parameter");

        if (oldDefaultPortal.isDefault()) {
            oldDefaultPortal.setDefaultFlag(Boolean.FALSE);
        }

        SelectQuery query = new SelectQuery(Portal.class);
        query.addOrdering(Portal.NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        Portal newDefaultPortal = oldDefaultPortal;

        List<Portal> result = performQuery(query);
        if (result != null && result.size() > 0) {
            Iterator<Portal> iter = result.iterator();
            Portal curPortal = iter.next();
            String oldPortalName = oldDefaultPortal.getName();
            while (iter.hasNext() && !curPortal.getName().equals(oldPortalName)) {
                curPortal = iter.next();
            }
            if (iter.hasNext()) {
                newDefaultPortal = iter.next();
            }
            else {
                newDefaultPortal = result.get(0);
            }
        }
        newDefaultPortal.setDefaultFlag(Boolean.TRUE);
        getDataContext().commitChanges();
    }

    public Set<Portal> getPortalsForUser(UserAccount userAccount) {
        Validate.notNull(userAccount, "Null userAccount parameter");

        SelectQuery query = new SelectQuery(PortalUser.class);

        query.andQualifier(ExpressionFactory.matchExp(PortalUser.USER_PROPERTY, userAccount));
        query.addPrefetch(PortalUser.PORTAL_PROPERTY);

        List<PortalUser> portalUsers = performQuery(query);

        Set<Portal> portals = new LinkedHashSet<Portal>();
        for (int i = 0; i < portalUsers.size(); i++) {
            PortalUser portalUser = portalUsers.get(i);
            portals.add(portalUser.getPortal());
        }

        return portals;
    }

    public void loadAdminConsolePortal() {
        Portal adminConsolePortal = getPortalByName(Portal.PORTAL_ADMIN_CONSOLE);
        if (adminConsolePortal == null) {
            adminConsolePortal = new Portal();
            adminConsolePortal.setName(Portal.PORTAL_ADMIN_CONSOLE);
            adminConsolePortal.setDescription("FormCenter Administration Console.");
            adminConsolePortal.setContextPath("http://localhost:9080/formcenter/");
            adminConsolePortal.setEditableFlag(Boolean.FALSE);

            getDataContext().registerNewObject(adminConsolePortal);

            getLogger().debug("Created Admin Console portal: " + Portal.PORTAL_ADMIN_CONSOLE);
        }
    }
}

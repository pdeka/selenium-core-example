package com.avoka.fc.core.dao;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.RequiredAttachment;

public class RequiredAttachmentDao extends BaseDao {

    public RequiredAttachment getObjectForPK(Object id) {
        return (RequiredAttachment) getObjectForPK(RequiredAttachment.class, id);
    }

}

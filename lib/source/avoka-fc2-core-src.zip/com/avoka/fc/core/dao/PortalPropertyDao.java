package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.PortalProperty;

public class PortalPropertyDao extends BaseDao {

    public PortalProperty getObjectForPK(Object object) {
        return (PortalProperty) super.getObjectForPK(PortalProperty.class, object);
    }

    public PortalProperty getPortalPropertyByName(Object portalId, String name) {
        Validate.notNull(portalId, "Null portalId parameter");
        Validate.notNull(name, "Null name parameter");

        SelectQuery query = new SelectQuery(PortalProperty.class);

        andQueryMatchExp(query, PortalProperty.PORTAL_PROPERTY, portalId);
        andQueryMatchExp(query, PortalProperty.NAME_PROPERTY, name);

        query.setCacheStrategy(QueryCacheStrategy.SHARED_CACHE);

        List<PortalProperty> pageList = performQuery(query);

        if (!pageList.isEmpty()) {
            return pageList.get(0);

        } else {
            return null;
        }
    }
}

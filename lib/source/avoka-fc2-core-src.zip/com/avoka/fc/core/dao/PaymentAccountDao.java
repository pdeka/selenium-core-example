
package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.PaymentAccount;

public class PaymentAccountDao extends BaseDao {

    public List getAccountList(String clientId, String accountNumberLike) {
        SelectQuery query = new SelectQuery(PaymentAccount.class);

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(PaymentAccount.CLIENT_PROPERTY, clientId));
        }
        if (StringUtils.isNotEmpty(accountNumberLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(PaymentAccount.ACCOUNT_NUMBER_PROPERTY, "%" + accountNumberLike + "%"));
        }
        query.addOrdering(PaymentAccount.CLIENT_PROPERTY + "." + Client.CLIENT_NAME_PROPERTY, Ordering.ASC);
        query.addOrdering(PaymentAccount.ACCOUNT_NUMBER_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

}

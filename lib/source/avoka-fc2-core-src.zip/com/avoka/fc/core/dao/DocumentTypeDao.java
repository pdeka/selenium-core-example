package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.DocumentType;

public class DocumentTypeDao extends BaseDao {

    public DocumentType getDocumentTypeForPK(Object id) {
        return (DocumentType) getObjectForPK(DocumentType.class, id);
    }

    public List getDocumentTypeList(String clientId, String name, String code, String description, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(DocumentType.class);

        if (StringUtils.isNotBlank(clientId)) {
            andQueryMatchExp(query, DocumentType.CLIENT_PROPERTY, clientId);
        }
        if (StringUtils.isNotBlank(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(DocumentType.NAME_PROPERTY, "%" + name + "%"));
        }
        if (StringUtils.isNotBlank(code)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(DocumentType.CODE_PROPERTY, "%" + code + "%"));
        }
        if (StringUtils.isNotBlank(description)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(DocumentType.DESCRIPTION_PROPERTY, "%" + description + "%"));
        }

        boolean sortedByName = false;
        boolean sortedByCode = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(DocumentType.NAME_PROPERTY)) {
                sortedByName = true;
            }
            if (sortBy.equals(DocumentType.CODE_PROPERTY)) {
                sortedByCode = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByName) {
            query.addOrdering(DocumentType.NAME_PROPERTY, true);
        }
        if (!sortedByCode) {
            query.addOrdering(DocumentType.CODE_PROPERTY, true);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List getGlobalDocumentTypes() {
        SelectQuery query = new SelectQuery(DocumentType.class);
        query.andQualifier(ExpressionFactory.matchExp(DocumentType.CLIENT_PROPERTY, null));

        query.addOrdering(DocumentType.NAME_PROPERTY, true);
        query.addOrdering(DocumentType.CODE_PROPERTY, true);

        return performQuery(query);
    }

    public List getDocumentTypeByCode(String code, String clientId) {
        SelectQuery query = new SelectQuery(DocumentType.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(DocumentType.CLIENT_PROPERTY, clientId));
        }

        query.andQualifier(ExpressionFactory.matchExp(DocumentType.CODE_PROPERTY, code));

        return performQuery(query);
    }

    public List getDocumentTypeByClient(String clientId) {
        SelectQuery query = new SelectQuery(DocumentType.class);

        query.andQualifier(ExpressionFactory.matchExp(DocumentType.CLIENT_PROPERTY, clientId));

        query.addOrdering(DocumentType.NAME_PROPERTY, true);
        query.addOrdering(DocumentType.CODE_PROPERTY, true);

        return performQuery(query);
    }

    public List getDocumentTypeByName(String name, String clientId) {
        SelectQuery query = new SelectQuery(DocumentType.class);

        if (StringUtils.isNotBlank(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(DocumentType.CLIENT_PROPERTY, clientId));
        }

        query.andQualifier(ExpressionFactory.matchExp(DocumentType.NAME_PROPERTY, name));

        return performQuery(query);
    }

    public DocumentType cloneDocumentType(DocumentType fromDocumentType, Client toClient) {
        DocumentType newDocumentType = (DocumentType) createAndRegisterNewObject(DocumentType.class);

        newDocumentType.setClient(toClient);
        newDocumentType.setCode(fromDocumentType.getCode());
        newDocumentType.setDescription(fromDocumentType.getDescription());
        newDocumentType.setMaxSize(fromDocumentType.getMaxSize());
        newDocumentType.setMimeOrFileTypes(fromDocumentType.getMimeOrFileTypes());
        newDocumentType.setName(fromDocumentType.getName());

        return newDocumentType;
    }
}

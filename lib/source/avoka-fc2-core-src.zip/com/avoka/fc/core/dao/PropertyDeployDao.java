package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.PropertyDeploy;
import com.avoka.fc.core.entity.PropertyType;

public class PropertyDeployDao extends BaseDao {

    public PropertyDeploy getPropertyDeploy(Object formDeployId, String name) {
        Validate.notNull(formDeployId, "Null formId parameter");
        Validate.notNull(name, "Null name parameter");

        Expression expression = ExpressionFactory.matchExp(PropertyDeploy.FORM_DEPLOY_XML_PROPERTY, formDeployId);
        expression = expression.andExp(ExpressionFactory.matchExp(PropertyDeploy.NAME_PROPERTY, name));

        SelectQuery query = new SelectQuery(PropertyDeploy.class, expression);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (PropertyDeploy) list.get(0);

        } else {
            return null;
        }
    }

    public String getPropertyDeployValue(Long id, String propertyName) {
        PropertyDeploy propertyDeploy = getPropertyDeploy(id, propertyName);

        if (propertyDeploy != null) {
            if (PropertyType.DATA_TYPE_String.equals(propertyDeploy.getType())) {
                return propertyDeploy.getValue();

            } else if (PropertyType.DATA_TYPE_Boolean.equals(propertyDeploy.getType())) {
                return propertyDeploy.getValue();

            } else if (PropertyType.DATA_TYPE_Number.equals(propertyDeploy.getType())) {
                return propertyDeploy.getValue();

            } else if (PropertyType.DATA_TYPE_LongText.equals(propertyDeploy.getType())) {
                return propertyDeploy.getBase64Value();

            } else if (PropertyType.DATA_TYPE_Image.equals(propertyDeploy.getType())) {
                return propertyDeploy.getBase64Value();

            } else {
                assert(false);
                return null;
            }

        } else {
            return null;
        }
    }
}

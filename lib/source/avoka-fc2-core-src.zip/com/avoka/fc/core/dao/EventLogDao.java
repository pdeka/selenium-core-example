
package com.avoka.fc.core.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.EventLog;
import com.avoka.fc.core.entity.Submission;

public class EventLogDao extends BaseDao {

    public List getEventLogList(String eventId, String type, String message, String submissionId, Date startDate, Date endDate, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(EventLog.class);

        if (StringUtils.isNotBlank(eventId)) {
            andQueryMatchDbExp(query, EventLog.EVENT_OID_PK_COLUMN, eventId);
        }
        if (StringUtils.isNotBlank(type)) {
            query.andQualifier(ExpressionFactory.matchExp(EventLog.EVENT_TYPE_PROPERTY, type));
        }
        if (StringUtils.isNotBlank(message)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(EventLog.MESSAGE_PROPERTY, "%" + message + "%"));
        }
        if (StringUtils.isNotBlank(submissionId)) {
            query.andQualifier(ExpressionFactory.matchDbExp(EventLog.SUBMISSION_PROPERTY + "." + Submission.SUBMISSION_OID_PK_COLUMN, submissionId));
        }
        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(EventLog.EVENT_TIME_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(EventLog.EVENT_TIME_PROPERTY, endDate));
        }

        boolean sortedByEventTime = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(EventLog.EVENT_TIME_PROPERTY)) {
                sortedByEventTime = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByEventTime) {
            query.addOrdering(EventLog.EVENT_TIME_PROPERTY, Ordering.DESC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public void purgeEventLog(int maxAgeDays) {
        if (maxAgeDays > 0) {
            Calendar calendar = new GregorianCalendar();
            calendar.add(Calendar.DATE, -1 * maxAgeDays);
            java.sql.Date cutoffDate = new java.sql.Date(calendar.getTime().getTime());
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("cutoffTime", cutoffDate);

            performNamedQuery(NamedQueries.PURGE_EVENT_LOG, params, true);
        }
    }
}

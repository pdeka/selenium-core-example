
package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.SupportLog;
import com.avoka.fc.core.entity.Template;

public class SupportLogDao extends BaseDao {

    public SupportLog getSupportLogForPK(Object id) {
        return (SupportLog) getObjectForPK(SupportLog.class, id);
    }

    public List<SupportLog> getSupportLogList(String clientId, String userId, String templateId, Date startDate, Date endDate, int pageSize) {
        SelectQuery query = new SelectQuery(SupportLog.class);

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(SupportLog.CLIENT_PROPERTY, clientId));
        }
        if (StringUtils.isNotEmpty(userId)) {
            query.andQualifier(ExpressionFactory.matchExp(SupportLog.USER_PROPERTY, userId));
        }
        if (StringUtils.isNotEmpty(templateId)) {
            Template template = (Template) getObjectForPK(Template.class, templateId);
            if (template != null) {
                List forms = template.getForms();
                if (forms != null && forms.size() > 0) {
                    query.andQualifier(ExpressionFactory.inExp(SupportLog.FORM_PROPERTY, forms));
                }
            }
        }

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(SupportLog.CREATED_AT_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(SupportLog.CREATED_AT_PROPERTY, endDate));
        }
        query.addOrdering(SupportLog.CREATED_AT_PROPERTY, Ordering.DESC);

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public List getSupportLogMessages(String supportLogId) {
        SupportLog supportLog = getSupportLogForPK(supportLogId);
//        if (supportLog != null){
            return supportLog.getMessages();
//        }
//        return null;
    }
}

/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.PromotionLog;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.util.RemoteUserProvider;

/**
 * Provides the PromotionLog DAO.
 *
 * @author pcopeland@avoka.com
 */
public class PromotionDao extends BaseDao{

    public PromotionLog getPromotionLogForPK(Object primaryKeyId){
        return (PromotionLog) getObjectForPK(PromotionLog.class, primaryKeyId);
    }

    public PromotionLog createPromotionLog(TemplateVersion templateVersion){

        // Ensure that all the existing ones are set to false;
        List<PromotionLog> promotionLogList = templateVersion.getPromotionLogs();
        for (PromotionLog promotionLog2 : promotionLogList) {
            promotionLog2.setCurrentFlag(false);
        }

        PromotionLog promotionLog = new PromotionLog();

        getDataContext().registerNewObject(promotionLog);

        promotionLog.setPromotionStatus(PromotionLog.PROMOTION_STATUS_DEVELOPMENT);
        promotionLog.setCurrentFlag(true);

        promotionLog.setVersion(templateVersion);

        Template template = templateVersion.getTemplate();
        promotionLog.setTemplate(template);
        Client client = template.getClient();
        if (client != null) {
            promotionLog.setClient(client);
        }

        promotionLog.setCreatedTime(new Date());

        UserAccountDao adminDao = new UserAccountDao();

        UserAccount adminUser = adminDao.getUserAccountForPK(RemoteUserProvider.getAdminId());
        promotionLog.setAdminUser(adminUser);

        return promotionLog;

    }

    public PromotionLog getCurrentPromotionLog(TemplateVersion templateVersion, Form form){
        SelectQuery query = new SelectQuery(PromotionLog.class);

        query.andQualifier(ExpressionFactory.matchDbExp(PromotionLog.VERSION_PROPERTY, templateVersion));
        query.andQualifier(ExpressionFactory.matchDbExp(PromotionLog.FORM_PROPERTY, form));

        query.addOrdering(PromotionLog.CREATED_TIME_PROPERTY, true);

        List<PromotionLog> queryList = performQuery(query);
        int size = queryList.size();

        if (size == 0) {
            return null;
        } else {
            return queryList.get(size - 1);
        }

    }

    public List<PromotionLog> getPromotionList(Client client, String promotionStatus, boolean showHistory, Form form){
        SelectQuery query = new SelectQuery(PromotionLog.class);

        if (client != null) {
            query.andQualifier(ExpressionFactory.matchExp(PromotionLog.CLIENT_PROPERTY, client));
        }

        if (form != null) {
            query.andQualifier(ExpressionFactory.matchExp(PromotionLog.FORM_PROPERTY, form));
        }

        if (StringUtils.isNotEmpty(promotionStatus)) {
            query.andQualifier(ExpressionFactory.matchExp(PromotionLog.PROMOTION_STATUS_PROPERTY, promotionStatus));
        }

        if (showHistory == false) {
            query.andQualifier(ExpressionFactory.matchExp(PromotionLog.CURRENT_FLAG_PROPERTY, "1"));
        }

        query.addOrdering(PromotionLog.CREATED_TIME_PROPERTY, Ordering.DESC);
        query.addPrefetch(PromotionLog.FORM_PROPERTY);
        query.addPrefetch(PromotionLog.CLIENT_PROPERTY);
        query.addPrefetch(PromotionLog.VERSION_PROPERTY);

        return performQuery(query);
    }

    public List getPromotionList(String clientId, String promotionStatus, boolean showHistory, String formName, int pageSize){
        SelectQuery query = new SelectQuery(PromotionLog.class);

        if (StringUtils.isNotEmpty(clientId)) {
            andQueryMatchExp(query, PromotionLog.CLIENT_PROPERTY, clientId);
        }

        if (StringUtils.isNotEmpty(formName)) {
            andQueryLikeIgnoreCaseExp(query, PromotionLog.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY, formName);
        }

        if (StringUtils.isNotEmpty(promotionStatus)) {
            andQueryMatchExp(query, PromotionLog.PROMOTION_STATUS_PROPERTY, promotionStatus);
        }

        if (showHistory == false) {
            query.andQualifier(ExpressionFactory.matchExp(PromotionLog.CURRENT_FLAG_PROPERTY, "1"));
        }

        query.addOrdering(PromotionLog.CREATED_TIME_PROPERTY, Ordering.DESC);
        query.addPrefetch(PromotionLog.FORM_PROPERTY);
        query.addPrefetch(PromotionLog.CLIENT_PROPERTY);
        query.addPrefetch(PromotionLog.VERSION_PROPERTY);

        query.setPageSize(pageSize);

        return performQuery(query);
    }

}

/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides a <tt>DeploymentProperty</tt> DAO.
 * <p/>
 * The current caching implementation will reload the deployment properties after
 * a configured number seconds. Please note the static cache is only local to the
 * web application instance and is not shared across multiple web application
 * instances on the JBoss server.
 * <p/>
 * Cayenne shared cache JGroup implementation relies upon JGroups version 2.x
 * which is not compatible with JBoss 3.2.5 version of JGroups 3.x. Alternative
 * caching strategy is to use JMS queue of JBoss.
 *
 * @author medgar@avoka.com
 */
public class DeploymentPropertyDao extends BaseDao {

    /** The property cache. */
    private static final Map<String, String> PROPERTY_VALUE_CACHE = new HashMap<String, String>();

    /** The cache synchronization lock. */
    private static final Object SYNC_LOCK = new Object();

    /** The maximum age of the cache in milliseconds. */
    private static long MAX_CACHE_AGE_MS = 560 * 1000;

    /** The time the cache was last updated in milliseconds. */
    private static long LAST_UPDATED_MS;

    /**
     * Create and register a new deployment property.
     */
    private DeploymentProperty createDeploymentProperty() {
        return (DeploymentProperty) createAndRegisterNewObject(DeploymentProperty.class);
    }

    /**
     * Refresh the deployment property cache.
     */
    public void refreshCache() {
        synchronized (SYNC_LOCK) {
            PROPERTY_VALUE_CACHE.clear();
        }
    }

    public DeploymentProperty getDeploymentPropertyForPK(Object id) {
        return (DeploymentProperty) getObjectForPK(DeploymentProperty.class, id);
    }

    public List getDeploymentPropertyList(String name, String value, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(DeploymentProperty.class);

        if (StringUtils.isNotEmpty(name)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(DeploymentProperty.NAME_PROPERTY, "%" + name + "%"));
        }

        if (StringUtils.isNotEmpty(value)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(DeploymentProperty.VALUE_PROPERTY, "%" + value + "%"));
        }

        query.andQualifier(ExpressionFactory.noMatchExp(DeploymentProperty.NAME_PROPERTY, DeploymentProperty.PROPERTY_Operation_Status));
        query.andQualifier(ExpressionFactory.noMatchExp(DeploymentProperty.NAME_PROPERTY, DeploymentProperty.PROPERTY_Operation_Status_Message));
        query.andQualifier(ExpressionFactory.noMatchExp(DeploymentProperty.NAME_PROPERTY, DeploymentProperty.PROPERTY_Production_Mode));
        query.andQualifier(ExpressionFactory.noMatchExp(DeploymentProperty.NAME_PROPERTY, DeploymentProperty.PROPERTY_Payment_Module_Enabled));

        if (!isPaymentModuleEnabled()) {
            query.andQualifier(ExpressionFactory.notLikeExp(DeploymentProperty.NAME_PROPERTY, "%Payment%"));
        }

        boolean sortedByName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(DeploymentProperty.NAME_PROPERTY)) {
                sortedByName = true;
            }
            if (ascending) {
                query.addOrdering(sortBy, SortOrder.ASCENDING_INSENSITIVE);
            } else {
                query.addOrdering(sortBy, SortOrder.DESCENDING_INSENSITIVE);
            }
        }

        if (!sortedByName) {
            query.addOrdering(DeploymentProperty.NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    /**
     * Return true if a property exists for the given name or false otherwise.
     *
     * @param name the name of the property
     * @return true if a property exists for the given name or false otherwise
     */
    public boolean hasProperty(String name) {
        return getDeploymentPropertyValue(name) != null;
    }

    /**
     * Return the DeploymentProperty object for the given name.
     *
     * @param name the name of the deployment property
     * @return DeploymentProperty for the given name
     */
    public DeploymentProperty getProperty(String name) {
        return (DeploymentProperty) findObject(DeploymentProperty.class, DeploymentProperty.NAME_PROPERTY, name);
    }

    /**
     * Return the deployment property for the given name.
     *
     * @param name the name of the property
     * @return true if a property exists for the given name or false otherwise
     * @throws ApplicationException if the specified property does not exist, or more than one value exists
     */
    public String getPropertyValue(String name) throws ApplicationException {
        Validate.notNull(name, "Null name argument");

        String value = getDeploymentPropertyValue(name);

        if (value != null) {
            return value;

        } else {
            String context = "Property name: '" + name + "'";
            throw new ApplicationException("MissingPropertyValue",
                context,
                "Missing deployment property: '" + name + "'",
                "A configuration value is missing in the deployment_property table: '" + name + "'");
        }
    }

    public DateFormat getPropertyDateFormat(String name) {
        String value = getDeploymentPropertyValue(name);

        return new SimpleDateFormat(value);
    }

    public int getPropertyValueInt(String key) throws ApplicationException {
        return Integer.parseInt(getPropertyValue(key));
    }

    public long getPropertyValueLong(String key) throws ApplicationException {
        return Long.parseLong(getPropertyValue(key));
    }

    public boolean getPropertyValueBoolean(String key) throws ApplicationException {
        return Boolean.parseBoolean(getPropertyValue(key));
    }

    /**
     * Return the specified sub directory under the configure root FormCenter
     * directory. This method will create the sub directory if it does not exist.
     *
     * @param subdirectory the sub directory name under the configure root FormCenter directory.
     * @return the full formcenter subdirectory path
     */
    public String getConfigSubDirectory(String subdirectory) {
        Validate.notEmpty(subdirectory, "Blank subdirectory parameter");

        String directory = getPropertyValue(DeploymentProperty.PROPERTY_Config_Directory);
        if (!directory.endsWith(File.separator)) {
            directory += File.separator;
        }
        directory += subdirectory + File.separator;

        File file = new File(directory);
        if (!file.exists()) {
            file.mkdirs();
        }

        return directory;
    }

    public boolean isDebugMode() {
        String value = getPropertyValue(DeploymentProperty.PROPERTY_Debug_Mode);

        return "true".equalsIgnoreCase(value) || "1".equalsIgnoreCase(value);
    }

    public boolean isProductionMode() {
        String value = getPropertyValue(DeploymentProperty.PROPERTY_Production_Mode);

        return DeploymentProperty.PRODUCTION_Mode_Production.equals(value);
    }

    public boolean isPaymentModuleEnabled() {
        String value = getPropertyValue(DeploymentProperty.PROPERTY_Payment_Module_Enabled);

        return "true".equalsIgnoreCase(value);
    }

    /**
     * Load the default system deployment properties.
     */
    public void loadDefaultProperties() {

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Admin_Console_Banner_Color,
                DeploymentProperty.TYPE_STRING,
                "#355797",
                "Admin Console banner ribbon background color");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Date_Format_Long,
                DeploymentProperty.TYPE_STRING,
                "dd MMM yyyy",
                "Long date format.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Date_Time_Format_Long,
                DeploymentProperty.TYPE_STRING,
                "dd MMM yyyy h:mm:ss a",
                "Long date time format.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Attachment_MaxEmbeddedSize,
                DeploymentProperty.TYPE_NUMBER,
                "1048576",
                "The maximum size of embedded(PDF) attachments");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Config_Directory,
                DeploymentProperty.TYPE_STRING,
                "c:\\formcenter\\local",
                "FormCenter configuration root directory.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_HTTPS_Port,
                DeploymentProperty.TYPE_NUMBER,
                "443",
                "Port on which HTTPS operates");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Debug_Mode,
                DeploymentProperty.TYPE_BOOLEAN,
                "false",
                "Is the system in Debug mode?");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Operation_Status,
                DeploymentProperty.TYPE_STRING,
                DeploymentProperty.OPERATION_Status_Normal,
                "Controls the operational status of FormCenter");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Operation_Status_Message,
                DeploymentProperty.TYPE_STRING,
                "This application is currently offline, please try again later.",
                "Message to display when operational status of FormCenter is Offline");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Cache_Timeout,
                DeploymentProperty.TYPE_NUMBER,
                "60",
                "Deployment property cache timeout in seconds");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_SMTP_Host,
                DeploymentProperty.TYPE_STRING,
                "",
                "SMTP email server Hostname (mail.smtp.host)");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_SMTP_Port,
                DeploymentProperty.TYPE_NUMBER,
                "25",
                "SMTP email server Port (mail.smtp.port)");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_SMTP_User,
                DeploymentProperty.TYPE_STRING,
                "",
                "SMTP email server authentication User (mail.smtp.user)");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_SMTP_Password,
                DeploymentProperty.TYPE_STRING,
                "",
                "SMTP email server authentication Password (mail.smtp.password)");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Environment_Name,
                DeploymentProperty.TYPE_STRING,
                "TODO: please enter the environment name [ TEST| PRODUCTION ]",
                "The name of this FormCenter Environment");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Support_Sender,
                DeploymentProperty.TYPE_EMAIL,
                "",
                "Support email address");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Receipt_Subject,
                DeploymentProperty.TYPE_STRING,
                "${environmentName} - Form Receipt",
                "Form receipt email subject");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Receipt_Message,
                DeploymentProperty.TYPE_LONG_TEXT,
                "<html><head><style type='text/css'>body {font-family:Arial;}</style></head><body><h3>${environmentName}</h3> Please see the attached file for your $submission.form.client.clientName - $submission.form.formName receipt.</body></html>",
                "Form receipt email message");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Promotion_Subject,
                DeploymentProperty.TYPE_STRING,
                "Form Promotion Notification - Form: ${formName} on ${environmentName}",
                "Form promotion notification subject");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Promotion_Message,
                DeploymentProperty.TYPE_LONG_TEXT,
                "<html><head><style type='text/css'>body {font-family:Arial;}</style></head><body>" +
                "Form '${formName}' (${clientName}) <br/> has been promoted to '${promotionLevelName}' on ${environmentName}." +
                "#if ($notes) <p>$notes</p>#end" +
                "</body></html>",
                "Form promotion notification body");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Promotion_Sender,
                DeploymentProperty.TYPE_EMAIL,
                "",
                "The email address for the promotion notification messages");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Lost_Password_Subject,
                DeploymentProperty.TYPE_STRING,
                "FormCenter Lost Password - ${environmentName}",
                "Lost password email subject");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Lost_Password_Message,
                DeploymentProperty.TYPE_LONG_TEXT,
                "<html><head><style type='text/css'>body {font-family:Arial;}</style></head><body><p style='font-weight:bold'>Login Password</p>${user.fullName} your account password is: &nbsp; ${user.password}</body></html>",
                "Lost password email message");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Submission_Update_Subject,
                DeploymentProperty.TYPE_STRING,
                "FormCenter Submission Status Update",
                "Submission status update email subject");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Submission_Update_Message,
                DeploymentProperty.TYPE_LONG_TEXT,
                "<html><head><style type='text/css'>body {font-family:Arial;}</style></head><body><p style='font-weight:bold'>Form Submission Status Update</p>${user.fullName} your form submission ${submission.receiptNumber} status has been updated to: &nbsp; ${submission.processingStatus}</body></html>",
                "Submission status update email message");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Report_Subject,
                DeploymentProperty.TYPE_STRING,
                "${environmentName} - Report: #if (${schedule.reportClient}) ${schedule.reportClient.report.name} #else ${schedule.systemReport.name} #end",
                "Report delivery email subject");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Report_Message,
                DeploymentProperty.TYPE_STRING,
                "Attached is the report: #if (${schedule.reportClient}) ${schedule.reportClient.report.name} #else ${schedule.systemReport.name} #end",
                "Report delivery email message");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Report_URL,
                DeploymentProperty.TYPE_STRING,
                "${context}webreport/",
                "Location where reports are run by an admin user (ie http://localhost:9080/webreport/)");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Report_Internal_URL,
                DeploymentProperty.TYPE_STRING,
                "http://localhost:9080/webreport/",
                "Location where reports are run internally by the application (ie http://localhost:9080/webreport/)");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Report_Sender,
                DeploymentProperty.TYPE_EMAIL,
                "",
                "The email address for the report service sender");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Report_Reschedule_Delay,
                DeploymentProperty.TYPE_NUMBER,
                "60",
                "Amount of time in minutes to wait before rescheduling a running report.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Export_Directory,
                DeploymentProperty.TYPE_STRING,
                "C:\\formcenter\\local\\export\\",
                "Location where exports are stored.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_FormCenter_Log_File,
                DeploymentProperty.TYPE_STRING,
                "C:/Adobe/LiveCycle8.2/jboss/server/formcenter/log/server.log",
                "Location of the FormCenter log file");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Import_Directory,
                DeploymentProperty.TYPE_STRING,
                "C:\\formcenter\\local\\import\\",
                "Location where imports are stored.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Context,
                DeploymentProperty.TYPE_STRING,
                "http://localhost:9080",
                "The application server URL context root.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_LiveCycle_Log_File,
                DeploymentProperty.TYPE_STRING,
                "C:/Adobe/LiveCycle8.2/jboss/server/all/log/server.log",
                "Location of the LiveCycle log file");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Production_Mode,
                DeploymentProperty.TYPE_STRING,
                DeploymentProperty.PRODUCTION_Mode_Non_Production,
                "Is in system in Production mode?");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Payment_Module_Enabled,
                DeploymentProperty.TYPE_BOOLEAN,
                "false",
                "");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Publish_Templates_Directory,
                DeploymentProperty.TYPE_STRING,
                "C:\\formcenter\\publish\\",
                "Shared LiveCycleC ES directory for publishing templates to");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Publish_Templates_Share,
                DeploymentProperty.TYPE_STRING,
                "C:\\formcenter\\publish\\",
                "Shared LiveCycleC ES share path for rendering templates from");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Portal_Form_Not_Found_URL,
                DeploymentProperty.TYPE_STRING,
                "${context}${defaultPortalContext}/form/form-not-found.htm",
                "Portal Form Not Found page URL");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Portal_Submission_Offline_URL,
                DeploymentProperty.TYPE_STRING,
                "${context}${defaultPortalContext}/off-line.htm",
                "Portal Offline for submissions page URL");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Render_Service_Base_Path,
                DeploymentProperty.TYPE_STRING,
                "",
                "Remote Render Service Base Path");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Enable_Script_Submissions,
                DeploymentProperty.TYPE_BOOLEAN,
                "false",
                "Enable test submssion scripts by switching off submission RequestLog checks");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Forms_WS_IP_Address_Filtering,
                DeploymentProperty.TYPE_BOOLEAN,
                "false",
                "Enable Forms Web Service client request IP address filtering");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_IP_Address_Logging,
                DeploymentProperty.TYPE_BOOLEAN,
                "true",
                "Option to record remote user IP address in Request and Submission Logs");

        DeliveryDetailsDao deliveryDetailsDao = DaoFactory.getDeliveryDetailsDao();

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Supported_Delivery_Methods,
                DeploymentProperty.TYPE_STRING,
                deliveryDetailsDao.getAllDeliveryMethodsString(),
                "Supported delivery methods");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Online_Save_Enabled,
                DeploymentProperty.TYPE_BOOLEAN,
                "true",
                "Option to globally disable Online Saving of forms. If set to true, the individual form's setting will be used.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Duplicate_Submission_Rejection_Delay,
                DeploymentProperty.TYPE_NUMBER,
                "30000",
                "Time in milliseconds after which a duplicate submission is rejected.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Enable_PDF_Submit_Attachment_Delivery,
                DeploymentProperty.TYPE_BOOLEAN,
                "true",
                "Deliver PDF submitted forms as a file attachment");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Display_Submission_FormCenter_User_ID,
                DeploymentProperty.TYPE_BOOLEAN,
                "true",
                "Display the FormCenter User ID in the Submission View.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Display_Submission_External_User_ID,
                DeploymentProperty.TYPE_BOOLEAN,
                "true",
                "Display the External User ID in the Submission View.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Portal_Cache_Enabled,
                DeploymentProperty.TYPE_BOOLEAN,
                "true",
                "Option to globally enable/disable Portal caching. Set this value to true in production environments, and false in development environments.");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Task_Notification_Subject,
                DeploymentProperty.TYPE_STRING,
                "New Task",
                "Task notification subject");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Task_Notification_Message,
                DeploymentProperty.TYPE_LONG_TEXT,
                "<html><head><style type='text/css'>body {font-family:Arial;}</style></head><body>" +
                "A new task has been assigned to you on ${environmentName}. <br/><br/>${task.taskMessage} <br/><br/>Please complete the task" +
                "#if ($portal)" +
                " <a href=\"${portal.contextPath}\">here</a>" +
                "#end" +
                ".</body></html>",
                "Task notification body");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Task_Sender,
                DeploymentProperty.TYPE_EMAIL,
                "",
                "The email address shown as the sender for task notification messages");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Welcome_User_Subject,
                DeploymentProperty.TYPE_STRING,
                "${environmentName} - Welcome to FormCenter",
                "User welcome email subject");

        registerDeploymentProperty(
                DeploymentProperty.PROPERTY_Email_Welcome_User_Message,
                DeploymentProperty.TYPE_LONG_TEXT,
                "<html><head><style type='text/css'>body {font-family:Arial;}</style></head>" +
                "<body>Welcome ${user.fullName} a new FormCenter account has been set up for you. " +
                "<br/><br/>User name: ${user.loginName} " +
                "<br/><br/>Password: ${user.password} <br/><br/>" +
                "Please log in and change your password <a href=\"${portal.contextPath}\">here</a></body></html>",
                "User welcome email body");
    }

    public void purgeObsoleteValues() {
        // Purge old properties
//        SelectQuery query = new SelectQuery(DeploymentProperty.class);
//        List<DeploymentProperty> properties = performQuery(query);
//        for (DeploymentProperty property : properties) {
//            boolean found = false;
//            for (String name : DeploymentProperty.NAMES) {
//
//                if (name.equals(property.getName())) {
//                    found = true;
//                    break;
//                }
//            }
//
//            if (!found) {
//                getLogger().info("Deleting obsolete DeploymentProperty: " + property.getName());
//                getDataContext().deleteObject(property);
//            }
//        }
    }

    public void registerDeploymentProperty(String name, String type, String value, String description) {
        Validate.notEmpty(name, "Blank name parameter");
        Validate.notEmpty(type, "Blank type parameter");

        if (!hasProperty(name)) {

            DeploymentProperty property = createDeploymentProperty();

            property.setName(name);
            property.setType(type);
            property.setValue(value);
            property.setDescription(description);

            getLogger().debug("added DeploymentProperty: " + name);
        }
    }

    // -------------------------------------------------------- Private Methods

    private String getDeploymentPropertyValue(String name) {
        Validate.notNull(name, "Null name parameter");

        synchronized (SYNC_LOCK) {
            if (PROPERTY_VALUE_CACHE.isEmpty() || hasCacheExpired()) {

                PROPERTY_VALUE_CACHE.clear();

                // Update cache
                SelectQuery query = new SelectQuery(DeploymentProperty.class);
                List<DeploymentProperty> list = performQuery(query);
                for (DeploymentProperty deploymentProperty : list) {
                    PROPERTY_VALUE_CACHE.put(deploymentProperty.getName(), deploymentProperty.getValue());
                }

                LAST_UPDATED_MS = System.currentTimeMillis();

                if (getLogger().isDebugEnabled()) {
                    getLogger().debug("loaded DeploymentProperty cache with " + list.size() + " items");
                }

                // Update cache timeout value
                String value = (String) PROPERTY_VALUE_CACHE.get(DeploymentProperty.PROPERTY_Cache_Timeout);
                if (StringUtils.isNotBlank(value)) {
                    try {
                        long cacheTimeout = Long.parseLong(value);

                        if (cacheTimeout != MAX_CACHE_AGE_MS) {
                            if (getLogger().isDebugEnabled()) {
                                String msg = "update cache timeout changed from "
                                    + (MAX_CACHE_AGE_MS / 1000) + " sec to "
                                    + cacheTimeout + " sec.";
                                getLogger().debug(msg);
                            }

                            MAX_CACHE_AGE_MS = cacheTimeout * 1000;
                        }

                    } catch (NumberFormatException nfe) {
                        String msg = "Could not parse DeploymentProperty '"
                            + DeploymentProperty.PROPERTY_Cache_Timeout
                            + "' with value " + value;
                        getLogger().warn(msg, nfe);
                    }
                }
            }

            String value = (String) PROPERTY_VALUE_CACHE.get(name);

            if (value != null && value.indexOf("${context}") != -1) {
                String context = (String)  PROPERTY_VALUE_CACHE.get(DeploymentProperty.PROPERTY_Context);
                if (!context.endsWith("/")) {
                    context += "/";
                }
                value = StringUtils.replace(value, "${context}", context);
            }

            return value;
        }
    }

    private boolean hasCacheExpired() {
        return System.currentTimeMillis() - LAST_UPDATED_MS > MAX_CACHE_AGE_MS;
    }

}

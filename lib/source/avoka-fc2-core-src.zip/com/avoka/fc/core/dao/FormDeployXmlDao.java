/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;

/**
 * Provides the Form DAO.
 *
 * @author pcopeland@avoka.com
 */
public class FormDeployXmlDao extends BaseDao{

    public FormDeployXml getFormDeployXmlFromPK(Object primaryKeyId){
        return (FormDeployXml) getObjectForPK(FormDeployXml.class, primaryKeyId);
    }

    public FormDeployXml getFormDeployXML(Form form, TemplateVersion templateVersion) {
        return getFormDeployXML(form, templateVersion, false);
    }

    public FormDeployXml getFormDeployXML(Form form, TemplateVersion templateVersion, boolean refresh){

        SelectQuery query = new SelectQuery(FormDeployXml.class);
        query.andQualifier(ExpressionFactory.matchExp(FormDeployXml.FORM_PROPERTY, form));
        query.andQualifier(ExpressionFactory.matchExp(FormDeployXml.TEMPLATE_VERSION_PROPERTY, templateVersion));

        if (refresh) {
            query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE_REFRESH);
        } else {
            query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);
        }

        List formList = performQuery(query);

        if (formList.isEmpty()) {
            return null;
        }

        return (FormDeployXml) formList.get(0);
    }

    /**
     * Return all the FormDeployXml records for the given client.
     *
     * @param client the client
     * @return all the FormDeployXml records for the given client
     */
    public List<FormDeployXml> getFormDeployXMLForClient(Client client) {
        Validate.notNull(client, "Null client parameter");

        List<FormDeployXml> formDeployXmlList = new ArrayList<FormDeployXml>();

        List<Form> forms = client.getForms();

        for (Form form : forms) {
             List<FormDeployXml> list2 = form.getFormDeployXml();
             formDeployXmlList.addAll(list2);
        }

        return formDeployXmlList;
    }

    /**
     * Return all the FormDeployXml records for the given template.
     *
     * @param template the template
     * @return all the FormDeployXml records for the given template
     */
    public List<FormDeployXml> getFormDeployXMLForTemplate(Template template) {
        Validate.notNull(template, "Null template parameter");

        List<FormDeployXml> formDeployXmlList = new ArrayList<FormDeployXml>();

        List<Form> forms = template.getForms();

        for (Form form : forms) {
             List<FormDeployXml> list2 = form.getFormDeployXml();
             formDeployXmlList.addAll(list2);
        }

        return formDeployXmlList;
    }

    public void deleteUserDeployMap(FormDeployXml formDeployXML){
        // First delete existing map.
        deleteObjects(formDeployXML.getUserDeployMaps());
    }

    public void deleteSchemaDeployMap(FormDeployXml formDeployXML){
        // First delete existing map.
        deleteObjects(formDeployXML.getSchemaDeployMaps());
    }

    public List getFormDeployXmlList(String clientId,
            String formName,
            Date startDate,
            Date endDate,
            String sortedColumn,
            boolean sortedAscending,
            int pageSize) {

        SelectQuery query = new SelectQuery(FormDeployXml.class);
        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(FormDeployXml.FORM_PROPERTY + "." + Form.CLIENT_PROPERTY, clientId));
        }
        if (StringUtils.isNotEmpty(formName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(FormDeployXml.FORM_PROPERTY + "." + Form.FORM_NAME_PROPERTY, "%" + formName + "%"));
        }

        if (startDate != null) {
            query.andQualifier(ExpressionFactory.greaterOrEqualExp(FormDeployXml.DEPLOY_TIMESTAMP_PROPERTY, startDate));
        }
        if (endDate != null) {
            query.andQualifier(ExpressionFactory.lessOrEqualExp(FormDeployXml.DEPLOY_TIMESTAMP_PROPERTY, endDate));
        }

        query.addPrefetch(FormDeployXml.FORM_PROPERTY);
        query.addPrefetch(FormDeployXml.TEMPLATE_VERSION_PROPERTY);


        boolean defaultSortColumnSorted = false;
        if (StringUtils.isNotBlank(sortedColumn)) {
            if (sortedColumn.equals(FormDeployXml.DEPLOY_TIMESTAMP_PROPERTY)) {
                defaultSortColumnSorted = true;
            }
            query.addOrdering(sortedColumn, sortedAscending);
        }

        if (!defaultSortColumnSorted) {
            query.addOrdering(FormDeployXml.DEPLOY_TIMESTAMP_PROPERTY, Ordering.DESC);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }
}

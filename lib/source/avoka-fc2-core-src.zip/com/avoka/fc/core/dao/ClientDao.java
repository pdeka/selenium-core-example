package com.avoka.fc.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.PropertyType;

public class ClientDao extends BaseDao {

    public Client getClientForPK(Object id) {
        SelectQuery query = new SelectQuery(Client.class);

        andQueryMatchDbExp(query, Client.CLIENT_OID_PK_COLUMN, id);

        query.setCacheStrategy(QueryCacheStrategy.SHARED_CACHE);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (Client) list.get(0);

        } else {
            return null;
        }
    }

    public Client getClientByName(String clientName) {
        SelectQuery query = new SelectQuery(Client.class, ExpressionFactory.matchExp(Client.CLIENT_NAME_PROPERTY, clientName));
        List clients = performQuery(query);
        if (clients != null && clients.size() > 0) {
            return (Client) clients.get(0);
        }
        return null;
    }

    public Client getClientByCode(String clientCode) {
        SelectQuery query = new SelectQuery(Client.class, ExpressionFactory.matchExp(Client.CLIENT_CODE_PROPERTY, clientCode));
        List clients = performQuery(query);
        if (clients != null && clients.size() > 0) {
            return (Client) clients.get(0);
        }
        return null;
    }

    public Client getClientByCodeIgnoreCase(String clientCode) {
        SelectQuery query = new SelectQuery(Client.class);

        query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Client.CLIENT_CODE_PROPERTY, clientCode));

        List<Client> clients = performQuery(query);
        if (!clients.isEmpty()) {
            return clients.get(0);
        }

        return null;
    }

    public Client getClientByKey(String clientKey) {
        SelectQuery query = new SelectQuery(Client.class, ExpressionFactory.matchExp(Client.CLIENT_KEY_PROPERTY, clientKey));
        List clients = performQuery(query);
        if (clients != null && clients.size() > 0) {
            return (Client) clients.get(0);
        }
        return null;
    }

    public String getClientPropertyValue(Client client, String name) {
        Validate.notNull(client, "Null client parameter");
        Validate.notNull(name, "Null name parameter");

        Expression qual = ExpressionFactory.matchDbExp(ClientProperty.CLIENT_PROPERTY + "." + Client.CLIENT_OID_PK_COLUMN, client.getId());
        qual = qual.andExp(ExpressionFactory.matchExp(ClientProperty.PROPERTY_TYPE_PROPERTY + "." + PropertyType.NAME_PROPERTY, name));

        SelectQuery query = new SelectQuery(ClientProperty.class, qual);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return ((ClientProperty) list.get(0)).getValue();

        } else {
            return null;
        }
    }

    public List<Client> getActiveClientListByDate(Date eventDate) {
        SelectQuery query = new SelectQuery(Client.class);

        Expression activateTimestampExp = ExpressionFactory.greaterOrEqualExp(Client.ACTIVATE_TIMESTAMP_PROPERTY, eventDate);
        activateTimestampExp = activateTimestampExp.orExp(ExpressionFactory.matchExp(Client.ACTIVATE_TIMESTAMP_PROPERTY, null));
        query.andQualifier(activateTimestampExp);

        Expression deactiveTimeStampExp = ExpressionFactory.lessExp(Client.DEACTIVATE_TIMESTAMP_PROPERTY, eventDate);
        deactiveTimeStampExp = deactiveTimeStampExp.orExp(ExpressionFactory.matchExp(Client.DEACTIVATE_TIMESTAMP_PROPERTY, null));
        query.andQualifier(deactiveTimeStampExp);

        query.addOrdering(Client.CLIENT_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<Client> getClientList(String nameLike, String clientCode, String clientKey, boolean activeOnly, String sortBy, boolean ascending) {
        SelectQuery query = new SelectQuery(Client.class);

        if (StringUtils.isNotEmpty(nameLike)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(Client.CLIENT_NAME_PROPERTY, "%" + nameLike + "%"));
        }
        if (StringUtils.isNotEmpty(clientCode)) {
            andQueryMatchExp(query, Client.CLIENT_CODE_PROPERTY, clientCode);
        }
        if (StringUtils.isNotEmpty(clientKey)) {
            andQueryMatchExp(query, Client.CLIENT_KEY_PROPERTY, clientKey);
        }
        if (activeOnly) {
            query.andQualifier(ExpressionFactory.matchExp(Client.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));
        }

        boolean sortedByName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(Client.CLIENT_NAME_PROPERTY)) {
                sortedByName = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByName) {
            query.addOrdering(Client.CLIENT_NAME_PROPERTY, Ordering.ASC);
        }

        return performQuery(query);
    }


    public List<Client> getClientsWithoutKeys() {
        SelectQuery query = new SelectQuery(Client.class);

        andQueryMatchExp(query, Client.CLIENT_KEY_PROPERTY, null);

        return performQuery(query);
    }

    public List<Client> getActiveClientList() {
        SelectQuery query = new SelectQuery(Client.class);

        query.andQualifier(ExpressionFactory.matchExp(Client.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));

        query.addOrdering(Client.CLIENT_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

    public List<Client> getAllClients() {
        SelectQuery query = new SelectQuery(Client.class);

        query.addOrdering(Client.CLIENT_NAME_PROPERTY, Ordering.ASC);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        return performQuery(query);
    }

    public List<Client> getClientsSearch(String value) {
        SelectQuery query = new SelectQuery(Client.class);

        if (StringUtils.isNotEmpty(value)) {
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(Client.CLIENT_NAME_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(Client.CLIENT_CODE_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(Client.CLIENT_DESCRIPTION_PROPERTY, "%" + value + "%"));
            if (NumberUtils.isNumber(value)) {
                query.orQualifier(ExpressionFactory.matchDbExp(Client.CLIENT_OID_PK_COLUMN, value));
            }
        }

        query.addOrdering(Client.CLIENT_NAME_PROPERTY, Ordering.ASC);

        return performQuery(query);
    }

}

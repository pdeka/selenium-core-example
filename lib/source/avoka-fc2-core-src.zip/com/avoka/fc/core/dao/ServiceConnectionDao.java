package com.avoka.fc.core.dao;

import java.util.List;

import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.util.ApplicationException;

public class ServiceConnectionDao extends BaseDao {

    public static final String LIVECYCLE_CONNECTION_NAME = "LiveCycle ES";

    public static final String VIRUS_SCAN_CONNECTION_NAME = "Virus Scan";

    /**
     * Return the service connection object for the given id, or null if not found.
     *
     * @param id the service connection id
     * @return the service connection object for the given id, or null if not found
     */
    public ServiceConnection getServiceConnectionForPK(Object id) {
        return (ServiceConnection) getObjectForPK(ServiceConnection.class, id);
    }

    /**
     * Return the ServiceConnection for the given service name.
     *
     * @param name the service name to lookup
     * @return the ServiceConnection for the given name
     */
    public ServiceConnection getServiceConnectionForName(String name) {
        Validate.notNull(name, "Null serviceName parameter");

        SelectQuery query = new SelectQuery(ServiceConnection.class);

        andQueryMatchExp(query, ServiceConnection.NAME_PROPERTY, name);

        java.util.List list = performQuery(query);

        if (list.isEmpty()) {
            return null;

        } else if (list.size() == 1) {
            return (ServiceConnection) list.get(0);

        } else {
            String context = "ServiceConnection not found for name: " + name;
            String solution = "Configure ServiceConnection for name: " + name;
            throw new ApplicationException("ServiceLocator", context, context, solution);
        }
    }

    /**
     * Return true if there is a ServiceConnection for the given service name.
     *
     * @param name the name of the service
     * @return true if there is a ServiceConnection for the given service name.
     */
    public boolean hasServiceConnectionForName(String name) {
        Validate.notNull(name, "Null serviceName parameter");

        SelectQuery query = new SelectQuery(ServiceConnection.class);

        andQueryMatchExp(query, ServiceConnection.NAME_PROPERTY, name);

        java.util.List list = performQuery(query);

        return !list.isEmpty();
    }

    /**
     * Return the service connection list for the given name and end point value.
     *
     * @param name the connection name
     * @param endPointValue the connection end point value
     * @return the list of service definitions for the given name and type
     */
    public List<ServiceConnection> getServiceConnectionList(String name, String endPointValue, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(ServiceConnection.class);

        if (StringUtils.isNotEmpty(name)) {
            andQueryLikeIgnoreCaseExp(query, ServiceConnection.NAME_PROPERTY, name);
        }

        if (StringUtils.isNotEmpty(endPointValue)) {
            andQueryLikeIgnoreCaseExp(query, ServiceConnection.ENDPOINT_VALUE_PROPERTY, endPointValue);
        }

        boolean sortedByName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(ServiceConnection.NAME_PROPERTY)) {
                sortedByName = true;
            }
            query.addOrdering(sortBy, ascending);
        }

        if (!sortedByName) {
            query.addOrdering(ServiceConnection.NAME_PROPERTY, true);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    public void loadDefaultConnections() {
        if (!hasServiceConnectionForName(LIVECYCLE_CONNECTION_NAME)) {
            ServiceConnection sc = new ServiceConnection();
            registerNewObject(sc);
            sc.setName(LIVECYCLE_CONNECTION_NAME);
            sc.setUsername("administrator");
            sc.setPassword("password");
            sc.setEndpointType("DSC_DEFAULT_EJB_ENDPOINT");
            sc.setTransport("EJB");

            if (isJBossServer()) {
                sc.setServerType("Jboss");
                sc.setEndpointValue("jnp://localhost:1099");

            } else if (isWebLogicServer()) {
                sc.setServerType("WebLogic");
                sc.setEndpointValue("t3://localhost:8001");
            }
        }

        if (!hasServiceConnectionForName(VIRUS_SCAN_CONNECTION_NAME)) {
            ServiceConnection sc = new ServiceConnection();
            registerNewObject(sc);
            sc.setName(VIRUS_SCAN_CONNECTION_NAME);
            sc.setEndpointValue("localhost:1344");
        }
    }

    private boolean isJBossServer() {
        return System.getProperty("jboss.home.dir") != null;
    }

    private boolean isWebLogicServer() {
        return System.getProperty("weblogic.Name") != null;
    }

}

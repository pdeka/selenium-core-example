package com.avoka.fc.core.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Ordering;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.dao.BaseDao;
import com.avoka.core.util.CayenneUtils;
import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.FileUploadData;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.UserAccount;

public class FileUploadDao extends BaseDao {

    /**
     * Return the FileUplad for the specified id.
     *
     * @param id the file upload id
     * @param the FileUplad for the specified id
     */
    public FileUpload getFileUpload(Object id) {
        Validate.notNull(id, "Null id parameter");
        return (FileUpload) getObjectForPK(FileUpload.class, id);
    }

    /**
     * Return the list of required attachments for the given user.
     *
     * @param user the login user
     * @return the list of required attachments for the given user
     */
    public List<FileUpload> getFileUploads(UserAccount user, Boolean sharedFlag) {
        Validate.notNull(user, "Null user parameter");

        SelectQuery query = new SelectQuery(FileUpload.class);

        if (sharedFlag != null) {
            andQueryMatchExp(query, FileUpload.SHARED_FLAG_PROPERTY, sharedFlag);
        }

        andQueryMatchExp(query, FileUpload.USER_PROPERTY, user);
        Expression deletedExpression = ExpressionFactory.matchExp(FileUpload.DELETED_FLAG_PROPERTY, null);
        query.andQualifier(deletedExpression.orExp(ExpressionFactory.noMatchExp(FileUpload.DELETED_FLAG_PROPERTY, 1)));

        query.addOrdering(FileUpload.FILE_NAME_PROPERTY, true);
        query.addPrefetch(FileUpload.ATTACHMENTS_PROPERTY);

        return performQuery(query);
    }

    public List<FileUpload> getFileUploadsForSubmission(Submission submission) {
        Validate.notNull(submission, "Null submissionId parameter");

        if (submission.isDeleted()) {
            return null;
        }

        List<Attachment> attachments = submission.getAttachments();
        List<FileUpload> fileUploads = new ArrayList<FileUpload>(attachments.size());
        for (int i = 0; i < attachments.size(); i++) {
            FileUpload curFileUpload = attachments.get(i).getFileUpload();
            if (curFileUpload != null) {
                fileUploads.add(curFileUpload);
            }
        }
        return fileUploads;
    }

    public List<FileUpload> getSubmittedFileUploadsToAudit(Date submittedBefore) {
        SelectQuery query = new SelectQuery(FileUpload.class);

        Expression statusExpression = ExpressionFactory.matchExp(FileUpload.SUBMISSION_AUDIT_STATUS_PROPERTY, Submission.STATUS_Ready);
        query.andQualifier(statusExpression.orExp(ExpressionFactory.matchExp(FileUpload.SUBMISSION_AUDIT_STATUS_PROPERTY, Submission.STATUS_Error)));
        if (submittedBefore != null) {
            query.andQualifier(ExpressionFactory.lessExp(FileUpload.UPLOAD_TIMESTAMP_PROPERTY, submittedBefore));
        }

        query.addOrdering(FileUpload.UPLOAD_TIMESTAMP_PROPERTY, Ordering.DESC);

        return performQuery(query);
    }

    public List<FileUpload> getDeliveredFileUploadsToAudit() {
        SelectQuery query = new SelectQuery(FileUpload.class);

        Expression statusExpression = ExpressionFactory.matchExp(FileUpload.DELIVERY_AUDIT_STATUS_PROPERTY, Submission.STATUS_Ready);
        query.andQualifier(statusExpression.orExp(ExpressionFactory.matchExp(FileUpload.DELIVERY_AUDIT_STATUS_PROPERTY, Submission.STATUS_Error)));

        return performQuery(query);
    }

    public FileUpload cloneFileUpload(FileUpload fileUpload) {
        Validate.notNull(fileUpload, "Null fileUpload parameter");
        FileUpload clone = (FileUpload) CayenneUtils.cloneEntity(fileUpload);
        clone.setUser(fileUpload.getUser());
        // clear shared flag when cloning - only attachments explicitly uploaded via the attachment center are marked as shared
        clone.setSharedFlag(Boolean.FALSE);

        FileUploadData fileUploadData = fileUpload.getFileUploadData();

        if (fileUploadData != null) {
            fileUploadData.getFileUploadData();
            FileUploadData clonedFileUploadData = (FileUploadData) CayenneUtils.cloneEntity(fileUploadData);
            clone.setFileUploadData(clonedFileUploadData);
        }
        return clone;
    }

    public List<FileUpload> getFileUploadsForVirusScan() {
        SelectQuery query = new SelectQuery(FileUpload.class);

        Expression statusExpression = ExpressionFactory.matchExp(FileUpload.VIRUS_STATUS_PROPERTY, FileUpload.VIRUS_STATUS_SCAN_ERROR);
        query.andQualifier(statusExpression.orExp(ExpressionFactory.matchExp(FileUpload.VIRUS_STATUS_PROPERTY, null)));

        query.andQualifier(ExpressionFactory.noMatchExp(FileUpload.FILE_UPLOAD_DATA_PROPERTY, null));

        query.addPrefetch(FileUpload.FILE_UPLOAD_DATA_PROPERTY);

        return performQuery(query);
    }
}

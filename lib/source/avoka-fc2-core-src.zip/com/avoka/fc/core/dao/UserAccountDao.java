/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.QueryCacheStrategy;
import org.apache.cayenne.query.SelectQuery;
import org.apache.cayenne.query.SortOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.dao.BaseDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Group;
import com.avoka.fc.core.entity.PaymentAccount;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalUser;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserGroup;

/**
 * Provides an UserAccount DAO.
 */
public class UserAccountDao extends BaseDao{

    /**
     * Return the admin details for the given id.
     *
     * @param id the admin details primary key
     * @return the admin details for the given id
     */
    public UserAccount getUserAccountForPK(Object id){
        SelectQuery query = new SelectQuery(UserAccount.class);

        andQueryMatchDbExp(query, UserAccount.USER_OID_PK_COLUMN, id);

        query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (UserAccount) list.get(0);

        } else {
            return null;
        }
    }

    /**
     * Return the user account for the given user key.
     *
     * @param userKey the user account user key
     * @return the user details object
     */
    public UserAccount getUserAccountForUserKey(String userKey) {
        return (UserAccount) findObject(UserAccount.class, UserAccount.USER_KEY_PROPERTY, userKey);
    }

    /**
     * Return the admin details for the given login_name.
     *
     * @param loginName the admin details login name
     * @return the admin details for the given login name
     */
    public UserAccount getUserAccountForLogin(String loginName){
        if (StringUtils.isNotEmpty(loginName)) {

            SelectQuery query = new SelectQuery(UserAccount.class);
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.LOGIN_NAME_PROPERTY, loginName));

            query.addPrefetch(UserAccount.CLIENT_PROPERTY);

            query.setCacheStrategy(QueryCacheStrategy.LOCAL_CACHE);

            List list = performQuery(query);

            if (!list.isEmpty()) {
                return (UserAccount) list.get(0);
            }
        }
        return null;
    }

    public UserAccount getActiveUserAccountForLogin(String loginName){
        if (StringUtils.isNotEmpty(loginName)) {

            SelectQuery query = new SelectQuery(UserAccount.class);
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.LOGIN_NAME_PROPERTY, loginName));
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));

            List list = performQuery(query);

            if (!list.isEmpty()) {
                return (UserAccount) list.get(0);
            }
        }
        return null;
    }

    public UserAccount getActiveAdminUserAccountForLogin(String loginName, String portalName){
        if (StringUtils.isNotEmpty(loginName)) {
            SelectQuery query = new SelectQuery(UserAccount.class);
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.LOGIN_NAME_PROPERTY, loginName));
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.PORTAL_USERS_PROPERTY
                    + "." + PortalUser.PORTAL_PROPERTY + "." + Portal.NAME_PROPERTY, portalName));

            List list = performQuery(query);

            if (!list.isEmpty()) {
                return (UserAccount) list.get(0);
            }
        }
        return null;
    }

    public UserAccount getUserForLoginAndPortal(String loginName, Portal portal) {
        SelectQuery query = new SelectQuery(UserAccount.class);

        andQueryMatchExp(query, UserAccount.LOGIN_NAME_PROPERTY, loginName);
        andQueryMatchExp(query, UserAccount.ACTIVE_FLAG_PROPERTY, true);
        andQueryMatchExp(query, UserAccount.PORTAL_USERS_PROPERTY + "." + PortalUser.PORTAL_PROPERTY, portal);

        List list = performQuery(query);

        if (list.isEmpty()) {
            return null;

        } else if (list.size() == 1) {
            return (UserAccount) list.get(0);

        } else {
            String msg = "" + list.size() + " users share login name '" + loginName + "'";
            throw new IllegalStateException(msg);
        }
    }

    @SuppressWarnings("unchecked")
    public Set<String> getPermissionNames(String userOid, String portalName) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("userOid", userOid);
        params.put("portalName", portalName);

        List<Map> rows = (List<Map>) performNamedQuery(NamedQueries.USER_PORTAL_PERMISSION_NAMES, params);

        Set<String> permissionNames = new HashSet<String>();

        for (Map permissionNameRow : rows) {
            permissionNames.add(permissionNameRow.get("permission_name").toString());
        }

        return permissionNames;
    }

    /**
     * Return all the admin details.
     *
     * @return all the admin details
     */
    public List getUserAccountList(){
        SelectQuery query = new SelectQuery(UserAccount.class);

        query.addOrdering(UserAccount.LOGIN_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    public List<UserAccount> getUserAccountList(String clientId, String userId, String name,
            String loginName, String portalId, String sortBy, boolean ascending, int pageSize) {
        SelectQuery query = new SelectQuery(UserAccount.class);

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.CLIENT_PROPERTY, clientId));
        }

        if (StringUtils.isNotEmpty(userId)) {
            andQueryMatchDbExp(query, UserAccount.USER_OID_PK_COLUMN, userId);
        }

        if (StringUtils.isNotEmpty(name)) {
            Expression nameExpression = ExpressionFactory.likeIgnoreCaseExp(UserAccount.FAMILY_NAME_PROPERTY, "%" + name + "%");
            nameExpression = nameExpression.orExp(ExpressionFactory.likeIgnoreCaseExp(UserAccount.GIVEN_NAME_PROPERTY, "%" + name + "%"));
            query.andQualifier(nameExpression);
        }

        if (StringUtils.isNotEmpty(loginName)) {
            query.andQualifier(ExpressionFactory.likeIgnoreCaseExp(UserAccount.LOGIN_NAME_PROPERTY, "%" + loginName + "%"));
        }

        // only retrieve accounts associated with the specified portal
        if (StringUtils.isNotEmpty(portalId)) {
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.PORTAL_USERS_PROPERTY + "." + PortalUser.PORTAL_PROPERTY, portalId));
        }

        boolean sortedByLoginName = false;
        if (StringUtils.isNotBlank(sortBy)) {
            if (sortBy.equals(UserAccount.LOGIN_NAME_PROPERTY)) {
                sortedByLoginName = true;
            }
            if (ascending) {
                query.addOrdering(sortBy, SortOrder.ASCENDING_INSENSITIVE);
            } else {
                query.addOrdering(sortBy, SortOrder.DESCENDING_INSENSITIVE);
            }
        }

        if (!sortedByLoginName) {
            query.addOrdering(UserAccount.LOGIN_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);
        }

        query.setPageSize(pageSize);

        return performQuery(query);
    }

    /**
     * Return all members of a specific group.
     */
    public List<UserAccount> getActiveUsersInGroup(String groupName) {
        Validate.notEmpty(groupName, "Empty groupName parameter");

        SelectQuery query = new SelectQuery(UserAccount.class);

        andQueryMatchExp(query, UserAccount.ACTIVE_FLAG_PROPERTY, true);
        String path = UserAccount.USER_GROUPS_PROPERTY + "." + UserGroup.GROUP_PROPERTY + "." + Group.GROUP_NAME_PROPERTY;
        andQueryMatchExp(query, path, groupName);

        query.addOrdering(UserAccount.LOGIN_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    public List getAdminsWithPermission(String clientId, String permissionName){

        Map<String, Object> params = new HashMap<String, Object>();

        if (StringUtils.isNotEmpty(clientId)) {
            params.put("clientId", clientId);
        }

        if (StringUtils.isNotEmpty(permissionName)) {
            params.put("permission", permissionName);
        }

        return performNamedQuery(NamedQueries.ADMIN_PROMOTION_LEVEL, params, true);

    }

    public List getAdminsSearch(String clientId, String value){
        SelectQuery query = new SelectQuery(UserAccount.class);

        if (StringUtils.isNotEmpty(value)) {
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(UserAccount.GIVEN_NAME_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(UserAccount.FAMILY_NAME_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(UserAccount.LOGIN_NAME_PROPERTY, "%" + value + "%"));
            query.orQualifier(ExpressionFactory.likeIgnoreCaseExp(UserAccount.EMAIL_PROPERTY, "%" + value + "%"));

            if (NumberUtils.isNumber(value)) {
                query.orQualifier(ExpressionFactory.matchDbExp(UserAccount.USER_OID_PK_COLUMN, value));
            }
        }
        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.CLIENT_PROPERTY, clientId));
        }

        query.addOrdering(UserAccount.LOGIN_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    public List getUserAccountsForClient(String clientId){
        SelectQuery query = new SelectQuery(UserAccount.class);

        if (StringUtils.isNotEmpty(clientId)) {
            query.andQualifier(ExpressionFactory.matchExp(UserAccount.CLIENT_PROPERTY, clientId));
        }

        andQueryMatchExp(query, UserAccount.ACTIVE_FLAG_PROPERTY, true);

        query.addOrdering(UserAccount.LOGIN_NAME_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }

    public List<UserAccount> getUserSubscribedToSubmissionAlerts(String clientId){
        SelectQuery query = new SelectQuery(UserAccount.class);

        Expression clientExpression = ExpressionFactory.matchExp(UserAccount.CLIENT_PROPERTY, null);
        query.andQualifier(clientExpression.orExp(ExpressionFactory.matchExp(UserAccount.CLIENT_PROPERTY, clientId)));

        andQueryMatchExp(query, UserAccount.ACTIVE_FLAG_PROPERTY, true);
        String path = UserAccount.USER_GROUPS_PROPERTY + "." + UserGroup.GROUP_PROPERTY + "." + Group.GROUP_NAME_PROPERTY;
        andQueryMatchExp(query,  path, Group.RECEIVE_SUBMISSION_ALERTS);

        return performQuery(query);
    }


    public List<UserAccount> getUsersWithoutUserkey() {
        SelectQuery query = new SelectQuery(UserAccount.class);

        query.andQualifier(ExpressionFactory.matchExp(UserAccount.USER_KEY_PROPERTY, null));

        return performQuery(query);
    }

    public List<PaymentAccount> getUserClientAccounts(UserAccount userAccount, Client client) {
        SelectQuery query = new SelectQuery(PaymentAccount.class);

        query.andQualifier(ExpressionFactory.matchExp(PaymentAccount.USER_PROPERTY, userAccount));
        query.andQualifier(ExpressionFactory.matchExp(PaymentAccount.CLIENT_PROPERTY, client));
        query.andQualifier(ExpressionFactory.matchExp(PaymentAccount.ACTIVE_FLAG_PROPERTY, Boolean.TRUE));
        query.addOrdering(PaymentAccount.ACCOUNT_NUMBER_PROPERTY, SortOrder.ASCENDING_INSENSITIVE);

        return performQuery(query);
    }


    public void setReceiveSubmissionUpdates(UserAccount userAccount, boolean receive) {
        UserGroup foundUserGroup = null;
        List<UserGroup> userGroups = userAccount.getUserGroups();
        for (UserGroup userGroup : userGroups) {
            if (userGroup.getGroup().getGroupName().equals(Group.RECEIVE_SUBMISSION_UPDATES)) {
                foundUserGroup = userGroup;
                break;
            }
        }

        // Add user group
        if (receive) {
            if (foundUserGroup == null) {
                Group group = DaoFactory.getGroupDao().getGroupForName(Group.RECEIVE_SUBMISSION_UPDATES);
                UserGroup userGroup = new UserGroup();
                userAccount.addToUserGroups(userGroup);
                group.addToUserGroups(userGroup);
            }

        // Else remove user group
        } else {
            if (foundUserGroup != null) {
                userAccount.removeFromUserGroups(foundUserGroup);
                deleteObject(foundUserGroup);
            }
        }
    }

}

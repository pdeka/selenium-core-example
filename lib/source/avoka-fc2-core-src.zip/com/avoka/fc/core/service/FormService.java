package com.avoka.fc.core.service;

import java.util.Date;

import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.entity.FormPdfParams;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PromotionLog;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.TemplateVersionData;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.FormUtils;
import com.avoka.fc.core.util.RemoteUserProvider;

public class FormService extends CayenneService {

    /**
     * Package private constructor to enforce ServiceFactory pattern.
     */
    FormService(){
    }

    /**
     * Create a new form, template, template version, template version data,
     * schema for the given information.
     */
    public Form createNewForm(FormBean formBean) {

        Validate.notNull(formBean.formName, "Null form parameter");
        Validate.notNull(formBean.formCode, "Null formCode parameter");
        Validate.notNull(formBean.formType, "Null formType parameter");
        Validate.notNull(formBean.client, "Null client parameter");
        Validate.notNull(formBean.templateFilename, "Null templateFilename parameter");
        Validate.notNull(formBean.templateBytes, "Null templateBytes parameter");
        Validate.notNull(formBean.portalId, "Null portalId parameter");

        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction transaction = domain.createTransaction();

        Transaction.bindThreadTransaction(transaction);

        try {
            // Create Form Object
            Form form = new Form();
            registerNewObject(form);

            form.setFormName(formBean.formName);
            form.setClientFormCode(formBean.formCode);
            form.setFormDescription(formBean.formDescription);
            form.setActiveFlag(Boolean.TRUE);
            form.setActivateTimestamp(new Date());

            form.setTestEnabledFlag(Boolean.TRUE);
            form.setClient(formBean.client);
            form.setSubmissionExpiryDays(new Integer(1));
            form.setReceiptEnabledFlag(Boolean.TRUE);

            Portal portal = DaoFactory.getPortalDao().getObjectForPK(formBean.portalId);
            form.setPortal(portal);

            commitChanges();

            // Create Schema Object if existing schema not provided
            SchemaSeed schemaSeed = null;
            if (formBean.seedBytes != null && formBean.seedBytes.length > 0) {
                schemaSeed = new SchemaSeed();
                registerNewObject(schemaSeed);

                String schemaName = CoreUtils.limitLength(form.getFormName() + " Schema 1", 40, "");
                schemaSeed.setName(schemaName);
                schemaSeed.setFileData(formBean.seedBytes);
                schemaSeed.setFileName(formBean.seedFilename);
                schemaSeed.setClient(formBean.client);

                commitChanges();
            }

            // Create Template
            Template template = new Template();
            registerNewObject(template);

            template.setSharedFlag(false);
            String templateName = CoreUtils.limitLength(form.getFormName() + " Template", 40, "");
            template.setTemplateName(templateName);
            String templateCode = CoreUtils.limitLength(form.getClientFormCode() + "-template", 20, "");
            template.setTemplateCode(templateCode);
            template.setActiveFlag(Boolean.TRUE);
            template.setClient(formBean.client);
            form.setTemplate(template);
            commitChanges();

            // Create Template Version
            TemplateVersion templateVersion = new TemplateVersion();
            registerNewObject(templateVersion);

            templateVersion.setFileName(formBean.templateFilename);

            if (TemplateVersion.FORM_TYPE_FORM_GUIDE.equals(templateVersion.getFormType())) {
                // for form guides, we use the size of the xdp file
                Long xdpSize = FormUtils.getFormGuideFilesize(formBean.templateBytes);
                if (xdpSize == null) {
                    EventLogService eventLogService = ServiceFactory.getEventLogService();
                    eventLogService.logWarnEvent("Formguide for template version " + templateVersion.getId() + " does not contain an xdp file.");
                }
                else {
                    templateVersion.setFileSize(xdpSize);
                }
            }
            else {
                // use the template version data size
                templateVersion.setFileSize(new Long(formBean.templateBytes.length));
            }

            templateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_READY);
            templateVersion.setFormType(formBean.formType);
            templateVersion.setVersionNumber("1");
            templateVersion.setTemplate(template);
            templateVersion.setSchema(schemaSeed);
            templateVersion.setReaderExtendFlag(formBean.readerExtend);
            commitChanges();

            // Create Template Version Data
            TemplateVersionData templateVersionData = new TemplateVersionData();
            registerNewObject(templateVersionData);

            templateVersionData.setFileData(formBean.templateBytes);
            templateVersionData.setTemplateVersion(templateVersion);
            template.setCurrentVersion(templateVersion);
            commitChanges();

            // Create Form Promotion Record
            PromotionLog promotionLog = new PromotionLog();
            registerNewObject(promotionLog);
            promotionLog.setCreatedTime(new Date());
            promotionLog.setTemplate(template);
            promotionLog.setVersion(templateVersion);
            promotionLog.setClient(formBean.client);
            promotionLog.setCreatedTime(new Date());
            promotionLog.setCurrentFlag(Boolean.TRUE);
            promotionLog.setForm(form);
            promotionLog.setPromotionStatus(PromotionLog.PROMOTION_STATUS_DEVELOPMENT);

            UserAccountDao adminDao = new UserAccountDao();
            UserAccount adminUser = adminDao.getUserAccountForPK(RemoteUserProvider.getAdminId());
            promotionLog.setAdminUser(adminUser);

            commitChanges();

            // Create PDF Parameters
            FormPdfParams formParams = new FormPdfParams();
            form.setPdfParams(formParams);
            if (FormBean.ZOOM_100.equals(formBean.pdfFormView)) {
                formParams.setZoom("100");

            } else if (FormBean.FIT_HEIGHT.equals(formBean.pdfFormView)) {
                formParams.setView("FitV");

            } else if (FormBean.FIT_WIDTH.equals(formBean.pdfFormView)) {
                formParams.setView("FitH");
            }

            formParams.setNavpanes(formBean.showNavbar);
            formParams.setScrollbar(formBean.showScrollbar);
            formParams.setToolbar(formBean.showToolbar);

            commitChanges();

            // Publish the form template
            PublishTemplateService publishService = (PublishTemplateService) ServiceLocator
                    .getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_PUBLISH_TEMPLATE);
            publishService.publishTemplate(templateVersion);

            transaction.commit();

            return form;

        } catch (Exception error) {
            try {
                transaction.rollback();

            } catch (Exception e) {
                getLogger().error("Error Rolling back transaction...", e);

            } finally {
                Transaction.bindThreadTransaction(null);
            }

            ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
            errorLogService.logException(error);

            if (error instanceof RuntimeException) {
                throw (RuntimeException) error;

            } else {
                String msg = "Unknown error: " + error.toString();
                throw new ApplicationException("FormService", error, msg, msg,
                        null);
            }

        } finally {
            Transaction.bindThreadTransaction(null);
        }
    }

    public static class FormBean {

        public static final String ZOOM_100 = "Zoom to 100%";
        public static final String FIT_HEIGHT = "Fit to Height";
        public static final String FIT_WIDTH = "Fit to Width";

        public static final String[] PDF_FORM_VIEWS = { "", ZOOM_100, FIT_HEIGHT, FIT_WIDTH };

        public String formName;
        public String formCode;
        public String formDescription;
        public String formType;
        public Client client;
        public String templateFilename;
        public byte[] templateBytes;
        public String seedFilename;
        public byte[] seedBytes;
        public boolean readerExtend;
        public String portalId;
        public String pdfFormView;
        public String showToolbar;
        public String showNavbar;
        public String showScrollbar;
    }

}

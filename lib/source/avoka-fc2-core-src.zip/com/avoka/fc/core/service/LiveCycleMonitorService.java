package com.avoka.fc.core.service;

public interface LiveCycleMonitorService {

    public boolean isLiveCycleInitialized();

}

/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.BaseContext;
import org.apache.cayenne.DataObject;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.Query;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CayenneUtils;

/**
 * Provides a base Cayenne ORM service for service classes to extend.
 *
 * @author medgar@avoka.com
 */
public class CayenneService extends BaseService {

    protected DataContext getDataContext() {
        return (DataContext) BaseContext.getThreadObjectContext();
    }

    public void commitChanges() {
        getDataContext().commitChanges();
    }

    public void rollbackChanges() {
        try {
            getDataContext().rollbackChanges();
        } catch (Exception e) {
            getLogger().warn(e.toString(), e);
        }
    }

    protected DataObject refetchObject(DataObject dataObject) {
        Validate.notNull(dataObject, "Null dataObject parameter");
        return (DataObject) getDataContext().refetchObject(dataObject.getObjectId());
    }

    protected void registerNewObject(DataObject dataObject) {
        getDataContext().registerNewObject(dataObject);
    }

    @SuppressWarnings("deprecation")
    protected DataObject createAndRegisterNewObject(Class dataObjectClass) {
        return getDataContext().createAndRegisterNewObject(dataObjectClass);
    }

    protected void deleteObject(DataObject dataObject) {
        getDataContext().deleteObject(dataObject);
    }

    protected void deleteObjects(Collection objects) {
        getDataContext().deleteObjects(objects);
    }

    protected Object getObjectForPK(Class dataObjectClass, Object id) {
        if (id == null) {
            return null;
        }

        return CayenneUtils.getObjectForPK(dataObjectClass, id);
    }

    protected DataObject findObject(Class dataObjectClass, String property,
            Object value) {

        if (dataObjectClass == null) {
            String msg = "Null dataObjectClass parameter";
            throw new IllegalArgumentException(msg);
        }

        if (property == null) {
            throw new IllegalArgumentException("Null property parameter");
        }

        if (property == null) {
            throw new IllegalArgumentException("Null value parameter");
        }

        Expression qual = ExpressionFactory.matchExp(property, value);
        List list = performQuery(new SelectQuery(dataObjectClass, qual));

        if (list.size() == 1) {
            return (DataObject) list.get(0);

        } else if (list.size() > 1) {
            String msg = "SelectQuery for " + dataObjectClass.getName()
                    + " where " + property + " equals " + value + " returned "
                    + list.size() + " rows";
            throw new RuntimeException(msg);

        } else {
            return null;
        }
    }

    protected int[] performNonSelectingQuery(Query query) {
        return getDataContext().performNonSelectingQuery(query);
    }

    protected int[] performNonSelectingQuery(String queryName) {
        return getDataContext().performNonSelectingQuery(queryName);
    }

    protected int[] performNonSelectingQuery(String queryName, Map parameters) {
        return getDataContext().performNonSelectingQuery(queryName, parameters);
    }

    protected List performQuery(Query query) {
        return getDataContext().performQuery(query);
    }

    protected List performNamedQuery(String queryName, boolean refresh) {
        return getDataContext().performQuery(queryName, refresh);
    }

    protected List performNamedQuery(String queryName, Map parameters,
            boolean refresh) {

        return getDataContext().performQuery(queryName, parameters, refresh);
    }

    protected List performNamedQuery(String queryName, String[] keys,
            String[] values, boolean refresh) {

        return performNamedQuery(queryName, toMap(keys, values), refresh);
    }

    protected List performQuery(Class dataObjectClass, String property,
            Object value) {

        if (dataObjectClass == null) {
            String msg = "Null dataObjectClass parameter";
            throw new IllegalArgumentException(msg);
        }

        if (property == null) {
            throw new IllegalArgumentException("Null property parameter");
        }

        if (property == null) {
            throw new IllegalArgumentException("Null value parameter");
        }

        Expression qual = ExpressionFactory.matchExp(property, value);
        return performQuery(new SelectQuery(dataObjectClass, qual));
    }

    protected int[] performNonSelectingQuery(String queryName, String[] keys,
            String[] values) {

        return performNonSelectingQuery(queryName, toMap(keys, values));
    }

    protected Map toMap(String key, Object value) {
        return Collections.singletonMap(key, value);
    }

    protected Map toMap(String[] keys, Object[] values) {

        if (keys == null || keys.length == 0) {
            return Collections.EMPTY_MAP;
        }

        int len = keys.length;
        if (len == 1) {
            return Collections.singletonMap(keys[0], values[0]);
        }

        Map map = new HashMap();
        for (int i = 0; i < len; i++) {
            map.put(keys[i], values[i]);
        }

        return map;
    }

}

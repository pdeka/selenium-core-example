/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.CayenneUtils;
import com.avoka.fc.core.dao.DocumentTypeDao;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.MetadataTagDao;
import com.avoka.fc.core.dao.PropertyTypeDao;
import com.avoka.fc.core.dao.SchemaSeedDao;
import com.avoka.fc.core.dao.TemplateDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.DocumentType;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormProperty;
import com.avoka.fc.core.entity.MetadataListValue;
import com.avoka.fc.core.entity.MetadataTag;
import com.avoka.fc.core.entity.MetadataValue;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.PropertyTypeMap;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.TemplateVersionData;
import com.avoka.fc.core.entity.XmlInputMap;
import com.avoka.fc.core.entity.XmlInputVersion;
import com.avoka.fc.core.util.ApplicationException;

public class CloneService extends CayenneService {

    protected List<PropertyType> newPropertyTypes;
    protected List<MetadataTag> newMetadataTags;
    protected List<SchemaSeed> newSchemaSeeds;
    protected List<DocumentType> newDocumentTypes;
    protected List<Template> newSharedTemplates;
    protected List<String> newFormCodes;

    public CloneService() {
        super();
        newPropertyTypes = new ArrayList<PropertyType>();
        newMetadataTags = new ArrayList<MetadataTag>();
        newSchemaSeeds = new ArrayList<SchemaSeed>();
        newDocumentTypes = new ArrayList<DocumentType>();
        newSharedTemplates = new ArrayList<Template>();
        newFormCodes = new ArrayList<String>();
    }

    public void cloneClient(String fromClientId, String toClientId, Boolean importForms) {

        if (StringUtils.isNotBlank(fromClientId) && StringUtils.isNotBlank(toClientId)) {

            Client fromClient = (Client) getObjectForPK(Client.class, fromClientId);
            Client toClient = (Client) getObjectForPK(Client.class, toClientId);

            if (fromClient != null && toClient != null) {

                DataDomain domain = Configuration.getSharedConfiguration().getDomain();
                Transaction transaction = domain.createTransaction();

                Transaction.bindThreadTransaction(transaction);

                try {
                    newPropertyTypes = clonePropertyTypes(fromClient, toClient);
                    newMetadataTags = cloneMetadataTags(fromClient, toClient);
                    newDocumentTypes = cloneDocumentTypes(fromClient, toClient);
                    cloneClientProperties(fromClient, toClient);
                    cloneClientMetadata(fromClient, toClient);
                    if (Boolean.TRUE.equals(importForms)) {
                        newSchemaSeeds = cloneSchemaSeeds(fromClient, toClient, newSchemaSeeds);
                        newSharedTemplates = cloneSharedTemplates(fromClient, toClient);
                        cloneAllForms(fromClient, toClient);
                    }
                    commitChanges();

                    // if we copied forms, we need to synchronise templates
                    if (Boolean.TRUE.equals(importForms)) {
                        SynchronizeTemplatesService synchronizeTemplatesService = (SynchronizeTemplatesService)
                            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SYNCHRONIZE_TEMPLATES);

                        synchronizeTemplatesService.synchronizeTemplates();
                    }

                    transaction.commit();

                } catch (Exception e) {
                    e.printStackTrace();

                    try {
                        transaction.rollback();

                    } catch (Exception er) {
                        getLogger().error("Error rolling back transaction", er);
                    }

                    throw new ApplicationException("Error copying client", e, "Copying client " + fromClientId, "An error occurred copying a client to another", "Look at the error details and correct the configuration.");

                } finally {
                    Transaction.bindThreadTransaction(null);
                }
            }
        }
    }

    /**
     * Given a formId, create a copy and attach to given client. (not committed).
     *
     * @param formId
     * @param clientId
     */
    public Form cloneForm(String oldFormId, String toClientId) {
        if (StringUtils.isNotBlank(oldFormId) && StringUtils.isNotBlank(toClientId)) {
            Form oldForm = (Form) getObjectForPK(Form.class, oldFormId);
            Client toClient = (Client) getObjectForPK(Client.class, toClientId);
            return cloneForm(oldForm, toClient);
        }
        return null;
    }

    /**
     * Append a version number starting at 2 on the formCode if a form already exists for the given
     * formCode I.e try 2, then 3 until it's unique.
     *
     */
    private String createFormCode(Client client, Form oldForm) {
        Template template = oldForm.getTemplate();
        String templateCode = template.getTemplateCode();
        if (StringUtils.isBlank(templateCode)) {
            templateCode = StringUtils.left(template.getTemplateName(), 5);
        }
        else {
            templateCode = StringUtils.left(templateCode, 5);
        }

        String clientCode = client.getClientCode();
        if (StringUtils.isBlank(clientCode)) {
            clientCode = StringUtils.left(client.getClientName(), 5);
        }
        else {
            clientCode = StringUtils.left(clientCode, 5);
        }

        FormDao formDao = new FormDao();
        String formCode = templateCode.toLowerCase() + "-" + clientCode.toLowerCase();
        String uniqueFormCode = formCode;
        for (int i = 2;; i++) {
            Form existingForm = formDao.getFormByFormCode(uniqueFormCode);
            if (existingForm == null && !newFormCodes.contains(uniqueFormCode)) {
                newFormCodes.add(uniqueFormCode);
                return uniqueFormCode;
            }
            uniqueFormCode = formCode + i;
        }
    }

    protected PropertyType getPropertyType(PropertyType oldPropertyType) {

        if (oldPropertyType != null) {

            if (oldPropertyType.getClient() == null) {
                return oldPropertyType;
            }

            for (int i = 0; i < newPropertyTypes.size(); i++) {
                PropertyType newPropertyType = newPropertyTypes.get(i);
                if (newPropertyType.getName().equals(oldPropertyType.getName()) && newPropertyType.getScope().equals(oldPropertyType.getScope())) {
                    return newPropertyType;
                }
            }
        }
        return null;
    }

    protected MetadataTag getMetadataTag(MetadataTag oldMetadataTag) {

        if (oldMetadataTag != null) {

            if (oldMetadataTag.getClient() == null) {
                return oldMetadataTag;
            }

            for (int i = 0; i < newMetadataTags.size(); i++) {
                MetadataTag newMetadataTag = newMetadataTags.get(i);
                if (newMetadataTag.getName().equals(oldMetadataTag.getName()) && newMetadataTag.getScope().equals(oldMetadataTag.getScope())) {
                    return newMetadataTag;
                }
            }
        }
        return null;
    }

    protected SchemaSeed getSchemaSeed(SchemaSeed oldSchemaSeed) {

        if (oldSchemaSeed != null) {

            if (oldSchemaSeed.getClient() == null) {
                return oldSchemaSeed;
            }

            for (int i = 0; i < newSchemaSeeds.size(); i++) {
                SchemaSeed newSchemaSeed = newSchemaSeeds.get(i);
                if (newSchemaSeed.getName().equals(oldSchemaSeed.getName())) {
                    return newSchemaSeed;
                }
            }
        }
        return null;
    }

    protected DocumentType getDocumentType(DocumentType oldDocumentType) {

        if (oldDocumentType != null) {

            if (oldDocumentType.getClient() == null) {
                return oldDocumentType;
            }

            for (int i = 0; i < newDocumentTypes.size(); i++) {
                DocumentType newDocumentType = newDocumentTypes.get(i);
                if (newDocumentType.getName().equals(oldDocumentType.getName())) {
                    return newDocumentType;
                }
            }
        }
        return null;
    }

    protected Template getSharedTemplate(Template oldTemplate) {

        if (oldTemplate != null) {

            if (oldTemplate.getClient() == null) {
                return oldTemplate;
            }

            for (int i = 0; i < newSharedTemplates.size(); i++) {
                Template newTemplate = newSharedTemplates.get(i);
                if (newTemplate.getTemplateName().equals(oldTemplate.getTemplateName())) {
                    return newTemplate;
                }
            }
        }
        return null;
    }

    /**
     * Creates a copy of all property types for the selected client (uncommitted)
     * Does not copy global property types
     * @param fromClient the client to copy property types from
     * @param toClient the client for which to create property types
     * @return a list of property types belonging to toClient
     */
    private List<PropertyType> clonePropertyTypes(Client fromClient, Client toClient) {
        List<PropertyType> newPropertyTypeList = new ArrayList<PropertyType>();

        PropertyTypeDao propertyTypeDao = new PropertyTypeDao();
        List<PropertyType> oldPropertyTypeList = propertyTypeDao.getPropertyTypeList(fromClient.getId().toString(), null, null, null, null, true, 100);

        if (oldPropertyTypeList != null) {
           for (int i = 0; i < oldPropertyTypeList.size(); i++) {
               PropertyType oldPropertyType = oldPropertyTypeList.get(i);
               PropertyType newPropertyType = clonePropertyType(oldPropertyType, toClient);

               newPropertyTypeList.add(newPropertyType);
           }
        }

        return newPropertyTypeList;
    }

    private PropertyType clonePropertyType(PropertyType oldPropertyType, Client toClient) {
        PropertyType newPropertyType = (PropertyType) CayenneUtils.cloneEntity(oldPropertyType);
        newPropertyType.setClient(toClient);

        return newPropertyType;
    }

    /**
     * Creates a copy of all metadata tags for the selected client (uncommitted)
     * Does not copy global metadata tags
     * @param fromClient the client to copy metadata tags from
     * @param toClient the client for which to create metadata tags
     * @return a list of metadata tags belonging to toClient
     */
    private List<MetadataTag> cloneMetadataTags(Client fromClient, Client toClient) {
        List<MetadataTag> newMetadataTagList = new ArrayList<MetadataTag>();

        MetadataTagDao metadataTagDao = new MetadataTagDao();
        List<MetadataTag> oldMetadataTagList = metadataTagDao.getMetadataTagListForClient(fromClient);

        if (oldMetadataTagList != null) {
           for (int i = 0; i < oldMetadataTagList.size(); i++) {
               MetadataTag oldMetadataTag = oldMetadataTagList.get(i);
               MetadataTag newMetadataTag = cloneMetadataTag(oldMetadataTag, toClient);

               newMetadataTagList.add(newMetadataTag);
           }
        }

        return newMetadataTagList;
    }

    private MetadataTag cloneMetadataTag(MetadataTag oldMetadataTag, Client toClient) {
        MetadataTag newMetadataTag = (MetadataTag) CayenneUtils.cloneEntity(oldMetadataTag);
        newMetadataTag.setClient(toClient);

        if (MetadataTag.PROPERTY_Type_List.equals(oldMetadataTag.getType()) || MetadataTag.PROPERTY_Type_ListHierarchy.equals(oldMetadataTag.getType())) {
            List<MetadataListValue> oldListValues = oldMetadataTag.getMetadataListValues();
            Map<String, MetadataListValue> listValuesMap = new HashMap<String, MetadataListValue>();
            if (oldListValues != null) {
                for (int i = 0; i < oldListValues.size(); i++) {
                    MetadataListValue oldListValue = oldListValues.get(i);
                    MetadataListValue newListValue = cloneMetadataListValue(oldListValue, toClient);

                    listValuesMap.put(oldListValue.getId().toString(), newListValue);
                    newMetadataTag.addToMetadataListValues(newListValue);
                }

                if (MetadataTag.PROPERTY_Type_ListHierarchy.equals(oldMetadataTag.getType())) {
                    // hook up parent relationships
                    for (MetadataListValue oldValue: oldListValues) {
                        MetadataListValue newValue = listValuesMap.get(oldValue.getId().toString());
                        MetadataListValue oldParentValue = oldValue.getParentValue();
                        if (oldParentValue != null) {
                            MetadataListValue newParentValue = listValuesMap.get(oldParentValue.getId().toString());
                            newValue.setParentValue(newParentValue);
                        }
                    }
                }
            }
        }

        return newMetadataTag;
    }

    private MetadataListValue cloneMetadataListValue(MetadataListValue oldListValue, Client toClient) {
        MetadataListValue newListValue = (MetadataListValue) CayenneUtils.cloneEntity(oldListValue);
        return newListValue;
    }

    /**
     * Creates a copy of all schema seeds for the selected client (uncommitted)
     * Does not copy global schema seeds
     * @param fromClient the client to copy schema seeds from
     * @param toClient the client for which to create schema seeds
     * @param schemaSeeds the list of schema seeds to which to append the new schema seeds
     * @return a list of schema seeds belonging to toClient
     */
    private List<SchemaSeed> cloneSchemaSeeds(Client fromClient, Client toClient, List<SchemaSeed> schemaSeeds) {
        if (schemaSeeds == null) {
            schemaSeeds = new ArrayList<SchemaSeed>();
        }

        SchemaSeedDao schemaDao = new SchemaSeedDao();
        List<SchemaSeed> oldSchemaList = schemaDao.getSchemasList(fromClient.getId().toString());

        if (oldSchemaList != null) {
           for (int i = 0; i < oldSchemaList.size(); i++) {
               SchemaSeed oldSchema = oldSchemaList.get(i);
               SchemaSeed newSchema = cloneSchemaSeed(oldSchema, toClient, schemaSeeds);

               schemaSeeds.add(newSchema);
           }
        }
        return schemaSeeds;
    }

    private SchemaSeed cloneSchemaSeed(SchemaSeed fromSchemaSeed, Client toClient, List<SchemaSeed> existingSchemaSeeds) {
        // we do not want to create the same schema twice, so check if we've already cloned the schema
        SchemaSeed existingSchemaSeed = getSchemaSeed(fromSchemaSeed);
        if (existingSchemaSeed != null) {
            return existingSchemaSeed;
        }

        SchemaSeed newSchemaSeed = (SchemaSeed) CayenneUtils.cloneEntity(fromSchemaSeed);
        newSchemaSeed.setClient(toClient);
        existingSchemaSeeds.add(newSchemaSeed);

        // recursive call to clone parent schema if needed
        SchemaSeed fromBaseSchemaSeed = fromSchemaSeed.getBaseSchema();
        SchemaSeed newBaseSchemaSeed = fromBaseSchemaSeed;
        if (fromBaseSchemaSeed != null && fromBaseSchemaSeed.getClient() != null && !fromBaseSchemaSeed.getClient().equals(toClient)) {
            newBaseSchemaSeed = cloneSchemaSeed(fromBaseSchemaSeed, toClient, existingSchemaSeeds);
            newSchemaSeed.setBaseSchema(newBaseSchemaSeed);
        }

        // schema config map
        List<SchemaConfigMap> oldConfigMap = fromSchemaSeed.getSchemaConfigMaps();
        if (oldConfigMap != null) {
            cloneSchemaConfigMap(oldConfigMap, newSchemaSeed);
        }

        // property type map
        List<PropertyTypeMap> oldPropertyMap = fromSchemaSeed.getPropertyMap();
        if (oldPropertyMap != null) {
            clonePropertyTypeMap(oldPropertyMap, newSchemaSeed, toClient);
        }

        // prefill XML configurations
        List<XmlInputVersion> oldXmlInputVersions = fromSchemaSeed.getXmlInputVersions();
        if (oldXmlInputVersions != null) {
            for (XmlInputVersion oldXmlInputVersion: oldXmlInputVersions) {
                cloneXmlInputVersion(oldXmlInputVersion, newSchemaSeed, toClient);
            }
        }

        return newSchemaSeed;
    }

    /**
     * Creates a copy of all document types for the selected client (uncommitted)
     * Does not copy global document types
     * @param fromClient the client to copy document types from
     * @param toClient the client for which to create document types
     * @return a list of document types belonging to toClient
     */
    private List<DocumentType> cloneDocumentTypes(Client fromClient, Client toClient) {
        List<DocumentType> newDocumentTypeList = new ArrayList<DocumentType>();

        DocumentTypeDao documentTypeDao = new DocumentTypeDao();
        List<DocumentType> oldDocumentTypeList = documentTypeDao.getDocumentTypeByClient(fromClient.getId().toString());

        if (oldDocumentTypeList != null) {
           for (int i = 0; i < oldDocumentTypeList.size(); i++) {
               DocumentType oldDocumentType = oldDocumentTypeList.get(i);
               DocumentType newDocumentType = cloneDocumentType(oldDocumentType, toClient);

               newDocumentTypeList.add(newDocumentType);
           }
        }

        return newDocumentTypeList;
    }

    private DocumentType cloneDocumentType(DocumentType fromDocumentType, Client toClient) {
        DocumentType newDocumentType = (DocumentType) CayenneUtils.cloneEntity(fromDocumentType);
        newDocumentType.setClient(toClient);
        newDocumentType.setCode(createDocumentTypeCode(fromDocumentType.getCode(), toClient.getId().toString()));
        newDocumentType.setName(createDocumentTypeName(fromDocumentType.getName(), toClient.getId().toString()));

        return newDocumentType;
    }

    private Client cloneClientProperties(Client fromClient, Client toClient) {
        if (fromClient != null && toClient != null) {
            Object[] clientProperties = fromClient.getClientProperties().toArray();
            for (int i = 0; i < clientProperties.length; i++) {
                ClientProperty baseClientProperty = (ClientProperty) clientProperties[i];

                ClientProperty newClientProperty = (ClientProperty) CayenneUtils.cloneEntity(baseClientProperty);
                newClientProperty.setClient(toClient);

                PropertyType oldPropertyType = baseClientProperty.getPropertyType();
                PropertyType newPropertyType = oldPropertyType;
                if (oldPropertyType.getClient() != null && !toClient.equals(oldPropertyType.getClient())) {
                    newPropertyType = getPropertyType(oldPropertyType);
                }
                newClientProperty.setPropertyType(newPropertyType);
            }
            return toClient;
        }
        return null;
    }

    /**
     * Create a copy of all the specified metadata and attach them to the given client (uncommitted).
     *
     * @param fromClient the client containing the metadata values to be copied
     * @param toClient the client to copy the metadata values to
     * @return
     */
    private Client cloneClientMetadata(final Client fromClient, Client toClient) {
        List clientMetadataValues = fromClient.getClientMetadataValues();
        for (int i = 0; i < clientMetadataValues.size(); i++) {
            MetadataValue baseClientMetadataValue = (MetadataValue) clientMetadataValues.get(i);

            MetadataValue newClientMetadataValue = (MetadataValue) CayenneUtils.cloneEntity(baseClientMetadataValue);
            newClientMetadataValue.setClient(toClient);

            MetadataTag oldMetadataTag = baseClientMetadataValue.getMetadataTag();
            MetadataTag newMetadataTag = oldMetadataTag;
            if (oldMetadataTag != null && oldMetadataTag.getClient() != null && !toClient.equals(oldMetadataTag.getClient())) {
                newMetadataTag = getMetadataTag(oldMetadataTag);
            }
            newClientMetadataValue.setMetadataTag(newMetadataTag);
        }
        return toClient;
    }

    private void cloneAllForms(Client fromClient, Client toClient) {
        if (fromClient != null && toClient != null) {
            Object[] forms = fromClient.getForms().toArray();
            for (int i = 0; i < forms.length; i++ ) {
                Form form = (Form) forms[i];
                cloneForm(form, toClient);
            }
        }
    }

    /**
     * Given a form, create a copy and attach to given client. (not committed).
     *
     * @param oldForm
     * @param toClient
     */
    private Form cloneForm(Form oldForm, Client toClient) {
        if (oldForm != null && toClient != null) {
            Form newForm = (Form) CayenneUtils.cloneEntity(oldForm);
            newForm.setClient(toClient);
            newForm.setClientFormCode(createFormCode(toClient, oldForm));
            newForm.setFormName(getClientUniqueFormName(toClient, oldForm.getFormName()));
            newForm.setPortal(oldForm.getPortal());

            cloneFormProperties(oldForm, newForm, toClient);

            Template oldTemplate = oldForm.getTemplate();
            Template newTemplate = oldTemplate;
            // we can simply re-use the template if and only if the template is shared and does not belong to a client
            if (Boolean.TRUE.equals(oldTemplate.getSharedFlag()) && oldTemplate.getClient() != null && oldForm.getClient().getId().longValue() == oldTemplate.getClient().getId().longValue()) {
                // shared template belonging to the client can be retrieved from the pre-cloned set of shared templates
                newTemplate = getSharedTemplate(oldTemplate);
            }
            else if (!Boolean.TRUE.equals(oldTemplate.getSharedFlag())) {
                // non-shared template needs to be cloned
                newTemplate = cloneTemplate(oldTemplate, toClient);
            }
            newForm.setTemplate(newTemplate);

            // Only keep contact and delivery details if it's the same client.
            if (!oldForm.getClient().equals(toClient)) {
                newForm.setDeliveryProd(null);
                newForm.setDeliveryTest(null);
                newForm.setFormAdminManager(null);
            }

            cloneFormSpecifiedAttachments(oldForm, newForm, toClient);
            cloneFormMetadata(oldForm, newForm, toClient);

            return newForm;
        }
        return null;
    }

    private List<Template> cloneSharedTemplates(Client fromClient, Client toClient) {
        List<Template> result = new ArrayList<Template>();

        TemplateDao templateDao = new TemplateDao();
        List<Template> oldTemplateList = templateDao.getSharedTemplatesForClient(fromClient.getId().toString());

        if (oldTemplateList != null) {
           for (int i = 0; i < oldTemplateList.size(); i++) {
               Template oldTemplate = oldTemplateList.get(i);
               Template newTemplate = cloneTemplate(oldTemplate, toClient);

               result.add(newTemplate);
           }
        }
        return result;
    }

    /**
     * Given a template, create a copy for the given client. (part of a transaction).
     *
     * @param oldTemplate
     * @param toClient
     */
    private Template cloneTemplate(Template oldTemplate, Client toClient) {
        Template newTemplate = (Template) CayenneUtils.cloneEntity(oldTemplate);
        newTemplate.setClient(toClient);

        // without this, the copy process does not work
        commitChanges();

        // clone template metadata
        cloneTemplateMetadata(oldTemplate, newTemplate, toClient);

        // clone template versions
        cloneAllTemplateVersions(oldTemplate, newTemplate, toClient);

        // clone template attachments
        cloneTemplateSpecifiedAttachments(oldTemplate, newTemplate, toClient);

        return newTemplate;
    }

    private void cloneAllTemplateVersions(Template fromTemplate, Template toTemplate, Client toClient) {
        TemplateDao templateDao = new TemplateDao();
        List oldTemplateVersions = templateDao.getTemplateVersions(fromTemplate);
        if (oldTemplateVersions != null) {
            TemplateVersion oldCurrentVersion = fromTemplate.getCurrentVersion();
            for (int i = 0; i < oldTemplateVersions.size(); i++) {
                TemplateVersion oldTemplateVersion = (TemplateVersion) oldTemplateVersions.get(i);
                TemplateVersion newTemplateVersion = cloneTemplateVersion(oldTemplateVersion, toTemplate, toClient);

                // check whether we've just cloned the template's current version
                if (oldTemplateVersion.getId().equals(oldCurrentVersion.getId())) {
                    toTemplate.setCurrentVersion(newTemplateVersion);
                }
            }
        }
    }

    /**
     * Create a copy of all the specified metadata and attach them to the given client (uncommitted).
     *
     * @param fromClient the client containing the metadata values to be copied
     * @param toClient the client to copy the metadata values to
     * @return
     */
    private Template cloneTemplateMetadata(final Template fromTemplate, Template toTemplate, Client toClient) {
        List clientMetadataValues = fromTemplate.getMetadataValues();
        for (int i = 0; i < clientMetadataValues.size(); i++) {
            MetadataValue baseTemplateMetadataValue = (MetadataValue) clientMetadataValues.get(i);

            MetadataValue newTemplateMetadataValue = (MetadataValue) CayenneUtils.cloneEntity(baseTemplateMetadataValue);
            newTemplateMetadataValue.setTemplate(toTemplate);

            MetadataTag oldMetadataTag = baseTemplateMetadataValue.getMetadataTag();
            MetadataTag newMetadataTag = oldMetadataTag;
            if (oldMetadataTag != null && oldMetadataTag.getClient() != null && !toClient.equals(oldMetadataTag.getClient())) {
                newMetadataTag = getMetadataTag(oldMetadataTag);
            }
            newTemplateMetadataValue.setMetadataTag(newMetadataTag);
        }
        return toTemplate;
    }

    private TemplateVersion cloneTemplateVersion(TemplateVersion fromTemplateVersion, Template toTemplate, Client toClient) {
        TemplateVersion newTemplateVersion = (TemplateVersion) CayenneUtils.cloneEntity(fromTemplateVersion);
        newTemplateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_READY);
        newTemplateVersion.setTemplate(toTemplate);

        // schema
        SchemaSeed oldSchemaSeed = fromTemplateVersion.getSchema();
        SchemaSeed newSchemaSeed = oldSchemaSeed;
        if (oldSchemaSeed != null && oldSchemaSeed.getClient() != null) {
            newSchemaSeed = cloneSchemaSeed(oldSchemaSeed, toClient, newSchemaSeeds);
        }
        newTemplateVersion.setSchema(newSchemaSeed);

        // template data
        TemplateVersionData oldTemplateVersionData = fromTemplateVersion.getTemplateVersionData();
        oldTemplateVersionData.getFileData();
        TemplateVersionData newTemplateVersionData = cloneTemplateVersionData(oldTemplateVersionData);

        newTemplateVersionData.setTemplateVersion(newTemplateVersion);
        newTemplateVersion.setTemplateVersionData(newTemplateVersionData);

        // XML input version
        XmlInputVersion oldXmlInputVersion = fromTemplateVersion.getXmlInputVersion();
        XmlInputVersion newXmlInputVersion = oldXmlInputVersion;
        if (oldXmlInputVersion != null
            && oldXmlInputVersion.getSchema() != null
            && oldXmlInputVersion.getSchema().getClient() != null
            && !oldXmlInputVersion.getSchema().getClient().equals(toClient)) {
            String versionName = oldXmlInputVersion.getVersionName();
            newXmlInputVersion = getXmlInputVersion(newSchemaSeed, versionName);
        }
        newTemplateVersion.setXmlInputVersion(newXmlInputVersion);

        return newTemplateVersion;
    }

    private TemplateVersionData cloneTemplateVersionData(TemplateVersionData fromTemplateVersionData) {
        TemplateVersionData newTemplateVersionData = (TemplateVersionData) CayenneUtils.cloneEntity(fromTemplateVersionData);

        return newTemplateVersionData;
    }

    private List<SchemaConfigMap> cloneSchemaConfigMap(List<SchemaConfigMap> fromConfigMapList, SchemaSeed toSchemaSeed) {
        List<SchemaConfigMap> newConfigMapList = new ArrayList<SchemaConfigMap>();

        for (int i = 0; i < fromConfigMapList.size(); i++) {
            SchemaConfigMap oldConfigMap = fromConfigMapList.get(i);

            SchemaConfigMap newConfigMap = (SchemaConfigMap) CayenneUtils.cloneEntity(oldConfigMap);
            newConfigMap.setSchema(toSchemaSeed);

            newConfigMapList.add(newConfigMap);
        }

        return newConfigMapList;
    }

    private List<PropertyTypeMap> clonePropertyTypeMap(List<PropertyTypeMap> fromPropertyMapList, SchemaSeed toSchemaSeed, Client toClient) {
        List<PropertyTypeMap> newPropertyMapList = new ArrayList<PropertyTypeMap>();

        System.out.println(fromPropertyMapList.size());
        for (int i = 0; i < fromPropertyMapList.size(); i++) {
            System.out.println(fromPropertyMapList.size() + " i: " + i);
            PropertyTypeMap oldPropertyMap = fromPropertyMapList.get(i);

            System.out.println(fromPropertyMapList.size() + " i: " + i);
            PropertyTypeMap newPropertyMap = (PropertyTypeMap) CayenneUtils.cloneEntity(oldPropertyMap);
            System.out.println(fromPropertyMapList.size() + " i: " + i);
            newPropertyMap.setSchema(toSchemaSeed);
            System.out.println(fromPropertyMapList.size() + " i: " + i);

            PropertyType oldPropertyType = oldPropertyMap.getPropertyType();
            PropertyType newPropertyType = oldPropertyType;
            if (oldPropertyType.getClient() != null && !toClient.equals(oldPropertyType.getClient())) {
                newPropertyType = getPropertyType(oldPropertyType);
            }
            System.out.println(fromPropertyMapList.size() + " i: " + i);

            // since we previously cloned all property types necessary, the property type should be found for the target client
            newPropertyMap.setPropertyType(newPropertyType);


            newPropertyMapList.add(newPropertyMap);
        }

        return newPropertyMapList;
    }

    private XmlInputVersion cloneXmlInputVersion(XmlInputVersion fromInputVersion, SchemaSeed toSchemaSeed, Client toClient) {
        XmlInputVersion newInputVersion = (XmlInputVersion) CayenneUtils.cloneEntity(fromInputVersion);
        newInputVersion.setSchema(toSchemaSeed);

        List<XmlInputMap> oldXmlInputMap = fromInputVersion.getXmlInputMap();
        cloneXmlInputMap(oldXmlInputMap, newInputVersion);

        return newInputVersion;
    }

    private XmlInputVersion getXmlInputVersion(SchemaSeed toSchemaSeed, String versionName) {
        if (toSchemaSeed == null || StringUtils.isEmpty(versionName)) {
            return null;
        }

        List<XmlInputVersion> newXmlInputVersions = toSchemaSeed.getXmlInputVersions();
        for (XmlInputVersion xmlInputVersion: newXmlInputVersions) {
            if (versionName.equals(xmlInputVersion.getVersionName())) {
                return xmlInputVersion;
            }
        }

        // not found
        return null;
    }

    private List<XmlInputMap> cloneXmlInputMap(List<XmlInputMap> fromInputMapList, XmlInputVersion toVersion) {
        List<XmlInputMap> newInputMapList = new ArrayList<XmlInputMap>();

        for (int i = 0; i < fromInputMapList.size(); i++) {
            XmlInputMap oldInputMap = fromInputMapList.get(i);

            XmlInputMap newInputMap = (XmlInputMap) CayenneUtils.cloneEntity(oldInputMap);
            newInputMap.setXmlInputVersion(toVersion);

            newInputMapList.add(newInputMap);
        }

        return newInputMapList;
    }

    /**
     * Create a copy of all the specified attachments from fromTemplate add them to toTemplate.
     *
     * @param fromTemplate
     * @param toTemplate
     * @param toClient
     * @return toTemplate
     */
    private Template cloneTemplateSpecifiedAttachments(final Template fromTemplate, Template toTemplate, Client toClient) {
        List attachments = fromTemplate.getSpecifiedAttachments();
        for (int i = 0; i < attachments.size(); i++) {
            SpecifiedAttachment baseAttachment = (SpecifiedAttachment) attachments.get(i);

            SpecifiedAttachment newAttachment = (SpecifiedAttachment) CayenneUtils.cloneEntity(baseAttachment);
            newAttachment.setTemplate(toTemplate);

            DocumentType oldDocumentType = baseAttachment.getDocumentType();
            DocumentType newDocumentType = oldDocumentType;
            if (oldDocumentType.getClient() != null) {
                newDocumentType = getDocumentType(oldDocumentType);
            }
            newAttachment.setDocumentType(newDocumentType);
        }
        return toTemplate;
    }

    /**
     * Create a copy of all the specified attachments from fromForm add them to toForm.
     *
     * @param fromForm
     * @return toForm.
     */
    private Form cloneFormSpecifiedAttachments(final Form fromForm, Form toForm, Client toClient) {
        List attachments = fromForm.getSpecifiedAttachments();
        for (int i = 0; i < attachments.size(); i++) {
            SpecifiedAttachment baseAttachment = (SpecifiedAttachment) attachments.get(i);

            SpecifiedAttachment newAttachment = (SpecifiedAttachment) CayenneUtils.cloneEntity(baseAttachment);
            newAttachment.setForm(toForm);

            DocumentType oldDocumentType = baseAttachment.getDocumentType();
            DocumentType newDocumentType = oldDocumentType;
            if (oldDocumentType.getClient() != null) {
                newDocumentType = getDocumentType(oldDocumentType);
            }
            newAttachment.setDocumentType(newDocumentType);
        }
        return toForm;
    }

    /**
     * Create a copy of all the specified attachments and attach them to the given form.
     *
     * @param toForm
     * @return
     */
    private Form cloneFormProperties(final Form fromForm, Form toForm, Client toClient) {
        List formProperties = fromForm.getFormProperties();
        for (int i = 0; i < formProperties.size(); i++) {
            FormProperty baseFormProperty = (FormProperty) formProperties.get(i);

            FormProperty newFormProperty = (FormProperty) CayenneUtils.cloneEntity(baseFormProperty);
            newFormProperty.setForm(toForm);

            PropertyType oldPropertyType = baseFormProperty.getPropertyType();
            PropertyType newPropertyType = oldPropertyType;
            if (oldPropertyType.getClient() != null && !toClient.equals(oldPropertyType.getClient())) {
                newPropertyType = getPropertyType(oldPropertyType);
            }
            newFormProperty.setPropertyType(newPropertyType);
        }
        return toForm;
    }

    /**
     * Create a copy of all the specified attachments and attach them to the given form.
     *
     * @param toForm
     * @return
     */
    private Form cloneFormMetadata(final Form fromForm, Form toForm, Client toClient) {
        List formMetadataValues = fromForm.getFormMetadataValues();
        for (int i = 0; i < formMetadataValues.size(); i++) {

            MetadataValue baseFormMetadataValue = (MetadataValue) formMetadataValues.get(i);

            MetadataValue newFormMetadataValue = (MetadataValue) CayenneUtils.cloneEntity(baseFormMetadataValue);
            newFormMetadataValue.setForm(toForm);

            MetadataTag oldMetadataTag = baseFormMetadataValue.getMetadataTag();
            MetadataTag newMetadataTag = oldMetadataTag;
            if (oldMetadataTag != null && oldMetadataTag.getClient() != null && !toClient.equals(oldMetadataTag.getClient())) {
                newMetadataTag = getMetadataTag(oldMetadataTag);
            }
            newFormMetadataValue.setMetadataTag(newMetadataTag);
        }
        return toForm;
    }

    /**
     * Append a version number starting at 2 to the document type code until a unique code has been generated
     */
    private String createDocumentTypeCode(String oldCode, String clientId) {
        DocumentTypeDao documentTypeDao = new DocumentTypeDao();
        String newCode = oldCode;
        for (int i = 2;; i++) {
            List existingDocumentTypes = documentTypeDao.getDocumentTypeByCode(newCode, clientId);
            if (existingDocumentTypes.isEmpty()) {
                return newCode;
            }
            newCode = oldCode + i;
        }
    }

    /**
     * Append a version number starting at 2 to the document type code until a unique code has been generated
     */
    private String createDocumentTypeName(String oldName, String clientId) {
        DocumentTypeDao documentTypeDao = new DocumentTypeDao();
        String newName = oldName;
        for (int i = 2;; i++) {
            List existingDocumentTypes = documentTypeDao.getDocumentTypeByName(newName, clientId);
            if (existingDocumentTypes.isEmpty()) {
                return newName;
            }
            newName = oldName + i;
        }
    }

    /**
     * Append a version number starting at 2 on the name if a form already exists for the given
     * client with the given name. I.e try 2, then 3 until it's unique.
     *
     */
    private String getClientUniqueFormName(Client client, String name) {
        FormDao formDao = new FormDao();
        String uniqueName = name;
        for (int i = 2;; i++) {
            List existingForms = formDao.getFormsByName(client.getId().toString(), uniqueName);
            if (existingForms.isEmpty()) {
                return uniqueName;
            }
            uniqueName = name + " " + i;
        }
    }
}

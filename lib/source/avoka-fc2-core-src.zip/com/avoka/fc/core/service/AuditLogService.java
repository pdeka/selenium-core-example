package com.avoka.fc.core.service;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.LifecycleListener;
import org.apache.cayenne.access.DataContext;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.AuditLog;
import com.avoka.fc.core.entity.Auditable;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormProperty;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserProperty;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.RemoteUserProvider;

public class AuditLogService extends CayenneService implements LifecycleListener {

    /**
     * @see LifecycleListener#postAdd(Object)
     */
    public void postAdd(Object entity) {
    }

    /**
     * @see LifecycleListener#postLoad(Object)
     */
    public void postLoad(Object entity) {
    }

    /**
     * @see LifecycleListener#postPersist(Object)
     */
    public void postPersist(Object entity) {
        if (entity instanceof Auditable) {
            createAuditLog((Auditable) entity, AuditLog.EVENT_TYPE_CREATE);
        }
    }

    /**
     * @see LifecycleListener#postRemove(Object)
     */
    public void postRemove(Object entity) {
    }

    /**
     * @see LifecycleListener#postUpdate(Object)
     */
    public void postUpdate(Object entity) {
    }

    /**
     * @see LifecycleListener#prePersist(Object)
     */
    public void prePersist(Object entity) {
    }

    /**
     * @see LifecycleListener#preRemove(Object)
     */
    public void preRemove(Object entity) {
        if (entity instanceof Auditable) {
            createAuditLog((Auditable) entity, AuditLog.EVENT_TYPE_DELETE);
        }
    }

    /**
     * @see LifecycleListener#preUpdate(Object)
     */
    public void preUpdate(Object entity) {
        if (entity instanceof Auditable) {
            createAuditLog((Auditable) entity, AuditLog.EVENT_TYPE_UPDATE);
        }
    }

    public void createAuditLog(Auditable auditable, String eventType) {
        AuditLog auditLog = null;
        try {
            DataContext dataContext = DataContext.createDataContext(false);

            // Create audit message
            StringBuilder message = new StringBuilder();

            if (AuditLog.EVENT_TYPE_VIEW.equals(eventType)) {
                writeViewAuditMessage(auditable, message);

            } else if (AuditLog.EVENT_TYPE_CREATE.equals(eventType)) {
                writeCreateAuditMessage(auditable, message);

            } else if (AuditLog.EVENT_TYPE_DELETE.equals(eventType)) {
                writeDeleteAuditMessage(auditable, message);

            } else if (AuditLog.EVENT_TYPE_UPDATE.equals(eventType)) {
                // Don't create an audit record if there were no updates
                boolean updated = writeUpdateAuditMessage(auditable, message);
                if (!updated) {
                    return;
                }
            }

            auditLog = new AuditLog();
            dataContext.registerNewObject(auditLog);

            auditLog.setEntityName(toShortClassname(auditable));
            auditLog.setEntityOid(auditable.getId());
            auditLog.setEventType(eventType);
            auditLog.setAuditDatetime(new Date());

            // Set changed by
            String userLogin = RemoteUserProvider.getRemoteUser();
            if (userLogin != null) {
                auditLog.setChangedBy(userLogin);

                String clientId = RemoteUserProvider.getClientId();
                if (NumberUtils.isNumber(clientId)) {
                    auditLog.setClientOid(new Long(clientId));
                }

            } else {
                String msg = "Remote user not defined by " + auditable;
                EventLogService els = new EventLogService();
                els.logWarnEvent(msg);
                // TODO LP 07/05/2009 user is not always set correctly - this needs to be fixed and the line below removed (FCT-483)
                auditLog.setChangedBy("unknown");
            }

            auditLog.setMessage(CoreUtils.limitLength(message.toString(), 1000));

            dataContext.commitChanges();

        } catch (RuntimeException cre) {
            String context = "eventType=" + eventType + ",auditable=" + auditable + ",auditLog=" + auditLog;
            String msg = "AuditLog Error: " + cre.toString();
            throw new ApplicationException("AuditLogService", context, msg, null);
        }
    }

    // Private Methods --------------------------------------------------------

    private void writeViewAuditMessage(Auditable auditable, StringBuilder buffer) {
        buffer.append("Viewed ");
        buffer.append(toShortClassname(auditable));
        buffer.append(((auditable.getId() != null) ? " " + auditable.getId() : ""));

        // Provide additional scope information
        addName(buffer, auditable, true);

        buffer.append(".");
    }

    private void writeCreateAuditMessage(Auditable auditable, StringBuilder message) {
        message.append("Created " + toShortClassname(auditable) + " " + auditable.getId());

        // Provide additional scope information
        addName(message, auditable, false);

        StringBuilder additions = new StringBuilder();

        Map newValues = auditable.getValuesMap();

        for (Iterator i = newValues.keySet().iterator(); i.hasNext();) {
            String newName = (String) i.next();
            Object newValue =  newValues.get(newName);
            if (includeValue(newName, newValue)) {
                if (!newName.equalsIgnoreCase("password")) {
                    additions.append(",\n" + toLabel(newName) + " is '" + newValue + "'");
                }
            }
        }

        message.append(additions);
        message.append(".");
    }

    private boolean writeUpdateAuditMessage(Auditable auditable, StringBuilder buffer) {

        DataContext dataContext = DataContext.createDataContext(false);

        Auditable existing = (Auditable) DataObjectUtils.objectForPK(dataContext, auditable.getClass(), auditable.getId());

        Map existingValues = existing.getValuesMap();
        Map newValues = auditable.getValuesMap();

        buffer.append("Updated " + toShortClassname(auditable) + " " + auditable.getId());

        StringBuilder changes = new StringBuilder();
        StringBuilder additions = new StringBuilder();
        StringBuilder removals = new StringBuilder();

        // Provide additional scope information
        addName(buffer, auditable, false);

        for (Iterator i = existingValues.keySet().iterator(); i.hasNext();) {
            String existingName = (String) i.next();
            Object existingValue =  existingValues.get(existingName);

            Object newValue = newValues.get(existingName);

            if (newValue != null) {
                if (includeValue(existingName, newValue) && !newValue.equals(existingValue)) {
                    if (existingName.equalsIgnoreCase("password")) {
                        changes.append(",\n" + toLabel(existingName) + " changed");

                    } else {
                        changes.append(",\n" + toLabel(existingName) + " changed from '" + existingValue + "' to '" + newValue + "'");
                    }
                }

            } else if (existingValue != null) {
                if (includeValue(existingName, existingValue)) {
                    removals.append(",\n" + toLabel(existingName) + " removed");
                }
            }

            // Work out new values added by subtraction process
            newValues.remove(existingName);
        }

        for (Iterator i = newValues.keySet().iterator(); i.hasNext();) {
            String newName = (String) i.next();
            Object newValue =  newValues.get(newName);
            if (includeValue(newName, newValue)) {
                additions.append(", added " + toLabel(newName) + " '" + newValue + "'");
            }
        }

        buffer.append(additions);
        buffer.append(removals);
        buffer.append(changes);

        buffer.append(".");

        return (additions.length() > 0) || (changes.length() > 0) || (removals.length() > 0);
    }

    private void writeDeleteAuditMessage(Auditable auditable, StringBuilder buffer) {
        buffer.append("Deleted ");
        buffer.append(toShortClassname(auditable));
        buffer.append(((auditable.getId() != null) ? " " + auditable.getId() : ""));

        // Provide additional scope information
        addName(buffer, auditable, true);

        buffer.append(".");
    }

    private String toShortClassname(Auditable auditable) {
        return auditable.getClass().getSimpleName();
    }

    private String toLabel(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Null name parameter");
        }

        StringBuilder buffer = new StringBuilder();

        for (int i = 0, size = name.length(); i < size; i++) {
            char aChar = name.charAt(i);

            if (i == 0) {
                buffer.append(Character.toUpperCase(aChar));

            } else {
                buffer.append(aChar);

                if (i < name.length() - 1) {
                    char nextChar = name.charAt(i + 1);
                    if (Character.isLowerCase(aChar)
                        && (Character.isUpperCase(nextChar)
                            || Character.isDigit(nextChar))) {
                       buffer.append(" ");
                    }
                }
            }
        }

        return buffer.toString();
    }

    private boolean includeValue(String name, Object value) {
        if (value instanceof String || value instanceof Boolean || value instanceof Number) {
            return true;
        }
        return false;
    }

    private void addName(StringBuilder buffer, Auditable auditable, boolean isDeleted) {
        if (auditable instanceof Form) {
            Form form = (Form) auditable;
            buffer.append(" [");
            buffer.append(form.getClient().getClientName());
            buffer.append(":");
            buffer.append(form.getFormName());
            buffer.append("]");

        } else if (auditable instanceof Client) {
            buffer.append(" [");
            buffer.append(((Client)auditable).getClientName());
            buffer.append("]");

        } else if (auditable instanceof UserAccount) {
            buffer.append(" [");
            buffer.append(((UserAccount)auditable).getLoginName());
            buffer.append("]");

        } else if (auditable instanceof Template) {
            buffer.append(" [");
            buffer.append(((Template)auditable).getTemplateName());
            buffer.append("]");

        } else if (auditable instanceof ClientProperty) {
            ClientProperty clientProperty = (ClientProperty) auditable;
            buffer.append(" [");
            buffer.append(clientProperty.getClient().getClientName());
            buffer.append(":");
            buffer.append(clientProperty.getPropertyType().getName());
            buffer.append("]");

        } else if (auditable instanceof FormProperty) {
            FormProperty formProperty = (FormProperty) auditable;
            buffer.append(" [");
            buffer.append(formProperty.getForm().getClient().getClientName());
            buffer.append(":");
            buffer.append(formProperty.getForm().getFormName());
            buffer.append(":");
            buffer.append(formProperty.getPropertyType().getName());
            buffer.append("]");

        } else if (auditable instanceof UserProperty) {
            UserProperty userProperty = (UserProperty) auditable;
            if (userProperty.getValue() != null) {
                buffer.append(" [");
                buffer.append(userProperty.getValue());
                buffer.append("]");
            }
        }
    }

}

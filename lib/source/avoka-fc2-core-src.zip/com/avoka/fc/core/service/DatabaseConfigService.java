package com.avoka.fc.core.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.click.util.ClickUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.quartz.JobDetail;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.PermissionDao;
import com.avoka.fc.core.dao.PortalDao;
import com.avoka.fc.core.dao.PortalPageDao;
import com.avoka.fc.core.dao.PortalPropertyDao;
import com.avoka.fc.core.dao.PortalResourceDao;
import com.avoka.fc.core.dao.PropertyTypeDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalPage;
import com.avoka.fc.core.entity.PortalProperty;
import com.avoka.fc.core.entity.PortalResource;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.ServiceParameter;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.DeployUtils;

public class DatabaseConfigService extends CayenneService {

    public void loadConfiguration(SchedulerService schedulerService, ServletContext servletContext) {

        InputStream inputStream = null;
        try {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();

            inputStream = classLoader.getResourceAsStream("db-config.xml");

            if (inputStream != null) {
                Document document = XmlUtils.buildDocument(inputStream);

                Element rootElm = document.getDocumentElement();

                Element serviceConnectionsElm = XmlUtils.getChild(rootElm, "service-connections");
                if (serviceConnectionsElm != null) {
                    List<Element> serviceConnectionList = XmlUtils.getChildren(serviceConnectionsElm, "service-connection");
                    for (Element element : serviceConnectionList) {
                        loadServiceConnection(element);
                    }
                }

                Element serviceDefinitionsElm = XmlUtils.getChild(rootElm, "service-definitions");
                if (serviceDefinitionsElm != null) {
                    List<Element> serviceDefinitionList = XmlUtils.getChildren(serviceDefinitionsElm, "service-definition");
                    for (Element element : serviceDefinitionList) {
                        ServiceDefinition sd = loadServiceDefinition(element);

                        // If ServiceDefinition created then perform a test load
                        if (sd != null) {
                            try {
                                ServiceLocator.getServiceForName(sd.getServiceName());
                            } catch (ApplicationException ae) {
                                String msg = "Error performing test instantation of ServiceDefinition: " + sd.getServiceName();
                                getLogger().error("Could not test instantiate service definition:" + msg, ae);
                            }
                        }
                    }
                }

                if (schedulerService != null) {
                    Element jobsElm = XmlUtils.getChild(rootElm, "jobs");
                    if (jobsElm != null) {
                        List<Element> jobList = XmlUtils.getChildren(jobsElm, "job");
                        for (Element element : jobList) {
                            loadJob(element, schedulerService);
                        }
                    }
                }

                Element deploymentPropertiesElm = XmlUtils.getChild(rootElm, "deployment-properties");
                if (deploymentPropertiesElm != null) {
                    List<Element> deploymentPropertyList = XmlUtils.getChildren(deploymentPropertiesElm, "deployment-property");
                    for (Element element : deploymentPropertyList) {
                        loadDeploymentProperty(element);
                    }
                }

                Element propertyTypesElm = XmlUtils.getChild(rootElm, "property-types");
                if (propertyTypesElm != null) {
                    List<Element> propertyTypeList = XmlUtils.getChildren(propertyTypesElm, "property-type");
                    for (Element element : propertyTypeList) {
                        loadPropertyType(element);
                    }
                }

                Element portalsElm = XmlUtils.getChild(rootElm, "portals");
                if (portalsElm != null) {
                    List<Element> portalList = XmlUtils.getChildren(portalsElm, "portal");
                    for (Element element : portalList) {
                        loadPortal(element, servletContext);
                    }
                }

            }

        } finally {
            IOUtils.closeQuietly(inputStream);
        }
    }

    // Private Methods --------------------------------------------------------

    private void loadServiceConnection(Element element) {
        String name = element.getAttribute("name");

        if (StringUtils.isNotBlank(name)) {
            if (getServiceConnectionForName(name) == null) {

                ServiceConnection sc = new ServiceConnection();
                getDataContext().registerNewObject(sc);

                sc.setName(name);

                sc.setEndpointType(getChildValue(element, "endpoint-type"));
                sc.setEndpointValue(getChildValue(element, "endpoint-value"));
                sc.setServerType(getChildValue(element, "server-type"));
                sc.setTransport(getChildValue(element, "transport"));
                sc.setUsername(getChildValue(element, "username"));
                sc.setPassword(getChildValue(element, "password"));

                commitChanges();
            }

        } else {
            getLogger().warn("ServiceConnection name is blank");
        }
    }

    private ServiceDefinition loadServiceDefinition(Element element) {
        String name = element.getAttribute("name");

        if (StringUtils.isNotBlank(name)) {

            if (getServiceDefinitionForName(name) == null) {

                // Attempt test load of service class
                final String classname = getChildValue(element, "classname");
                try {
                    Thread.currentThread().getContextClassLoader().loadClass(classname);
                } catch (Exception e) {
                    getLogger().error("ServiceDefinition class not found: " + classname, e);
                    return null;
                }

                // Create the service definition
                ServiceDefinition sd = new ServiceDefinition();
                getDataContext().registerNewObject(sd);

                sd.setServiceName(name);

                sd.setClassname(getChildValue(element, "classname"));
                sd.setDescription(getChildValue(element, "description"));
                sd.setServiceType(getChildValue(element, "service-type"));
                String value = getChildValue(element, "service-type-default");
                if (value != null && value.trim().equalsIgnoreCase("true")) {
                    DaoFactory.getServiceDefinitionDao().setDefaultType(sd);
                }

                // Set the service connection
                String connectionName = getChildValue(element, "connection-name");
                if (connectionName != null) {
                    ServiceConnection sc = getServiceConnectionForName(connectionName);
                    if (sc != null) {
                        sd.setConnection(sc);

                    } else {
                        getLogger().warn("ServiceConnection not found: " + connectionName);
                    }
                }

                // Load parameter names
                Element serviceParametersElm = XmlUtils.getChild(element, "service-parameters");
                if (serviceParametersElm != null) {
                    List<Element> serviceParameterList = XmlUtils.getChildren(serviceParametersElm, "service-parameter");
                    for (Element serviceParameterElement : serviceParameterList) {
                        ServiceParameter sp = createServiceParameter(serviceParameterElement);
                        if (sp != null) {
                            sd.addToParameters(sp);
                        }
                    }
                }

                commitChanges();

                return sd;
            }

        } else {
            getLogger().warn("ServiceDefinition name is blank");
        }

        return null;
    }


    private void loadJob(Element element, SchedulerService schedulerService) {
        String name = element.getAttribute("name");

        if (StringUtils.isNotBlank(name)) {

            if (!schedulerService.hasJob(name)) {
                try {
                    String classname = getChildValue(element, "classname");
                    Class jobClass = Thread.currentThread().getContextClassLoader().loadClass(classname);

                    JobDetail jobDetail = new JobDetail();

                    jobDetail.setName(name);
                    jobDetail.setDescription(getChildValue(element, "description"));
                    jobDetail.setJobClass(jobClass);

                    long repeatInterval = Long.parseLong(getChildValue(element, "interval-minutes"));

                    // Convert minutes to milliseconds
                    repeatInterval = repeatInterval * 60 * 1000;

                    if (repeatInterval == 0) {
                        // create a once-off job
                        schedulerService.scheduleJob(jobDetail, new java.util.Date(), null, 0, 0);
                    }
                    else {
                        schedulerService.scheduleJob(jobDetail, new java.util.Date(), null, -1, repeatInterval);
                    }


                } catch (Exception e) {
                    getLogger().error("Error creating job: " + name, e);
                }
            }

        } else {
            getLogger().warn("Job name is blank");
        }
    }

    private void loadDeploymentProperty(Element element) {
        String name = element.getAttribute("name");
        boolean override = "true".equalsIgnoreCase(element.getAttribute("override"));

        if (StringUtils.isNotBlank(name)) {
            String value = getChildValue(element, "value");
            if (value == null) {
                value = "";
            }

            DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();

            // If
            DeploymentProperty dp = deploymentPropertyDao.getProperty(name);

            if (dp != null) {
                if (override || StringUtils.isBlank(dp.getValue())) {
                    dp.setValue(value);

                    String type = getChildValue(element, "type");
                    type = (type !=  null) ? type : "String";
                    dp.setType(type);

                    String description = getChildValue(element, "description");
                    dp.setDescription(description);

                    commitChanges();
                }

            } else {
                dp = new DeploymentProperty();

                dp.setName(name);
                dp.setValue(value);

                String type = getChildValue(element, "type");
                type = (type !=  null) ? type : "String";
                dp.setType(type);

                String description = getChildValue(element, "description");
                dp.setDescription(description);

                registerNewObject(dp);

                commitChanges();
            }

        } else {
            getLogger().warn("DeploymentProperty name is blank");
        }
    }

    private void loadPermission(Portal portal, Element element) {
        if (portal == null) {
            getLogger().warn("Portal is null");
            return;
        }

        String name = element.getAttribute("name");

        if (StringUtils.isBlank(name)) {
            getLogger().warn("Permission name is blank");
            return;
        }

        PermissionDao permissionDao = DaoFactory.getPermissionDao();

        Permission permission = permissionDao.getPermissionByName(name);
        if (permission == null) {
            permission = new Permission();

            permission.setPermissionName(name);
            permission.setPortal(portal);

            registerNewObject(permission);

            commitChanges();
        }
    }

    private void loadPropertyType(Element element) {
        String name = element.getAttribute("name");

        if (StringUtils.isBlank(name)) {
            getLogger().warn("PropertyType name is blank");
            return;
        }

        final String scope = getChildValue(element, "scope");
        if (StringUtils.isBlank(scope)) {
            getLogger().warn("PropertyType scope is blank");
            return;
        }

        PropertyTypeDao propertyTypeDao = DaoFactory.getPropertyTypeDao();

        PropertyType pt = propertyTypeDao.getPropertyByName(name, scope);
        if (pt == null) {
            pt = new PropertyType();

            pt.setName(name);
            pt.setScope(scope);

            String dataType = getChildValue(element, "data-type");
            dataType = (dataType !=  null) ? dataType : PropertyType.DATA_TYPE_String;
            pt.setDataType(dataType);

            String description = getChildValue(element, "description");
            pt.setDescription(description);

            registerNewObject(pt);

            commitChanges();
        }
    }

    private void loadPortal(Element element, ServletContext servletContext) {
        String name = element.getAttribute("name");

        if (StringUtils.isBlank(name)) {
            getLogger().warn("Portal name is blank");
            return;
        }

        final String contextPath = getChildValue(element, "context-path");
        if (StringUtils.isBlank(contextPath)) {
            getLogger().warn("Portal context path is blank");
            return;
        }

        PortalDao portalDao = DaoFactory.getPortalDao();

        Portal p = portalDao.getPortalByName(name);
        if (p == null) {
            p = portalDao.getPortalByContextPath(contextPath);
        }
        if (p == null) {
            p = new Portal();

            p.setName(name);
            p.setContextPath(contextPath);

            String description = getChildValue(element, "description");
            p.setDescription(description);

            boolean defaultFlag = false;
            String defaultFlagString = getChildValue(element, "default-flag");
            if (defaultFlagString != null && defaultFlagString.trim().equalsIgnoreCase("true")) {
                defaultFlag = true;
            }
            p.setDefaultFlag(defaultFlag);

            boolean editableFlag = false;
            defaultFlagString = getChildValue(element, "editable-flag");
            if (defaultFlagString != null && defaultFlagString.trim().equalsIgnoreCase("true")) {
                editableFlag = true;
            }
            p.setEditableFlag(editableFlag);

            registerNewObject(p);
            commitChanges();

            if (defaultFlag) {
                portalDao.setDefaultPortal(p);
            }
        }

        Element portalPagesElm = XmlUtils.getChild(element, "portal-pages");
        List<Element> portalPageList = XmlUtils.getChildren(portalPagesElm, "portal-page");
        for (Element portalPageElement : portalPageList) {
            loadPortalPage(p, portalPageElement, servletContext);
        }
        commitChanges();

        // Lookup portal resources under the "resources" folder
        String resourceDirectory = "resources";
        List<String> resources = new DeployUtils().findResources(resourceDirectory).getResources();
        for (String resourcePath : resources) {
            loadPortalResource(p, resourcePath, servletContext);
        }
        commitChanges();

        Element portalPropertyElm = XmlUtils.getChild(element, "portal-properties");
        if (portalPropertyElm != null) {
            List<Element> portalPropertyList = XmlUtils.getChildren(portalPropertyElm, "portal-property");
            for (Element portalPropertyElement : portalPropertyList) {
                loadPortalProperty(p, portalPropertyElement, servletContext);
            }
        }
        commitChanges();

        if (p.getOfflineSubmissionForm() == null) {
            OfflineSubmissionForm offlineSubmissionForm = getDefaultOfflineSubmissionForm();
            if (offlineSubmissionForm != null) {
                p.setOfflineSubmissionForm(offlineSubmissionForm);
            }
            commitChanges();
        }

        Element permissionsElm = XmlUtils.getChild(element, "permissions");
        if (permissionsElm != null) {
            List<Element> permissionList = XmlUtils.getChildren(permissionsElm, "permission");
            for (Element permissionElement : permissionList) {
                loadPermission(p, permissionElement);
            }
            commitChanges();
        }
    }

    private void loadPortalPage(Portal portal, Element element, ServletContext servletContext) {
        String name = element.getAttribute("name");

        if (StringUtils.isBlank(name)) {
            getLogger().warn("Page name is blank");
            return;
        }

        String description = element.getAttribute("description");

        String path = getChildValue(element, "path");
        if (StringUtils.isBlank(path)) {
            getLogger().warn("Page path is blank");
            return;
        }

        PortalPageDao portalPageDao = DaoFactory.getPortalPageDao();
        PortalPage pp = portalPageDao.getPortalPageByName(portal.getId(), name);
        if (pp == null) {
            pp = new PortalPage();
            pp.setName(name);
            pp.setPath(path);
            pp.setPortal(portal);
            pp.setDescription(description);
            registerNewObject(pp);
        }

        InputStream is = null;
        byte[] content = null;

        try {
            is = servletContext.getResourceAsStream("/" + path);
            if (is != null) {
                content = IOUtils.toByteArray(is);

                // If this is the first time application starts up, set content
                // to content on file system
                if (pp.getContent() == null) {
                    pp.setContent(content);
                }

                // Always update the ContentBase so users have an option to
                // rollback to the original content
                pp.setContentBase(content);
            }
        } catch (IOException e) {
            getLogger().error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(is);
        }
    }

    private void loadPortalResource(Portal portal, String resourcePath, ServletContext servletContext) {
        InputStream inputStream = null;
        try {
            byte[] content = null;
            inputStream = ClickUtils.getResourceAsStream(resourcePath, DatabaseConfigService.class);

            if (inputStream != null) {
                content = IOUtils.toByteArray(inputStream);
                if (!resourcePath.startsWith("/")) {
                    resourcePath = "/" + resourcePath;
                }
            }

            PortalResourceDao portalResourceDao = DaoFactory.getPortalResourceDao();
            PortalResource pr = portalResourceDao.getPortalResourceByPath(portal.getId(), resourcePath);
            if (pr == null) {
                pr = new PortalResource();
                pr.setPath(resourcePath);
                pr.setPortal(portal);

                // If this is the first time application starts up, set content to content on file system
                pr.setContent(content);
                registerNewObject(pr);
            }
            // Always update the ContentBase so users have an option to rollback to the original content
            pr.setContentBase(content);

        } catch (IOException e) {
            getLogger().error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
    }

    private void loadPortalProperty(Portal portal, Element element, ServletContext servletContext) {
        String name = element.getAttribute("name");

        if (StringUtils.isBlank(name)) {
            getLogger().warn("Property name is blank");
            return;
        }

        PortalPropertyDao portalPropertyDao = DaoFactory.getPortalPropertyDao();
        PortalProperty pp = portalPropertyDao.getPortalPropertyByName(portal.getId(), name);
        if (pp == null) {
            pp = new PortalProperty();
            pp.setName(name);
            pp.setPortal(portal);
            pp.setDescription(getChildValue(element, "description"));
            pp.setType(getChildValue(element, "type"));
            pp.setValue(getChildValue(element, "value"));
            boolean required = BooleanUtils.toBoolean(getChildValue(element, "required-flag"));
            pp.setRequiredFlag(required);
            pp.setListValues(getChildValue(element, "list-values"));
            registerNewObject(pp);
        }
    }

    private ServiceParameter createServiceParameter(Element element) {
        String name = element.getAttribute("name");
        if (StringUtils.isNotBlank(name)) {
            ServiceParameter sp = new ServiceParameter();
            registerNewObject(sp);

            sp.setName(name);

            sp.setDescription(getChildValue(element, "description"));
            sp.setValue(getChildValue(element, "value"));
            sp.setType(getChildValue(element, "type"));
            sp.setListValues(getChildValue(element, "list-values"));

            return sp;

        } else {
            getLogger().warn("ServiceParameter name is blank");
            return null;
        }
    }

    private ServiceDefinition getServiceDefinitionForName(String serviceName) {

        SelectQuery query = new SelectQuery(ServiceDefinition.class);

        query.andQualifier(ExpressionFactory.matchExp(ServiceDefinition.SERVICE_NAME_PROPERTY, serviceName));

        List list = performQuery(query);

        if (!list.isEmpty()) {
            return (ServiceDefinition) list.get(0);

        } else {
            return null;
        }
    }

    private ServiceConnection getServiceConnectionForName(String name) {

        SelectQuery query = new SelectQuery(ServiceConnection.class);

        query.andQualifier(ExpressionFactory.matchExp(ServiceConnection.NAME_PROPERTY, name));

        java.util.List list = performQuery(query);

        if (!list.isEmpty()) {
            return (ServiceConnection) list.get(0);

        } else {
            return null;
        }
    }


    private static String getChildValue(Element parent, String childName) {
        String value = XmlUtils.getChildValue(parent, childName);
        return (value != null) ? value.trim() : null;
    }

    private OfflineSubmissionForm getDefaultOfflineSubmissionForm() {
        OfflineSubmissionForm offlineSubmissionForm = new OfflineSubmissionForm();
        byte[] templateFileData = getResourceBytes("META-INF/offlinesubmit/offlineSubmitForm.pdf");
        byte[] seedXmlData = getResourceBytes("META-INF/offlinesubmit/offlineSubmitSeed.xml");
        if (templateFileData != null && seedXmlData != null) {
            registerNewObject(offlineSubmissionForm);
            offlineSubmissionForm.setBodyTextError("An error has occurred during form submission.\nPlease click the button below to view the error details.");
            offlineSubmissionForm.setBodyTextSaved("Your form has been saved to FormCenter.\nPlease click the button below to go to the confirmation page and review your submission.");
            offlineSubmissionForm.setBodyTextSubmitted("Thank you, your form has been submitted to FormCenter.\nPlease note this document is not a receipt. To view a receipt please click the button below to go to the confirmation page.");
            offlineSubmissionForm.setBodyTextPayment("Your form has been submitted to FormCenter.\nTo complete your submission, please click the button below to go to the payment page.");
            offlineSubmissionForm.setBodyTextAttachments("Your form has been submitted to FormCenter.\nTo complete your submission, please click the button below to go to the attachments page.");
            offlineSubmissionForm.setButtonTextError("Go To FormCenter");
            offlineSubmissionForm.setButtonTextSaved("Go To FormCenter");
            offlineSubmissionForm.setButtonTextSubmitted("Go To Submission Confirmation Page");
            offlineSubmissionForm.setButtonTextPayment("Go To Payment Page");
            offlineSubmissionForm.setButtonTextAttachments("Go To Attachments Page");
            offlineSubmissionForm.setFormTemplate(templateFileData);
            offlineSubmissionForm.setHeaderBgColor("0,102,153");
            offlineSubmissionForm.setHeaderFontColor("255,255,255");
            offlineSubmissionForm.setHeaderText("FormCenter");
            offlineSubmissionForm.setPublishStatus(TemplateVersion.PUBLISH_STATUS_READY);
            offlineSubmissionForm.setSchemaFileName("offlineSubmitSeed.xml");
            offlineSubmissionForm.setSchemaXmlData(seedXmlData);
            offlineSubmissionForm.setTemplateFileName("offlineSubmitForm.pdf");

            return offlineSubmissionForm;
        }
        else {
            return null;
        }
    }

    private byte[] getResourceBytes(String name) {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();

        InputStream inputStream = null;
        try {
            inputStream = classLoader.getResourceAsStream(name);
            if (inputStream == null) {
                inputStream = getClass().getResourceAsStream(name);
            }

            return IOUtils.toByteArray(inputStream);
        }
        catch (IOException ioe) {
            ErrorLogService errorLogService = new ErrorLogService();
            errorLogService.logException(ioe, false);
            return null;
        }
        finally {
            IOUtils.closeQuietly(inputStream);
        }
    }


}

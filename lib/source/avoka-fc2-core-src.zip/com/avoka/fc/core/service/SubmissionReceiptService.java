package com.avoka.fc.core.service;

import com.avoka.fc.core.entity.Submission;

public interface SubmissionReceiptService {

    /**
     * Create the PDF Receipt and store it in the submission
     *
     * @param submission - the submission for which a receipt is to be created
     */
    public void createReceiptPdf(Submission submission);

    /**
     * Return the number of submissions for the submission receipt job to process per run.
     *
     * @return number of submissions for the submission receipt job to process per run
     */
    public int getNumberSubmissionsToProcess();

    /**
     * Set the number of submissions for the submission receipt job to process per run.
     *
     * @param numberSubmissionsToProcess the number of submissions for the submission receipt job to process per run
     */
    public void setNumberSubmissionsToProcess(int numberSubmissionsToProcess);
}

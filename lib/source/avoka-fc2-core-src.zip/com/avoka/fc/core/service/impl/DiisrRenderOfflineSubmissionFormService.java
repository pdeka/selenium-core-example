package com.avoka.fc.core.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.w3c.dom.Element;

import com.avoka.core.util.CoreUtils;
import com.avoka.core.util.FileUtils;
import com.avoka.core.util.ServletUtils;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.RenderOfflineSubmissionFormService;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.FormUtils;

public class DiisrRenderOfflineSubmissionFormService extends DiisrRenderService
        implements RenderOfflineSubmissionFormService {

    /** The form xml seed data request parameter. */
    public static final String PARAM_READER_EXTEND = "readerExtend";

    /** The target submission URL to be rendered in the form, e.g. /servlet/SubmissionServlet */
    public static final String PARAM_SUBMIT_URL = "submitURL";

    /** The target submission web root to be rendered in the form, e.g. http://localhost:8080/test/ */
    public static final String PARAM_SUBMIT_WEB_ROOT = "submitWebRoot";

    public void renderOfflineSubmissionForm(
            final OfflineSubmissionForm offlineSubmissionForm, final String xmlData,
            final HttpServletRequest request, final HttpServletResponse response)
            throws ApplicationException {

        getRequestParams().put(PARAM_READER_EXTEND, Boolean.FALSE.toString());
        getRequestParams().put(PARAM_SUBMIT_URL, getTargetServlet());
        getRequestParams().put(PARAM_SUBMIT_WEB_ROOT, getApplicationWebRoot(request));

        // Perform the remote render
        remoteRender(offlineSubmissionForm, getRootXmlData(xmlData), new DiisrResponseHandler() {

            public void handleResponse(String remoteContentType, byte[] remoteByteArray) throws IOException {

                // If a HTML response an error has occurred. Otherwise set set the given headers.
                if ("text/html".equals(remoteContentType)) {
                    response.setContentType(remoteContentType);
                    response.setHeader("Content-Length", String.valueOf(remoteByteArray.length));

                    EventLogService eventLogService = new EventLogService();
                    eventLogService.logErrorEvent("Error rendering Offline Submission Form ID " + offlineSubmissionForm.getId());

                } else {
                    // Setup response headers
                    response.setContentType("application/pdf");

                    // TODO: MAE 24/4/08 - "attachment;filename" performing very poorly on Firefox
                    String filename = FileUtils.changeFileExtension(offlineSubmissionForm.getTemplateFileName(), "pdf");
                    response.setHeader("Content-Disposition", "inline;filename=" + filename);

                    ServletUtils.setNoCacheHeaders(request, response);
                }

                // Write the form to the browser
                ServletUtils.renderByteArray(request, response, remoteByteArray);
            }
        });
    }

    public void remoteRender(OfflineSubmissionForm offlineSubmissionForm,
            String xmlData,
            DiisrResponseHandler responseHandler) throws ApplicationException {

        Validate.notNull(offlineSubmissionForm, "Null offlineSubmissionForm paraemter");
        Validate.notNull(xmlData, "Null xmlData parameter");

        if (!TemplateVersion.PUBLISH_STATUS_COMPLETE.equals(offlineSubmissionForm.getPublishStatus())) {
            String context = "Offline Submission Form ID=" + offlineSubmissionForm.getId() + ",PublishStatus=" + offlineSubmissionForm.getPublishStatus();
            String userMessage = "Offline Submission Form has not published and cannot be rendered";
            String solution = "Ensure the Offline Submission Form has been published";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        // Get the base path
        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String basePath = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Render_Service_Base_Path);
        if (StringUtils.isBlank(basePath)) {
            String context = DeploymentProperty.PROPERTY_Render_Service_Base_Path + " is not defined";
            String userMessage = "Remote Render Service Base Path has not been configured";
            String solution = "Configure the DeploymentProperty: " + DeploymentProperty.PROPERTY_Render_Service_Base_Path;
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }
        basePath = basePath.replace('\\', '/');
        basePath = (basePath.startsWith("/")) ? basePath : "/" + basePath;
        basePath = (basePath.endsWith("/")) ? basePath : basePath + '/';

        final String orchestrationName = getOrchestrationName();
        if (StringUtils.isBlank(orchestrationName)) {
            String context = "orchestrationName=" + orchestrationName;
            String userMessage = "Service Definition orchestration name has not been configured";
            String solution = "Configure the Service Definition orchestration name";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        ServiceConnection serviceConnection = getServiceDefinition().getConnection();
        if (serviceConnection == null) {
            String context = "ServiceDefinition.ServiceName=" + getServiceDefinition().getServiceName();
            String userMessage = "ServiceConnection has not been configured for ServiceDefinition";
            String solution = "Configure the ServiceConnection for the ServiceDefinition";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        String password = serviceConnection.getPassword();
        if (StringUtils.isBlank(password)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection password is blank";
            String solution = "Configure the ServiceConnection Password";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        // Get the target server URL
        String requestTarget = serviceConnection.getEndpointValue();
        if (StringUtils.isBlank(requestTarget)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection EndPointValue has not been configured";
            String solution = "Configure the ServiceConnection EndPointValue";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }
        if (requestTarget.endsWith("/")) {
            requestTarget += getTargetServlet();
        } else {
            requestTarget += "/" + getTargetServlet();
        }

        // Get the template file name
        String formName = offlineSubmissionForm.getTemplateFileName();

        // Get the form path
        String formPath = basePath + OfflineSubmissionForm.OSF_PREFIX + offlineSubmissionForm.getId();

        getRequestParams().put(PARAM_SECURITY_HASH, password);
        getRequestParams().put(PARAM_FORM_NAME, formName);
        getRequestParams().put(PARAM_FORM_PATH, formPath);
        getRequestParams().put(PARAM_FORM_XML, xmlData);
        getRequestParams().put(PARAM_ORCHESTRATION_NAME, orchestrationName);

        NameValuePair[] data = new NameValuePair[getRequestParams().size()];
        Iterator<String> iterator = getRequestParams().keySet().iterator();
        int index = 0;
        while (iterator.hasNext()) {
            String name = iterator.next();
            String value = getRequestParams().get(name);
            data[index++] = new NameValuePair(name, value);
        }

        HttpClient client = new HttpClient();
        PostMethod postMethod = new PostMethod(requestTarget);

        postMethod.setRequestBody(data);

        InputStream responseStream = null;
        try {
            final int responseCode = client.executeMethod(postMethod);

            responseStream = postMethod.getResponseBodyAsStream();

            byte[] byteArray = IOUtils.toByteArray(responseStream);

            if (responseCode == HttpServletResponse.SC_OK) {

                final String contentType = postMethod.getResponseHeader("Content-Type").getValue();

                responseHandler.handleResponse(contentType, byteArray);

            } else {
                String error = new String(byteArray);
                String context = "responseCode=" + responseCode + ",requestTarget=" + requestTarget + ",formName=" + formName + ",formPath=" + formPath;
                String userMsg  = "Unknown error occured: " + error;
                throw new ApplicationException(getClass().getSimpleName(), context, userMsg, null);
            }

        } catch (UnknownHostException uhe) {
            String context = "requestTarget=" + requestTarget + ",formName=" + formName + ",formPath=" + formPath;
            String userMsg  = "Unable to connect to render Service: " + uhe.toString() + " when rendering form";
            String solution = "Check RenderService configuration and availability";
            throw new ApplicationException(getClass().getSimpleName(), uhe, context, userMsg, solution);

        } catch (IOException ioe) {
            // Log "ClientAbortException" which is a Tomcat specific exception
            if (ioe.toString().indexOf("ClientAbortException") != -1) {
                StringBuffer buffer = new StringBuffer();
                buffer.append("ClientAbortException for request ");

                EventLogService eventLogService = new EventLogService();
                eventLogService.logWarnEvent(buffer.toString());

            } else {
                String context = "requestTarget=" + requestTarget + ",formName=" + formName + ",formPath=" + formPath;
                String userMsg  = "Unknown error occured: " + ioe.toString();
                throw new ApplicationException(getClass().getSimpleName(), ioe, context, userMsg, null);
            }

        } finally {
            CoreUtils.close(responseStream);
            postMethod.releaseConnection();
        }
    }

    protected String getTargetServlet() {
        return "servlet/RenderFormServlet";
    }

    /**
     * Ensure xmlData does not contain <xfa:datasets> elements.
     */
    private String getRootXmlData(String xmlData) {

        if (xmlData.contains("<xfa:datasets")) {
            org.w3c.dom.Document document = XmlUtils.parseDocumentFromString(xmlData);
            Element dataElement = FormUtils.getRootDataElement(document);
            xmlData = XmlUtils.toString(dataElement);
        }

        return xmlData;
    }

    /**
     * Return the Process input parameter "applicationWebRoot".
     */
    private String getApplicationWebRoot(HttpServletRequest request){

        String applicationWebRoot = "http";

        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        int localHttpsPort = deploymentPropertyDao.getPropertyValueInt(DeploymentProperty.PROPERTY_HTTPS_Port);
        int port = request.getLocalPort();

        if (port == localHttpsPort) {
            applicationWebRoot += "s";
        }

        applicationWebRoot += "://" + request.getServerName() + ":" + port + request.getContextPath();

        return applicationWebRoot;
    }
}

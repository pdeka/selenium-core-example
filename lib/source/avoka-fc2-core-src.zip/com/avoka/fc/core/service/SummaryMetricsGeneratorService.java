package com.avoka.fc.core.service;

import java.util.Date;

/**
 * @author mdeandrade
 *
 */
public interface SummaryMetricsGeneratorService {

    public void calculateMetrics(Date eventDate);

    public String getStartCalcDate();

    public void setStartCalcDate(String startCalcDate);

}

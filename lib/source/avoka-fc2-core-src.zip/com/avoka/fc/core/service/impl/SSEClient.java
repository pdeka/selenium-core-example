package com.avoka.fc.core.service.impl;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.Validate;

import com.avoka.fc.core.service.VirusScanException;

public class SSEClient {

    // Response codes
    private static final String RESPONSE_ONE = "ICAP/1.0 100";
    private static final String RESPONSE_TWO = "ICAP/1.0 200";
    private static final String RESPONSE_THREE = "ICAP/1.0 201";
    private static final String RESPONSE_FOUR = "ICAP/1.0 204";
    private static final String RESPONSE_FOURTEEN = "ICAP/1.0 539";
    private static final String RESPONSE_SIXTEEN = "ICAP/1.0 558";

    private final static String SCAN_POLICY = "SCAN";

    private final String hostname;
    private final int port;

    private Socket socket = null;
    private DataOutputStream output = null;
    private BufferedReader input = null;

    private String[] results;

    // protected String preview = 4;
    private int allow = 204;

    // Constructor ------------------------------------------------------------

    /**
     * Create a Synmatic Scan Engine (SSE) client with the given hostname and port.
     *
     * @param hostname the server hostname
     * @param port the server port
     */
    public SSEClient(String hostname, int port) {
        this.hostname = hostname;
        this.port = port;
    }

    // Public Methods ---------------------------------------------------------

    /**
     * Scan the given file specified by the file name and the file byte data, returning true if the file is virus free
     * or false, if it contains a virus.
     *
     * @param fileName the name of the file
     * @param fileData the file data bytes
     * @return true if file data virus free, or false otherwise
     * @throws VirusScanException if an error occurs scanning the file
     */
    public boolean scanFile(String fileName, byte[] fileData) throws VirusScanException {

         Validate.notNull(fileName, "Null filename parameter");
         Validate.notNull(fileData, "Null fileData parameter");

        // Fixes ArrayIndexOutOfBoundsException (http://manly.avoka.com/jira/browse/FCT-593)
        if (fileData.length <= 4) {
            return true;
        }

        int returnStatus = 0;
        String serverMessage = "";

        // where file is sent to be scanned.
        try {
            connect();

            long fileLength = fileData.length;
            long long_length = 4;
            String text = "";

            int req_header = 0;

            String reqheader = "GET http://scapi.symantec.com" + "/" + fileName
                + " HTTP/1.1\r\n" + "Host: scapi.symantec.com\r\n" + "\r\n";

            String resheader = "HTTP/1.1 200 OK\r\n"
                + "Transfer-Encoding: chunked\r\n" + "\r\n";
            int res_header = reqheader.length();
            int res_body = res_header + (resheader.length());

            String header = "RESPMOD icap://" + hostname + ":" + port
                + "/AVSCAN?action=" + SCAN_POLICY + " ICAP/1.0\r\n"
                + "Host: " + hostname + ":" + port + "\r\n"
                + "Preview: 4" + "\r\n" + "Allow: " + allow + "\r\n"
                + "Encapsulated: req-hdr=" + req_header + " res-hdr="
                + res_header + " res-body=" + res_body + "\r\n" + "\r\n";

            send(header);
            send(reqheader);
            send(resheader);

            // byte[] b = convert();
            // sending 4 byte preview.
            header = "";

            header = Long.toHexString(long_length);
            header = header + "\r\n";
            send(header);

            header = "\r\n" + "0" + "\r\n" + "\r\n";
            output.write(fileData, 0, 4);
            send(header);

            // respond according the response to ScanEngine.
            header = recieve();

            if (continueCheck(header)) {

                fileLength = fileLength - 4;
                header = Long.toHexString(fileLength);
                header = header + "\r\n";
                send(header);

                output.write(fileData, 4, (int) fileLength);
                send("\r\n0\r\n\r\n");

                // Receive second message from ScanEngine.
                header = "";
                header = recieve();
                serverMessage = header.substring(0, 12);
                serverMessage = toResponseMessage(serverMessage);
                if (serverMessage.equals("virus")) {
                    header = header + recieve();
                    text = recieve();
                    header = header + text;
                }

            } else {
                returnStatus = 1;
            }

        } catch (IOException ioe) {
            String msg = "Could not connect to SSE: " + ioe.getMessage();
            String context = "hostname=" + hostname + ",port=" + port + ",fileName=" + fileName;
            throw new VirusScanException(msg, ioe, context);

        } finally {
            disconnect();
        }

        if (returnStatus != 1) {
            if (serverMessage.equals("virus")) {
                returnStatus = -1;
            }

            if (serverMessage.equals("clean")) {
                returnStatus = 0;
            }
        }

        return (returnStatus != -1);
    }

    // Private Methods --------------------------------------------------------

    private void connect() throws VirusScanException {
        try {
            InetAddress ip_address = InetAddress.getByName(hostname);
            socket = new Socket(ip_address, port);
            output = new DataOutputStream(socket.getOutputStream());
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        } catch (IOException ioe) {
            String msg = "Could not connect to SSE: " + ioe.getMessage();
            String context = "hostname=" + hostname + ",port=" + port;
            String solution = "Please ensure Symantec Scan Engine (SSE) virus scanner is available on " + hostname
                + ":" + port;
            throw new VirusScanException(msg, ioe, context, solution);
        }
    }

    private void send(String str) throws IOException {
        output.writeBytes(str);
        output.flush();
    }

    private String recieve() throws IOException {
        String value = "  ";
        String the_message = new String();
        results = new String[512];
        int array_location = 0;

        while (value.length() != 0) {
            value = input.readLine();
            the_message = the_message + value + "\n";
            results[array_location] = value;
            array_location++;
        }

        return the_message;
    }

    private void disconnect() {
        IOUtils.closeQuietly(input);
        IOUtils.closeQuietly(output);

        try {
            socket.close();
            socket = null;
        } catch (Exception exception) {
            // Ignore exception
        }
    }

    private boolean continueCheck(String server_response) {
        boolean the_return = true;

        if (server_response.length() != 12) {
            server_response = server_response.substring(0, 12);
        }

        if (server_response.equals(RESPONSE_ONE)) {
            the_return = true;

        } else {
            the_return = false;
        }

        return the_return;
    }

    private String toResponseMessage(String server_response) throws VirusScanException {
        String the_return = " ";
        if ((server_response.length()) != 12) {
            server_response = server_response.substring(0, 12);
        }

        // license is bad
        if (server_response.equals(RESPONSE_FOURTEEN) || server_response.equals(RESPONSE_SIXTEEN)) {
            the_return = "clean";

            String msg = "Note the license for Symantec Scan Engine is invalid or has expired!\n\rPlease see CGS Template code - class AVRespond for more info.";
            String context = "server_response=" + server_response;
            throw new VirusScanException(msg, context);
        }

        if (server_response.equals(RESPONSE_FOUR)) {
            the_return = "clean";
        }

        if (server_response.equals(RESPONSE_TWO)) {
            the_return = "virus";
        }

        if (server_response.equals(RESPONSE_THREE)) {
            the_return = "virus";
        }

        return the_return;
    }


}

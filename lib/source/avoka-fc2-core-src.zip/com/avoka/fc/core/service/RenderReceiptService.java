package com.avoka.fc.core.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.util.ApplicationException;

public interface RenderReceiptService {

    /**
     * Render the PDF Receipt using the given Form TemplateVersion and XML Data
     * to the response.
     *
     * @param templateVersion - the form template version to render
     * @param form - the form for which a receipt should be rendered
     * @param xmlData - the XML form data seed document
     * @param request - the users Http servlet request
     * @param response - the Http servlet response to render to
     * @param requestLog - optional request log parameter
     * @throws ApplicationException if an error occurs
     */
    public void renderReceipt(TemplateVersion templateVersion,
                              Form form,
                              String xmlData,
                              HttpServletRequest request,
                              HttpServletResponse response,
                              RequestLog requestLog)
            throws ApplicationException;

    /**
     * Return a PDF Receipt byte array rendered from the given Form
     * TemplateVersion and XML Data.
     *
     * @param templateVersion - the form template version to render
     * @param form - the form for which a receipt should be rendered
     * @param xmlData - the XML form data seed document
     * @throws ApplicationException if an error occurs
     */
    public byte[] renderReceipt(TemplateVersion templateVersion, Form form, String xmlData)
            throws ApplicationException;

}

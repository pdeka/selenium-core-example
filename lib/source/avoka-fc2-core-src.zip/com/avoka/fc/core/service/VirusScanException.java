/*
 * Copyright (c) 2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

/**
 * Provides a VirusScanning exception.
 *
 * @author medgar@avoka.com
 */
public class VirusScanException extends Exception {

    private static final long serialVersionUID = 1L;

    /** The execution context message. */
    private final String context;

    /** The exception solution message. */
    private final String solution;

    /**
     * Create a VirusScan exception with the given message and execution context.
     *
     * @param message the exception message
     * @param context the execution context
     */
    public VirusScanException(String message, String context) {
        super(message);
        this.context = context;
        this.solution = null;
    }

    /**
     * Create a VirusScan exception with the given message and execution context and solution
     *
     * @param message the exception message
     * @param context the execution context
     * @param solution the solution
     */
    public VirusScanException(String message, String context, String solution) {
        super(message);
        this.context = context;
        this.solution = solution;
    }

    /**
     * Create a VirusScan exception with the given message, cause and execution context.
     *
     * @param message the exception message
     * @param cause the cause of the exception
     * @param context the execution context
     */
    public VirusScanException(String message, Throwable cause, String context) {
        super(message, cause);
        this.context = context;
        this.solution = null;
    }

    /**
     * Create a VirusScan exception with the given message, cause and execution context.
     *
     * @param message the exception message
     * @param cause the cause of the exception
     * @param context the execution context
     * @param solution the solution
     */
    public VirusScanException(String message, Throwable cause, String context, String solution) {
        super(message, cause);
        this.context = context;
        this.solution = solution;
    }

    /**
     * Return the execution context.
     *
     * @return the execution context
     */
    public String getContext() {
        return context;
    }

    /**
     * Return the solution.
     *
     * @return the solution
     */
    public String getSolution() {
        return solution;
    }

}

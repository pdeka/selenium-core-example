package com.avoka.fc.core.service;

import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.Submission;

/**
 * Provides an service interface for LC submission delivery process.
 *
 * @author medgar@avoka.com
 */
public interface DeliveryProcessService {

    /**
     * Delivery the given submission using a LC delivery process and return the LC invocation identifier.
     *
     * @param submission the submission to deliver
     * @param deliveryDetails the submission delivery details
     * @return the LC invocation identifier
     */
    public String deliverSubmission(Submission submission, DeliveryDetails deliveryDetails);

    public void setProcessName(String processName);

}

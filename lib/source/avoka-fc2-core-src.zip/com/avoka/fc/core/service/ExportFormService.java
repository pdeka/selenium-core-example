package com.avoka.fc.core.service;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.avoka.core.xml.export.ExportManager;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.MetadataListValueDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.FormPdfParams;
import com.avoka.fc.core.entity.FormProperty;
import com.avoka.fc.core.entity.MetadataListValue;
import com.avoka.fc.core.entity.MetadataTag;
import com.avoka.fc.core.entity.MetadataValue;
import com.avoka.fc.core.entity.MetadataValueDeploy;
import com.avoka.fc.core.entity.PropertyDeploy;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.PropertyTypeMap;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.SchemaDeployMap;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.SpecifiedAttachmentDeploy;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserDeployMap;
import com.avoka.fc.core.entity.XmlInDeployMap;
import com.avoka.fc.core.entity.XmlInputMap;
import com.avoka.fc.core.entity.XmlInputVersion;

public class ExportFormService extends BaseService {

    public static final String EXPORT_Type_Form = "Form Export";

    ExportManager      _exportManager  = null;
    FC2CayenneMetaData metaDataManager = new FC2CayenneMetaData();

    public void exportForm(Form form,
            boolean allVersionsFlag,
            TemplateVersion version,
            OutputStream exportOutStream,
            String formName,
            String formDescription,
            String environmentName){
        ExportManager exportManager = new ExportManager(metaDataManager);

        exportFormData(form, exportManager, allVersionsFlag, version);

        exportManager.writeXml(exportOutStream, EXPORT_Type_Form, formName, formDescription, environmentName);
    }

    /**
     *
     * @param form
     * @param productionExportFlag
     * @param exportManager
     * @param currentVersionFlag -
     *            specifies if only the current template version should be exported.
     * @return
     */
    public ExportManager exportFormData(Form form,
            ExportManager exportManager,
            boolean allVersionsFlag,
            TemplateVersion paramVersion){

        this._exportManager = exportManager;

        Client client = form.getClient();
        _exportManager.addRow(client, true, false);

        List<ClientProperty> clientPropertiesList = client.getClientProperties();
        for (Iterator iterator = clientPropertiesList.iterator(); iterator.hasNext();) {
            ClientProperty clientProperty = (ClientProperty) iterator.next();
            PropertyType propertyType = clientProperty.getPropertyType();
            exportManager.addRow(propertyType, true, true);
            exportManager.addRow(clientProperty, false, true);
        }

        FormPdfParams pdfParams = form.getPdfParams();
        if (pdfParams != null) {
            _exportManager.addRow(pdfParams, true, true);
        }

        _exportManager.addRow(form.getDeliveryProd(), true, false);
        _exportManager.addRow(form.getDeliveryTest(), true, false);
        _exportManager.addRow(form.getPortal(), true, false);

        Template template = form.getTemplate();

        _exportManager.addRow(template, true, true);

        List<SpecifiedAttachment> specifiedAttachmentList = template.getSpecifiedAttachments();

        for (SpecifiedAttachment specifiedAttachment : specifiedAttachmentList) {
            _exportManager.addRow(specifiedAttachment, true, true);
            _exportManager.addRow(specifiedAttachment.getDocumentType(), true, true);
        }

        _exportManager.addRow(form, true, true);

        if (paramVersion != null) {
            // Used for a Promotion Export
            exportTemplateVersion(form, paramVersion, _exportManager);
        } else if (allVersionsFlag == false) {
            TemplateVersion currentVersion = template.getCurrentVersion();
            exportTemplateVersion(form, currentVersion, _exportManager);
        } else {
            List<TemplateVersion> versionList = template.getVersions();
            for (TemplateVersion templateVersion : versionList) {
                exportTemplateVersion(form, templateVersion, _exportManager);
            }
        }

        List<FormProperty> formProperties = form.getFormProperties();
        for (Iterator iterator = formProperties.iterator(); iterator.hasNext();) {
            FormProperty formProperty = (FormProperty) iterator.next();

            // This should be there by now - but lets double check;
            _exportManager.addRow(formProperty.getPropertyType(), true, true);
            _exportManager.addRow(formProperty, false, true);
        }

        // NB - This query does form & Template
        FormDao formDao = new FormDao();
        addMetaDataValues(formDao.getFormAndTemplateMetadataValues(form), _exportManager);

        // Attachments
        List<SpecifiedAttachment> formSpecifiedAttachmentList = form.getSpecifiedAttachments();
        for (SpecifiedAttachment specifiedAttachment : formSpecifiedAttachmentList) {
            _exportManager.addRow(specifiedAttachment, true, true);
            _exportManager.addRow(specifiedAttachment.getDocumentType(), true, true);
        }

        return this._exportManager;

    }

    public void exportTemplateVersion(Form form, TemplateVersion templateVersion, ExportManager exportManager){
        if (templateVersion == null) {
            return;
        }

        Template template = templateVersion.getTemplate();
        getLogger().info(
                "ExportTemplateVerion. Template =" + template.getTemplateName() + " TemplateVersion="
                        + templateVersion.getVersionNumber());
        // Get the blob (template file).
        // Don't see a way to delete the existing record if one exists!
        exportManager.addRow(templateVersion.getTemplateVersionData(), false, true);

        ServiceDefinition formRenderService = templateVersion.getFormRenderService();
        if (formRenderService != null) {
            ServiceConnection connection = formRenderService.getConnection();
            exportManager.addRow(connection, true, false);
            exportManager.addRow(formRenderService, true, false);
        }

        ServiceDefinition receiptRenderService = templateVersion.getReceiptRenderService();
        if (receiptRenderService != null) {
            exportManager.addRow(receiptRenderService.getConnection(), true, false);
            exportManager.addRow(receiptRenderService, true, false);
        }

        SchemaSeed schema = templateVersion.getSchema();
        if (schema != null) {
            addSchemaDetails(schema, exportManager);
        }

        exportManager.addRow(templateVersion, true, true);

        // deployment Data - only if form is not null
        if (form != null) {
            FormDeployService formDeployService = ServiceFactory.getFormDeployService();
            FormDeployXml formDeployXML = formDeployService.getOrCreateFormDeploy(form);

            _exportManager.addRow(formDeployXML, true, true);
            UserDeployMap userDeployMap = null;

            List<UserDeployMap> userDeployMapList = formDeployXML.getUserDeployMaps();
            for (Iterator iterator = userDeployMapList.iterator(); iterator.hasNext();) {
                userDeployMap = (UserDeployMap) iterator.next();
                // NB That the find is false because these are dependant entities
                _exportManager.addRow(userDeployMap, false, false);
            }

            SchemaDeployMap schemaDeployMap = null;
            List<SchemaDeployMap> schemaDeployMapList = formDeployXML.getSchemaDeployMaps();
            for (Iterator iterator = schemaDeployMapList.iterator(); iterator.hasNext();) {
                schemaDeployMap = (SchemaDeployMap) iterator.next();
                _exportManager.addRow(schemaDeployMap, false, false);
            }

            List<XmlInDeployMap> xmlInDeployMaps = formDeployXML.getXmlInDeployMaps();
            for (XmlInDeployMap xmlInDeployMap : xmlInDeployMaps) {
                _exportManager.addRow(xmlInDeployMap, false, false);
            }

            List<MetadataValueDeploy> metadataValueDeploys = formDeployXML.getMetadataContentList();
            for (MetadataValueDeploy metadataValueDeploy : metadataValueDeploys) {
                _exportManager.addRow(metadataValueDeploy, false, false);
            }

            List<PropertyDeploy> propertyDeploys = formDeployXML.getPropertyDeployList();
            for (PropertyDeploy propertyDeploy : propertyDeploys) {
                _exportManager.addRow(propertyDeploy, false, false);
            }

            List<SpecifiedAttachmentDeploy> attachmentDeploys = formDeployXML.getSpecifiedAttachmentDeployList();
            for (SpecifiedAttachmentDeploy specifiedAttachmentDeploy : attachmentDeploys) {
                _exportManager.addRow(specifiedAttachmentDeploy, false, false);
            }
        }
    }

    /**
     * Only added if exportType is not for production.
     *
     * @param schema
     * @param exportManager
     */
    public void addSchemaDetails(SchemaSeed schema, ExportManager exportManager){
        exportManager.addRow(schema, true, true);

        List<PropertyTypeMap> propertyTypeMaps = schema.getPropertyMap();
        for (PropertyTypeMap propertyTypeMap : propertyTypeMaps) {

            exportManager.addRow(propertyTypeMap.getPropertyType(), true, true);
            exportManager.addRow(propertyTypeMap, true, true);
        }

        List<SchemaConfigMap> schemaConfigMaps = schema.getSchemaConfigMaps();
        for (SchemaConfigMap schemaConfigMap : schemaConfigMaps) {
            exportManager.addRow(schemaConfigMap, true, true);
        }

        // XmlInputVersions & XmlInputMaps
        List<XmlInputVersion> xmlInputVersions = schema.getXmlInputVersions();
        for (XmlInputVersion xmlInputVersion : xmlInputVersions) {
            exportManager.addRow(xmlInputVersion, true, true);

            List<XmlInputMap> xmlInputMapList = xmlInputVersion.getXmlInputMap();
            for (XmlInputMap xmlInputMap : xmlInputMapList) {
                exportManager.addRow(xmlInputMap, true, true);
            }
        }

        SchemaSeed baseSchema = schema.getBaseSchema();

        if (baseSchema != null) {
            // Recurse
            addSchemaDetails(baseSchema, exportManager);
        }
    }

    private void addMetaDataValues(List<MetadataValue> metaDataValues, ExportManager exportManager){
        if (metaDataValues == null) {
            return;
        }

        MetadataListValueDao metadataListValueDao = DaoFactory.getMetadataListValueDao();
        for (Iterator<MetadataValue> iterator = metaDataValues.iterator(); iterator.hasNext();) {
            MetadataValue metaDataValue = iterator.next();
            MetadataTag metadataTag = metaDataValue.getMetadataTag();

            exportManager.addRow(metadataTag, true, true);
            exportManager.addRow(metaDataValue, true, true);

            if (MetadataTag.PROPERTY_Type_ListHierarchy.equals(metadataTag.getType())) {
                List<MetadataListValue> rootValueList = metadataListValueDao.getRootValues(metadataTag.getId().toString());
                List<MetadataListValue> metadataListValueList = new ArrayList<MetadataListValue>();
                for (MetadataListValue listValue : rootValueList) {
                    metadataListValueList.addAll(metadataListValueDao.getValueTree(listValue.getId().toString()));
                }
                for (MetadataListValue listValue : metadataListValueList) {
                    exportManager.addRow(listValue, true, true);
                }
            }
            else if (MetadataTag.PROPERTY_Type_List.equals(metadataTag.getType())) {
                List<MetadataListValue> listValues = metadataListValueDao.getListValuesForTag(metadataTag.getId().toString());
                for (MetadataListValue listValue : listValues) {
                    exportManager.addRow(listValue, true, true);
                }
            }
        }
    }

}

package com.avoka.fc.core.service.finder;

public interface CategoryDataContants {

    final static String WORKSHEET_CATEGORY_DATA = "Category Data";

    final static String COLUMN_NAME_SERVICE_CODE = "Service Code";
    final static String COLUMN_NAME_SERVICE_TYPE = "Service Type";
    final static String COLUMN_NAME_SERVICE_NAME = "Service Name";
    final static String COLUMN_NAME_SUMMARY      = "Summary";
    final static String COLUMN_NAME_DESCRIPTION  = "Description";

    final static String[] REQUIRED_COLUMN_NAMES = {
        COLUMN_NAME_SERVICE_CODE,
        COLUMN_NAME_SERVICE_TYPE,
        COLUMN_NAME_SERVICE_NAME,
        COLUMN_NAME_SUMMARY,
        COLUMN_NAME_DESCRIPTION
    };

    final static int MAX_COLUMN_WIDTH = 4000;

}

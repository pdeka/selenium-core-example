/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.util.Map;

import com.avoka.fc.core.entity.PaymentLog;
import com.avoka.fc.core.entity.Submission;

public interface CardPaymentService {

    /**
     * Perform a card payment for the given submission, using the given
     * cardNumber, cardExpiryDate and cardCsc.
     *
     * @param submission the submission to perform the payment for
     * @param cardNumber the credit/debit card number
     * @param cardExpiryDate the expiry date YYMM format
     * @param ipAddress the user's IP address
     * @param cardCsc the 3-4 digit card security code
     *
     * @return PaymentLog record for the submission
     */
    public PaymentLog performPayment(Submission submission,
                                     String cardNumber,
                                     String cardExpiryDate,
                                     String cardCsc,
                                     String ipAddress);

    /**
     * Perform an adhoc payment gateway query against the given payment log.
     *
     * @param paymentLog
     * @return map of query response parameters
     */
    public Map performQuery(PaymentLog paymentLog);

    /**
     * Resolve any outstanding payments against the payment gateway
     */
    public void resolveOutstandingPayments();

}

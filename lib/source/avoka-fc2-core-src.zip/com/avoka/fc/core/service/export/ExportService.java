package com.avoka.fc.core.service.export;

import java.util.Map;

import com.avoka.fc.core.entity.Form;

/**
 * Provides a generic service for exporting data to a report.
 * <p/>
 * Example implementation included below:
 *
 * <pre>
 * public class MyExportService implements ExportService {
 *
 *   // Return the report data
 *   public ExportData getExportData(Form form, Map inputParams) {
 *     ExportData data = new ExportData();
 *     data.addHeader("form");
 *     data.addHeader("submissionDate");
 *
 *     ResultSet rs = getResultSet();
 *
 *     while(rs.next()) {
 *         ExportDataRow row = new ExportDataRow();
 *         row.add(rs.getString("form"));
 *         row.add(rs.getDate("submissionDate"));
 *         data.addRow(row);
 *     }
 *
 *     // Close Statement
 *     // Close Connection
 *
 *     return data;
 *   }
 *
 *   // Return the metadata to build the report GUI
 *   public FormMetaData getFormMetaData() {
 *     FormMetaData formMeta = new FormMetaData();
 *
 *     // Example of specifying a text field
 *     FieldMetaData fieldMeta = new FieldMetaData("form");
 *     formMeta.add(fieldMeta);
 *
 *     // Example of specifying a date field
 *     fieldMeta = new FieldMetaData("submissionDate", "Submission Date", FieldMetaData.FieldType.DATE);
 *     formMeta.add(fieldMeta);
 *
 *     formMeta;
 *   }
 *
 *   private ResultSet getResultSet() {
 *     // Lookup datasource
 *     // Perform query, optionally passing in inputParams
 *     // Return query resultset
 *   }
 * }
 * <pre>
 */
public interface ExportService {

    public ExportData getExportData(Form form, Map<String, Object> inputParams);


    public FormMetaData getFormMetaData();
}

/* *************************************************************************
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka
 * Technologies ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only as may be permitted in writing by
 * Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited.
 * No part of this work may be produced or transmitted in any form by any
 * means, electronic or mechanical, including photocopying and recording,
 * or by any information storage or retrieval system except as may be permitted
 * in writing by Avoka Technologies Pty Limited.
 *
 * Created on Apr 11, 2007
 ************************************************************************* */

package com.avoka.fc.core.service;

import java.util.Date;

import com.avoka.fc.core.entity.SupportLog;
import com.avoka.fc.core.entity.SupportMessage;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.RemoteUserProvider;


public class SupportService extends CayenneService {

    public SupportLog createNewSupportThread(UserAccount user, String subject, String message) {
        SupportLog supportLog = (SupportLog) createAndRegisterNewObject(SupportLog.class);

        supportLog.setUser(user);
        supportLog.setSubject(subject);
        supportLog.setStatus(SupportLog.STATUS_OPEN);
        supportLog.setCreatedAt(new Date());
        supportLog.setCreatedBy(RemoteUserProvider.getRemoteUser());

        createNewSupportMessage(user, supportLog, message);

        return supportLog;
    }

    public SupportMessage createNewSupportMessage(UserAccount user, SupportLog supportLog, String message) {
        SupportMessage supportMessage = (SupportMessage) createAndRegisterNewObject(SupportMessage.class);

        supportLog.addToMessages(supportMessage);

        supportMessage.setSupportLog(supportLog);
        supportMessage.setUser(user);
        supportMessage.setMessageText(message);
        supportMessage.setCreatedAt(new Date());
        supportMessage.setCreatedBy(RemoteUserProvider.getRemoteUser());

        return supportMessage;
    }

}

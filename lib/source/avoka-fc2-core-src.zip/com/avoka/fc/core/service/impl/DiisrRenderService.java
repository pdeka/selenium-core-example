package com.avoka.fc.core.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.BaseService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.RenderFormService;
import com.avoka.fc.core.service.ServiceDefinitionAware;
import com.avoka.fc.core.util.ApplicationException;

public abstract class DiisrRenderService extends BaseService implements ServiceDefinitionAware {

    /** The security hash to access this service. */
    public static final String PARAM_SECURITY_HASH = "securityHash";

    /** The form name request parameter. */
    public static final String PARAM_FORM_NAME = "formName";

    /** The form path request parameter. */
    public static final String PARAM_FORM_PATH = "formPath";

    /** The form xml seed data request parameter. */
    public static final String PARAM_FORM_XML = "formXML";

    /** The form rendering orchestration name request parameter. */
    public static final String PARAM_ORCHESTRATION_NAME = "orchestrationName";

    // Variables --------------------------------------------------------------

    /** The service definition. */
    private ServiceDefinition  serviceDefinition;

    /** The request parameters. */
    private Map<String, String> requestParams = new HashMap<String, String>();

    private EventLogService eventLogService = new EventLogService();

    private String orchestrationName;

    // --------------------------------------------------------- Public Methods

    public String getOrchestrationName() {
        return orchestrationName;
    }

    public void setOrchestrationName(String orchestrationName) {
        this.orchestrationName = orchestrationName;
    }

    protected abstract String getTargetServlet();

    protected Map<String, String> getRequestParams() {
        return requestParams;
    }

    /**
     * @see ServiceDefinitionAware#setServiceDefinition(ServiceDefinition)
     */
    public void setServiceDefinition(ServiceDefinition serviceDefinition){
        this.serviceDefinition = serviceDefinition;
    }

    /**
     * @see ServiceDefinitionAware#getServiceDefinition()
     */
    public ServiceDefinition getServiceDefinition(){
        return serviceDefinition;
    }

    /**
     * @see RenderFormService#renderForm(TemplateVersion, String, HttpServletRequest, HttpServletResponse, String, RequestLog)
     */
    public void remoteRender(TemplateVersion templateVersion,
                             String xmlData,
                             RequestLog requestLog,
                             DiisrResponseHandler responseHandler) throws ApplicationException {

        Validate.notNull(templateVersion, "Null templateVersion paraemter");
        Validate.notNull(xmlData, "Null xmlData paraemter");

        long start = System.currentTimeMillis();

        if (!TemplateVersion.PUBLISH_STATUS_COMPLETE.equals(templateVersion.getPublishStatus())) {
            String context = "TemplateVersion ID=" + templateVersion.getId() + ",PublishStatus=" + templateVersion.getPublishStatus();
            String userMessage = "TemplateVersion has not published and cannot be rendered";
            String solution = "Ensure the TemplateVersion has been Published";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        // Get the base path
        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String basePath = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Render_Service_Base_Path);
        if (StringUtils.isBlank(basePath)) {
            String context = DeploymentProperty.PROPERTY_Render_Service_Base_Path + " is not defined";
            String userMessage = "Remote Render Service Base Path has not been configured";
            String solution = "Configure the DeploymentProperty: " + DeploymentProperty.PROPERTY_Render_Service_Base_Path;
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }
        basePath = basePath.replace('\\', '/');
        basePath = (basePath.startsWith("/")) ? basePath : "/" + basePath;
        basePath = (basePath.endsWith("/")) ? basePath : basePath + '/';

        final String orchestrationName = getOrchestrationName();
        if (StringUtils.isBlank(orchestrationName)) {
            String context = "orchestrationName=" + orchestrationName;
            String userMessage = "Service Definition orchestration name has not been configured";
            String solution = "Configure the Service Definition orchestration name";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        ServiceConnection serviceConnection = getServiceDefinition().getConnection();
        if (serviceConnection == null) {
            String context = "ServiceDefinition.ServiceName=" + getServiceDefinition().getServiceName();
            String userMessage = "ServiceConnection has not been configured for ServiceDefinition";
            String solution = "Configure the ServiceConnection for the ServiceDefinition";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        String password = serviceConnection.getPassword();
        if (StringUtils.isBlank(password)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection password is blank";
            String solution = "Configure the ServiceConnection Password";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        // Get the target server URL
        String requestTarget = serviceConnection.getEndpointValue();
        if (StringUtils.isBlank(requestTarget)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection EndPointValue has not been configured";
            String solution = "Configure the ServiceConnection EndPointValue";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }
        if (requestTarget.endsWith("/")) {
            requestTarget += getTargetServlet();
        } else {
            requestTarget += "/" + getTargetServlet();
        }

        // Get the form name
        String formName = templateVersion.getFileName();

        // Get the form path
        String formPath = basePath + templateVersion.getId();

        getRequestParams().put(PARAM_SECURITY_HASH, password);
        getRequestParams().put(PARAM_FORM_NAME, formName);
        getRequestParams().put(PARAM_FORM_PATH, formPath);
        getRequestParams().put(PARAM_FORM_XML, xmlData);
        getRequestParams().put(PARAM_ORCHESTRATION_NAME, orchestrationName);

        NameValuePair[] data = new NameValuePair[getRequestParams().size()];
        Iterator<String> iterator = getRequestParams().keySet().iterator();
        int index = 0;
        while (iterator.hasNext()) {
            String name = iterator.next();
            String value = getRequestParams().get(name);
            data[index++] = new NameValuePair(name, value);
        }

        HttpClient client = new HttpClient();
        PostMethod postMethod = new PostMethod(requestTarget);

        postMethod.setRequestBody(data);

        InputStream responseStream = null;
        try {
            final int responseCode = client.executeMethod(postMethod);

            responseStream = postMethod.getResponseBodyAsStream();

            byte[] byteArray = IOUtils.toByteArray(responseStream);

            if (responseCode == HttpServletResponse.SC_OK) {

                // Log duration of render
                if (requestLog != null) {
                    int duration = (int) (System.currentTimeMillis() - start);
                    requestLog.setDurationRender(new Integer(duration));
                    String msg = "Rendered '" + templateVersion.getFileName() + "', output size " + byteArray.length + " bytes in "
                    + (System.currentTimeMillis() - start) + " ms";
                    getLogger().info(msg);
                }

                final String contentType = postMethod.getResponseHeader("Content-Type").getValue();

                responseHandler.handleResponse(contentType, byteArray);

            } else {
                String error = new String(byteArray);
                String context = "responseCode=" + responseCode + ",requestTarget=" + requestTarget + ",formName=" + formName + ",formPath=" + formPath;
                String userMsg  = "Unknown error occured: " + error;
                throw new ApplicationException(getClass().getSimpleName(), context, userMsg, null);
            }

        } catch (UnknownHostException uhe) {
            String context = "requestTarget=" + requestTarget + ",formName=" + formName + ",formPath=" + formPath;
            String userMsg  = "Unable to connect to render Service: " + uhe.toString() + " when rendering form";
            String solution = "Check RenderService configuration and availability";
            throw new ApplicationException(getClass().getSimpleName(), uhe, context, userMsg, solution);

        } catch (IOException ioe) {
            // Log "ClientAbortException" which is a Tomcat specific exception
            if (ioe.toString().indexOf("ClientAbortException") != -1) {
                StringBuffer buffer = new StringBuffer();
                buffer.append("ClientAbortException for request ");

                eventLogService.logWarnEvent(buffer.toString());

            } else {
                String context = "requestTarget=" + requestTarget + ",formName=" + formName + ",formPath=" + formPath;
                String userMsg  = "Unknown error occured: " + ioe.toString();
                throw new ApplicationException(getClass().getSimpleName(), ioe, context, userMsg, null);
            }

        } finally {
            CoreUtils.close(responseStream);
            postMethod.releaseConnection();
        }

    }

}

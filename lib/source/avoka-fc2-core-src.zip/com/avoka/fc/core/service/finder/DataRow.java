package com.avoka.fc.core.service.finder;

import java.util.Iterator;
import java.util.LinkedHashMap;

import org.apache.poi.hssf.usermodel.HSSFRow;

import com.avoka.core.util.HSSFUtils;
import com.avoka.fc.core.util.ApplicationException;

class DataRow {

    private final int rowNumber;
    private final HSSFRow row;
    private final CategoryWorksheetMetaData metaData;

    public DataRow(int rowNumber, HSSFRow row, CategoryWorksheetMetaData metaData) {
        this.rowNumber = rowNumber;
        this.row = row;
        this.metaData = metaData;

        assertRequiredValues();
    }

    // Private Methods --------------------------------------------------------

    private void assertRequiredValues() {
        for (int i = 0; i < CategoryDataContants.REQUIRED_COLUMN_NAMES.length; i++) {
            if (HSSFUtils.isEmptyCell(row, i)) {
                String[] columnHeaders = { "A", "B", "C", "D", "E", "F" };

                String name = "Category Data Import Error";
                String context = "Column " + columnHeaders[i] + " Row " + (rowNumber + 1) + " (" +
                    CategoryDataContants.REQUIRED_COLUMN_NAMES[i] + ") is empty";
                String userMsg = "Column " + columnHeaders[i] + " Row " + (rowNumber + 1) + " ( " +
                    CategoryDataContants.REQUIRED_COLUMN_NAMES[i] + ") must have a value";
                String solution = "Revise spreadsheet to correct row data error";
                throw new ApplicationException(name, context, userMsg, solution);
            }
        }
    }


    public String createInsertStatement() {
        StringBuilder builder = new StringBuilder();

        LinkedHashMap<String, String> columnNameValues = new LinkedHashMap<String, String>();

        for (int i = 0; i < row.getLastCellNum() + 1; i++) {
            if (!HSSFUtils.isEmptyCell(row, i)) {
                String name = metaData.getTableColumnNames().get(i);
                String value = HSSFUtils.getCellValue(row, i);

                // Escaped single quotes
                value = value.trim().replace("'", "''");

                columnNameValues.put(name, value);
            }
        }

        builder.append("insert into ");
        builder.append(metaData.getTableName());
        builder.append(" (");

        Iterator<String> columnNames = columnNameValues.keySet().iterator();
        while (columnNames.hasNext()) {
            builder.append(columnNames.next());
            if (columnNames.hasNext()) {
                builder.append(", ");
            }
        }

        builder.append(" ) values ( ");

        Iterator<String> columnValues = columnNameValues.values().iterator();
        while (columnValues.hasNext()) {
            builder.append("'");
            builder.append(columnValues.next());
            builder.append("'");
            if (columnValues.hasNext()) {
                builder.append(", ");
            }
        }

        builder.append(");");

        return builder.toString();
    }


}

/*
 * Copyright (c) 2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import org.w3c.dom.Document;

/**
 * Provides a holder for extracted form submission data from LiveCycle ES.
 *
 * @author medgar@avoka.com
 */
public class SubmissionDataBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /** The XML form data document. */
    private final Document document;

    /** The LiveCycle submission process state. */
    private final String processState;

    /** The list of embedded file attachments. */
    private List embeddedAttachments;

    /** The validation errors. */
    private final String validationErrors;

    public SubmissionDataBean(Document document, String processState, List<EmbeddedAttachment> embeddedAttachments, String validationErrors) {
        this.document = document;
        this.processState = processState;
        this.embeddedAttachments = embeddedAttachments;
        this.validationErrors = validationErrors;
    }

    public SubmissionDataBean(Document document, String processState) {
        this.document = document;
        this.processState = processState;
        this.embeddedAttachments = Collections.emptyList();
        this.validationErrors = null;
    }

    public SubmissionDataBean(Document document, String processState, String validationErrors) {
        this.document = document;
        this.processState = processState;
        this.embeddedAttachments = Collections.emptyList();
        this.validationErrors = validationErrors;
    }

    public SubmissionDataBean(Document document) {
        this.document = document;
        this.processState = null;
        this.embeddedAttachments = Collections.emptyList();
        this.validationErrors = null;
    }

    public Document getDocument() {
        return document;
    }

    public String getProcessState() {
        return processState;
    }

    public List<EmbeddedAttachment> getEmbeddedAttachments() {
        return embeddedAttachments;
    }

    public String getValidationErrors() {
        return validationErrors;
    }

    public void setEmbeddedAttachments(List<EmbeddedAttachment> embeddedAttachments){
        this.embeddedAttachments = embeddedAttachments;
    }
}

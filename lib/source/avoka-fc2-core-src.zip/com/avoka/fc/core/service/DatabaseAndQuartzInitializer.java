package com.avoka.fc.core.service;

import javax.servlet.ServletContext;

import org.apache.cayenne.BaseContext;
import org.apache.cayenne.access.DataContext;
import org.apache.commons.lang.Validate;
import org.quartz.Scheduler;
import org.quartz.ee.servlet.QuartzInitializerListener;
import org.quartz.impl.StdSchedulerFactory;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.GroupDao;
import com.avoka.fc.core.dao.PermissionDao;
import com.avoka.fc.core.dao.PortalDao;
import com.avoka.fc.core.dao.PropertyTypeDao;
import com.avoka.fc.core.dao.RoleDao;
import com.avoka.fc.core.dao.ServiceConnectionDao;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.RemoteUserProvider;

/**
 * Provides a utility to load the default database data.
 *
 * @author medgar@avoka.com
 */
public class DatabaseAndQuartzInitializer extends BaseService {

    final ServletContext servletContext;

    // Constructor ------------------------------------------------------------

    public DatabaseAndQuartzInitializer(ServletContext servletContext) {
        Validate.notNull(servletContext);

        this.servletContext = servletContext;
    }

    // Public Methods ---------------------------------------------------------

    /**
     * Load the default system data into the database.
     */
    public void initialize() {

        RemoteUserProvider.setRemoteUser("system");

        DataContext dataContext = DataContext.createDataContext(false);
        BaseContext.bindThreadObjectContext(dataContext);

        try {
            // Load admin console portal entry
            PortalDao portalDao = DaoFactory.getPortalDao();
            portalDao.loadAdminConsolePortal();
            dataContext.commitChanges();

            // Load default permissions
            PermissionDao permissionDao = DaoFactory.getPermissionDao();
            permissionDao.loadDefaultPermissions();
            dataContext.commitChanges();

            permissionDao.purgeObsoleteValues();
            dataContext.commitChanges();

            // Load default deployment properties
            DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
            deploymentPropertyDao.loadDefaultProperties();
            dataContext.commitChanges();

            deploymentPropertyDao.purgeObsoleteValues();
            dataContext.commitChanges();

            deploymentPropertyDao.refreshCache();

            // Load default property types
            PropertyTypeDao propertyTypeDao = DaoFactory.getPropertyTypeDao();
            propertyTypeDao.loadDefaultProperties();

            // Load default admin role
            RoleDao roleDao = DaoFactory.getRoleDao();
            roleDao.assignDefaultPermissions();
            dataContext.commitChanges();

            // Load default groups
            GroupDao groupDao = DaoFactory.getGroupDao();
            groupDao.loadDefaultGroups();
            dataContext.commitChanges();

            // Create default admin users
            UserService userService = ServiceFactory.getUserService();
            userService.loadDefaultAdminUser();

            dataContext.commitChanges();

            deploymentPropertyDao.refreshCache();

            dataContext.commitChanges();

            ServiceConnectionDao serviceConnectionDao = DaoFactory.getServiceConnectionDao();
            serviceConnectionDao.loadDefaultConnections();

            // Initialise quartz scheduler
            final StdSchedulerFactory schedulerFactory = new StdSchedulerFactory();

            // Always want to get the scheduler, even if it isn't starting,
            // to make sure it is both initialized and registered.
            final Scheduler quartzScheduler = schedulerFactory.getScheduler();
            SchedulerService schedulerService = new SchedulerService(quartzScheduler);

            // Load default config settings
            DatabaseConfigService databaseConfigService = new DatabaseConfigService();
            databaseConfigService.loadConfiguration(schedulerService, servletContext);

            dataContext.commitChanges();

            // Don't want to fail startup if there is a publication an issue.
            try {
                // Publish form templates
                SynchronizeTemplatesService synchronizeTemplatesService = (SynchronizeTemplatesService)
                    ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SYNCHRONIZE_TEMPLATES);

                synchronizeTemplatesService.synchronizeTemplates();

                // Publish reports
                ReportService reportService = new ReportService();
                reportService.synchronizeReports();

            } catch (ApplicationException ae) {
                ServiceFactory.getErrorLogService().logException(ae);
            }

            // Wait for LC to finish initializing before starting Quartz scheduler
            waitForLiveCycleInitialization();

            // Start the Quartz scheduler and set in the servlet context
            quartzScheduler.start();
            servletContext.setAttribute(QuartzInitializerListener.QUARTZ_FACTORY_KEY, schedulerFactory);

            getLogger().info("Scheduler has been started");

        } catch (Exception e) {
            getLogger().error("Initialization error: " + e.toString(), e);
            throw new RuntimeException(e);

        } finally {
            BaseContext.bindThreadObjectContext(null);
            RemoteUserProvider.setRemoteUser(null);
        }
    }

    // Private Methods ------------------------------------------------------------------------------------------------

    public void waitForLiveCycleInitialization() {
        long startTime = System.currentTimeMillis();

        // Look up default LC service connection, and if found wait until LC initialized otherwise skip test

        if (ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_LIVECYCLE_MONITOR)) {

            LiveCycleMonitorService liveCycleMonitorService = (LiveCycleMonitorService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_LIVECYCLE_MONITOR);

            while (true) {
                if (liveCycleMonitorService.isLiveCycleInitialized()) {
                    String msg = "LiveCycle service validated after {} sec";
                    long waitTime = (System.currentTimeMillis() - startTime) / 1000;
                    getLogger().info(msg, waitTime);

                    return;

                } else {
                    getLogger().info("Waiting for LiveCycle to initialize...");

                    try {
                        Thread.sleep(15 * 1000L);

                    } catch (InterruptedException ie) {
                    }
                }
            }

        }
    }

}

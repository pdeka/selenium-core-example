package com.avoka.fc.core.service;

/**
 * Provides an interface for synchronizing all the form template versions to the systems rendering module.
 *
 * @author medgar@avoka.com
 */
public interface SynchronizeTemplatesService {

    /**
     * Synchronize all form TemplateVersions with the system's rendering module. This method will invoke the
     * synchronizeOfflineSubmissionForms method.
     */
    public void synchronizeTemplates();

    /**
     * Synchronize all offline submission forms with the system's rendering module.
     */
    public void synchronizeOfflineSubmissionForms();
}

package com.avoka.fc.core.service.impl;

import javax.servlet.http.HttpServletRequest;

import com.avoka.fc.core.service.AuthenticationService;

public class AuthenticationServiceImpl implements AuthenticationService {

    /**
     * @see AuthenticationService#getUserId(HttpServletRequest)
     */
    public String getUserId(HttpServletRequest request) {
        return request.getRemoteUser();
    }

    /**
     * @see AuthenticationService#isAuthenticated(HttpServletRequest)
     */
    public boolean isAuthenticated(HttpServletRequest request) {
        return request.getRemoteUser() != null;
    }

}

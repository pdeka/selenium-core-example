package com.avoka.fc.core.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.PublishTemplateService;

/**
 * Provide a service to publish form templates to a shared file system for use
 * by the systems form rendering module, such as LiveCycle ES.
 *
 * @author medgar@avoka.com
 */
public class FileSystemPublishService extends CayenneService implements PublishTemplateService {

    private EventLogService eventLogService = new EventLogService();

    // Public Methods ---------------------------------------------------------

    /**
     * @see PublishTemplateService#publishTemplate(TemplateVersion)
     */
    public void publishTemplate(TemplateVersion templateVersion) {

        Validate.notNull(templateVersion, "Null templateVersion");

        String publishStatus = templateVersion.getPublishStatus();
        if (!TemplateVersion.PUBLISH_STATUS_READY.equals(publishStatus)) {
            return;
        }

        if (templateVersion.getFileName() == null || templateVersion.getTemplateVersionData() == null) {
            return;
        }

        String directoryPath = getPublishDirectoryPath();
        if (directoryPath == null) {
            return;
        }

        try {
            // Ensure template version directory exists
            String templateDir = directoryPath + templateVersion.getId();
            File dirFile = new File(templateDir);
            dirFile.mkdirs();

            // Delete any existing files
            boolean fileDeleted = false;
            File[] templateDirFiles = dirFile.listFiles();
            if (templateDirFiles != null) {
                for (File file : templateDirFiles) {
                    if (file.isFile()) {
                        // Delete any existing file
                        if (file.isFile()) {
                            fileDeleted = true;
                            boolean status = file.delete();
                            getLogger().debug("Deleted existing template: " + file.getName() + ", deleted=" + status);
                        }
                    }
                }
            }

            // Sleep for 1 second to allow file system to complete the delete
            if (fileDeleted) {
                sleep();
            }

            if (!templateVersion.isFormGuide()) {

                String targetPath = templateDir + File.separator + templateVersion.getFileName();

                // Write template data to the shared file system
                FileOutputStream fos = new FileOutputStream(targetPath);
                byte[] data = templateVersion.getTemplateVersionData().getFileData();
                IOUtils.write(data, fos);
                CoreUtils.close(fos);

            } else {

                byte[] data = templateVersion.getTemplateVersionData().getFileData();
                ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(data));

                ZipEntry ze = null;
                while ((ze = zis.getNextEntry()) != null) {
                    if (ze.isDirectory()) {
                        continue;
                    }

                    String filename = ze.getName();
                    byte[] fileData = getEntryByteArray(ze, zis);

                    String targetPath = templateDir + File.separator + filename;
                    targetPath = targetPath.replace('/', File.separatorChar);

                    // Ensure parent directory exits.
                    File fgFile = new File(targetPath);
                    String dirPath = fgFile.getParent();
                    File fgDir = new File(dirPath);
                    if (!fgDir.exists()) {
                        fgDir.mkdirs();
                        sleep();
                    }

                    // Write template data to the shared file system
                    FileOutputStream fos = new FileOutputStream(targetPath);
                    IOUtils.write(fileData, fos);
                    CoreUtils.close(fos);
                }

                zis.close();
            }

            // Update the template version publishing status
            templateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_COMPLETE);
            commitChanges();

            getLogger().info("Published Template Version [" + templateVersion.getId() + "]");

        } catch (Exception ioe) {
            ErrorLogService errorLogService = new ErrorLogService();
            errorLogService.logException(ioe);

            templateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_ERROR);
            commitChanges();
        }
    }

    public void publishOfflineSubmissionForm(OfflineSubmissionForm offlineSubmissionForm) {

        Validate.notNull(offlineSubmissionForm, "Null offlineSubmissionForm");

        String publishStatus = offlineSubmissionForm.getPublishStatus();
        if (!TemplateVersion.PUBLISH_STATUS_READY.equals(publishStatus)) {
            return;
        }

        if (offlineSubmissionForm.getTemplateFileName() == null || offlineSubmissionForm.getFormTemplate() == null) {
            return;
        }

        String directoryPath = getPublishDirectoryPath();
        if (directoryPath == null) {
            return;
        }

        try {
            // Ensure template version directory exists
            String templateDir = directoryPath + "ofs_" + offlineSubmissionForm.getId();
            File dirFile = new File(templateDir);
            dirFile.mkdirs();

            // Delete any existing files
            boolean fileDeleted = false;
            File[] templateDirFiles = dirFile.listFiles();
            if (templateDirFiles != null) {
                for (File file : templateDirFiles) {
                    if (file.isFile()) {
                        // Delete any existing file
                        if (file.isFile()) {
                            fileDeleted = true;
                            boolean status = file.delete();
                            getLogger().debug("Deleted existing offline submission form: " + file.getName() + ", deleted=" + status);
                        }
                    }
                }
            }

            // Sleep for 1 second to allow file system to complete the delete
            if (fileDeleted) {
                sleep();
            }

            String targetPath = templateDir + File.separator + offlineSubmissionForm.getTemplateFileName();

            // Write template data to the shared file system
            FileOutputStream fos = new FileOutputStream(targetPath);
            byte[] data = offlineSubmissionForm.getFormTemplate();
            IOUtils.write(data, fos);
            CoreUtils.close(fos);

            // Update the template version publishing status
            offlineSubmissionForm.setPublishStatus(TemplateVersion.PUBLISH_STATUS_COMPLETE);
            offlineSubmissionForm.setPublishTime(new Date());
            commitChanges();

            getLogger().info("Published Offline Submission Form [" + offlineSubmissionForm.getId() + "]");

        } catch (Exception ioe) {
            ErrorLogService errorLogService = new ErrorLogService();
            errorLogService.logException(ioe);

            offlineSubmissionForm.setPublishStatus(TemplateVersion.PUBLISH_STATUS_ERROR);
            commitChanges();
        }
    }

    private String getPublishDirectoryPath() {
        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String directoryPath = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Publish_Templates_Directory);
        if (StringUtils.isBlank(directoryPath)) {
            String message = "FileSystemPublishService: " + DeploymentProperty.PROPERTY_Publish_Templates_Directory + " is blank";
            eventLogService.logErrorEvent(message);
            getLogger().error(message);
            return null;
        }

        if (!directoryPath.endsWith("\\") && !directoryPath.endsWith("/")) {
            directoryPath += File.separator;
        }

        File directory = new File(directoryPath);
        if (!directory.exists()) {
            if (!directory.mkdirs()) {
                String message = "FileSystemPublishService could not create directory: " + directoryPath;
                eventLogService.logErrorEvent(message);
                getLogger().error(message);
                return null;
            }
        }

        return directoryPath;
    }

    private byte[] getEntryByteArray(ZipEntry entry, ZipInputStream zis) throws IOException {

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        byte[] buffer = new byte[1024];
        while (true) {
            int read = zis.read(buffer);
            if (read == -1 ) {
                break;
            }
            out.write(buffer, 0, read);
        }

        return out.toByteArray();
    }

    private void sleep() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            // Do nothing
        }
    }
}

package com.avoka.fc.core.service.impl;

import java.io.IOException;

public interface DiisrResponseHandler {

    public void handleResponse(String remoteContentType, byte[] remoteByteArray) throws IOException;

}

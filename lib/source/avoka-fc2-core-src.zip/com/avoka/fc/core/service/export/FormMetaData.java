package com.avoka.fc.core.service.export;

import java.util.ArrayList;
import java.util.List;

public class FormMetaData {

    private List<FieldMetaData> fieldMetaDataList;

    private int columns;

    public void setFieldMetaDataList(List<FieldMetaData> fieldMetaDataList) {
        this.fieldMetaDataList = fieldMetaDataList;
    }

    public void add(FieldMetaData fieldMetaDataList) {
        getFieldMetaDataList().add(fieldMetaDataList);
    }

    public List<FieldMetaData> getFieldMetaDataList() {
        if (fieldMetaDataList == null) {
            fieldMetaDataList = new ArrayList();
        }
        return fieldMetaDataList;
    }

    public void setColumns(int columns) {
        this.columns = columns;
    }

    public int getColumns() {
        return columns;
    }

}

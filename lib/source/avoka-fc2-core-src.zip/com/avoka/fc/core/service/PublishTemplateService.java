package com.avoka.fc.core.service;

import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.TemplateVersion;

/**
 * Provides an interface for publishing form template versions to the systems
 * rendering module.
 * <p/>
 * When a template version is ready to be published its publish_status will be
 * marked "Ready" and once the publishing service has completed the status
 * will be marked as "Complete".
 *
 * @author medgar@avoka.com
 */
public interface PublishTemplateService {

    /**
     * Publish the given form TemplateVersion to the systems rendering module.
     *
     * @param templateVersion the form template version
     */
    public void publishTemplate(TemplateVersion templateVersion);

    /**
     * Publish the given offline submission form to the system's rendering module.
     *
     * @param offlineSubmissionForm the offline submission form to publish
     */
    public void publishOfflineSubmissionForm(OfflineSubmissionForm offlineSubmissionForm);
}

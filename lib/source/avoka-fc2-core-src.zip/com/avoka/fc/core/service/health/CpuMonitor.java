package com.avoka.fc.core.service.health;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vladium.utils.CPUUsageThread;
import com.vladium.utils.SystemInformation;
import com.vladium.utils.SystemInformation.CPUUsageSnapshot;

class CpuMonitor {

    private int snapshotCacheSize;

    private CPUUsageThread cpuMonitor = null;

    private DecimalFormat format = new DecimalFormat();

    private List<ListEntry> cpuSnapshots;

    private CpuInfo currCpuSnapshot;

    private Date prevSnapshotDate;

    private int pid;

    private CPUUsageSnapshot prevInternalSnapshot;

    private static Logger logger;

    CpuMonitor() {
    }

    // --------------------------------------------------------- Public Methods

    public void start(int snapshotCacheSize, long cpuSamplingIntervalInMilli) throws UnsatisfiedLinkError {
        setPrevSnapshotDate(new Date());
        setPid(SystemInformation.getProcessID());
        cpuMonitor = CPUUsageThread.getCPUThreadUsageThread();
        cpuMonitor.setSamplingInterval(cpuSamplingIntervalInMilli);
        setSnapshotCacheSize(snapshotCacheSize);
        CPUListener listener = new CPUListener();
        cpuMonitor.addUsageEventListener(listener);
        cpuMonitor.start();
        format.setMaximumFractionDigits(1);
    }

    public void stop() {
        if (cpuMonitor != null) {
            cpuMonitor.interrupt();
        }
    }

    public int getLatestCpuUsage() {
        return convertToPercentage(currCpuSnapshot.getCpuUsage());
    }

    public int calcCpuAveragePercentage() {
        Date from = getPrevSnapshotDate();
        setPrevSnapshotDate(new Date());
        return calcCpuAveragePercentage(from);
    }

    public boolean isCpuMonitorAvailable() {
        return cpuMonitor != null;
    }

    // ------------------------------------------------ Private Methods

    private List<ListEntry> getCPUSnapshots() {
        if (cpuSnapshots == null) {
            cpuSnapshots = new ArrayList<ListEntry>();
        }
        return cpuSnapshots;
    }

    private void setPrevSnapshotDate(Date prevSnapshotDate) {
        this.prevSnapshotDate = prevSnapshotDate;
    }

    private Date getPrevSnapshotDate() {
        return prevSnapshotDate;
    }

    public int getSnapshotCacheSize() {
        return snapshotCacheSize;
    }

    public void setSnapshotCacheSize(int snapshotCacheSize) {
        this.snapshotCacheSize = snapshotCacheSize;
    }

    // -------------------------------------------------------- Private Methods

    private void add(CpuInfo info) {
        getLogger().debug("Adding new snapshot : "
            + getCpuUsageAsPercentage(info.getCpuUsage()));
        Date now = new Date();
        ListEntry entry = new ListEntry();
        entry.date = now;
        entry.cpuInfo = info;
        getCPUSnapshots().add(entry);
        trimSnapshotCache();
    }

    private void trimSnapshotCache() {
        List snapshots = getCPUSnapshots();
        while(snapshots.size() > getSnapshotCacheSize()) {
            snapshots.remove(0);
        }
    }

    private CpuInfo createCPUInfo() {
        CpuInfo info = new CpuInfo();
        info.setPid(getPid());
        return info;
    }

    private int getPid() {
        return pid;
    }

    private void setPid(int pid) {
        this.pid = pid;
    }

    private String getCpuUsageAsPercentage(double usage) {
        return format.format(convertToPercentage(usage)) + "%";
    }

    private int calcCpuAveragePercentage(Date from) {
        List<ListEntry> snapshots = getCPUSnapshots();
        boolean valid = false;
        double total = 0;
        int count = 1;
        for(ListEntry snapshot : snapshots) {
            if (valid) {
                total += snapshot.cpuInfo.getCpuUsage();
                count++;
            } else {
                Date snapshotDate = snapshot.date;
                if (from.before(snapshotDate)) {
                    valid = true;
                    total += snapshot.cpuInfo.getCpuUsage();
                }
            }
        }
        total = total / count;
        return convertToPercentage(total);
    }

    private int convertToPercentage(double usage) {
        return (int) (100.0 * usage);
    }

    private class CPUListener implements CPUUsageThread.IUsageEventListener {
        public void accept(CPUUsageSnapshot snapshot) {
            processSnapshot(snapshot);
        }
    }

    private void processSnapshot(CPUUsageSnapshot internalSnapshot) {
        if (prevInternalSnapshot != null) {
            double usage = SystemInformation.getProcessCPUUsage(prevInternalSnapshot, internalSnapshot);
            currCpuSnapshot = createCPUInfo();
            currCpuSnapshot.setCpuUsage(usage);
            add(currCpuSnapshot);
        }
        prevInternalSnapshot = internalSnapshot;
    }

    class ListEntry {
        public Date date;
        public CpuInfo cpuInfo;
    }

    private Logger getLogger() {
        if(logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }
}

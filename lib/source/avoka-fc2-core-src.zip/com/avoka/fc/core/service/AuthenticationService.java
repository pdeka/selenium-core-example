package com.avoka.fc.core.service;

import javax.servlet.http.HttpServletRequest;

/**
 * Provides an pluggable authentication interface.
 *
 * @author Malcolm Edgar
 */
public interface AuthenticationService {

    /**
     * Return true if the user request has been authenticated by an external system.
     *
     * @param request the user servlet request
     * @return true if the user request has been authenticated by an external system.
     */
    public boolean isAuthenticated(HttpServletRequest request);

    /**
     * Return user identifier for the given request.
     *
     * @param request the user servlet request
     * @return user identifier for the given request
     */
    public String getUserId(HttpServletRequest request);

}

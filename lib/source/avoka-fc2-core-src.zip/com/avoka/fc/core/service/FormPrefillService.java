package com.avoka.fc.core.service;

import javax.servlet.http.HttpServletRequest;

import com.avoka.fc.core.entity.Form;

/**
 * Provides a service to get the form pre-population data for the given form and request.
 *
 * @author medgar@avoka.com
 */
public interface FormPrefillService {

    /**
     * Return the form pre-population data for the given form and request.
     *
     * @param form the get the pre-population data for
     * @param request the form request
     * @return the XML prefill data
     */
    public String getFormPrefillData(Form form, HttpServletRequest request);

    /**
     * The authentication service for determining the authenticated user
     *
     * @param authenticationService for determining the authenticated user
     */
    public void setAuthenticationService(AuthenticationService authenticationService);

}

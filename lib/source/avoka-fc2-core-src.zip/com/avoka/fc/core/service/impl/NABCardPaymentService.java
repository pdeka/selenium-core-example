/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import au.com.nab.jxa.api.Payment;
import au.com.nab.jxa.api.Txn;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.PaymentLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.CardPaymentService;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ReceiptDataService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.SubmissionStatusService;
import com.avoka.fc.core.util.ApplicationException;

public class NABCardPaymentService extends CayenneService implements CardPaymentService {

    // Constants
    public static final String PARAM_PAYMENT_URL = "paymentUrl";
    public static final String PARAM_QUERY_URL = "queryUrl";
    public static final String PARAM_TIMEOUT = "timeout";

    public static final String PAYMENT_SERVICE_CODE_NAB = "NAB";

    static final String TEST_PAYMENT_AMOUNT = "TEST_PAYMENT_AMOUNT";

    // Request Parameter Names
    static final String VPC_ACCESS_CODE            = "vpc_AccessCode";
    static final String VPC_AMOUNT                 = "vpc_Amount";
    static final String VPC_COMMAND                = "vpc_Command";
    static final String VPC_MERCHANT            = "vpc_Merchant";
    static final String VPC_MERCH_TXN_REF         = "vpc_MerchTxnRef";
    static final String VPC_ORDER_INFO            = "vpc_OrderInfo";
    static final String VPC_VERSION                = "vpc_Version";

    static final String VPC_CARD_SECURITY_CODE     = "vpc_CardSecurityCode";
    static final String VPC_CARD_NUM             = "vpc_CardNum";
    static final String VPC_CARD_EXP             = "vpc_CardExp";

    static final String VPC_STATUS_CODE            = "vpc_StatusCode";
    static final String VPC_STATUS_DESC            = "vpc_StatusDescription";
    static final String VPC_RESULT                = "vpc_Result";
    static final String VPC_PAYMENT_COUNT        = "vpc_PaymentCount";

//    static final String VPC_ACQ_RESPONSE_CODE    = "vpc_AcqResponseCode";
    static final String VPC_AUTHORIZED_ID        = "vpc_AuthorizeId";
    static final String VPC_BATCH_NO             = "vpc_BatchNo";
    static final String VPC_CARD                = "vpc_Card";
    static final String VPC_MESSAGE                = "vpc_Message";
    static final String VPC_RECEIPT_NO            = "vpc_ReceiptNo";
    static final String VPC_TAX_AMOUNT            = "vpc_TaxAmount";
    static final String VPC_TRANSACTION_NO        = "vpc_TransactionNo";
    static final String VPC_TXN_RESPONSE_CODE    = "vpc_TxnResponseCode";
    static final String VPC_TXN_RESPONSE_MSG    = "vpc_TxnResponseMsg";
    static final String VPC_TXN_SETTLEMENT_DATE = "vpc_TxnSettlementDate";
    static final String VPC_TXN_OBJECT_ERROR    = "vpc_TxnObjectError";
    static final String VPC_PAYMENT                = "payment";
    static final String VPC_TXN                    = "txn";

    static final String VPC_USER                = "vpc_User";
    static final String VPC_PASSWORD            = "vpc_Password";

    static final String VPC_DR_EXISTS           = "vpc_DRExists";
    static final String VPC_FOUND_MULTIPLE_DRS  = "vpc_FoundMultipleDRs";


    static final String VPC_COMMAND_PAY         = "pay";
    static final String VPC_COMMAND_DRQUERY     = "queryDR";
    static final String VPC_VERSION_VALUE         = "1";

    static final String TXN_RESPONSE_CODE_SUCCESS_VALUE = "0";
    static final String TXN_RESPONSE_CODE_FAILURE_VALUE = "1";
    static final String TXN_STATUS_CODE_SUCCESS_VALUE = "0";
    static final String TXN_RESPONSE_CODE_SERVER_ERROR_VALUE = "7";
    static final String TXN_PAYMENT_NOT_SENT = "PaymentNotSentToServer";
    static final String TXN_RESULT_OK = "OK";
    static final String TXN_CURRENCY_CODE = "AUD";
    static final int TXN_SOURCE_API = 8;

    static final int PAYMENT_SOURCE_STANDARD = 0;

    static final String    DR_QUERY_NOT_FOUND_MSG  = "Not Found by DR Query";


    // ----------------------------------------------------- Instance Variables

    private String paymentUrl;
    private String timeout;


    // --------------------------------------------------------- Public Methods

    /**
     * @see CardPaymentService#performPayment(Submission, String, String, String)
     */
    public PaymentLog performPayment(Submission submission, String cardNumber, String cardExpiryDate, String cardCsc, String ipAddress) {

        Validate.notNull(submission, "Null submission parameter");
        Validate.notNull(cardNumber, "Null cardNumber parameter");
        Validate.notNull(cardExpiryDate, "Null cardExpiryDate parameter");
        Validate.notNull(cardCsc, "Null cardCsc parameter");

        //Changing the structure of the date....
        String nabCardExpiryDate=null;
        if (cardExpiryDate.length()==4) {
            nabCardExpiryDate  = cardExpiryDate.substring(2) + "/" + cardExpiryDate.substring(0,2);
        }

        // If completed return first successful payment
        if (submission.isPaymentCompleted()) {
            List payments = submission.getPayments();
            for (Iterator i = payments.iterator(); i.hasNext();) {
                PaymentLog paymentLog = (PaymentLog) i.next();
                if (paymentLog.isPaymentCompleted()) {
                    return paymentLog;
                }
            }
            return (PaymentLog) payments.get(payments.size() - 1);
        }

        Client client = submission.getClient();

        // Client details
        String vpc_MerchantId = client.getPaymentMerchantId();
        String vpc_Password = client.getPaymentMerchantPassword();

        // Get payment amount and convert to cents
        Integer vpc_Amount = getPaymentTotal(submission);

        // Test payment amount for testing system response to NAB errors
        DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
        if (deploymentPropertyDao.hasProperty(TEST_PAYMENT_AMOUNT)) {
            String paymentAmount = deploymentPropertyDao.getPropertyValue(TEST_PAYMENT_AMOUNT);
            if (StringUtils.isNotBlank(paymentAmount)) {
                vpc_Amount = Integer.parseInt(paymentAmount);
                getLogger().debug(TEST_PAYMENT_AMOUNT + ": " + vpc_Amount);
            }
        }

        // Create payment log record and complete DO fields
        PaymentLog paymentLog = (PaymentLog) createAndRegisterNewObject(PaymentLog.class);
        paymentLog.setDoTimestamp(new Date());
        paymentLog.setSubmission(submission);
        paymentLog.setPaymentServiceCode(PAYMENT_SERVICE_CODE_NAB);

        paymentLog.setDoAmount(vpc_Amount);
        paymentLog.setDoMerchant(vpc_MerchantId);
        paymentLog.setDoVersion(VPC_VERSION_VALUE);

        commitChanges();

        // Order details
//        String vpc_OrderInfo = paymentLog.getId().toString();

        // Set merchant transaction reference to payment log id
        String vpc_MerchTxnRef = paymentLog.getId().toString();
        paymentLog.setDoMerchTxnRef(vpc_MerchTxnRef);

        commitChanges();

        String paymentUrl = getPaymentUrl();

        return processNABPayment(vpc_MerchantId, vpc_Password, vpc_Amount, cardNumber, cardCsc, nabCardExpiryDate, paymentLog, submission, paymentUrl);
    }

    /**
     * @see CardPaymentService#performQuery(PaymentLog)
     */
    public Map performQuery(PaymentLog paymentLog) {
        return null;
    }

    /**
     * @see CardPaymentService#resolveOutstandingPayments()
     */
    public void resolveOutstandingPayments() {
    }

    public String getPaymentUrl() {
        return paymentUrl;
    }

    public void setPaymentUrl(String newPaymentUrl) {
        paymentUrl = newPaymentUrl;
    }


    public String getTimeout() {
        return timeout;
    }

    public void setTimeout(String newTimeout) {
        timeout = newTimeout;
    }

    // ----------------------------------------------- Package Private Methods

    /**
     * Process the NAB VPC payment receipt parameters and return the
     * Submission object of the payment
     *
     * @param paymentLog the Payment Log record
     * @param params the VPC Digital Receipt (DR) payment receipt parameters
     */
    PaymentLog processPaymentReceipt(PaymentLog paymentLog, Map params) {
        Validate.notNull(paymentLog, "Null paymentLog parameter");
        Validate.notNull(params, "Null params parameter");

        paymentLog.setDrTimestamp(new Date());
        paymentLog.setDrAmount(getInteger(params, VPC_AMOUNT));
        paymentLog.setDrBatchNo(getInteger(params, VPC_BATCH_NO));
        paymentLog.setDoMerchant(getString(params, VPC_MERCHANT));
        paymentLog.setDrMerchTxnRef(getString(params, VPC_MERCH_TXN_REF));
        paymentLog.setDrMessage(getString(params, VPC_MESSAGE));
        paymentLog.setDrTransactionNo(getLong(params, VPC_TRANSACTION_NO));
        paymentLog.setDrTxnResponseCode(getString(params, VPC_TXN_RESPONSE_CODE));
        paymentLog.setDrTxnResponseMsg(getString(params,VPC_TXN_RESPONSE_MSG));
        paymentLog.setDrReceiptNo(getString(params,VPC_RECEIPT_NO));
//        paymentLog.setOriginatingIp(getString(params,VPC_ORIGINATING_IP));
//        paymentLog.setAntiFraudResponseCode(getString(params, VPC_ANTIFRAUD_RESPONSE_CODE));
//        paymentLog.setAntiFraudResponseMessage(getString(params, VPC_ANTIFRAUD_RESPONSE_MESSAGE));

        updateFormReceiptInfo(paymentLog);

        commitChanges();

        return paymentLog;
    }

    void updateFormReceiptInfo(PaymentLog paymentLog) {
        Submission submission = paymentLog.getSubmission();

        if (TXN_RESPONSE_CODE_SUCCESS_VALUE.equals(paymentLog.getDrTxnResponseCode())) {
            paymentLog.setDrTxnResponseMsg("Transaction approved");

            if (paymentLog.getDrReceiptNo() != null) {
                ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
                receiptDataService.setPaymentReceiptDetails(submission, paymentLog.getDrReceiptNo(), paymentLog.getDrTimestamp());
            }
            paymentLog.setPaymentStatus(PaymentLog.STATUS_Completed);
            submission.setPaymentStatus(Submission.STATUS_Completed);

        } else {
            paymentLog.setPaymentStatus(PaymentLog.STATUS_Error);
            submission.setPaymentStatus(Submission.STATUS_Error);
        }
        SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
        submissionStatusService.updateStatus(submission);
    }

    String getString(Map params, String key) {
        Object value = params.get(key);
        if (value != null) {
            return value.toString();

        } else {
            return null;
        }
    }

    Integer getInteger(Map params, String key) {
        Object value = params.get(key);
        if (value != null) {
            return Integer.valueOf(value.toString());

        } else {
            return null;
        }
    }

    Long getLong(Map params, String key) {
        Object value = params.get(key);
        if (value != null) {
            return Long.valueOf(value.toString());

        } else {
            return null;
        }
    }

    Integer getPaymentTotal(Submission submission) {
        try {
            Double paymentDouble = submission.getPaymentTotal();

            int paymentCents = (int) Math.round(paymentDouble.doubleValue() * 100);

            return new Integer(paymentCents);

        } catch (Exception e) {
            String msg = "Unexpected error occured determing payment amount";
            throw new ApplicationException("CardPaymentService", e, msg + ": " + e.getMessage(), msg, null);
        }
    }

    /**
     * This method takes a data String and returns a predefined value if empty If data Sting is
     * null, returns string "No Value Returned", else returns input
     *
     * @param name String containing the data String @return String containing the output String
     */
    String getQueryDrResponseValue(String name, Map responseFields) {
        if (responseFields.containsKey(name)) {
            return (String) responseFields.get(name);

        } else {
            return "No Value Returned";
        }
    }


    private int processTimeOut(String sTimeOut) {
        return Integer.parseInt(sTimeOut);
    }

    private PaymentLog processNABPayment(String merchantId, String password, Integer amount, String cardNumber,
            String cardCsc, String cardExpiryDate, PaymentLog paymentLog, Submission submission, String paymentUrl) {
        // Create request URL

        Map<String, String> params = new HashMap<String, String>();

        params.put(VPC_AMOUNT, (amount == null ? null : String.valueOf(amount)));
        params.put(VPC_CARD_EXP, cardExpiryDate);
        params.put(VPC_CARD_NUM, cardNumber);

        if (StringUtils.isNotBlank(cardCsc)) {
            params.put(VPC_CARD_SECURITY_CODE, cardCsc);
        }

        params.put(VPC_CARD_NUM, cardNumber);
        params.put(VPC_COMMAND, VPC_COMMAND_PAY);
        params.put(VPC_MERCHANT, merchantId);
        params.put(VPC_VERSION, VPC_VERSION_VALUE);

        HashMap<String, String> response  = doPayment(merchantId, password, amount, cardNumber, cardCsc, cardExpiryDate, submission.getId().toString());

        String result = response.get(VPC_RESULT);

        params.put(VPC_MERCH_TXN_REF,response.get(VPC_MERCH_TXN_REF) );
        params.put(VPC_TRANSACTION_NO, response.get(VPC_TRANSACTION_NO));
        params.put(VPC_RECEIPT_NO, response.get(VPC_RECEIPT_NO));
        params.put(VPC_BATCH_NO, response.get(VPC_TXN_SETTLEMENT_DATE));
        params.put(VPC_TXN_RESPONSE_CODE, response.get(VPC_TXN_RESPONSE_CODE));
        params.put(VPC_TXN_RESPONSE_MSG, response.get(VPC_TXN_RESPONSE_MSG));
        params.put(VPC_MESSAGE,response.get(VPC_STATUS_DESC));

        if ((result.equalsIgnoreCase(TXN_RESULT_OK)) && (response.get(VPC_TXN_RESPONSE_CODE)).equals(TXN_RESPONSE_CODE_SUCCESS_VALUE)) {
            paymentLog =  processPaymentReceipt(paymentLog, params);
        } else {
            // Log warning, and query the payment
            String msg = "Attempt at making card payment failed. Error: Payment was not sent to server at: "
                + paymentUrl
                + ", Status: "
                + response.get(VPC_STATUS_CODE)
                + ", Status description: "
                + response.get(VPC_STATUS_DESC)
                + ", Response: "
                + response.get(VPC_TXN_RESPONSE_CODE)
                + ", Response description: "
                + response.get(VPC_TXN_RESPONSE_MSG);
            EventLogService eventLogService = ServiceFactory.getEventLogService();
            eventLogService.logErrorEvent(msg, submission);

            paymentLog = processPaymentReceipt(paymentLog, params);

        }
        return paymentLog;
    }

    private HashMap<String,String> doPayment(String merchantId, String password, Integer amount, String cardNumber, String cardCsc, String cardExpiryDate, String submissionId) {

        HashMap<String,String> response = new HashMap<String,String>();

        Payment payment = new Payment();

        payment.setServerURL(getPaymentUrl());
        payment.setProcessTimeout(processTimeOut(getTimeout()));
        payment.setMerchantId(merchantId);
        response.put(VPC_MERCHANT, merchantId);

        Txn txn = payment.addTxn(PAYMENT_SOURCE_STANDARD, submissionId);
        response.put(VPC_MERCH_TXN_REF, submissionId);

        txn.setTxnSource(TXN_SOURCE_API);
        String strAmount = Integer.toString(amount);
        txn.setAmount(strAmount);
        response.put(VPC_AMOUNT,strAmount );

        txn.setCardNumber(cardNumber);
        response.put(VPC_CARD_NUM,cardNumber );

        if (StringUtils.isNotBlank(cardCsc)) {
            txn.setCVV(cardCsc);
            response.put(VPC_CARD_SECURITY_CODE, cardCsc);
        }

        txn.setCurrencyCode(TXN_CURRENCY_CODE);

        txn.setExpiryDate(cardExpiryDate);
        response.put(VPC_CARD_EXP, cardExpiryDate);

        //process the payment
        boolean processed = payment.process(password);

        if (! processed) {
            response.put(VPC_RESULT, TXN_PAYMENT_NOT_SENT);
            response.put(VPC_STATUS_CODE, Long.toString(payment.getStatusCode()));
            response.put(VPC_TXN_RESPONSE_CODE,Long.toString(payment.getStatusCode()));
            response.put(VPC_STATUS_DESC, payment.getStatusDesc());
            response.put(VPC_TXN_RESPONSE_MSG,payment.getStatusDesc());
        } else {
            response.put(VPC_RESULT,TXN_RESULT_OK);
            response.put(VPC_STATUS_CODE,Long.toString(payment.getStatusCode()));
            response.put(VPC_TXN_RESPONSE_CODE,Long.toString(payment.getStatusCode()));
            response.put(VPC_STATUS_DESC,payment.getStatusDesc());
            response.put(VPC_TXN_RESPONSE_MSG,payment.getStatusDesc());
            response.put(VPC_PAYMENT_COUNT, Integer.toString(payment.getCount()));

            if (payment.getCount()==1) {

                Txn resp = payment.getTxn(0);

                if (resp.getApproved()) {
                    response.put(VPC_TXN_RESPONSE_CODE, TXN_RESPONSE_CODE_SUCCESS_VALUE);
                } else {
                    response.put(VPC_TXN_RESPONSE_CODE, TXN_RESPONSE_CODE_FAILURE_VALUE);
                }

                response.put(VPC_TXN_RESPONSE_MSG,resp.getResponseText() );
                response.put(VPC_TXN_SETTLEMENT_DATE,resp.getSettlementDate());
                response.put(VPC_TRANSACTION_NO, resp.getTxnId());
                response.put(VPC_RECEIPT_NO, resp.getTxnId());
            } else {
                response.put(VPC_TXN_OBJECT_ERROR,"No Txn object returned");
            }
        }

        return response;
    }
 }

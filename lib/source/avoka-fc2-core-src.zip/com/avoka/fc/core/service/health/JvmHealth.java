package com.avoka.fc.core.service.health;

import java.text.MessageFormat;

public class JvmHealth {

    public static final long SECONDS_PER_DAY = 24*60*60;
    public static final long SECONDS_PER_HOUR = 60*60;
    public static final long SECONDS_PER_MINUTE = 60;

    private MessageFormat format = new MessageFormat("Uptime (days:{0} hours:{1} minutes:{2})");

    private long uptime;

    public void setUptime(long uptime) {
        this.uptime = uptime;
    }

    public long getUptime() {
        return uptime;
    }

    public String getUptimeAsDaysHourMinute() {
        long uptime = getUptime();

        String days = new Long(uptime / SECONDS_PER_DAY).toString();
        uptime = uptime % SECONDS_PER_DAY;

        String hours = new Long(uptime / SECONDS_PER_HOUR).toString();
        uptime = uptime % SECONDS_PER_HOUR;

        String minutes = new Long(uptime / SECONDS_PER_MINUTE).toString();
        uptime = uptime % SECONDS_PER_MINUTE;

        Object[] args = {days, hours, minutes};
        return format.format(args);
    }
}

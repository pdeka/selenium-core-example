package com.avoka.fc.core.service;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.avoka.core.xml.export.ExportManager;
import com.avoka.fc.core.dao.ClientDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.MetadataListValueDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.MetadataListValue;
import com.avoka.fc.core.entity.MetadataTag;
import com.avoka.fc.core.entity.MetadataValue;
import com.avoka.fc.core.entity.PaymentAccount;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.Report;
import com.avoka.fc.core.entity.ReportClient;
import com.avoka.fc.core.entity.ReportParameter;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserAccount;

public class ExportClientService{

    public static final String EXPORT_Type_Client = "Client Export";

    public void exportClient(String clientCode,
            boolean exportDeliveryDetails,
            boolean exportForms,
            boolean allVersionsFlag,
            OutputStream exportOutStream,
            String clientName,
            String description,
            String environmentName){

        ExportManager exportManager = new ExportManager(new FC2CayenneMetaData());
        ExportFormService formExportService = new ExportFormService();

        ClientDao clientDao = new ClientDao();
        Client client = clientDao.getClientByCode(clientCode);

        // Blank out the client key so it will be regenerated
        String oldClientKey = client.getClientKey();
        client.setClientKey(null);

        try {
            exportManager.addRow(client, true, true);

            List<PropertyType> propertyTypeList = client.getPropertyTypes();
            for (PropertyType propertyType : propertyTypeList) {
                exportManager.addRow(propertyType, true, true);

                System.out.println("Adding Property Type " + propertyType.getName());

            }

            if (exportDeliveryDetails) {
                List<DeliveryDetails> deliveryDetailsList = client.getDeliveryDetails();
                for (DeliveryDetails deliveryDetails : deliveryDetailsList) {
                    exportManager.addRow(deliveryDetails, true, true);
                    if (DeliveryDetails.METHOD_LC_PROCESS.equals(deliveryDetails.getDeliveryMethod())) {
                        exportManager.addRow(deliveryDetails.getDeliveryProcessService(), true, false);
                    }
                }
            }

            List<ClientProperty> clientPropertiesList = client.getClientProperties();
            for (Iterator iterator = clientPropertiesList.iterator(); iterator.hasNext();) {
                ClientProperty clientProperty = (ClientProperty) iterator.next();
                PropertyType propertyType = clientProperty.getPropertyType();
                exportManager.addRow(propertyType, true, true);
                exportManager.addRow(clientProperty, false, true);
            }

            // add metadata tags for client
            List<MetadataTag> clientTagList = client.getMetadataTags();
            for (Iterator<MetadataTag> iterator = clientTagList.iterator(); iterator.hasNext();) {
                MetadataTag metadataTag = iterator.next();
                exportManager.addRow(metadataTag, true, true);
            }

            List<MetadataValue> clientMetadataList = client.getClientMetadataValues();
            MetadataListValueDao metadataListValueDao = DaoFactory.getMetadataListValueDao();
            for (Iterator<MetadataValue> iterator = clientMetadataList.iterator(); iterator.hasNext();) {
                MetadataValue metadataValue = iterator.next();
                MetadataTag metadataTag = metadataValue.getMetadataTag();
                exportManager.addRow(metadataTag, true, true);
                exportManager.addRow(metadataValue, true, true);

                if (MetadataTag.PROPERTY_Type_ListHierarchy.equals(metadataTag.getType())) {
                    List<MetadataListValue> rootValueList = metadataListValueDao.getRootValues(metadataTag.getId().toString());
                    List<MetadataListValue> metadataListValueList = new ArrayList<MetadataListValue>();
                    for (MetadataListValue listValue : rootValueList) {
                        metadataListValueList.addAll(metadataListValueDao.getValueTree(listValue.getId().toString()));
                    }
                    for (MetadataListValue listValue : metadataListValueList) {
                        exportManager.addRow(listValue, true, true);
                    }
                }
                else if (MetadataTag.PROPERTY_Type_List.equals(metadataTag.getType())) {
                    List<MetadataListValue> listValues = metadataListValueDao.getListValuesForTag(metadataTag.getId().toString());
                    for (MetadataListValue listValue : listValues) {
                        exportManager.addRow(listValue, true, true);
                    }
                }
            }

            // Forms
            if (exportForms) {
                List<Form> formList = client.getForms();
                for (Form form : formList) {
                    formExportService.exportFormData(form, exportManager, allVersionsFlag, null);
                }

                // Schema PropertyMap & PropertyTypes
                List<SchemaSeed> schemaList = client.getSchemas();
                for (SchemaSeed schema : schemaList) {
                    formExportService.addSchemaDetails(schema, exportManager);
                }

                // Payment Accounts and Users!
                List<PaymentAccount> accounts = client.getAccounts();
                for (PaymentAccount paymentAccount : accounts) {
                    UserAccount user = paymentAccount.getUser();
                    exportManager.addRow(user, true, false);
                    exportManager.addRow(paymentAccount, true, true);
                }

                // Templates - this will pick up any templates that have been left out by Forms
                List<Template> templateList = client.getTemplates();
                for (Template template : templateList) {
                    exportManager.addRow(template, true, true);
                    List<TemplateVersion> versionList = template.getVersions();

                    if (allVersionsFlag) {
                        for (TemplateVersion templateVersion : versionList) {
                            formExportService.exportTemplateVersion(null, templateVersion, exportManager);
                        }
                    } else {
                        TemplateVersion currentVersion = template.getCurrentVersion();
                        if (currentVersion != null) {
                            formExportService.exportTemplateVersion(null, currentVersion, exportManager);
                        }
                    }
                }
            }

            List<ReportClient> reportClientList = client.getReports();
            for (ReportClient reportClient : reportClientList) {
                exportManager.addRow(reportClient, true, true);
                Report report = reportClient.getReport();
                exportManager.addRow(report, true, true);
                List<ReportParameter> parameterList = report.getParameters();
                for (ReportParameter reportParameter : parameterList) {
                    // Dependant entity
                    exportManager.addRow(reportParameter, false, false);

                }

//                List<ReportSchedule> scheduledReportList = reportClient.getScheduledReports();
//                for (ReportSchedule reportSchedule : scheduledReportList) {
//                    exportManager.addRow(reportSchedule, false, false);
//                }
            }

            // DeploymentPropertyDao deploymentDao = new DeploymentPropertyDao();
            // String exportDir =
            // deploymentDao.getPropertyValue(DeploymentProperty.PROPERTY_Export_Directory);
            //
            // SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-DD-HH-mm-SS");
            // String name = sdf.format(new Date());

            // exportManager.writeXml(exportDir, "client_export" + name + ".xml", metaDataManager,
            // exportOutStream, "Client Export", clientName, description);
            exportManager.writeXml(exportOutStream, EXPORT_Type_Client, clientName, description, environmentName);
        }
        finally {
            client.setClientKey(oldClientKey);
        }
    }

}

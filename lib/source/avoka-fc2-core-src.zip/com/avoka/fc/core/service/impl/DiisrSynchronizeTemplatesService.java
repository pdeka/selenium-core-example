package com.avoka.fc.core.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.OfflineSubmissionFormDao;
import com.avoka.fc.core.dao.TemplateVersionDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.PublishTemplateService;
import com.avoka.fc.core.service.ServiceDefinitionAware;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SynchronizeTemplatesService;
import com.avoka.fc.core.util.ApplicationException;

public class DiisrSynchronizeTemplatesService extends CayenneService
    implements SynchronizeTemplatesService, ServiceDefinitionAware {

    /** The security hash to access this service. */
    public static final String PARAM_SECURITY_HASH = "securityHash";

    /** The form name request parameter. */
    public static final String PARAM_FORM_NAME = "formName";

    /** The form deployment folder path request parameter. */
    public static final String PARAM_FORM_PATH = "formPath";

    // Variables --------------------------------------------------------------

    /** The service definition. */
    private ServiceDefinition  serviceDefinition;

    private EventLogService eventLogService = new EventLogService();

    // Public Methods ---------------------------------------------------------

    /**
     * @see ServiceDefinitionAware#setServiceDefinition(ServiceDefinition)
     */
    public void setServiceDefinition(ServiceDefinition serviceDefinition){
        this.serviceDefinition = serviceDefinition;
    }

    /**
     * @see ServiceDefinitionAware#getServiceDefinition()
     */
    public ServiceDefinition getServiceDefinition(){
        return serviceDefinition;
    }

    /**
     * @see SynchronizeTemplatesService#synchronizeTemplates()
     */
    public void synchronizeTemplates() {

        DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
        String basePath = dpDao.getPropertyValue(DeploymentProperty.PROPERTY_Render_Service_Base_Path);
        if (StringUtils.isBlank(basePath)) {
            String message = "DeploymentProperty: '" + DeploymentProperty.PROPERTY_Render_Service_Base_Path
            + "' has not been configured. Please configure this property to enable template synchronization";
            ServiceFactory.getEventLogService().logErrorEvent(message);
            return;
        }

        // Check the remote server for deployed templates
        Set<FormTemplate> remoteTemplates = getRemoteTemplates();

        // Check for database templates
        Set<FormTemplate> localTemplates = getLocalTemplates();

        // Get delete templates
        Set<FormTemplate> deletedTemplates = new HashSet<FormTemplate>(remoteTemplates);
        deletedTemplates.removeAll(localTemplates);
        deleteRemoteTemplates(deletedTemplates);

        // Publish new templates
        Set<FormTemplate> newTemplates = new HashSet<FormTemplate>(localTemplates);
        newTemplates.removeAll(remoteTemplates);
        publishRemoteTemplates(newTemplates);

        synchronizeOfflineSubmissionForms();
    }

    public void synchronizeOfflineSubmissionForms() {

        DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
        String basePath = dpDao.getPropertyValue(DeploymentProperty.PROPERTY_Render_Service_Base_Path);
        if (StringUtils.isBlank(basePath)) {
            String message = "DeploymentProperty: '" + DeploymentProperty.PROPERTY_Render_Service_Base_Path
            + "' has not been configured. Please configure this property to enable template synchronization";
            ServiceFactory.getEventLogService().logErrorEvent(message);
            return;
        }

        // Check the remote server for deployed templates
        Set<OfflineForm> remoteOfflineForms = getRemoteOfflineForms();

        // Check for database templates
        Set<OfflineForm> localOfflineForms = getLocalOfflineForms();

        // Get delete templates
        Set<OfflineForm> deletedOfflineForms = new HashSet<OfflineForm>(remoteOfflineForms);
        deletedOfflineForms.removeAll(localOfflineForms);
        deleteRemoteOfflineForms(deletedOfflineForms);

        // Publish new templates
        Set<OfflineForm> newOfflineForms = new HashSet<OfflineForm>(localOfflineForms);
        newOfflineForms.removeAll(remoteOfflineForms);
        publishRemoteOfflineForms(newOfflineForms);
    }

    // Public Methods ---------------------------------------------------------

    /**
     * Return the set of form templates from the remote server.
     *
     * @return the set of form templates from the remote server.
     */
    private Set<FormTemplate> getRemoteTemplates() {
        final Set<FormTemplate> remoteTemplates = new HashSet<FormTemplate>();

        final String basePath = getBasePath();

        Map<String, String> requestParams = new HashMap<String, String>();

        makeRemoteCall("servlet/ListFormsServlet", requestParams, new ResponseHandler(){
            public void handleResponse(int responseCode, String responseBody) {
                if (responseCode == HttpStatus.SC_OK) {

                    StringTokenizer tokenizer = new StringTokenizer(responseBody);

                    // Process all the listed forms and make sure they belong to this server, i.e.
                    // they have the same basepath.
                    while (tokenizer.hasMoreTokens()) {
                        String form = tokenizer.nextToken();

                        if (form.startsWith(basePath)) {
                            // String base path
                            String baseForm = form.substring(basePath.length() + 1);
                            String formPath = baseForm.substring(0, baseForm.indexOf('/'));
                            String formName = baseForm.substring(baseForm.indexOf('/') + 1);

                            // ignore offline submission forms
                            if (!formPath.startsWith(OfflineSubmissionForm.OSF_PREFIX)) {
                                remoteTemplates.add(new FormTemplate(formPath, formName));
                            }
                        }
                    }
                }
            }
        });

        return remoteTemplates;
    }

    /**
     * Return the set of form templates from the local database.
     *
     * @return the set of form templates from the local database.
     */
    private Set<FormTemplate> getLocalTemplates() {
        Set<FormTemplate> localTemplates = new HashSet<FormTemplate>();

        TemplateVersionDao templateVersionDao = new TemplateVersionDao();

        List<TemplateVersion> templateVersionList = templateVersionDao.getAll();

        for (TemplateVersion templateVersion : templateVersionList) {
            FormTemplate formTemplate = new FormTemplate(templateVersion);
            localTemplates.add(formTemplate);
        }

        return localTemplates;
    }

    /**
     * Delete the set of given form template from the remote server.
     *
     * @param formTemplateSet the form template to delete
     */
    private void deleteRemoteTemplates(Set<FormTemplate> formTemplateSet) {
        String basePath = getBasePath();

        basePath = (basePath.endsWith("/")) ? basePath : basePath + '/';

        for (FormTemplate formTemplate : formTemplateSet) {

            Map<String, String> requestParams = new HashMap<String, String>();

            final String formPath = basePath + formTemplate.version;
            final String formName = formTemplate.formName;
            requestParams.put(PARAM_FORM_PATH, formPath);
            requestParams.put(PARAM_FORM_NAME, formName);

            makeRemoteCall("servlet/RemoveFormServlet", requestParams, new ResponseHandler(){
                public void handleResponse(int responseCode, String responseBody) {
                    if (responseCode == HttpStatus.SC_OK) {
                        String msg = "Deleted remote template [" + formPath + '/' + formName + "] : "
                            + responseCode + " : " + responseBody;
                        getLogger().info(msg);

                    } else {
                        String msg = "Could not deleted remote template [" + formPath + '/' + formName + "] : "
                            + responseCode + " : " + responseBody;
                        getLogger().info(msg);
                    }
                }
            });

        }
    }

    /**
     * Publish the set of given form template to the remote server.
     *
     * @param formTemplateSet the form template to publish
     */
    private void publishRemoteTemplates(Set<FormTemplate> formTemplateSet) {
        PublishTemplateService publishService = (PublishTemplateService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_PUBLISH_TEMPLATE);

        if (publishService instanceof DiisrPublishTemplateService) {
            for (FormTemplate formTemplate : formTemplateSet) {
                publishService.publishTemplate(formTemplate.templateVersion);
            }

        } else {
            String msg = "PublishTemplateService not configured as: " +
                DiisrPublishTemplateService.class.getName();
            eventLogService.logWarnEvent(msg);
        }
    }

    /**
     * Return the set of offline submission forms from the remote server.
     *
     * @return the set of offline forms from the remote server.
     */
    private Set<OfflineForm> getRemoteOfflineForms() {
        final Set<OfflineForm> remoteOfflineForms = new HashSet<OfflineForm>();

        final String basePath = getBasePath();

        Map<String, String> requestParams = new HashMap<String, String>();

        makeRemoteCall("servlet/ListFormsServlet", requestParams, new ResponseHandler(){
            public void handleResponse(int responseCode, String responseBody) {
                if (responseCode == HttpStatus.SC_OK) {

                    StringTokenizer tokenizer = new StringTokenizer(responseBody);

                    // Process all the listed forms and make sure they belong to this server, i.e.
                    // they have the same basepath.
                    while (tokenizer.hasMoreTokens()) {
                        String form = tokenizer.nextToken();

                        if (form.startsWith(basePath)) {
                            // String base path
                            String baseForm = form.substring(basePath.length() + 1);
                            String formPath = baseForm.substring(0, baseForm.indexOf('/'));
                            String formName = baseForm.substring(baseForm.indexOf('/') + 1);

                            // include only offline submission forms
                            if (formPath.startsWith(OfflineSubmissionForm.OSF_PREFIX)) {
                                remoteOfflineForms.add(new OfflineForm(formPath, formName, formPath.substring(OfflineSubmissionForm.OSF_PREFIX.length())));
                            }
                        }
                    }
                }
            }
        });

        return remoteOfflineForms;
    }

    /**
     * Return the set of offline submission forms from the local database.
     *
     * @return the set of offline forms from the local database.
     */
    private Set<OfflineForm> getLocalOfflineForms() {
        Set<OfflineForm> localOfflineForms = new HashSet<OfflineForm>();

        OfflineSubmissionFormDao offlineSubmissionFormDao = new OfflineSubmissionFormDao();

        List<OfflineSubmissionForm> offlineSubmissionFormList = offlineSubmissionFormDao.getAll();

        for (OfflineSubmissionForm offlineSubmissionForm : offlineSubmissionFormList) {
            OfflineForm offlineForm = new OfflineForm(offlineSubmissionForm);
            localOfflineForms.add(offlineForm);
        }

        return localOfflineForms;
    }

    /**
     * Delete the set of given offline submission forms from the remote server.
     *
     * @param offlineFormSet the offline forms to delete
     */
    private void deleteRemoteOfflineForms(Set<OfflineForm> offlineFormSet) {
        String basePath = getBasePath();

        basePath = (basePath.endsWith("/")) ? basePath : basePath + '/';

        for (OfflineForm offlineForm : offlineFormSet) {

            Map<String, String> requestParams = new HashMap<String, String>();

            final String formPath = basePath + OfflineSubmissionForm.OSF_PREFIX + offlineForm.version;
            final String formName = offlineForm.formName;
            requestParams.put(PARAM_FORM_PATH, formPath);
            requestParams.put(PARAM_FORM_NAME, formName);

            makeRemoteCall("servlet/RemoveFormServlet", requestParams, new ResponseHandler(){
                public void handleResponse(int responseCode, String responseBody) {
                    if (responseCode == HttpStatus.SC_OK) {
                        String msg = "Deleted remote offline submission form [" + formPath + '/' + formName + "] : "
                            + responseCode + " : " + responseBody;
                        getLogger().info(msg);

                    } else {
                        String msg = "Could not delet remote offline submission form [" + formPath + '/' + formName + "] : "
                            + responseCode + " : " + responseBody;
                        getLogger().info(msg);
                    }
                }
            });

        }
    }

    /**
     * Publish the set of given offline submission forms to the remote server.
     *
     * @param offlineFormSet the offline forms to publish
     */
    private void publishRemoteOfflineForms(Set<OfflineForm> offlineFormSet) {
        PublishTemplateService publishService = (PublishTemplateService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_PUBLISH_TEMPLATE);

        if (publishService instanceof DiisrPublishTemplateService) {
            for (OfflineForm offlineForm : offlineFormSet) {
                publishService.publishOfflineSubmissionForm(offlineForm.offlineSubmissionForm);
            }

        } else {
            String msg = "PublishTemplateService not configured as: " +
                DiisrPublishTemplateService.class.getName();
            eventLogService.logWarnEvent(msg);
        }
    }

    /**
     * Make a remote HTTP service call to the given servlet with the specified parameters,
     *
     * @param targetServlet the target servlet to call
     * @param requesParams the additional servlet specific request parameters
     * @param responseHandler the HTTP response handler
     */
    private void makeRemoteCall(
            final String targetServlet,
            final Map<String, String> requestParams,
            final ResponseHandler responseHandler) {

        ServiceConnection serviceConnection = getServiceDefinition().getConnection();
        if (serviceConnection == null) {
            String context = "ServiceDefinition.ServiceName=" + getServiceDefinition().getServiceName();
            String userMessage = "ServiceConnection has not been configured for ServiceDefinition";
            String solution = "Configure the ServiceConnection for the ServiceDefinition";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        String password = serviceConnection.getPassword();
        if (StringUtils.isBlank(password)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection password is blank";
            String solution = "Configure the ServiceConnection Password";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        // Get the target server URL
        String requestTarget = serviceConnection.getEndpointValue();
        if (StringUtils.isBlank(requestTarget)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection EndPointValue has not been configured";
            String solution = "Configure the ServiceConnection EndPointValue";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }
        if (requestTarget.endsWith("/")) {
            requestTarget += targetServlet;
        } else {
            requestTarget += "/" + targetServlet;
        }

        requestParams.put(PARAM_SECURITY_HASH, password);

        NameValuePair[] data = new NameValuePair[requestParams.size()];
        Iterator<String> iterator = requestParams.keySet().iterator();
        int index = 0;
        while (iterator.hasNext()) {
            String name = iterator.next();
            String value = requestParams.get(name);
            data[index++] = new NameValuePair(name, value);
        }

        HttpClient client = new HttpClient();
        PostMethod postMethod = new PostMethod(requestTarget);

        postMethod.setRequestBody(data);

        InputStream responseStream = null;
        try {
            int responseCode = client.executeMethod(postMethod);

            responseStream = postMethod.getResponseBodyAsStream();

            byte[] byteArray = IOUtils.toByteArray(responseStream);

            String responseBody = new String(byteArray);

            responseHandler.handleResponse(responseCode, responseBody);

        } catch (IOException ioe) {
            String context = "requestTarget=" + requestTarget;
            String userMsg  = "Unknown error occured: " + ioe.toString();
            throw new ApplicationException(getClass().getSimpleName(), ioe, context, userMsg, null);

        } finally {
            CoreUtils.close(responseStream);
            postMethod.releaseConnection();
        }
    }

    private String getBasePath() {

        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String basePath = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Render_Service_Base_Path);

        if (StringUtils.isBlank(basePath)) {
            String context = DeploymentProperty.PROPERTY_Render_Service_Base_Path + " is not defined";
            String userMessage = "Remote Render Service Base Path has not been configured";
            String solution = "Configure the DeploymentProperty: " + DeploymentProperty.PROPERTY_Render_Service_Base_Path;
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        basePath = basePath.replace('\\', '/');

        basePath = (basePath.startsWith("/")) ? basePath : "/" + basePath;

        return basePath;
    }

    // Inner Classes ---------------------------------------------------------

    /**
     * Handle the HTTP response code and body interface.
     *
     * @author medgar
     */
    private interface ResponseHandler {
        public void handleResponse(int responseCode, String responseBody);
    }


    /**
     * Provides a form template bean.
     *
     * @author medgar
     */
    private static class FormTemplate {
        public String formName;
        public String formPath;
        public String version;
        public TemplateVersion templateVersion;

        public FormTemplate(TemplateVersion templateVersion) {
            this.templateVersion = templateVersion;
            this.version = templateVersion.getId().toString();
            this.formName = templateVersion.getFileName();
        }

        public FormTemplate(String formPath, String formName) {
            this.version = formPath;
            this.formName = formName;
            this.formPath= formPath;
        }

        public int hashCode() {
            return version.hashCode();
        }

        public boolean equals(Object object) {
            if (object instanceof FormTemplate) {
                FormTemplate formTemplate = (FormTemplate) object;
                return version.equals(formTemplate.version);
            }
            return false;
        }

        public String toString() {
            return getClass().getSimpleName()
                + "[formName=" + formName
                + ",formPath=" + formPath
                + ",version=" + version
                + "]";
        }
    }

    /**
     * Provides an offline form bean.
     *
     * @author lpammer
     */
    private static class OfflineForm {
        public String formName;
        public String formPath;
        public String version;
        public OfflineSubmissionForm offlineSubmissionForm;

        public OfflineForm(OfflineSubmissionForm offlineSubmissionForm) {
            this.offlineSubmissionForm = offlineSubmissionForm;
            version = offlineSubmissionForm.getId().toString();
            formName = offlineSubmissionForm.getTemplateFileName();
        }

        public OfflineForm(String formPath, String formName, String version) {
            this.version = version;
            this.formName = formName;
            this.formPath = formPath;
        }

        public int hashCode() {
            return version.hashCode();
        }

        public boolean equals(Object object) {
            if (object instanceof OfflineForm) {
                OfflineForm offlineForm = (OfflineForm) object;
                return version.equals(offlineForm.version);
            }
            return false;
        }

        public String toString() {
            return getClass().getSimpleName()
                + "[formName=" + formName
                + ",formPath=" + formPath
                + ",version=" + version
                + "]";
        }
    }
}

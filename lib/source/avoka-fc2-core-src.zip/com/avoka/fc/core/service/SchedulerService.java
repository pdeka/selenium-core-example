package com.avoka.fc.core.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.Validate;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.TriggerUtils;

import com.avoka.core.util.CayenneUtils;
import com.avoka.fc.core.util.ApplicationException;

public class SchedulerService extends BaseService {

    private static final String FC_GROUP_NAME = "fc-group";
    private static final String FC_TRIGGER_GROUP_NAME = "fc-trigger-group";

    private final Scheduler scheduler;

    private static SchedulerService instance;

    public SchedulerService(Scheduler scheduler) {
        Validate.notNull(scheduler, "Null servletContext param");

        assert(instance == null);

        this.scheduler = scheduler;

        instance = this;
    }

    public synchronized static SchedulerService getInstance() {
        return instance;
    }

    /**
     * Return the schduler instance.
     *
     * @return the schduler instance
     */
    public Scheduler getScheduler() {
        return scheduler;
    }

    public Date scheduleJob(JobDetail jobDetail, Date startDate, Date endDate, int repeatCount, long repeatInterval) {
        Validate.notNull(jobDetail, "Null jobDetail parameter");

        // get a "nice round" time a few seconds in the future....
        long ts = TriggerUtils.getNextGivenSecondDate(null, 10).getTime();

        if (startDate == null || startDate.before(new Date())) {
            startDate = new Date(ts);
        }

        jobDetail.setGroup(FC_GROUP_NAME);

        SimpleTrigger trigger =
            new SimpleTrigger(jobDetail.getName(),
                              FC_TRIGGER_GROUP_NAME,
                              jobDetail.getName(),
                              jobDetail.getGroup(),
                              startDate,
                              endDate,
                              repeatCount,
                              repeatInterval);

        try {
            return getScheduler().scheduleJob(jobDetail, trigger);

        } catch (SchedulerException se) {
            String msg = "Could not obtain schedule job " + jobDetail;
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Return true if the scheduler is paused.
     *
     * @return true if the scheduler is paused
     */
// MAE - does not function correctly with LC ES2 Quartz library
//    public boolean isPaused() {
//        Connection connection = null;
//        try {
//            connection = CayenneUtils.getConnection();
//
//            Statement statement = connection.createStatement();
//
//            ResultSet rs = statement.executeQuery("SELECT * FROM qrtz_paused_trigger_grps q where trigger_group = 'fc-trigger-group';");
//
//            return rs.next();
//
//        } catch (SQLException sqle) {
//            String msg = "Could not determine if scheduler paused";
//            throw new ApplicationException("SchedulerError", sqle, msg, msg, null);
//
//        } finally {
//            try {
//                connection.close();
//            } catch (SQLException sqle) {
//                // Ignore
//            }
//        }
//    }

    /**
     * Pause all the scheduled jobs, and interrupt any currently executing jobs.
     */
    public void pauseAll() {
        try {
            for (Iterator i = scheduler.getCurrentlyExecutingJobs().iterator(); i.hasNext();) {
                JobExecutionContext context = (JobExecutionContext) i.next();
                interuptJob(context.getJobDetail().getName());
            }

            getScheduler().pauseAll();

        } catch (SchedulerException se) {
            String msg = "Could not pause all jobs";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Resume all paused jobs.
     */
    public void resumeAll() {
        try {
            getScheduler().resumeAll();

        } catch (SchedulerException se) {
            String msg = "Could not resume all jobs";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Pause the job for the given name.
     *
     * @param jobName the name of the job to pause
     */
    public void pauseJob(String jobName) {
        try {
            getScheduler().pauseJob(jobName, FC_GROUP_NAME);

        } catch (SchedulerException se) {
            String msg = "Could not pause Quartz Scheduler job: " + jobName;
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Resume the job for the given name.
     *
     * @param jobName the name of the job to resume
     */
    public void resumeJob(String jobName) {
        try {
            getScheduler().resumeJob(jobName, FC_GROUP_NAME);

        } catch (SchedulerException se) {
            String msg = "Could not resume Quartz Scheduler job: " + jobName;
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Trigger the job for the given name.
     *
     * @param jobName the name of the job to trigger
     */
    public void triggerJob(String jobName) {
        try {
            getScheduler().triggerJob(jobName, FC_GROUP_NAME);

        } catch (SchedulerException se) {
            String msg = "Could not resume Quartz Scheduler job: " + jobName;
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Interupt the job for the given name, return true if the job was found.
     *
     * @param jobName the name of the job to interupt
     */
    public boolean interuptJob(String jobName) {
        try {
            return getScheduler().interrupt(jobName, FC_GROUP_NAME);

        } catch (SchedulerException se) {
            String msg = "Could not obtain Quartz Scheduler JobDetails";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Delete the job for the given name, return true if the job was found.
     *
     * @param jobName the name of the job to delete
     * @return true if the Job was found and deleted.
     */
    public boolean deleteJob(String jobName) {
        try {
            return getScheduler().deleteJob(jobName, FC_GROUP_NAME);

        } catch (SchedulerException se) {
            String msg = "Could not obtain Quartz Scheduler JobDetails";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Return the list of scheduled JobDetails for the group name: "fc-group".
     *
     * @return the list of scheduled JobDetails for the group name: "fc-group"
     */
    public List getJobDetailList() {
        try {
            List list = new ArrayList();

            String[] jobNames = getScheduler().getJobNames(FC_GROUP_NAME);

            for (int i = 0; i < jobNames.length; i++) {
                list.add(getScheduler().getJobDetail(jobNames[i], FC_GROUP_NAME));
            }

            return list;

        } catch (SchedulerException se) {
            String msg = "Could not obtain Quartz Scheduler JobDetails";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Return the JobDetail for the given name and group name: "fc-group".
     *
     * @return the JobDetail for the given name and group name: "fc-group".
     */
    public JobDetail getJobDetail(String jobName) {
        try {
            return getScheduler().getJobDetail(jobName, FC_GROUP_NAME);

        } catch (SchedulerException se) {
            String msg = "Could not obtain Quartz Scheduler JobDetail";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Return true if the scheduler has the named job.
     *
     * @param jobName the name of the job
     * @return true if the scheduler has the named job
     */
    public boolean hasJob(String jobName) {
        try {
            return (getScheduler().getJobDetail(jobName, FC_GROUP_NAME) != null);

        } catch (SchedulerException se) {
            String msg = "Could not obtain Quartz Scheduler JobDetail";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Return the list of JobDetail and Trigger associations.
     *
     * @return the list of JobDetail and Trigger associations
     */
    public List<JobAndTrigger> getJobAndTriggerList() {
        try {
            List<JobAndTrigger> list = new ArrayList<JobAndTrigger>();

            String[] jobNames = getScheduler().getJobNames(FC_GROUP_NAME);

            for (int i = 0; i < jobNames.length; i++) {
                String jobName = jobNames[i];

                JobDetail jobDetail = getJobDetail(jobName);

                SimpleTrigger trigger  = (SimpleTrigger) getScheduler().getTrigger(jobName, FC_TRIGGER_GROUP_NAME);

                list.add(new JobAndTrigger(jobDetail, (SimpleTrigger) trigger, getScheduler()));
            }

            return list;

        } catch (SchedulerException se) {
            String msg = "Could not obtain Quartz Scheduler JobAndTriggerList";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

    /**
     * Return the Job and Trigger for the given job name
     *
     * @param jobName the name of the job
     * @return the Job and Trigger for the given job name
     */
    public JobAndTrigger getJobAndTrigger(String jobName) {
        Validate.notNull(jobName, "Null jobName parameter");

        try {
            JobDetail jobDetail = getJobDetail(jobName);

            if (jobDetail != null) {
                SimpleTrigger trigger  = (SimpleTrigger) getScheduler().getTrigger(jobName, FC_TRIGGER_GROUP_NAME);

                return new JobAndTrigger(jobDetail, (SimpleTrigger) trigger, getScheduler());

            } else {
                return null;
            }

        } catch (SchedulerException se) {
            String msg = "Could not obtain Quartz Scheduler JobAndTrigger";
            throw new ApplicationException("SchedulerError", se, msg, msg, null);
        }
    }

}

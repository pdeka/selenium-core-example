package com.avoka.fc.core.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.FileUploadData;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.SubmissionHistory;
import com.avoka.fc.core.entity.SubmissionHistoryData;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.SubmissionDataPurgeService;
import com.avoka.fc.core.service.SubmissionStatusService;
import com.avoka.fc.core.util.RemoteUserProvider;

public class SubmissionDataPurgeServiceImpl extends CayenneService implements SubmissionDataPurgeService {

    public static final String PARAM_PURGE_SAVED_SUBMISSION_AGE = "purgeSavedSubmissionAgeMins";
    public static final String PARAM_PURGE_UNDELIVERED_SUBMISSION_AGE = "purgeUndeliveredSubmissionAgeMins";
    public static final String PARAM_PURGE_DELIVERED_SUBMISSION_AGE = "purgeDeliveredSubmissionAgeMins";
    public static final String DELETED_BY = "System";

    private String purgeSavedSubmissionAgeMins;
    private String purgeUndeliveredSubmissionAgeMins;
    private String purgeDeliveredSubmissionAgeMins;

    public void purgeSubmissionData(Submission submission) {
        String formStatus = submission.getFormStatus();
        String deliveryStatus = submission.getDeliveryStatus();

        boolean isSavedSubmission = Submission.STATUS_Saved.equals(formStatus);

        boolean isUndeliveredSubmission = (Submission.STATUS_Completed.equals(formStatus) && !Submission.STATUS_Completed.equals(deliveryStatus)) || Submission.STATUS_Submitted.equals(formStatus);

        boolean isDeliveredSubmission = Submission.STATUS_Completed.equals(deliveryStatus);

        if ((isSavedSubmission && isSavedSubmissionPurgable(submission))
             || (isUndeliveredSubmission && isUndeliveredSubmissionPurgable(submission))
             || (isDeliveredSubmission && isDeliveredSubmissionPurgable(submission))) {

            doPurge(submission);
        }
    }

    public String getPurgeSavedSubmissionAgeMins() {
        return purgeSavedSubmissionAgeMins;
    }

    public void setPurgeSavedSubmissionAgeMins(String newAge) {
        purgeSavedSubmissionAgeMins = newAge;
    }

    public String getPurgeUndeliveredSubmissionAgeMins() {
        return purgeUndeliveredSubmissionAgeMins;
    }

    public void setPurgeUndeliveredSubmissionAgeMins(String newAge) {
        purgeUndeliveredSubmissionAgeMins = newAge;
    }

    public String getPurgeDeliveredSubmissionAgeMins() {
        return purgeDeliveredSubmissionAgeMins;
    }

    public void setPurgeDeliveredSubmissionAgeMins(String newAge) {
        purgeDeliveredSubmissionAgeMins = newAge;
    }

    private boolean isSavedSubmissionPurgable(Submission submission) {
        String ageString = getPurgeSavedSubmissionAgeMins();
        if (StringUtils.isEmpty(ageString)) {
            return false;
        }
        Calendar cutoffTime = GregorianCalendar.getInstance();
        try {
            int age = Integer.parseInt(ageString);
            cutoffTime.add(Calendar.MINUTE, -age);
            Date requestTime = submission.getTimeRequest();
            return (cutoffTime.getTime().compareTo(requestTime) > 0);
        }
        catch (NumberFormatException nfe) {
            String msg = "SubmissionDataPurge: Invalid value for service parameter: '" + ageString + "'. Please change the value to a positive integer.";

            EventLogService eventLogService = new EventLogService();
            eventLogService.logWarnEvent(msg);
            return false;
        }
    }

    private boolean isUndeliveredSubmissionPurgable(Submission submission) {
        String ageString = getPurgeUndeliveredSubmissionAgeMins();
        if (StringUtils.isEmpty(ageString)) {
            return false;
        }
        Calendar cutoffTime = GregorianCalendar.getInstance();
        try {
            int age = Integer.parseInt(ageString);
            cutoffTime.add(Calendar.MINUTE, -age);
            Date submissionTime = submission.getTimeSubmission();
            return (cutoffTime.getTime().compareTo(submissionTime) > 0);
        }
        catch (NumberFormatException nfe) {
            String msg = "SubmissionDataPurge: Invalid value for service parameter: '" + ageString + "'. Please change the value to a positive integer.";

            EventLogService eventLogService = new EventLogService();
            eventLogService.logWarnEvent(msg);
            return false;
        }
    }

    private boolean isDeliveredSubmissionPurgable(Submission submission) {
        String ageString = getPurgeDeliveredSubmissionAgeMins();
        if (StringUtils.isEmpty(ageString)) {
            return false;
        }
        Calendar cutoffTime = GregorianCalendar.getInstance();
        try {
            int age = Integer.parseInt(ageString);
            cutoffTime.add(Calendar.MINUTE, -age);
            Date deliveryTime = submission.getDeliveryTime();
            return (cutoffTime.getTime().compareTo(deliveryTime) > 0);
        }
        catch (NumberFormatException nfe) {
            String msg = "SubmissionDataPurge: Invalid value for service parameter: '" + ageString + "'. Please change the value to a positive integer.";

            EventLogService eventLogService = new EventLogService();
            eventLogService.logWarnEvent(msg);
            return false;
        }
    }

    private void doPurge(Submission submission) {
        if (submission != null && !submission.isDeleted()) {
            SubmissionData submissionData = submission.getSubmissionData();
            if (submissionData != null) {
                deleteObject(submissionData);
            }

            Date deletedTimestamp = new Date();
            submission.setDeletedTimestamp(deletedTimestamp);
            submission.setDeletedFlag(Boolean.TRUE);

            int historyCount = 0;
            List<SubmissionHistory> history = submission.getSubmissionHistory();
            if (history != null) {
                for (int i = 0; i < history.size(); i++) {
                    SubmissionHistory curEntry = history.get(i);
                    purgeHistoryEntry(curEntry);
                }
                historyCount = history.size();
            }

            int attachmentCount = 0;
            List<Attachment> attachments = submission.getAttachments();
            if (attachments != null) {
                for (int i = 0; i < attachments.size(); i++) {
                    Attachment curAttachment = attachments.get(i);
                    purgeAttachment(curAttachment);
                    attachmentCount++;
                }
            }

            SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
            submissionStatusService.updateStatus(submission);

            EventLogService eventLogService = new EventLogService();
            StringBuilder message = new StringBuilder();
            message.append("Submission data");
            if (historyCount > 0) {
                message.append(" (including " + attachmentCount + " history entries)");
            }
            if (attachmentCount > 0) {
                message.append(" and " + attachmentCount + " attachments");
            }
            message.append(" deleted by ");
            message.append(RemoteUserProvider.getRemoteUser());

            eventLogService.logInfoEvent(message.toString(), submission);

            commitChanges();
        }
    }

    private void purgeAttachment(Attachment attachment) {
        if (attachment != null) {
            FileUpload fileUpload = attachment.getFileUpload();
            if (fileUpload != null && !fileUpload.isDeleted()) {
                FileUploadData fileUploadData = fileUpload.getFileUploadData();
                if (fileUploadData != null) {
                    deleteObject(fileUploadData);
                    fileUpload.setFileUploadData(null);
                }

                Date deletedTimestamp = new Date();
                fileUpload.setDeletedTimestamp(deletedTimestamp);
                fileUpload.setDeletedBy(DELETED_BY);
                fileUpload.setDeletedFlag(true);
            }
        }
    }

    private void purgeHistoryEntry(SubmissionHistory historyEntry) {
        if (historyEntry != null) {
            historyEntry.setDeletedFlag(true);

            SubmissionHistoryData submissionHistoryData = historyEntry.getSubmissionHistoryData();
            if (submissionHistoryData != null) {
                deleteObject(submissionHistoryData);
            }
        }
    }
}

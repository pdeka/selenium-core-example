package com.avoka.fc.core.service.health;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.management.ThreadMXBean;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.query.NamedQuery;
import org.apache.cayenne.query.Query;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.service.BaseService;
import com.avoka.fc.core.dao.NamedQueries;
import com.avoka.fc.core.entity.SystemHealth;

public class HealthMonitorService extends BaseService {

    private static CpuMonitor MONITOR;
    private static final int MEGABYTE_AS_BYTES = 1024 * 1024;

    public void startMonitor(long healthCheckIntervalInMilli, long cpuSamplingIntervalInMilli) {
        int snapshotCacheSize = calcSnapshotCacheSize(healthCheckIntervalInMilli, cpuSamplingIntervalInMilli);
        CpuMonitor monitor = getCpuMonitor();

        try {
            monitor.start(snapshotCacheSize, cpuSamplingIntervalInMilli);
        } catch (UnsatisfiedLinkError e) {
            getLogger().error(e.toString());
        }
    }

    public void stopMonitor() {
        getCpuMonitor().stop();
    }

    public SystemHealth collectFullSystemHealth() {
        SystemHealth systemHealth = collectBasicSystemHealth();
        registerNewObject(systemHealth);
        systemHealth.setFormRenderCount(getFormRenderCount());
        systemHealth.setReceiptRenderCount(getReceiptRenderCount());
        systemHealth.setSubmissionCount(getSubmissionCount());
        systemHealth.setDeliveryCompletedCount(getDeliveryCompletedCount());
        systemHealth.setErrorCount(getErrorCount());
        systemHealth.setEventCount(getEventCount());
        return systemHealth;
    }

    public JvmHealth collectJVMSystemHealth() {
        SystemHealth systemHealth = collectBasicSystemHealth();
        RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
        long uptime = runtimeBean.getUptime();
        JvmHealth jvmHealth = new JvmHealth();
        jvmHealth.setUptime(uptime);

        //TODO wrap systemHealth with JvmHealth
        return jvmHealth;
    }

    private SystemHealth collectBasicSystemHealth() {
        SystemHealth systemHealth = new SystemHealth();
        systemHealth.setTimeCreated(new Date());

        if (getCpuMonitor().isCpuMonitorAvailable()) {
            int avgCpuPercentage = getCpuMonitor().calcCpuAveragePercentage();
            systemHealth.setCpuPercentage(avgCpuPercentage);
        } else {
            systemHealth.setCpuPercentage(null);
        }

        Runtime runtime = Runtime.getRuntime();
        systemHealth.setMemoryFree(convertToMb(runtime.freeMemory()));
        systemHealth.setMemoryMax(convertToMb(runtime.maxMemory()));
        systemHealth.setMemoryTotal(convertToMb(runtime.totalMemory()));

        ThreadMXBean threads = ManagementFactory.getThreadMXBean();
        systemHealth.setThreadCount(threads.getThreadCount());
        systemHealth.setThreadMax(threads.getPeakThreadCount());

        return systemHealth;
    }

    private static CpuMonitor getCpuMonitor() {
        if (MONITOR == null) {
            MONITOR = new CpuMonitor();
        }
        return MONITOR;
    }

    private int convertToMb(long value) {
        return (int) (value / MEGABYTE_AS_BYTES);
    }

    private int getFormRenderCount() {
        NamedQuery query = new NamedQuery(NamedQueries.HEALTH_MON_FORM_RENDER_COUNT);
        return performCountQuery(query);
    }

    private int getReceiptRenderCount() {
        NamedQuery query = new NamedQuery(NamedQueries.HEALTH_MON_RECEIPT_RENDER_COUNT);
        return performCountQuery(query);
    }

    private int getSubmissionCount() {
        NamedQuery query = new NamedQuery(NamedQueries.HEALTH_MON_SUBMISSION_COUNT);
        return performCountQuery(query);
    }

    private int getDeliveryCompletedCount() {
        NamedQuery query = new NamedQuery(NamedQueries.HEALTH_MON_DELIVERY_COMPLETED_COUNT);
        return performCountQuery(query);
    }

    private int getErrorCount() {
        NamedQuery query = new NamedQuery(NamedQueries.HEALTH_MON_ERROR_COUNT);
        return performCountQuery(query);
    }

    private int getEventCount() {
        NamedQuery query = new NamedQuery(NamedQueries.HEALTH_MON_EVENT_COUNT);
        return performCountQuery(query);
    }

    private static int calcSnapshotCacheSize(long healthCheckIntervalInMilli,
            long cpuSamplingIntervalInMilli) {
        // the cache should be large enough to store all cpu samples,
        // until the next system health check is done
        int marginOfError = 10;
        return (int) (healthCheckIntervalInMilli / cpuSamplingIntervalInMilli) + marginOfError;
    }

    private int performCountQuery(Query query) {
        List result = getDataContext().performQuery(query);
        if (result == null || result.isEmpty()) {
            return 0;
        }
        Map entry = (Map) result.get(0);
        Object count = entry.get("count");
        return NumberUtils.toInt(count.toString());
    }
}

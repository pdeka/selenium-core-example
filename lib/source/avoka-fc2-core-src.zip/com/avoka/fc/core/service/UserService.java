/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.cayenne.exp.Expression;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.ClientDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.PermissionDao;
import com.avoka.fc.core.dao.PortalDao;
import com.avoka.fc.core.dao.PropertyTypeDao;
import com.avoka.fc.core.dao.RoleDao;
import com.avoka.fc.core.dao.RolePermissionDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Group;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalUser;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.Role;
import com.avoka.fc.core.entity.RolePermission;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserGroup;
import com.avoka.fc.core.entity.UserProfile;
import com.avoka.fc.core.entity.UserProperty;
import com.avoka.fc.core.entity.UserRole;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.RemoteUserProvider;

/**
 * Provides Management entities service.
 *
 * @author David Frizelle
 * @author Malcolm Edgar
 */
public class UserService extends CayenneService {

    private UserAccountDao      adminDetailsDao    = new UserAccountDao();
    private PropertyTypeDao     propertyTypeDao    = new PropertyTypeDao();
    private PermissionDao       permissionDao      = new PermissionDao();
    private RoleDao             roleDao            = new RoleDao();
    private UserAccountDao      userAccountDao     = new UserAccountDao();

    // --------------------------------------------------------- Public Methods

    public Permission getPermissionByName(String name) {
        return permissionDao.getPermissionByName(name);
    }

    public List getAdminsRoleIds(Object adminId) {
        UserAccount admin = adminDetailsDao.getUserAccountForPK(adminId);
        Expression qualifier = ExpressionFactory.matchExp(UserRole.ADMIN_PROPERTY, admin);
        SelectQuery query = new SelectQuery(UserRole.class, qualifier);
        List adminRoles = getDataContext().performQuery(query);
        List adminRoleIds = new ArrayList();
        for (Iterator i = adminRoles.iterator(); i.hasNext();) {
            UserRole adminRole = (UserRole) i.next();
            if (adminRole != null && adminRole.getRole() != null) {
                adminRoleIds.add(adminRole.getRole().getId().toString());
            }
        }
        return adminRoleIds;
    }

    public List getRolesPermissionIds(Object roleId, Object portalId) {
        PortalDao portalDao = DaoFactory.getPortalDao();
        Portal portal = portalDao.getObjectForPK(portalId);

        Role role = roleDao.getRole(roleId);
        Expression qualifier = ExpressionFactory.matchExp(RolePermission.ROLE_PROPERTY, role);

        SelectQuery query = new SelectQuery(RolePermission.class, qualifier);
        List rolePermissions = getDataContext().performQuery(query);

        List<String> permissionIds = new LinkedList<String>();
        for (Iterator i = rolePermissions.iterator(); i.hasNext();) {
            RolePermission rolePermission = (RolePermission) i.next();
            if (rolePermission != null && rolePermission.getPermission() != null) {
                Permission permission = rolePermission.getPermission();
                if (portal != null) {
                    Portal permissionPortal = permission.getPortal();
                    if (permissionPortal != null && portal.getName().equals(permissionPortal.getName())) {
                        permissionIds.add(permission.getId().toString());
                    }
                } else {
                    permissionIds.add(permission.getId().toString());
                }
            }
        }
        return permissionIds;
    }

    /**
     * Update the given user to have the given list of roles only (i.e delete ones not in list, add
     * ones in list).
     *
     * @param adminId
     * @param roleIds
     */
    public void updateRoles(Object adminId, List<String> newRoleIds, UserAccount currentAdminUser) {
        Validate.notNull(currentAdminUser, "Null currentAdminUser parameter");

        UserAccount admin = adminDetailsDao.getUserAccountForPK(adminId);

        List<UserRole> currentRoles = admin.getAdminRoles();

        List<Role> globalRolesToKeep = new ArrayList<Role>();
        if (currentAdminUser != null && currentAdminUser.getClient() != null) {
            // if the current user is a client admin we need to keep all the global roles because the client admin cannot modify them
            for (UserRole adminRole: currentRoles) {
                Role role = adminRole.getRole();
                if (role.getClientAssignableFlag() == null || Boolean.FALSE.equals(role.getClientAssignableFlag())) {
                    globalRolesToKeep.add(role);
                }
            }
        }

        // Remove all existing admin roles.
        getDataContext().deleteObjects(currentRoles);

        List<String> newRoleNames = new ArrayList<String>();

        // Add new Roles
        for (String newRoleId : newRoleIds) {
            UserRole userRole = new UserRole();
            Role newRole = roleDao.getRole(newRoleId);
            userRole.setRole(newRole);
            userRole.setAdmin(admin);
            getDataContext().registerNewObject(userRole);
            newRoleNames.add(newRole.getRoleName());
        }

        // add back all previous global roles
        for (Role role: globalRolesToKeep) {
            if (!newRoleNames.contains(role.getRoleName())) {
                UserRole userRole = new UserRole();
                userRole.setRole(role);
                userRole.setAdmin(admin);
                getDataContext().registerNewObject(userRole);
                newRoleNames.add(role.getRoleName());
            }
        }

        getDataContext().commitChanges();
    }

    public void updateGroups(Object adminId, List<String> groupIdList) {

        UserAccount userAccount = adminDetailsDao.getUserAccountForPK(adminId);

        getDataContext().deleteObjects(userAccount.getUserGroups());

        for (String groupId : groupIdList) {
            Group group = DaoFactory.getGroupDao().getGroupForPK(groupId);
            UserGroup userGroup = new UserGroup();
            userGroup.setGroup(group);
            userGroup.setUser(userAccount);
        }

        getDataContext().commitChanges();
    }

    public void updatePortals(Object userId, List<String> portalIdList) {

        UserAccount userAccount = adminDetailsDao.getUserAccountForPK(userId);

        getDataContext().deleteObjects(userAccount.getPortalUsers());

        for (String portalId : portalIdList) {
            Portal portal = DaoFactory.getPortalDao().getObjectForPK(portalId);
            PortalUser portalUser = new PortalUser();
            portalUser.setPortal(portal);
            portalUser.setUser(userAccount);
        }

        getDataContext().commitChanges();
    }

    public void updatePermissions(String roleId, String portalId, List<String> newPermissionIds) {
        Role role = roleDao.getRole(roleId);

        // delete existing role permissions for the specified portal
        RolePermissionDao rolePermissionDao = DaoFactory.getRolePermissionDao();
        List<RolePermission> obsoleteRolePermissions = rolePermissionDao.getRolePermissionsForPortal(roleId, portalId);
        deleteObjects(obsoleteRolePermissions);

        getDataContext().commitChanges();

        // Add new Permissions
        for (String newPermissionId : newPermissionIds) {
            RolePermission rolePermission = new RolePermission();
            Permission permission = permissionDao.getPermission(newPermissionId);
            rolePermission.setPermission(permission);
            rolePermission.setRole(role);
            getDataContext().registerNewObject(rolePermission);
        }
        getDataContext().commitChanges();
    }

    public void loadDefaultAdminUser() {
        if (adminDetailsDao.getUserAccountList().isEmpty()) {
            Role role = roleDao.getRoleForName(Role.ADMINISTRATOR_ROLE);
            if (role == null) {
                roleDao.assignDefaultPermissions();
            }

            PortalDao portalDao = DaoFactory.getPortalDao();
            Portal adminConsole = portalDao.getAdminConsolePortal();
            if (adminConsole == null) {
                portalDao.loadAdminConsolePortal();
                adminConsole = portalDao.getAdminConsolePortal();
            }

            UserAccount admin = new UserAccount();
            admin.setLoginName(UserAccount.ROOT_ADMIN);
            admin.setFamilyName("Root Administrator");
            admin.setPassword("password");
            admin.setActiveFlag(Boolean.TRUE);
            getDataContext().registerNewObject(admin);

            UserRole adminRole = new UserRole();
            adminRole.setAdmin(admin);
            adminRole.setRole(role);
            getDataContext().registerNewObject(adminRole);

            PortalUser portalUser = new PortalUser();
            portalUser.setUser(admin);
            portalUser.setPortal(adminConsole);
            getDataContext().registerNewObject(portalUser);

            getLogger().debug("Created Root Administrator user: " + UserAccount.ROOT_ADMIN);
        }
    }

    public boolean belongsToClient(String userName, String clientId) {
        UserAccountDao adminDetailsDao = new UserAccountDao();
        UserAccount admin = adminDetailsDao.getUserAccountForLogin(userName);
        if (admin != null) {
            Client client = admin.getClient();
            if (client != null) {
                if (client.getId().toString().equals(clientId)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Return a list of clients that the Currently logged in user has access too.
     *
     * @param request
     * @return
     */
    public List<Client> getAccessableClients(HttpServletRequest request) {
        // If user has global permissions then get all clients.
        String curClientId = RemoteUserProvider.getClientId();
        if (StringUtils.isEmpty(curClientId)) {
            ClientDao clientDao = new ClientDao();
            return clientDao.getAllClients();
        }

        // Otherwise return the client (if there is one) that the admin user belogs too.
        List<Client> clients = new ArrayList<Client>();
        UserAccountDao adminDetailsDao = new UserAccountDao();
        UserAccount admin = adminDetailsDao.getUserAccountForLogin(request.getRemoteUser());
        if (admin != null) {
            Client client = admin.getClient();
            if (client != null) {
                clients.add(client);
            }
        }
        return clients;
    }

    /**
     * Create a registered user with a default profile from the given user details.
     *
     * @param loginName the users login name (required)
     * @param email the users email (required)
     * @param password the users login password (required)
     * @param givenName the users first name (required)
     * @param familyName the users family name (required)
     * @return the persisted UserDetails object
     * @throws ApplicationException if the username already exists or the password is not valid
     */
    public UserAccount createUserAndProfile(String loginName, String email, String password, String givenName, String familyName, Portal portal) {

        Validate.notEmpty(loginName, "Empty loginName parameter");
        Validate.notEmpty(email, "Empty email parameter");
        Validate.notEmpty(password, "Empty password parameter");
        Validate.notEmpty(givenName, "Empty givenName parameter");
        Validate.notEmpty(familyName, "Empty familyName parameter");
        Validate.notNull(portal, "Null portal parameter");

        if (userAccountDao.getUserAccountForLogin(loginName) != null) {
            throw new ApplicationException("Invalid login name", "login name=" + loginName + " already exists",
                    "The login name specified already exists.", "Choose a different login name.");
        }

        validatePassword(password);

        UserAccount userAccount = (UserAccount) createAndRegisterNewObject(UserAccount.class);
        userAccount.setLoginName(loginName);
        userAccount.setEmail(email);
        userAccount.setGivenName(givenName);
        userAccount.setFamilyName(familyName);
        userAccount.setPassword(password);

        newUserAndProfile(userAccount);

        PortalUser portalUser = (PortalUser) createAndRegisterNewObject(PortalUser.class);
        portalUser.setUser(userAccount);
        portalUser.setPortal(portal);

        RemoteUserProvider.setRemoteUser(userAccount);

        commitChanges();

        return userAccount;
    }

    public boolean addPortalForUser(UserAccount user, Portal portal) {
        Validate.notNull(user, "Null user parameter");
        Validate.notNull(portal, "Null portal parameter");

        List<PortalUser> portalUsers = user.getPortalUsers();
        for (PortalUser portalUser: portalUsers) {
            if (portal.getName().equals(portalUser.getPortal().getName())) {
                // found a portal user for the portal - no need for a change, return false
                return false;
            }
        }

        // no portal user for the portal exists - create it, return true
        PortalUser newPortalUser = (PortalUser) createAndRegisterNewObject(PortalUser.class);
        newPortalUser.setUser(user);
        newPortalUser.setPortal(portal);
        commitChanges();

        return true;
    }

    public boolean isAssociatedWithPortal(UserAccount user, String portalName) {
        Validate.notNull(user, "Null user parameter");
        Validate.notEmpty(portalName, "Null portalName parameter");

        List<PortalUser> portalUsers = user.getPortalUsers();
        for (PortalUser portalUser: portalUsers) {
            if (portalName.equals(portalUser.getPortal().getName())) {
                return true;
            }
        }

        return false;
    }

    public void changeUserPassword(UserAccount userAccount, String newPassword) {
        Validate.notNull(userAccount, "Null userAccount parameter");
        Validate.notNull(newPassword, "Null newPassword parameter");

        String error = userAccount.validatePassword(newPassword);
        if (error != null) {
            throw new RuntimeException("Invalid password: " + error);
        }

        userAccount.setPassword(newPassword);

        commitChanges();
    }

    public void generatePassword(UserAccount userAccount) {
        Validate.notNull(userAccount, "Null userAccount parameter");

        String newPassword = UUID.randomUUID().toString();
        userAccount.setPassword(newPassword);
    }

    /**
     * Set a new user with a default profile from the given user details.
     *
     * @param email the users email (required)
     * @param password the users login password (required)
     * @return the persisted UserDetails object
     * @throws ApplicationException if the username already exists or the password is not valid
     */
    public void newUserAndProfile(UserAccount userAccount) {

        Validate.notNull(userAccount, "Null userAccount parameter");

        if (userAccountDao.getUserAccountForLogin(userAccount.getLoginName()) != null) {
            throw new ApplicationException("Invalid login name", "login name=" + userAccount.getLoginName() + " already exists",
                    "The specified login name already exists.", "Choose a different login name.");
        }

        String validationError = validatePassword(userAccount.getPassword());
        if (validationError != null) {
            throw new ApplicationException("Invalid Password", "password=" + userAccount.getPassword(), validationError, validationError);
        }

        userAccount.setActiveFlag(Boolean.TRUE);
        userAccount.setUserKey(CoreUtils.createAltKey());

        UserProfile userProfile = (UserProfile) createAndRegisterNewObject(UserProfile.class);
        userProfile.setProfileName(UserProfile.DEFAULT_PROFILE_NAME);
        userProfile.setProfileDescription(UserProfile.DEFAULT_PROFILE_DESCRIPTION);
        userProfile.setCurrentFlag(Boolean.TRUE);
        userProfile.setUser(userAccount);

        List properties = propertyTypeDao.getPropertyTypesByScope(PropertyType.SCOPE_User);

        for (Iterator iter = properties.iterator(); iter.hasNext();) {
            PropertyType pt = (PropertyType) iter.next();

            UserProperty up = (UserProperty) createAndRegisterNewObject(UserProperty.class);

            up.setPropertyType(pt);
            up.setProfile(userProfile);

            if (pt.getName().equals(PropertyType.USER_Property_Given_Name)) {
                up.setValue(userAccount.getGivenName());
            }
            if (pt.getName().equals(PropertyType.USER_Property_Family_Name)) {
                up.setValue(userAccount.getFamilyName());
            }
            if (pt.getName().equals(PropertyType.USER_Property_Email)) {
                up.setValue(userAccount.getEmail());
            }
        }

        commitChanges();
    }

    /**
     * Validate the given password return null if sufficiently complex or otherwise
     * will return an error message.
     * <p/>
     * Valid passwords must be 6 characters in length, and contain a letter and
     * a character, and does not contain the text password.
     *
     * @param password the password to test
     * @return true if the password is valid
     */
    public String validatePassword(String password) {
        if (password == null) {
            return "Password value is required";
        }

        password = password.trim();
        if (password.length() < 6) {
            return "Password value is too short. Password must be at least 6 characters";
        }
        if (password.toLowerCase().indexOf("password") != -1) {
            return "Password must not contain the text 'password'";
        }
        if (password.length() > 36) {
            return "Password value is too long. Password must be no longer than 32 characters";
        }

        boolean numFound = false;
        boolean letterFound = false;

        for (int i = 0 ; i < password.length(); i++ ) {
            char aChar = password.charAt(i);
            if (Character.isDigit(aChar)) {
                numFound = true;
            }
            if (Character.isLetter(aChar)) {
                letterFound = true;
            }
        }

        if (!numFound) {
            return "Password must contain at least one number character.";
        }

        if (!letterFound) {
            return "Password must contain at least one letter character.";
        }

        return null;
    }

}

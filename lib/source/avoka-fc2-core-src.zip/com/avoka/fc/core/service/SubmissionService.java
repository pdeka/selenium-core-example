/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.cayenne.BaseContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.adobe.workflow.DOMUtil;
import com.avoka.core.util.CoreUtils;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.AvokaTemplateSchema;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.FormDeployXmlDao;
import com.avoka.fc.core.dao.RequestLogDao;
import com.avoka.fc.core.dao.TaskDao;
import com.avoka.fc.core.dao.TemplateVersionDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.PaymentItem;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.RequiredAttachment;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.SubmissionHistory;
import com.avoka.fc.core.entity.SubmissionHistoryData;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.DuplicateSubmissionException;
import com.avoka.fc.core.util.FormUtils;
import com.avoka.fc.core.util.PortalUtils;
import com.avoka.fc.core.util.RemoteUserProvider;
import com.avoka.fc.core.util.XPath;
import com.avoka.fc.core.util.xml.SystemProfileHelper;
import com.avoka.fc.core.util.xml.XmlPropertyUtils;
import com.avoka.fc.forms.api.FormsClientWebService;
import com.avoka.fc.forms.api.utils.DataHashUtils;

public class SubmissionService extends CayenneService{

    private DeploymentPropertyDao    deploymentPropertyDao    = DaoFactory.getDeploymentPropertyDao();
    private ErrorLogService          errorLogService          = ServiceFactory.getErrorLogService();
    private EventLogService          eventLogService          = ServiceFactory.getEventLogService();
    private FormDao                  formDao                  = DaoFactory.getFormDao();
    private TemplateVersionDao       templateVersionDao       = DaoFactory.getTemplateVersionDao();
    private UserAccountDao           userAccountDao           = DaoFactory.getUserAccountDao();

    /** Spring injected. */
    private AuthenticationService authenticationService;

    // Public Methods ---------------------------------------------------------

    public AuthenticationService getAuthenticationService() {
        return authenticationService;
    }

    public void setAuthenticationService(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    /**
     * Create a Submission record for the given XML form submission document.
     */
    public Submission saveSubmission(SubmissionDataBean submissionDataBean, HttpServletRequest request, boolean offlineSubmission) {

        Validate.notNull(submissionDataBean);
        Validate.notNull(request);

        // Get all the session details
        String ipAddress = request.getRemoteAddr();
        String adobeVersion = CoreUtils.limitLength(FormUtils.getAcrobatVersion(request), 60);
        String userAgent = CoreUtils.limitLength(request.getHeader("user-agent"), 200);
        String contentType = request.getContentType();
        int contentLength = request.getContentLength();
        HttpSession session = request.getSession(false);
        String sessionId = (session != null) ? session.getId() : null;

        // Get the logged in user account
        String remoteUser = request.getRemoteUser();
        UserAccount userAccount = userAccountDao.getUserAccountForLogin(remoteUser);

        if (userAccount != null) {
            RemoteUserProvider.setRemoteUser(userAccount);
        } else {
            RemoteUserProvider.setRemoteUser("unknown");
        }

        String formStatus = null;

        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction transaction = domain.createTransaction();

        Transaction.bindThreadTransaction(transaction);
        try {

            SystemProfileHelper systemProfileHelper = new SystemProfileHelper(submissionDataBean.getDocument());

            RequestLogDao requestDao = new RequestLogDao();

            String requestLogKey = systemProfileHelper.getRequestLogKey();
            RequestLog requestLog = requestDao.getRequestLogFromKey(requestLogKey);

            if (requestLog == null) {
                // If running in script mode, create a new RequestLog for the incoming request
                if (deploymentPropertyDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_Enable_Script_Submissions)) {
                    // Ensure template version is up to date
                    String formCode = systemProfileHelper.getFormCode();
                    Form form = formDao.getFormByFormCode(formCode);
                    TemplateVersionDao templateVersionDao = DaoFactory.getTemplateVersionDao();

                    String templateVersionOid = systemProfileHelper.getTemplateVersionOid();
                    TemplateVersion templateVersion = templateVersionDao.getTemplateVersionFromPK(templateVersionOid);

                    requestLog = requestDao.createRequestLog(request,
                                                             form,
                                                             templateVersion,
                                                             null,
                                                             userAccount,
                                                             RequestLog.MODE_FORM,
                                                             null);

                    commitChanges();

                } else {

                    // This could be quite a serious problem as someone has attempted to log a
                    // submission without a valid request. Could be a hack attempt

                    getLogger().info(
                        "Audit Details for SubmissonWithInvalidRequestLogKey Exception." + "\nSessionID=" + sessionId
                                + "\nIPAddress=" + ipAddress + "\nSubmissonData= "
                                + XmlUtils.toFormattedString(submissionDataBean.getDocument()));

                    throw new ApplicationException("SubmissonWithInvalidRequestLogKey",
                                               "Submission Request Log Key=" + requestLogKey,
                                               "Invalid Submission. Missing request key.",
                                               null);
                }
            }

            formStatus = systemProfileHelper.getSubmissionType();
            if (!ArrayUtils.contains(Submission.FORM_STATUS_VALUES, formStatus)) {
                throw new ApplicationException("SubmissonWithInvalidFormStatus",
                        "Form Status=" + formStatus,
                        "Cannot process submission due to invalid form status.",
                        null);
            }

            // If a duplicate submission return it now
            Submission duplicateSubmission = getDuplicateSubmission
                (requestLog, systemProfileHelper, submissionDataBean, ipAddress, userAgent, sessionId);
            if (duplicateSubmission != null) {
                return duplicateSubmission;
            }

            formStatus = systemProfileHelper.getSubmissionType();
            if (!Submission.STATUS_Saved.equals(formStatus)) {
                int newSubmissionCount = (requestLog.getSubmissionCount() == null ? 1 : requestLog.getSubmissionCount() + 1);
                requestLog.setSubmissionCount(newSubmissionCount);
            }

            String formCode = systemProfileHelper.getFormCode();

            Form form = formDao.getFormByFormCode(formCode);
            if (form == null) {
                // Likely to only occur during testing or development.
                throw new ApplicationException("UnknownFormCode", "Formcode =" + formCode, "No form matching this form code",
                        "Please review the XPath Expressions.");
            }

            if (Submission.STATUS_Saved.equals(formStatus)) {
                boolean onlineSaveEnabled = false;
                DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
                Boolean globalOnlineSaveEnabled = deploymentPropertyDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_Online_Save_Enabled);
                if (Boolean.TRUE.equals(globalOnlineSaveEnabled) && Boolean.TRUE.equals(form.getSaveOnlineFlag())) {
                    onlineSaveEnabled = true;
                }
                if (!onlineSaveEnabled) {
                    // form cannot be saved online
                    throw new ApplicationException("OnlineSaveDenied", "Formcode =" + formCode, "Online Save not permitted for this form",
                        "Please contact an administrator or resubmit the form without saving it online.");
                }
            }

            Task task = requestLog.getTask();
            if (task == null) {
                String taskKey = systemProfileHelper.getTaskKey();
                if (StringUtils.isNotEmpty(taskKey)) {
                    TaskDao taskDao = DaoFactory.getTaskDao();
                    task = taskDao.getTaskByKey(taskKey);
                }
            }
            UserAccount requestUser = requestLog.getUser();
            TaskService taskService = ServiceFactory.getTaskService();

            if (task != null && task.isCompleted()) {
                // Deny submission as task has been completed already
                throw new ApplicationException("TaskAlreadyCompleted", "Task =" + task.getTaskKey(),
                        "The task has already been completed. Your submission will not be processed.", null);
            } else if (task != null && task.isExpired()) {
                // Deny submission as task has expired
                throw new ApplicationException("TaskExpired", "Task =" + task.getTaskKey(),
                        "The task has expired. Your submission will not be processed.", null);
            } else if (task != null && !taskService.isAssignee(task, requestUser)) {
                // Deny submission as task is not assigned to the current user
                throw new ApplicationException("TaskNotAssignedToUser", "Task =" + task.getTaskKey(),
                        "You are not authorized to complete the task '" + task.getTaskKey()
                        + "'. Your submission will not be processed.", null);
            }

            // Get the Form Deploy XML
            String formDeployOid = systemProfileHelper.getFormDeployOid();
            FormDeployXmlDao formDeployXMLDao = new FormDeployXmlDao();
            FormDeployXml formDeployXml = formDeployXMLDao.getFormDeployXmlFromPK(formDeployOid);

            // See if the submission had been saved previously...
            Submission submission = requestLog.getSubmission();

            // If no associated submission or is a test script submission then create a new submission record
            if (submission == null ||
                deploymentPropertyDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_Enable_Script_Submissions)) {

                submission = (Submission) createAndRegisterNewObject(Submission.class);
                submission.setSubmitKey(CoreUtils.createAltKey());
            }

            if (requestLog.getSubmission() == null) {
                requestLog.setSubmission(submission);
            }

            submission.setClient(form.getClient());
            submission.setForm(form);

            submission.setTask(task);

            Portal portal = PortalUtils.getPortal(request);
            submission.setPortal(portal);

            submission.setTimeSubmission(new Date());
            submission.setSubmittedOfflineFlag(offlineSubmission);
            submission.setUserAgent(userAgent);
            submission.setAdobeVersion(adobeVersion);
            submission.setContentType(CoreUtils.limitLength(contentType, 100));
            submission.setContentLength(String.valueOf(contentLength));

            // If an external authentication service has been configured
            if (getAuthenticationService() != null) {
                try {
                    if (getAuthenticationService().isAuthenticated(request)) {
                        String externalUserId = getAuthenticationService().getUserId(request);
                        submission.setExternalUserId(externalUserId);
                    }

                } catch (Throwable error) {
                    ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
                    errorLogService.logException(error, request, false, null);
                }

            } else {
                submission.setUser(userAccount);
            }

            // Save the submission confirmation page message
            submission.setSubmissionMessage(CoreUtils.limitLength(systemProfileHelper.getSubmissionMessage(), 1000));

            // Set the template version
            TemplateVersion templateVersion = requestLog.getTemplateVersion();
            if (templateVersion == null) {
                String templateVersionOid = systemProfileHelper.getTemplateVersionOid();
                templateVersion = templateVersionDao.getTemplateVersionFromPK(templateVersionOid);
            }
            submission.setVersion(templateVersion);

            // Save the embedded attachments
            AttachmentService attachmentService = ServiceFactory.getAttachmentService();
            for (EmbeddedAttachment embeddedAttachment : submissionDataBean.getEmbeddedAttachments()) {
                attachmentService.saveEmbeddedAttachmentForSubmission(embeddedAttachment, submission);
            }

            // Populate the required attachments
            if (formDeployXml != null && !Submission.STATUS_Saved.equals(formStatus)) {
                populateRequiredAttachments(submissionDataBean, submission, formDeployXml);
            }

            submission.setLcProcessState(submissionDataBean.getProcessState());

            // Create the submission record
            DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
            if (dpDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_IP_Address_Logging)) {
                submission.setIpAddress(CoreUtils.limitLength(ipAddress, 50));
                submission.setSessionId(CoreUtils.limitLength(sessionId, 128));
            }

            // Save submission type / form status [Saved|Submitted]
            formStatus = systemProfileHelper.getSubmissionType();
            submission.setFormStatus(formStatus);
            submission.setDeliveryStatus(Submission.STATUS_NotReady);

            submission.setTestMode(systemProfileHelper.getTestMode());

            // Save the signatures required status [true|false]
            if (formDeployXml != null) {
                String signaturesRequiredXPath = formDeployXml.getSchemaConfigXPath(SchemaConfigMap.NAME_SIGNATURES_REQUIRED);
                if (signaturesRequiredXPath != null) {
                    Element element = XmlPropertyUtils.getElement(submissionDataBean.getDocument(), signaturesRequiredXPath);
                    if (element != null
                        && element.getFirstChild() != null
                        && element.getFirstChild().getNodeValue().equalsIgnoreCase("true")) {
                        submission.setSignaturesRequiredFlag(Boolean.TRUE);
                    }

                } else {
                    String msg = "No " + SchemaConfigMap.NAME_SIGNATURES_REQUIRED + " Schema Config Map defined for"
                            + " Submission ID: " + submission.getId();
                    getLogger().debug(msg);
                }
            }

            // Set the request time
            Date requestDate = requestLog.getRequestTimestamp();
            submission.setTimeRequest(requestDate);

            // Save the submission record
            commitChanges();

            if (Submission.STATUS_Submitted.equalsIgnoreCase(formStatus)) {

                // Generate a receipt number
                String receiptNumber = null;
                final String formXml = XmlUtils.toString(submissionDataBean.getDocument());

                if (form.isReceiptWsEnabled()) {
                    String formsClientWsAddress = FormUtils.getFormClientWsAddress(form);

                    if (StringUtils.isNotBlank(formsClientWsAddress)) {
                        // May throw runtime exception when making remote call.
                        try {
                            FormsClientWebService service = ServiceFactory.getFormsClientService(formsClientWsAddress);

                            receiptNumber = service.CreateReceiptNumber(form.getClient().getClientCode(),
                                    submission.getId().toString(),
                                    form.getClientFormCode(),
                                    form.getClientFormId(),
                                    formXml);

                        } catch (Exception e) {
                            // Log an event log record
                            String msg = "Could not invoke '" + form.getClient().getClientName()
                                + "' CreateReceiptNumber WS, using Submission ID '"
                                + submission.getId() + "' for receipt number.";
                            eventLogService.logErrorEvent(msg, submission);

                            // Log an error log record
                            String name = "WS CreateReceiptNumber";
                            String context = "clientCode=" + form.getClient().getClientCode()
                                + ",formCode=" + form.getClientFormCode() + ",submissionId=" + submission.getId();
                            ApplicationException ae = new ApplicationException(name, e, context, "", null);
                            errorLogService.logException(ae, null, false, submission);
                        }
                    }
                }

                // If no Receipt Number generated use default ReceiptNumber service
                if (receiptNumber == null) {
                    FormReceiptService formReceiptService = ServiceFactory.getFormReceiptService();
                    receiptNumber = formReceiptService.generateReceiptNumber(submission);
                }

                systemProfileHelper.setReceiptNumber(receiptNumber);
                submission.setReceiptNumber(receiptNumber);
            }

            // Save the relevant values into the XML
            systemProfileHelper.setSubmissionNumber(submission.getId());

            DateFormat dateFormat =
                deploymentPropertyDao.getPropertyDateFormat(DeploymentProperty.PROPERTY_Date_Time_Format_Long);
            String submitDateString = dateFormat.format(submission.getTimeSubmission());
            systemProfileHelper.setSubmitDateString(submitDateString);

            // Update the payment details and payment items in the receipt only
            if (formDeployXml != null && !Submission.STATUS_Saved.equals(formStatus)) {
                updatePaymentDetails(submissionDataBean.getDocument(), submission, formDeployXml);
            }

            String xmlSubmission = XmlUtils.toString(submissionDataBean.getDocument());

            if (!Submission.STATUS_Saved.equalsIgnoreCase(formStatus)) {
                Document document = XmlUtils.parseDocumentFromString(xmlSubmission, false, false);
                SystemProfileHelper receiptSystemProfileHelper = new SystemProfileHelper(document);
                receiptSystemProfileHelper.setDisplayMode(SystemProfileHelper.MODE_RECEIPT);
                xmlSubmission = XmlUtils.toString(document);
            }

            SubmissionData submissionData = submission.getSubmissionData();
            if (submissionData == null) {
                submissionData = new SubmissionData();
                registerNewObject(submissionData);
                submissionData.setSubmission(submission);
            }
            submissionData.setSubmissionDataString(xmlSubmission);

            submission.calculateFormXmlHash();

            commitChanges();

            // Create the submission history entry
            createSubmissionHistory(submission);

            if (Submission.STATUS_Submitted.equalsIgnoreCase(formStatus)) {
                // This sets the SubmissionStatus to Ready and also the Delivery Status to ready.
                SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                submissionStatusService.updateStatus(submission);
            }

            commitChanges();

            transaction.commit();

            formStatus = submission.getFormStatus();

            Transaction.bindThreadTransaction(null);
            BaseContext.bindThreadObjectContext(null);

            return submission;

        } catch (Exception error) {
            try {
                transaction.rollback();

            } catch (Exception e) {
                getLogger().error("Error Rolling back transaction...", e);

            } finally {
                Transaction.bindThreadTransaction(null);
            }

            errorLogService.logException(error);

            if (error instanceof RuntimeException) {
                throw (RuntimeException) error;

            } else {
                String msg = "Unknown error: " + error.toString();
                throw new ApplicationException("FormService", error, msg, msg, null);
            }

        } finally {
            Transaction.bindThreadTransaction(null);
        }
    }

    // Private Methods --------------------------------------------------------

    /**
     * Update the submission payment status and payment type.
     */
    private void updatePaymentDetails(Document document, Submission submission, FormDeployXml formDeployXml){

        String paymentDetailsXPath = formDeployXml.getSchemaConfigXPath(SchemaConfigMap.NAME_PAYMENT_DETAILS);
        if (paymentDetailsXPath == null) {
            String msg = "No " + SchemaConfigMap.NAME_PAYMENT_DETAILS + " Schema Config Map defined for" + " Submission ID: "
                    + submission.getId();
            getLogger().debug(msg);
            return;
        }

        String receiptXPath = formDeployXml.getSchemaConfigXPath(SchemaConfigMap.NAME_RECEIPT);
        if (receiptXPath == null) {
            String msg = "No " + SchemaConfigMap.NAME_RECEIPT + " Schema Config Map defined for" + " Submission ID: "
                    + submission.getId();
            getLogger().debug(msg);
            return;
        }

        XPath formXPath = new XPath(document);

        Element paymentDetailsPaymentElm = formXPath.selectSingleNode(paymentDetailsXPath + "/"
                + AvokaTemplateSchema.PAYMENT_DETAILS_PAYMENT);

        // Set Receipt Payment Total value from Payment Details Total
        String paymentTotal = XmlUtils.getChildValue(paymentDetailsPaymentElm, AvokaTemplateSchema.TOTAL);
        formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_PAYMENT_TOTAL, paymentTotal);

        // Set total in submission
        if (StringUtils.isNotBlank(paymentTotal)) {
            try {
                double value = Double.parseDouble(paymentTotal);
                submission.setPaymentTotal(new Double(value));
                if (value > 0) {
                    submission.setPaymentStatus(Submission.STATUS_Required);

                    SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                    submissionStatusService.updateStatus(submission);
                }

            } catch (NumberFormatException nfe) {
                throw new ApplicationException("PaymentError", nfe, "PaymentTotal = " + paymentTotal,
                        "Error calculating payment total", "The payment total cannot be determined.");
            }
        }

        // Set Receipt Payment GST value from Payment Details GST
        String paymentGST = XmlUtils.getChildValue(paymentDetailsPaymentElm, AvokaTemplateSchema.GST);
        formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_PAYMENT_GST, paymentGST);

        // Set Receipt Payment SubTotal value from Payment Details SubTotal
        String paymentSubTotal = XmlUtils.getChildValue(paymentDetailsPaymentElm, AvokaTemplateSchema.SUB_TOTAL);
        formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_PAYMENT_SUB_TOTAL, paymentSubTotal);

        // Set Receipt Payment ServiceFee value from Payment Details ServiceFee
        String paymentServiceFee = XmlUtils.getChildValue(paymentDetailsPaymentElm, AvokaTemplateSchema.SERVICE_FEE);
        formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_PAYMENT_SERVICE_FEE, paymentServiceFee);

        // Set payment type is submission
        Element paymentDetailsElm = formXPath.selectSingleNode(paymentDetailsXPath);
        String paymentType = XmlUtils.getChildValue(paymentDetailsElm, AvokaTemplateSchema.PAYMENT_TYPE);
        submission.setPaymentType(paymentType);

        // Switch for account, bpay, creditcard

        if (Submission.PAYMENT_TYPE_Account.equals(paymentType)) {
            // Set account number
            String accountNumber = XmlUtils.getChildValue(paymentDetailsElm, AvokaTemplateSchema.ACCOUNT_NUMBER);
            submission.setAccountNumber(accountNumber);

            if (submission.isFormSubmitted()) {
                submission.setPaymentStatus(Submission.STATUS_Completed);

                SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                submissionStatusService.updateStatus(submission);
            }

        } else if (Submission.PAYMENT_TYPE_BPAY.equals(paymentType)) {
            // Set BPAY client transaction reference number
            String bpayBillerCode = XmlUtils.getChildValue(paymentDetailsElm, AvokaTemplateSchema.BPAY_BILLER_CODE);
            submission.setBpayBillerCode(bpayBillerCode);

            // Set BPAY client transaction reference number
            if (submission.isFormSubmitted()) {
                String bpayReferenceNumber = submission.getId().toString();
                submission.setBpayReferenceNumber(bpayReferenceNumber);
                formXPath.setNodeValue(AvokaTemplateSchema.PAYMENT_DETAILS_BPAY_REFERENCE_NUMBER, bpayReferenceNumber);
                submission.setPaymentStatus(Submission.STATUS_Completed);

                SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                submissionStatusService.updateStatus(submission);
            }

        } else if (Submission.PAYMENT_TYPE_CreditCard.equals(paymentType)) {
            // Do nothing

        } else if (Submission.PAYMENT_TYPE_EFT.equals(paymentType)) {
            if (submission.isFormSubmitted()) {
                submission.setPaymentStatus(Submission.STATUS_Completed);

                SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                submissionStatusService.updateStatus(submission);
            }

        } else if (StringUtils.isNotBlank(paymentType)) {
            getLogger().warn("Unknown paymentType: '" + paymentType + "' for submission: " + submission.getId());
        }

        // Account, BPAY and EFT make payment complete when submitted
        if (submission.isPaymentCompleted()) {
            // TODO: set payment receipt number & date
            formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_RECEIPT_NO, submission.getId().toString());

            DateFormat dateFormat = deploymentPropertyDao.getPropertyDateFormat(DeploymentProperty.PROPERTY_Date_Time_Format_Long);
            String dateTime = dateFormat.format(new Date());
            formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_RECEIPT_DATE_TIME, dateTime);
        }

        // Populate payment items and additional payment stuff
        if (!submission.isFormSaved()) {

            // delete any existing payment items
            List paymentItems = submission.getPaymentItems();
            getDataContext().deleteObjects(paymentItems);

            // delete any existing payment items
            Element receiptItemListElem = formXPath.selectSingleNode(receiptXPath + "/" + AvokaTemplateSchema.ITEM_LIST);
            NodeList receiptItemNodeList = receiptItemListElem.getChildNodes();
            for (int i = 0; i < receiptItemNodeList.getLength(); i++) {
                Node node = receiptItemNodeList.item(i);
                receiptItemListElem.removeChild(node);
            }

            // iterate through payment details itemlist items
            List paymentDetailsItemListItems = formXPath.selectNodes(paymentDetailsXPath + "/" + AvokaTemplateSchema.ITEM_LIST_ITEM);

            for (Iterator i = paymentDetailsItemListItems.iterator(); i.hasNext();) {
                Element element = (Element) i.next();

                String description = XmlUtils.getChildValue(element, AvokaTemplateSchema.PAYMENT_ITEM_DESCRIPTION);
                String quantity = XmlUtils.getChildValue(element, AvokaTemplateSchema.PAYMENT_ITEM_QUANTITY);
                String unitValue = XmlUtils.getChildValue(element, AvokaTemplateSchema.PAYMENT_ITEM_UNIT_VALUE);
                String gst = XmlUtils.getChildValue(element, AvokaTemplateSchema.PAYMENT_ITEM_GST);
                String total = XmlUtils.getChildValue(element, AvokaTemplateSchema.PAYMENT_ITEM_TOTAL);
                String feeCode = XmlUtils.getChildValue(element, AvokaTemplateSchema.PAYMENT_ITEM_FEE_CODE);
                String receiptCode = XmlUtils.getChildValue(element, AvokaTemplateSchema.PAYMENT_ITEM_RECEIPT_CODE);

                // If the item is the single empty payment item value in schema, break out of loop
                if (paymentDetailsItemListItems.size() == 1) {
                    if (StringUtils.isBlank(receiptCode)) {
                        break;
                    }
                }

                // create payment_item record
                PaymentItem paymentItem = new PaymentItem();
                getDataContext().registerNewObject(paymentItem);
                paymentItem.setDescription(description);
                if (StringUtils.isNotBlank(quantity)) {
                    paymentItem.setQuanity(Integer.valueOf(quantity));
                }
                if (StringUtils.isNotBlank(unitValue)) {
                    paymentItem.setUnitValue(new BigDecimal(unitValue));
                }
                if (StringUtils.isNotBlank(gst)) {
                    paymentItem.setGst(new BigDecimal(gst));
                }
                if (StringUtils.isNotBlank(total)) {
                    paymentItem.setTotal(new BigDecimal(total));
                }
                paymentItem.setFeeCode(feeCode);
                paymentItem.setReceiptCode(receiptCode);
                paymentItem.setSubmission(submission);

                // copy item to receipt payment item list
                Element receiptPaymentItem = DOMUtil.createElement(receiptItemListElem, AvokaTemplateSchema.ITEM);

                DOMUtil.createElementWithText(receiptPaymentItem, AvokaTemplateSchema.PAYMENT_ITEM_DESCRIPTION, description);
                DOMUtil.createElementWithText(receiptPaymentItem, AvokaTemplateSchema.PAYMENT_ITEM_QUANTITY, quantity);
                DOMUtil.createElementWithText(receiptPaymentItem, AvokaTemplateSchema.PAYMENT_ITEM_UNIT_VALUE, unitValue);
                DOMUtil.createElementWithText(receiptPaymentItem, AvokaTemplateSchema.PAYMENT_ITEM_GST, gst);
                DOMUtil.createElementWithText(receiptPaymentItem, AvokaTemplateSchema.PAYMENT_ITEM_TOTAL, total);
            }
        }
    }

    /**
     * Populate the submission's required attachments for the XML form submission.
     *
     * @param document the form submission XML document
     * @param submission the submission to save the attachments to
     */
    private void populateRequiredAttachments(SubmissionDataBean submissionData,
                                             Submission submission,
                                             FormDeployXml formDeployXml){

        String xpath = formDeployXml.getSchemaConfigXPath(SchemaConfigMap.NAME_ATTACHMENTS);

        // Tests whether attachments are supported for this form
        // TODO: MAE 17/4/2008 - need error handling behavior if form should have attachments
        if (xpath == null) {
            String msg = "No " + SchemaConfigMap.NAME_ATTACHMENTS + " Schema Config Map defined for Submission ID: "
                    + submission.getId();
            getLogger().debug(msg);
            return;
        }

        // TODO: MAE - save embedded attachments

        XPath formXPath = new XPath(submissionData.getDocument());

        List itemList = formXPath.selectNodes(xpath + "/" + AvokaTemplateSchema.ITEM_LIST_ITEM);
        String attachmentStatus = null;

        for (Iterator i = itemList.iterator(); i.hasNext();) {
            Element element = (Element) i.next();

            String documentCode = XmlUtils.getChildValue(element, AvokaTemplateSchema.DOCUMENT_TYPE_CODE);
            String documentName = XmlUtils.getChildValue(element, AvokaTemplateSchema.DOCUMENT_TYPE_NAME);
            String attachmentName = XmlUtils.getChildValue(element, AvokaTemplateSchema.ATTACHMENT_NAME);
            String mandatoryStatus = XmlUtils.getChildValue(element, AvokaTemplateSchema.MANDATORY_STATUS);
            String description = XmlUtils.getChildValue(element, AvokaTemplateSchema.ATTACHMENT_DESCRIPTION);
            String submitMethod = XmlUtils.getChildValue(element, AvokaTemplateSchema.SUBMIT_METHOD);
            String attachmentType = XmlUtils.getChildValue(element, AvokaTemplateSchema.ATTACHMENT_TYPE);
            String mimeOrFileTypes = XmlUtils.getChildValue(element, AvokaTemplateSchema.MIME_OR_FILE_TYPES);
            String maxSize = XmlUtils.getChildValue(element, AvokaTemplateSchema.MAX_SIZE);

            if (attachmentName != null) {

                RequiredAttachment requiredAttachment = (RequiredAttachment) createAndRegisterNewObject(RequiredAttachment.class);

                boolean required = AvokaTemplateSchema.MANDATORY_STATUS_REQUIRED.equals(mandatoryStatus);

                requiredAttachment.setRequiredFlag(new Boolean(required));
                requiredAttachment.setAttachmentName(attachmentName);
                requiredAttachment.setDescription(description);
                requiredAttachment.setSubmitMethod(submitMethod);
                requiredAttachment.setDocumentCode(documentCode);
                requiredAttachment.setDocumentTypeName(documentName);
                requiredAttachment.setMimeOrFileTypes(mimeOrFileTypes);
                if (StringUtils.isNotEmpty(maxSize)) {
                    requiredAttachment.setMaxSize(new Integer(maxSize));
                }

                submission.addToRequiredAttachments(requiredAttachment);

                if (required) {
                    attachmentStatus = Submission.STATUS_Required;
                }
                else if (attachmentStatus == null) {
                    attachmentStatus = Submission.STATUS_Optional;
                }
            }
        }
        submission.setAttachmentsStatus(attachmentStatus);

        SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
        submissionStatusService.updateStatus(submission);
    }

    /**
     * Return the duplicated submission if a duplicate, otherwise return null.
     */
    private Submission getDuplicateSubmission(
            RequestLog requestLog,
            SystemProfileHelper systemProfileHelper,
            SubmissionDataBean submissionData,
            String ipAddress,
            String userAgent,
            String sessionId) {

        if (deploymentPropertyDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_Enable_Script_Submissions)) {
            return null;
        }

        int submissionCount = requestLog.getSubmissionCount();

        if (submissionCount == 0) {
            return null;

        } else {
            String formCode = systemProfileHelper.getFormCode();
            Form form = formDao.getFormByFormCode(formCode);

            if (form != null) {

                // get all forms submitted within the specified interval
                Date cutoffTime = new Date();

                DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
                long rejectionDelayMs = dpDao.getPropertyValueLong(DeploymentProperty.PROPERTY_Duplicate_Submission_Rejection_Delay);

                cutoffTime.setTime(cutoffTime.getTime() - rejectionDelayMs);

                Submission previousSubmission = requestLog.getSubmission();
                if (previousSubmission != null) {
                    Date previousSubmissionTime = previousSubmission.getTimeSubmission();
                    String previousIpAddress = previousSubmission.getIpAddress();
                    String previousUserAgent = previousSubmission.getUserAgent();
                    if (cutoffTime.before(previousSubmissionTime)
                            && previousIpAddress.equals(ipAddress)
                            && ((previousUserAgent == null && userAgent == null) || previousUserAgent.equals(userAgent))) {
                        // most likely a double click related issue
                        return previousSubmission;
                    }
                }
            }
            // submission count > 0 but previous submission either not defined or outside the acceptable interval
            // This could be quite a serious problem as someone has attempted to log a
            // submission using an old request log
            getLogger().info(
                    "Audit Details for SubmissionRequestLogCountError Exception." + "\nSessionID=" + sessionId
                    + "\nIPAddress=" + ipAddress + "\nSubmissonData= "
                    + XmlUtils.toFormattedString(submissionData.getDocument()));

            throw new DuplicateSubmissionException(requestLog, form);
        }
    }

    private SubmissionHistory createSubmissionHistory(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        SubmissionHistory submissionHistory = (SubmissionHistory) createAndRegisterNewObject(SubmissionHistory.class);

        submissionHistory.setSubmission(submission);
        submissionHistory.setDeletedFlag(submission.getDeletedFlag());

        String formXml = null;
        SubmissionData submissionData = submission.getSubmissionData();
        if (submissionData != null) {
            formXml = submissionData.getSubmissionDataString();
        }

        if (StringUtils.isNotEmpty(formXml)) {
            SubmissionHistoryData submissionHistoryData = new SubmissionHistoryData();
            registerNewObject(submissionHistoryData);
            submissionHistoryData.setSubmissionHistoryDataString(formXml);
            submissionHistoryData.setSubmissionHistory(submissionHistory);

            String formHash = DataHashUtils.toSHA256Hash(formXml.getBytes());
            submissionHistory.setFormDataHash(formHash);
        }
        submissionHistory.setDatetimeCreated(submission.getTimeSubmission());
        submissionHistory.setFormStatus(submission.getFormStatus());
        submissionHistory.setTemplateVersion(submission.getVersion());
        submissionHistory.setUser(submission.getUser());

        return submissionHistory;
    }

}

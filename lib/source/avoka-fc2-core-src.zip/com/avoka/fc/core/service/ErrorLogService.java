/*
 * Copyright (c) 2007-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.ClientDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.ErrorLogData;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides an ErrorLog Service.
 *
 * @author medgar@avoka.com
 */
public class ErrorLogService extends CayenneService {

    /**
     * WARNING !- This method rollsback any database changes - then commits the logging of the
     * exception.
     *
     * Logs an Exception.
     *
     * @param error the error to log
     * @return the created error log record
     */
    public ErrorLog logException(Throwable error) {
        return logException(error, null, true, null);
    }

    /**
     * WARNING !- This method rollsback any database changes - then commits the logging of the
     * exception.
     *
     * Logs an Exception.
     *
     * @param error the error to log
     * @param submission the associated form submission
     * @return the created error log record
     */
    public ErrorLog logException(Throwable error, Submission submission) {
        return logException(error, null, true, submission);
    }

    public ErrorLog logExceptionNoRollback(Throwable error, Submission submission) {
        return logException(error, null, false, submission);
    }

    /**
     * Logs an Exception.
     *
     * @param error the error to log
     * @param request the servlet request (optional)
     * @param autoRollback the thread data context should be rolled back
     * @return the created error log record
     */
    public ErrorLog logException(Throwable error, boolean autoRollback) {
        return logException(error, null, autoRollback, null);
    }

    /**
     * WARNING !- This method rolls back any database changes - then commits the logging of the exception.
     *
     * Logs an Exception.
     *
     * @param error the error to log
     * @param request the servlet request (optional)
     * @return the created error log record
     */
    public ErrorLog logException(Throwable error, HttpServletRequest request) {
        return logException(error, request, true, null);
    }

    /**
     * Logs an Exception.
     *
     * @param error the error to log
     * @param request the servlet request (optional)
     * @param autoRollback the thread data context should be rolled back
     * @return the created error log record
     */
    @SuppressWarnings("deprecation")
    public ErrorLog logException(Throwable error, HttpServletRequest request, boolean autoRollback, Submission submission) {
        // Critical - first roll back any transactions.
        if (autoRollback) {
            DataContext.getThreadDataContext().rollbackChanges();
        }

        // Log error to logger and System.err
        if (error instanceof ApplicationException) {
            ApplicationException applicationException = (ApplicationException) error;
            getLogger().error("Name = " + applicationException.getName());
            getLogger().error("Context = " + applicationException.getContext());
            getLogger().error("Solution = " + applicationException.getSolution());
        }

        Throwable cause = null;
        if (error.getCause() != null) {
            cause = error.getCause();
            if (cause.getCause() != null) {
                cause = cause.getCause();
            }
        } else {
            cause = error;
        }
        getLogger().error(cause.toString(), cause);

        // Create ErrorLog entry
        DataContext dataContext = DataContext.createDataContext(false);
        ErrorLog errorLog = createErrorLog(dataContext, error, null, request, submission);
        dataContext.commitChanges();

        return errorLog;
    }

    /**
     * Create an error log entry for the given exception, logged in userName and requestUrl. <p/>
     * Note you should specify a new DataContext for this method, as the previous thread local data
     * context may be in an error state.
     *
     * @param dataContext the dataContext to create the error log with
     * @param error the error to log
     * @param userName the logged in userName
     * @param requestUrl the request URL which caused the error
     * @return a new ErrorLog
     */
    public ErrorLog createErrorLog(DataContext dataContext, Throwable error, String userName, HttpServletRequest request, Submission submission) {

        ErrorLog errorLog = new ErrorLog();
        dataContext.registerNewObject(errorLog);

        // Set error time
        errorLog.setErrorTime(new Date());

        // Search for causing exception strack trace.
        Throwable cause = null;
        if (error.getCause() != null) {
            cause = error.getCause();
            if (cause.getCause() != null) {
                cause = cause.getCause();
            }
        } else {
            cause = error;
        }

        // Set application exception info
        if (error instanceof ApplicationException) {
            ApplicationException ae = (ApplicationException) error;

            errorLog.setContext(CoreUtils.limitLength(ae.getContext(), 1000));
            errorLog.setSolution(CoreUtils.limitLength(ae.getSolution(), 1000));
            errorLog.setName(CoreUtils.limitLength(ae.getName(), 60));
            errorLog.setUserMessage(CoreUtils.limitLength(ae.getUserMessage(), 1000));

            if (ae.getClient() != null) {
                Client client = (Client) dataContext.refetchObject(ae.getClient().getObjectId());
                errorLog.setClient(client);
            }

            // Log any associated form XML
            if (StringUtils.isNotEmpty(ae.getFormXml())) {
                ErrorLogData errorLogData = new ErrorLogData();
                dataContext.registerNewObject(errorLogData);
                errorLogData.setErrorLogDataString(ae.getFormXml());

                errorLog.setErrorLogData(errorLogData);
            }

        } else {
            // Set name
            if (StringUtils.isNotBlank(error.getMessage())) {
                errorLog.setName(CoreUtils.limitLength(error.getMessage(), 60));
            } else {
                String classname = cause.getClass().getSimpleName();
                errorLog.setName(CoreUtils.limitLength(classname, 60));
            }

            // Set context
            if (request != null) {
                TreeMap requestParams = new TreeMap();
                Enumeration paramNames = request.getParameterNames();
                while (paramNames.hasMoreElements()) {
                    String name = paramNames.nextElement().toString();
                    requestParams.put(name, request.getParameter(name));
                }

                if (!requestParams.isEmpty()) {
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("Request Parameters: ");
                    for (Iterator i = requestParams.entrySet().iterator(); i.hasNext();) {
                        Map.Entry entry = (Map.Entry) i.next();
                        String key = entry.getKey().toString();
                        Object value = entry.getValue();

                        buffer.append(key);
                        buffer.append("=");
                        if (value != null) {
                            buffer.append(StringEscapeUtils.escapeHtml(value.toString()));
                        } else {
                            buffer.append("null");
                        }
                        if (i.hasNext()) {
                            buffer.append(", ");
                        }
                    }

                    errorLog.setContext(CoreUtils.limitLength(buffer.toString(), 1000));
                }
            }
        }

        if (request != null) {
            // Set Request URL
            StringBuffer buffer = new StringBuffer();
            buffer.append(request.getMethod());
            buffer.append(" ");
            buffer.append(request.getRequestURL());
            if (request.getQueryString() != null) {
                buffer.append("?");
                buffer.append(request.getQueryString());
            }
            errorLog.setRequestUrl(CoreUtils.limitLength(buffer.toString(), 200));

            // Set referer
            errorLog.setReferer(CoreUtils.limitLength(request.getHeader("referer"), 1000));

            // Set user agent
            errorLog.setUserAgent(CoreUtils.limitLength(request.getHeader("user-agent"), 200));
        }

        // Set user
        if (userName != null) {
            errorLog.setUsername(CoreUtils.limitLength(userName, 20));

        } else if (request != null) {
            errorLog.setUsername(CoreUtils.limitLength(request.getRemoteUser(), 20));
        }

        // Set message
        if (error.getMessage() != null) {
            errorLog.setMessage(CoreUtils.limitLength(error.getMessage(), 200));

        } else {
            StackTraceElement[] ste = cause.getStackTrace();
            if (ste != null && ste.length > 0) {
                errorLog.setMessage(ste[0].toString());
            }
        }

        // Set stacktrace
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        cause.printStackTrace(pw);
        errorLog.setStacktrace(sw.toString());

        if (submission != null && !submission.isNew()) {
            String submissionId = submission.getId().toString();
            SelectQuery selectQuery = new SelectQuery(Submission.class);
            selectQuery.andQualifier(ExpressionFactory.matchDbExp(Submission.SUBMISSION_OID_PK_COLUMN, submissionId));
            List list = dataContext.performQuery(selectQuery);
            if (!list.isEmpty()) {
                Submission localSubmission = (Submission) list.get(0);
                errorLog.setSubmission(localSubmission);
            }
        }

        return errorLog;
    }

}

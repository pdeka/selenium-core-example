package com.avoka.fc.core.service;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ExecutorService {
    static private Executor executor;

    static public synchronized Executor getExecutor() {
        if (executor == null) {
            executor = Executors.newCachedThreadPool();
        }
        return executor;
    }
}

package com.avoka.fc.core.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.query.NamedQuery;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.adobe.workflow.DOMUtil;
import com.avoka.core.util.CoreUtils;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.AvokaTemplateSchema;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.FormDeployXmlDao;
import com.avoka.fc.core.dao.NamedQueries;
import com.avoka.fc.core.dao.SchemaSeedDao;
import com.avoka.fc.core.dao.TemplateDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.DocumentType;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.FormProperty;
import com.avoka.fc.core.entity.MetadataValue;
import com.avoka.fc.core.entity.MetadataValueDeploy;
import com.avoka.fc.core.entity.PropertyDeploy;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.SchemaDeployMap;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.SpecifiedAttachmentDeploy;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserDeployMap;
import com.avoka.fc.core.entity.XmlInDeployMap;
import com.avoka.fc.core.entity.XmlInputMap;
import com.avoka.fc.core.entity.XmlInputVersion;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.RemoteUserProvider;
import com.avoka.fc.core.util.XPath;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

public class FormDeployService extends CayenneService {

    // constants
    private static final String EMPTY_SEED = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SmartForm><SystemProfile></SystemProfile></SmartForm>";

    // attributes
    private long time;

    /**
     * Package private constructor to enforce ServiceFactory pattern.
     */
    FormDeployService(){
    }

    /**
     * Returns the form deploy XML for the form's current template version
     * WARNING: Will update the current form template version if a newer version is scheduled to become active
     * @param form
     * @return the form deploy xml data associated with the form's current template version
     */
    public FormDeployXml getOrCreateFormDeploy(Form form) {
        Template template = form.getTemplate();

        // Ensure the template is active
        if (!template.isActive()) {
            throw new ApplicationException(
                    "TemplateIsNotActive",
                    "Requested FormCode=" + form.getClientFormCode(),
                    "This template is not currently active. Please check with support.",
                    "A request has been made for a template that is not active. Please check with the Forms Administrator if this form should be activated.");
        }

        if (StringUtils.isEmpty(RemoteUserProvider.getRemoteUser())) {
            RemoteUserProvider.setRemoteUser("System");
        }

        TemplateVersion templateVersion = null;
        TemplateDao templateDao = DaoFactory.getTemplateDao();
        // ensure that the latest version has been deployed.
        if (templateDao.setCurrentDeployVersion(template)) {
            commitChanges();
        }

        templateVersion = template.getCurrentVersion();

        return getOrCreateFormDeploy(form, templateVersion);
    }

    public FormDeployXml getOrCreateFormDeploy(Form form, TemplateVersion templateVersion) {
        Validate.notNull(form);
        Validate.notNull(templateVersion);

        if (StringUtils.isEmpty(RemoteUserProvider.getRemoteUser())) {
            RemoteUserProvider.setRemoteUser("System");
        }

        FormDeployXmlDao formDeployXmlDao = DaoFactory.getFormDeployXmlDao();
        // Get or create a form deployment record and load the stored XML
        // seed data
        FormDeployXml formDeployXml = formDeployXmlDao.getFormDeployXML(form, templateVersion);

        if (formDeployXml == null) {
            formDeployXml = createFormDeployXML(form, templateVersion);
        }
        return formDeployXml;
    }

    /**
     * Generates the populated FormDeployment XML File.
     *
     * It will still need System Properties, User Profile Data and Additional
     * Payments to be populated at run time.
     *
     * @author pcopeland
     */
    public FormDeployXml createFormDeployXML(Form form, TemplateVersion templateVersion) {
        Validate.notNull(form, "Null form parameter");

        startProfile();

        form = (Form) getDataContext().refetchObject(form.getObjectId());
        templateVersion = (TemplateVersion) getDataContext().refetchObject(templateVersion.getObjectId());

        // Ensure objects are not cached
        SchemaSeed schemaSeed = templateVersion.getSchema();
        if (schemaSeed != null) {
            schemaSeed = (SchemaSeed) refetchObject(schemaSeed);
        }

        // Get the XML data file
        Document seedDocument = null;
        if (schemaSeed != null) {
            seedDocument = getSeedDocument(schemaSeed);
            populateClientAndFormSchema(seedDocument, form, schemaSeed);
        }
        else {
            seedDocument = XmlUtils.parseDocumentFromString(EMPTY_SEED);
        }

        FormDeployXmlDao formDeployXmlDao = DaoFactory.getFormDeployXmlDao();
        FormDeployXml formDeployXml = formDeployXmlDao.getFormDeployXML(form, templateVersion);

        if (formDeployXml != null) {
            return formDeployXml;
        }

        formDeployXml = new FormDeployXml();
        registerNewObject(formDeployXml);
        formDeployXml.setForm(form);
        formDeployXml.setTemplateVersion(templateVersion);
        formDeployXml.setDeployTimestamp(new Date());
        commitChanges();

        SystemProfileHelper systemProfileHelper = new SystemProfileHelper(seedDocument);
        systemProfileHelper.setFormDeployOid(formDeployXml.getId());

        // Populate the specified attachment deploys
        createSpecifiedAttachmentDeploy(formDeployXml, form);

        if (schemaSeed != null) {
            // Save the schemas configuration mappings
            createSchemaConfigMap(formDeployXml, schemaSeed);

            // get the user property map and save that into user_deploy_map
            createUserProfileMap(formDeployXml, schemaSeed);

            // Populate the attachments in the form
            populateAttachments(seedDocument, form, formDeployXml);

            // Populate the form xml input mappings
            createXmlInDeployMaps(formDeployXml, templateVersion);
        }

        // Populate the metadata values
        createMetadataValueDeploy(formDeployXml, form);

        // Populate the property values
        createDeployPropertyList(formDeployXml, form);

        String seedDocumentString = XmlUtils.toString(seedDocument.getDocumentElement());
        formDeployXml.setFormDeployXmlData(seedDocumentString.getBytes());

        commitChanges();

        // Refresh query cache
        formDeployXmlDao.getFormDeployXML(form, templateVersion, true);

        endProfile("create FormDeployXML");

        return formDeployXml;
    }

    private void startProfile() {
        time = System.currentTimeMillis();
    }

    private void endProfile(String name) {
        // PRC - Please leave this as Info not debug
        if (getLogger().isInfoEnabled()) {
            getLogger().info(
                    name + " took: " + (System.currentTimeMillis() - time)
                            + " ms");
            time = System.currentTimeMillis();
        }
    }

    private void createSchemaConfigMap(FormDeployXml formDeployXML,
            SchemaSeed templateVersionSchema) {

        // Clear all the existing maps.
        deleteObjects(formDeployXML.getSchemaDeployMaps());

        Map configXPaths = templateVersionSchema.getConfigXPaths();

        for (Iterator i = configXPaths.keySet().iterator(); i.hasNext();) {
            String name = i.next().toString();
            String xpath = configXPaths.get(name).toString();

            SchemaDeployMap schemaDeployMap = new SchemaDeployMap();
            registerNewObject(schemaDeployMap);
            schemaDeployMap.setName(name);
            schemaDeployMap.setXpath(xpath);

            formDeployXML.addToSchemaDeployMaps(schemaDeployMap);
        }
    }

    private void createUserProfileMap(FormDeployXml formDeployXML, SchemaSeed templateVersionSchema) {
        // Clear all the existing maps.
        FormDeployXmlDao formDeployXmlDao = DaoFactory.getFormDeployXmlDao();
        formDeployXmlDao.deleteUserDeployMap(formDeployXML);

        // Iterate through the schemas from parent down to child schema
        // applying user properties
        SchemaSeedDao schemaDao = DaoFactory.getSchemaSeedDao();
        List schemaList = schemaDao.getParentSchemas(templateVersionSchema);

        int size = schemaList.size() - 1;

        for (int i = size; i >= 0; i--) {
            SchemaSeed aSchema = (SchemaSeed) schemaList.get(i);
            List propertyMaplist = schemaDao.getSchemaPropertyTypeMap(aSchema, PropertyType.SCOPE_User);
            saveUserDeployMap(formDeployXML, propertyMaplist);
        }
    }

    private void createXmlInDeployMaps(FormDeployXml formDeployXml, TemplateVersion templateVersion) {

        XmlInputVersion xmlInputVersion = templateVersion.getXmlInputVersion();
        if (xmlInputVersion != null) {
            List<XmlInputMap>  xmlInputMaps = xmlInputVersion.getXmlInputMap();

            for (XmlInputMap xmlInputMap : xmlInputMaps) {
                XmlInDeployMap xmlInDeployMap = new XmlInDeployMap();
                registerNewObject(xmlInDeployMap);

                xmlInDeployMap.setInXpath(xmlInputMap.getInXpath());
                xmlInDeployMap.setOutXpath(xmlInputMap.getOutXpath());

                formDeployXml.addToXmlInDeployMaps(xmlInDeployMap);
            }
        }
    }

    private void createMetadataValueDeploy(FormDeployXml formDeployXml, Form form) {
        FormDao formDao = new FormDao();
        List<MetadataValue> metadataValues = formDao.getAllFormMetadataValues(form);

        for (MetadataValue metadataValue: metadataValues) {
            MetadataValueDeploy valueDeploy = (MetadataValueDeploy) createAndRegisterNewObject(MetadataValueDeploy.class);
            valueDeploy.setName(metadataValue.getMetadataTag().getName());
            valueDeploy.setScheme(metadataValue.getMetadataTag().getScheme());
            valueDeploy.setValue(metadataValue.getValue());
            formDeployXml.addToMetadataContentList(valueDeploy);
        }
    }

    private void createDeployPropertyList(FormDeployXml formDeployXml, Form form) {
        Map<String, List<PropertyDeploy>> clientPropertyMap = new HashMap<String, List<PropertyDeploy>>();
        List<ClientProperty> clientProperties = form.getClient().getClientProperties();
        for (ClientProperty clientProperty: clientProperties) {
            PropertyDeploy propertyDeploy = (PropertyDeploy) createAndRegisterNewObject(PropertyDeploy.class);
            PropertyType propertyType = clientProperty.getPropertyType();
            String propertyName = propertyType.getName();
            propertyDeploy.setName(propertyName);
            propertyDeploy.setScope(propertyType.getScope());
            propertyDeploy.setType(propertyType.getDataType());
            propertyDeploy.setValue(clientProperty.getValue());
            propertyDeploy.setBase64Value(clientProperty.getBase64Value());
            formDeployXml.addToPropertyDeployList(propertyDeploy);

            List<PropertyDeploy> propertyValues = null;
            if (!clientPropertyMap.containsKey(propertyName)) {
                propertyValues = new ArrayList<PropertyDeploy>();
                clientPropertyMap.put(propertyName, propertyValues);
            }
            else {
                propertyValues = clientPropertyMap.get(propertyName);
            }
            propertyValues.add(propertyDeploy);
        }

        List<FormProperty> formProperties = form.getFormProperties();
        for (FormProperty formProperty: formProperties) {
            PropertyDeploy propertyDeploy = (PropertyDeploy) createAndRegisterNewObject(PropertyDeploy.class);
            PropertyType propertyType = formProperty.getPropertyType();
            String propertyName = propertyType.getName();
            propertyDeploy.setName(propertyName);
            propertyDeploy.setScope(propertyType.getScope());
            propertyDeploy.setType(propertyType.getDataType());
            propertyDeploy.setValue(formProperty.getValue());
            propertyDeploy.setBase64Value(formProperty.getBase64Value());
            formDeployXml.addToPropertyDeployList(propertyDeploy);

            // form properties override client properties
            if (clientPropertyMap.containsKey(propertyName)) {
                List<PropertyDeploy> obsoletePropertyDeploys = clientPropertyMap.remove(propertyName);
                for (PropertyDeploy obsoletePropertyDeploy: obsoletePropertyDeploys) {
                    formDeployXml.removeFromPropertyDeployList(obsoletePropertyDeploy);
                }
                deleteObjects(obsoletePropertyDeploys);
            }
        }
    }

    private void createSpecifiedAttachmentDeploy(FormDeployXml formDeployXml, Form form) {
        List<SpecifiedAttachment> specifiedAttachments = form.getSpecifiedAttachments();

        for (SpecifiedAttachment specifiedAttachment: specifiedAttachments) {
            DocumentType documentType = specifiedAttachment.getDocumentType();

            SpecifiedAttachmentDeploy attachmentDeploy =
                (SpecifiedAttachmentDeploy) createAndRegisterNewObject(SpecifiedAttachmentDeploy.class);

            attachmentDeploy.setDocumentTypeCode(documentType.getCode());
            attachmentDeploy.setDocumentTypeName(documentType.getName());

            attachmentDeploy.setAttachmentName(specifiedAttachment.getAttachmentName());
            attachmentDeploy.setDescription(specifiedAttachment.getDescription());
            attachmentDeploy.setMaxSize(specifiedAttachment.getMaxSize());
            attachmentDeploy.setMimeOrFileTypes(specifiedAttachment.getMimeOrFileTypes());
            attachmentDeploy.setRequiredFlag(specifiedAttachment.getRequiredFlag());
            attachmentDeploy.setSubmitMethod(specifiedAttachment.getSubmitMethod());

            formDeployXml.addToSpecifiedAttachmentDeployList(attachmentDeploy);
        }
    }

    private void saveUserDeployMap(FormDeployXml formDeployXML, List propertyMaplist) {
        for (Iterator iterator = propertyMaplist.iterator(); iterator.hasNext();) {
            Map row = (Map) iterator.next();
            UserDeployMap userDeployMap = new UserDeployMap();
            getDataContext().registerNewObject(userDeployMap);

            userDeployMap.setPropertyName(row.get("property_name").toString());
            userDeployMap.setPropertyScope(row.get("scope").toString());
            userDeployMap.setXpath(row.get("xpath").toString());

            formDeployXML.addToUserDeployMaps(userDeployMap);
        }
    }

    private Document getSeedDocument(SchemaSeed schema) {
        // Get the XML data file
        try {
            String seedFile = schema.getSeedFileData();

            // Ensure seed file data exists
            if (seedFile == null) {
                String context = "SeedFileName = " + schema.getFileName();
                throw new ApplicationException("SchemaError", context,
                        "Error loading Schema XML seed file",
                        "Check that the Schema or its parent schemas has a seed file defined.");
            }

            return XmlUtils.parseDocumentFromString(seedFile, false, false);

        } catch (Exception ex) {
            String context = (schema != null) ? "SeedFileName = "
                    + schema.getFileName() : "Schema=null";
            throw new ApplicationException(
                    "SchemaError",
                    ex,
                    context,
                    "Error loading XML Schema",
                    "Unable to parse XML Seed File. Check that the format of the XML Seed file is correct.");
        }
    }

    private void populateAttachments(Document seedDocument, Form form, FormDeployXml formDeployXml) {

        String attachmentsXpath = formDeployXml.getSchemaConfigXPath(SchemaConfigMap.NAME_ATTACHMENTS);

        // Tests whether attachments are supported for this form
        // TODO: MAE 17/4/2008 - need error handling behavior if form should
        // have attachments
        if (attachmentsXpath == null) {
            String msg = "No " + SchemaConfigMap.NAME_ATTACHMENTS
                    + " Schema Config Map defined for form code: "
                    + form.getClientFormCode();
            getLogger().debug(msg);
            return;
        }

        Element attachmentsElement = XmlUtils.getXPathElement(seedDocument, attachmentsXpath);
        if (attachmentsElement == null) {
            String context = "attachmentsXpath=" + attachmentsXpath;
            String userMsg = "Warning - Schema Seed file does not contain an Attachments element";
            String solution = "Add attachments elements to schema seed file";
            throw new ApplicationException(getClass().getSimpleName(), context, userMsg, solution);
        }

        Element firstItemElement =
            XmlUtils.getXPathElement(seedDocument, attachmentsXpath + "/" + AvokaTemplateSchema.ITEM_LIST_ITEM);

        Element itemListElement =
            XmlUtils.getXPathElement(seedDocument, attachmentsXpath + "/" + AvokaTemplateSchema.ITEM_LIST);

        List<SpecifiedAttachmentDeploy> attachmentDeployList = formDeployXml.getSpecifiedAttachmentDeployList();

        // For each attachment write out the details.
        for (int i = 0; i < attachmentDeployList.size(); i++) {

            SpecifiedAttachmentDeploy attachmentDeploy = (SpecifiedAttachmentDeploy) attachmentDeployList.get(i);

            String documentCode = attachmentDeploy.getDocumentTypeCode();
            String documentName = attachmentDeploy.getDocumentTypeName();
            String attachmentName = attachmentDeploy.getAttachmentName();
            String attachmentDescription = attachmentDeploy.getDescription();
            String submitMethod = attachmentDeploy.getSubmitMethod();
            String mandatoryStatus = (attachmentDeploy.isRequired()) ? AvokaTemplateSchema.MANDATORY_STATUS_REQUIRED
                    : AvokaTemplateSchema.MANDATORY_STATUS_OPTIONAL;
            String mimeOrFileTypes = attachmentDeploy.getMimeOrFileTypes();
            String maxSize = (attachmentDeploy.getMaxSize() == null ? null : attachmentDeploy.getMaxSize().toString());

            Element itemElement = null;

            // Handle issue a blank item always being present
            if (i == 0 && firstItemElement != null) {

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.DOCUMENT_TYPE_ID, documentCode);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.DOCUMENT_TYPE_CODE, documentCode);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.DOCUMENT_TYPE_NAME, documentName);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.ATTACHMENT_NAME, attachmentName);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.ATTACHMENT_DESCRIPTION, attachmentDescription);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.MANDATORY_STATUS, mandatoryStatus);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.SUBMIT_METHOD, submitMethod);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.MIME_OR_FILE_TYPES, mimeOrFileTypes);

                XmlUtils.setChildElementValue(firstItemElement, AvokaTemplateSchema.MAX_SIZE, maxSize);

            } else {
                if (itemListElement == null) {
                    itemListElement = XmlUtils.createChildElement(attachmentsElement, AvokaTemplateSchema.ITEM_LIST);
                }

                itemElement = XmlUtils.createChildElement(itemListElement, AvokaTemplateSchema.ITEM);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.DOCUMENT_TYPE_ID, documentCode);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.DOCUMENT_TYPE_CODE, documentCode);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.DOCUMENT_TYPE_NAME, documentName);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.ATTACHMENT_NAME, attachmentName);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.ATTACHMENT_DESCRIPTION, attachmentDescription);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.MANDATORY_STATUS, mandatoryStatus);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.SUBMIT_METHOD, submitMethod);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.MIME_OR_FILE_TYPES, mimeOrFileTypes);

                XmlUtils.setChildElementValue(itemElement, AvokaTemplateSchema.MAX_SIZE, maxSize);
            }

            if (getLogger().isDebugEnabled()) {
                String msg = "Set Attachment: DocumentType = "
                        + documentCode + " DocumentName = "
                        + documentName + " AttachmentName = "
                        + attachmentName + " MandatoryStatus = "
                        + mandatoryStatus + " SubmitMethod = " + submitMethod;
                getLogger().debug(msg);
            }
        }
    }

    /**
     * Work through the schema list and set the schemas client and form property
     * values into the XML seed document. Need to do this in reverse order - ie
     * start at the very top (root) schema and go down.
     */
    private void populateClientAndFormSchema(Document seedDocument, Form form,
            SchemaSeed schema) {
        Validate.notNull(form, "Null form parameter");
        Validate.notNull(form, "Null schema parameter");
        Validate.notNull(seedDocument, "Null seedDocument parameter");

        Client client = form.getClient();

        SchemaSeedDao schemaDao = DaoFactory.getSchemaSeedDao();
        List schemaList = schemaDao.getParentSchemas(schema);

        final int size = schemaList.size() - 1;

        endProfile("populateClientSchema");

        for (int i = size; i >= 0; i--) {
            SchemaSeed aSchema = (SchemaSeed) schemaList.get(i);

            populateClientProperties(aSchema, seedDocument, client);
            endProfile("populateClientProperties");

            populateFormProperties(aSchema, seedDocument, form);
            endProfile("populateFormProperties");
        }
    }

    /**
     * Load the client properties.
     */
    private void populateClientProperties(SchemaSeed schema, Document document,
            Client client) throws ApplicationException {

        Map queryParams = new HashMap();
        queryParams.put("schemaOid", schema.getId());
        queryParams.put("clientOid", client.getId());

        // Create query
        NamedQuery query = new NamedQuery(NamedQueries.SCHEMA_MAP, queryParams);

        List results = getDataContext().performQuery(query);

        populateDocumentProperties(document, results);
    }

    /**
     * Load the form properties.
     */
    private void populateFormProperties(SchemaSeed schema, Document document,
            Form form) throws ApplicationException {

        Map queryParams = new HashMap();
        queryParams.put("schemaOid", schema.getId());
        queryParams.put("formOid", form.getId());

        // Create query
        NamedQuery query = new NamedQuery(NamedQueries.FORM_SCHEMA_MAP,
                queryParams);

        List results = getDataContext().performQuery(query);

        populateDocumentProperties(document, results);
    }

    /**
     * Load the properties.
     */
    private void populateDocumentProperties(Document document, List propertyList)
            throws ApplicationException {

        for (int i = 0; i < propertyList.size(); i++) {
            Map row = (Map) propertyList.get(i);

            String type = (String) row.get("data_type");
            String xpath = (String) row.get("xpath");

            String value = null;
            if (type.equalsIgnoreCase(PropertyType.DATA_TYPE_Image) || type.equalsIgnoreCase(PropertyType.DATA_TYPE_LongText)) {
                value = (String) row.get("base64value");

            } else {
                value = (String) row.get("value");
            }

            if (StringUtils.isBlank(xpath)) {
                getLogger().warn("xpath not defined for property: " + row);
                continue;

            } else if (StringUtils.isBlank(value)) {
                getLogger().warn("value not defined for property: " + row);
                continue;
            }

            if (!type.equals(PropertyType.DATA_TYPE_List)) {

                XPath formXPath = new XPath(document);

                formXPath.setNodeValue(xpath, value);

                if (getLogger().isDebugEnabled()) {
                    String msg = "setting property name=" + row.get("name")
                            + ", type=" + type + ", xpath=" + xpath
                            + ", value=" + CoreUtils.limitLength(value, 40);

                    getLogger().debug(msg);
                }

            } else {

                if (xpath.endsWith("/")) {
                    xpath += "ItemList";
                } else {
                    xpath += "/ItemList";
                }

                XPath formXPath = new XPath(document);

                Element itemList = formXPath.selectSingleNode(xpath);

                Element item = DOMUtil.createElement(itemList, "Item");

                DOMUtil.createElementWithText(item, "Value", value);

                String label = (String) row.get("label");
                DOMUtil.createElementWithText(item, "Property", label);

                if (getLogger().isDebugEnabled()) {
                    String msg = "setting property name=" + row.get("name")
                            + ", type=" + type + ", xpath=" + xpath
                            + ", label=" + label + ", value="
                            + CoreUtils.limitLength(value, 40);

                    getLogger().debug(msg);
                }
            }
        }
    }
}

package com.avoka.fc.core.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.apache.cayenne.CayenneRuntimeException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CayenneUtils;
import com.avoka.core.util.StringTemplate;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FormReceiptSequenceDao;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormReceiptSequence;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.util.ApplicationException;

public class FormReceiptService extends CayenneService {

    // Constants
    public static final int MAX_RETRIES = 100;

    public String generateReceiptNumber(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        String submissionId = String.valueOf(submission.getId());

        Form form = submission.getForm();
        String formCode = form.getClientFormCode();
        String formId = String.valueOf(form.getId());
        String pattern = form.getReceiptPattern();

        Connection connection = null;
        try {
            connection = CayenneUtils.getConnection();

            if (StringUtils.isEmpty(pattern)) {
                pattern = Form.DEFAULT_RECEIPT_NUMBER_PATTERN;
                String updatePatternString = getReceiptPatternUpdateString(formId, pattern);
                Statement statement = connection.createStatement();
                statement.execute(updatePatternString);
                if (!connection.getAutoCommit()) {
                    connection.commit();
                }
            }

            StringTemplate stringTemplate = new StringTemplate(pattern);

            Map<String, String> model = new HashMap<String, String>();
            model.put("submissionId", submissionId);
            model.put("formCode", formCode);
            if (StringUtils.contains(pattern, "nextSequence")) {
                int nextValue = getNextReceiptSequence(connection, formId, MAX_RETRIES);
                model.put("nextSequence", String.valueOf(nextValue));
            }


            String result = stringTemplate.merge(model);
            if (StringUtils.isEmpty(result)) {
                String context = "Error during receipt number generation";
                String userMsg = "No receipt number could be assigned to submission " + submission.getId();
                throw new ApplicationException("EmptyReceiptNumber", context, userMsg, "Please contact an administrator");
            }
            return result;
        }
        catch (SQLException sqle) {
            String context = "Attempting to generate receipt sequence for form " + formId.toString();
            String userMsg =  "The receipt sequence number could not be generated successfully";
            throw new ApplicationException("DatabaseAccessFailed", sqle, context, userMsg, null);
        }
        finally {
            if (connection != null) {
                try {
                    connection.close();
                }
                catch (SQLException sqle) {
                    // ignore
                }
            }
        }
    }

    public boolean createFormReceiptSequence(Form form, int startValue) {
        FormReceiptSequence formReceiptSequence = (FormReceiptSequence) createAndRegisterNewObject(FormReceiptSequence.class);
        formReceiptSequence.setForm(form);
        formReceiptSequence.setSequenceNumber(startValue);
        try {
            getDataContext().commitChanges();
            return true;
        }
        catch (CayenneRuntimeException cre) {
            // probably an insert conflict - check if the sequence exists
            FormReceiptSequenceDao formReceiptSequenceDao = DaoFactory.getFormReceiptSequenceDao();
            FormReceiptSequence existingFormReceiptSequence = formReceiptSequenceDao.getFormReceiptSequence(form);
            if (existingFormReceiptSequence == null) {
                // no insert conflict - something more serious must be happening
                String context = "Form ID: " + form.getId();
                String userMsg = "Error when creating form sequence";
                throw new ApplicationException("InitialiseFormSequenceFailed", cre, context, userMsg, "Please try again or contact an administrator.");
            }
            else {
                // someone inserted a receipt sequence before we could - check the start value
                return (existingFormReceiptSequence.getSequenceNumber() == startValue);
            }
        }
    }

    private int getNextReceiptSequence(Connection connection, String formId, int maxRetries) throws SQLException {
        Validate.notNull(formId, "Null formId parameter");

        int result = Integer.MIN_VALUE;
        boolean updateSucceeded = false;
        int retryCount = 0;
        while (!updateSucceeded && retryCount <= maxRetries) {
            // attempt to retrieve the current receipt sequence entry
            String selectSequenceString = getReceiptSequenceSelectString(formId);
            Statement selectStatement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            selectStatement.execute(selectSequenceString);

            ResultSet resultSet = selectStatement.getResultSet();
            int resultSetSize = 0;
            if (resultSet != null && resultSet.last()) {
                resultSetSize = resultSet.getRow();
            }

            int updatedRows = 0;
            if (resultSetSize == 0) {
                // create the new sequence entry
                String createSequenceString = getReceiptSequenceCreateString(formId, 2);
                try {
                    // attempt to commit the new entry
                    // if this fails, it's most likely due to an insert conflict - we will abort the attempt and retry
                    Statement statement = connection.createStatement();
                    statement.execute(createSequenceString);
                    if (!connection.getAutoCommit()) {
                        connection.commit();
                    }
                    result = 1;
                    updatedRows = 1;
                }
                catch (SQLException sqle) {
                    // probably an insert conflict
                    updatedRows = 0;
                }
            }
            else {
                // update sequence entry
                resultSet.first();
                int curSequenceNumber = resultSet.getInt("sequence_number");

                String updateSequenceString = getReceiptSequenceUpdateString(formId, curSequenceNumber, curSequenceNumber + 1);

                // we will try to update the value to value + 1
                // only if this succeeds with no other transaction changing the value in the meantime, we consider the update complete
                try {
                    Statement statement = connection.createStatement();
                    statement.execute(updateSequenceString);
                    if (!connection.getAutoCommit()) {
                        connection.commit();
                    }
                    updatedRows = statement.getUpdateCount();
                    result = curSequenceNumber;
                }
                catch (SQLException sqle) {
                    String context = "Attempting to update receipt sequence for form " + formId.toString();
                    String userMsg =  "The receipt sequence number could not be generated successfully";
                    throw new ApplicationException("DatabaseAccessFailed", sqle, context, userMsg, null);
                }
            }

            if (updatedRows > 0) {
                updateSucceeded = true;
            }
            retryCount++;
        }

        if (!updateSucceeded) {
            String context = "Attempting to generate receipt sequence for form " + formId.toString();
            String userMsg =  "The receipt sequence number could not be generated successfully";
            throw new ApplicationException("SequenceGenerationFailed", context, userMsg, null);
        }
        return result;
    }

    private String getReceiptPatternUpdateString(String formId, String newPattern) {
        StringBuilder result = new StringBuilder();
        result.append("update form set receipt_pattern = '");
        result.append(newPattern);
        result.append("' where form_oid = ");
        result.append(formId);
        result.append(";");
        return result.toString();
    }

    private String getReceiptSequenceSelectString(String formId) {
        StringBuilder result = new StringBuilder();
        result.append("select sequence_number from form_receipt_sequence where form_oid = ");
        result.append(formId);
        result.append(";");
        return result.toString();
    }

    private String getReceiptSequenceCreateString(String formId, int newValue) {
        StringBuilder result = new StringBuilder();
        result.append("insert into form_receipt_sequence (form_oid, sequence_number) values (");
        result.append(formId);
        result.append(", ");
        result.append(newValue);
        result.append(");");
        return result.toString();
    }

    private String getReceiptSequenceUpdateString(String formId, int oldValue, int newValue) {
        StringBuilder result = new StringBuilder();
        result.append("update form_receipt_sequence set sequence_number = ");
        result.append(newValue);
        result.append(" where form_oid = ");
        result.append(formId);
        result.append(" and sequence_number = ");
        result.append(oldValue);
        result.append(";");
        return result.toString();
    }
}

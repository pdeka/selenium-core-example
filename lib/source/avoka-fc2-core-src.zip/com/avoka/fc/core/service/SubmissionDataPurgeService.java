package com.avoka.fc.core.service;

import com.avoka.fc.core.entity.Submission;

public interface SubmissionDataPurgeService {

    public void purgeSubmissionData(Submission submission);

    public String getPurgeDeliveredSubmissionAgeMins();
}

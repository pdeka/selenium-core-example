package com.avoka.fc.core.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;

import com.avoka.fc.core.dao.DailySummaryReportDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.entity.DailySummaryReport;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.SummaryMetricsGeneratorService;

/**
 *  Summary Metric Report Service
 *
 *  This service calculates various metrics for daily reports
 *
 * @author mdeandrade
 *
 */
public class SummaryMetricsGeneratorServiceImpl extends CayenneService implements
        SummaryMetricsGeneratorService {

     // Constants
    public static final int URL_REFERRERS_LIST_MAX = 10;

    // This variable will have its value injected from a Service Parameter
    private String startCalcDate;

    public String getStartCalcDate() {
        return startCalcDate;
    }

    public void setStartCalcDate(String startCalcDate) {
        this.startCalcDate = startCalcDate;
    }

    /*
     * Main function of the service.
     */
    public void calculateMetrics(Date eventDate) {
        getLogger().info("Calculating Daily Metrics Summary ... for "+eventDate);

        // Format dates
        eventDate = removeTimeFromDate(eventDate);
        Date endDate = addOneDayToDate(eventDate);
        DailySummaryReportDao dailySummaryReportDao = DaoFactory.getDailySummaryReportDao();
        DailySummaryReport dailySummaryReport = dailySummaryReportDao.getMostRecentDailySummaryReport();

        // extract file sequence number
        Integer fileSequenceNumber = 0;
        if (dailySummaryReport != null) {
            fileSequenceNumber = dailySummaryReport.getFileSequenceNumber() + 1;
        }

        // create a daily summary report to be edited
        dailySummaryReport = dailySummaryReportDao.getOrCreateDailySummaryReport(eventDate, fileSequenceNumber+1);
        commitChanges();
        calculateSummaryMetrics(eventDate, endDate);

        // we are done, create the daily_summary report
        dailySummaryReport.setCalcStatus(Submission.STATUS_Completed);
        commitChanges();
    }

    /**
     * Removed time from a date
     * @param date
     * @return
     */
    private Date removeTimeFromDate(Date date) {
        date = DateUtils.truncate(date, Calendar.DATE);
        return date;
    }

    /**
     * Adds one day to a date
     * @param date
     * @return
     */
    private Date addOneDayToDate(Date date) {
        date = DateUtils.truncate(date, Calendar.DATE);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    /**
     * Here we retrieve metrics that are calculated and not directly retrieved from a metric table
     *
     * @param startDate
     * @param endDate
     * @return
     */
    private void calculateSummaryMetrics(Date startDate, Date endDate) {
        getLogger().debug("Calculating summary metrics for date " + startDate);
        SubmissionDao submissionDao = DaoFactory.getSubmissionDao();
        DailySummaryReportDao dailySummaryReportDao = DaoFactory.getDailySummaryReportDao();
        List<Submission> submissionList = submissionDao.getActiveSubmissions(startDate, endDate, null, true);

        int authSmartformSubs = (submissionList == null ? 0 : submissionList.size());
        submissionList = submissionDao.getActiveSubmissions(startDate, endDate, null, false);

        int unauthSmartformSubs = (submissionList == null ? 0 : submissionList.size());
        submissionList = submissionDao.getOfflineSubmissions(startDate, endDate);

        int offlineSmartformSubs = (submissionList == null ? 0 : submissionList.size());
        dailySummaryReportDao.setDailySummaryReportSummaryMetrics(startDate, authSmartformSubs, unauthSmartformSubs, offlineSmartformSubs);
    }


}

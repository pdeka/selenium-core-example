package com.avoka.fc.core.service;

import org.apache.cxf.frontend.ClientProxyFactoryBean;
import org.apache.cxf.jaxws.JaxWsClientFactoryBean;

import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.service.finder.CategoryDataService;
import com.avoka.fc.core.service.health.HealthMonitorService;
import com.avoka.fc.forms.api.FormsClientWebService;

public class ServiceFactory {

    public static AuditLogService getAuditLogService() {
        return new AuditLogService();
    }

    public static AttachmentService getAttachmentService() {
        return new AttachmentService();
    }

    public static CategoryDataService getCategoryDataService() {
        return new CategoryDataService();
    }

    public static ClientService getClientService() {
        return new ClientService();
    }

    public static EmailService getEmailService() {
        return new EmailService();
    }

    public static ErrorLogService getErrorLogService() {
        return new ErrorLogService();
    }

    public static EventLogService getEventLogService() {
        return new EventLogService();
    }

    public static FormsClientWebService getFormsClientService(String formsClientWsAddress) {

        ClientProxyFactoryBean factory = new ClientProxyFactoryBean(new JaxWsClientFactoryBean());
        factory.setServiceClass(FormsClientWebService.class);

        factory.setAddress(formsClientWsAddress);

        return (FormsClientWebService) factory.create();
    }

    public static FormService getFormService() {
        return new FormService();
    }

    public static FormDeployService getFormDeployService() {
        return new FormDeployService();
    }

    public static FormReceiptService getFormReceiptService() {
        return new FormReceiptService();
    }

    public static HealthMonitorService getHealthMonitorService() {
        return new HealthMonitorService();
    }

    public static LogPurgeService getLogPurgeService() {
        LogPurgeService logPurgeService = (LogPurgeService) ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_LOG_PURGE);
        return logPurgeService;
    }

    public static ReceiptDataService getReceiptDataService() {
        return new ReceiptDataService();
    }

    public static SubmissionStatusService getSubmissionStatusService() {
        return new SubmissionStatusService();
    }

    public static SubmissionDeliveryService getSubmissionDeliveryService() {
        return (SubmissionDeliveryService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DELIVERY);
    }

    public static SummaryMetricsGeneratorService getSummaryMetricsReportingService() {
           SummaryMetricsGeneratorService summaryMetricsReportingService = (SummaryMetricsGeneratorService) ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUMMARY_METRICS_GENERATOR);
           return summaryMetricsReportingService;
    }

    public static SupportService getSupportService() {
        return new SupportService();
    }

    public static TaskService getTaskService() {
        return new TaskService();
    }

    public static UserService getUserService() {
        return new UserService();
    }
}


package com.avoka.fc.core.service;

import java.util.*;

import com.avoka.fc.core.dao.*;
import com.avoka.fc.core.entity.*;
import com.avoka.fc.core.util.ApplicationException;

/**
 *
 * @author pcopeland Created June 2007
 */
public class InvoiceService extends CayenneService {

    /**
     * Find all uninvoiced submissions and calculate the invoice costs for each one.
     *
     */
    public void invoiceAllSubmissions() {

        SubmissionDao submissionDao = new SubmissionDao();
        List submissionList = submissionDao.getSubmissionsNotInvoiced(100);

        for (Iterator iter = submissionList.iterator(); iter.hasNext();) {
            Submission submission = (Submission) iter.next();
            invoiceSubmission(submission);

            // Needs to be committed on a per submission basis.
            this.getDataContext().commitChanges();

        }

    }

    private void invoiceSubmission(Submission submission) {
        Client client = submission.getClient();

        // First find the appropiate plan
        InvoicePlan invoicePlan = client.getInvoicePlan();

        if (invoicePlan == null) {
            InvoicePlanDao invoicePlanDao = new InvoicePlanDao();
            invoicePlan = invoicePlanDao.getDetaultPlan();

        }

        if (invoicePlan == null) {

            throw new ApplicationException("NoDefaultInvoicePlan", "", "No default invoice plan has been defined.",
                    "Please ensure that a default invoice plan is selected.");
        }

        // Now find the invoice period
        Date submissionDate = submission.getTimeSubmission();
        InvoiceDao invoiceDao = new InvoiceDao();
        Invoice invoice = invoiceDao.getInvoice(client, submissionDate);

        if (invoice == null) {
            invoice = invoiceDao.createInvoice(client, submissionDate, invoicePlan);
        }

        /*
         * Now get the invoice line item.
         *
         * An invoiceLineItem is created for each step in the invoicing plan.
         *
         * ie LineItem 1 - Payments 1 to 100 are free LineItem 2 - Payments 101 to n cost 50c each.
         *
         * Each LineItem has n number (determined from the size of the plan step) of submissions
         * assocaited with it.
         */

        List lineItemList = invoice.getLineitemsOrderedDesc();
        InvoiceLineitem openLineItem = null;

        if (lineItemList == null) {
            openLineItem = invoiceDao.createLineItem(invoice, invoicePlan, 1, submission);
        } else {
            /*
             * The last line item will be the open one. If we need a new line item it will be added
             * during the allocattion process.
             */
            openLineItem = (InvoiceLineitem) lineItemList.get(0);
        }

        // Need to get the current item count no from openLineItem and check if we need to roll to a
        // new LineItem.

        int itemCount = openLineItem.getItemCount().intValue();

        InvoicePlanStep step = openLineItem.getStep();

        int stepEnd = step.getStepEnd().intValue();

        if (stepEnd == -1) {
            /*
             * Means that this is infinite - ie any number of items. Used for the last step in a
             * plan.
             *
             * Ignore
             */

        } else if ((itemCount + 1) > stepEnd) {
            openLineItem = invoiceDao.createLineItem(invoice, invoicePlan, itemCount + 1, submission);
        }

        openLineItem.setItemCount(new Integer(itemCount + 1));
        submission.setInvLineitemSeq(new Integer(itemCount + 1));
        submission.setLineitem(openLineItem);

        /*
         * Now calculate the payment.
         *
         * To do this we get the payment type from the submission then lookup how much that type
         * costs from the invoice_product_cost table - which is linked to the invoice_plan_step.
         *
         * The whole idea here is to store the item amount in the submission so that we can then
         * easily run a report or query to total the invoice amount - grouped by lineitem. We can
         * easily have both summary and detailed reports that can be run at any time.
         *
         * (You need to be viewing the ERWin mode of this while reading these comments.)
         *
         */

        List productCostList = step.getProductCost();

        String submissionPaymentType = submission.getPaymentType();
        int invoiceAmount = -1;

        for (Iterator iter = productCostList.iterator(); iter.hasNext();) {
            InvoiceProductCost productCost = (InvoiceProductCost) iter.next();
            if (productCost.getPaymentType().equalsIgnoreCase(submissionPaymentType)) {
                invoiceAmount = productCost.getAmount().intValue();
            }
        }

        if (invoiceAmount == -1) {
            /*
             * Missing product. Create an event in the event log and save the -1 value to the
             * submission amount
             *
             */
            EventLogService eventLogService = new EventLogService();

            String msg = "Invoicing Warning for Submission " + submission.getId() + " There is no payment type cost defined in this step. "
                    + " Payment Type = " + submissionPaymentType + " Invoice amount has been set to -1. Please correct this manually or "
                    + "reset the entire invoice period. Please also add the payment type to the payment plan step.";

            eventLogService.logWarnEvent(msg, submission);
        }

        submission.setInvLineitemAmount(new Integer(invoiceAmount));

        // Done.

    }
}

package com.avoka.fc.core.service.export;

import java.util.ArrayList;
import java.util.List;

public class ExportDataRow {

    private List<Object> cells;

    public ExportDataRow() {
    }

    public void add(Object cell) {
        getCells().add(cell);
    }

    public void setCells(List<Object> cells) {
        this.cells = cells;
    }

    public List<Object> getCells() {
        if (cells == null) {
            cells = new ArrayList();
        }
        return cells;
    }
}

/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.adobe.workflow.DOMUtil;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.AvokaTemplateSchema;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.FormDeployXmlDao;
import com.avoka.fc.core.dao.PropertyDeployDao;
import com.avoka.fc.core.dao.RequestLogDao;
import com.avoka.fc.core.dao.TemplateDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.dao.UserProfileDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.PaymentAccount;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.RequestLogData;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserProfile;
import com.avoka.fc.core.entity.XmlInDeployMap;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.PortalUtils;
import com.avoka.fc.core.util.XPath;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

/**
 * This refactors all the FormService for FC2. It assumes that the
 * Form_Deployment_XML File is generated prior to the render request.
 *
 * FormService provides the core API's to manage forms through FormCenter
 */
public class FormDataService extends CayenneService {

    // attributes
//    private long time;

    private ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
    private FormDeployXmlDao formXMLDao = DaoFactory.getFormDeployXmlDao();
    private TemplateDao templateDao = DaoFactory.getTemplateDao();
    private UserAccountDao userAccountDao = DaoFactory.getUserAccountDao();
    private UserProfileDao userProfileDao = DaoFactory.getUserProfileDao();

    /** Spring injected. */
    private FormPrefillService formPrefillService;

    // Public Methods --------------------------------------------------------

    public FormPrefillService getFormPrefillService() {
        return formPrefillService;
    }

    public void setFormPrefillService(FormPrefillService formPrefillService) {
        this.formPrefillService = formPrefillService;
    }

    /**
     * Return a populated form seed XML document, populated with the form
     * specific attachments, client properties, user properties and system
     * properties.
     */
    public String populateSeedXml(
            Form form,
            HttpServletRequest request,
            boolean getFormPrefillData,
            String xmlPrefillData,
            UserAccount userAccount,
            boolean userAccountPrefill,
            String requestLogKey,
            String referer,
            String taskKey)
            throws ApplicationException {

        Validate.notNull(form, "Null form parameter");
        Validate.notNull(requestLogKey, "Null formRequestNumber parameter");

        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction transaction = domain.createTransaction();

        Transaction.bindThreadTransaction(transaction);

        try {
            startProfile();

            // Ensure the form is active
            if (!form.isActive()) {
                throw new ApplicationException(
                        "FormIsNotActive",
                        "Requested FormCode=" + form.getClientFormCode(),
                        "This form is not currently active. Please check with support.",
                        "A request has been made for a form that is not active. Please check with the Forms Administrator if this form should be activated.");
            }

            // Now get the template
            Template template = form.getTemplate();

            // Ensure the template is active
            if (!template.isActive()) {
                throw new ApplicationException(
                        "TemplateIsNotActive",
                        "Requested FormCode=" + form.getClientFormCode(),
                        "This template is not currently active. Please check with support.",
                        "A request has been made for a template that is not active. Please check with the Forms Administrator if this form should be activated.");
            }

            TemplateVersion requestVersion = null;
            TemplateVersion templateVersion = null;

            // Get the template Version
            if (requestVersion == null) {
                // ensure that the latest version has been deployed.
                if (templateDao.setCurrentDeployVersion(template)) {
                    commitChanges();
                }

                templateVersion = template.getCurrentVersion();

            } else {
                // TODO: MAE 23/4/08 - the second code path will never be
                // executed, as
                // requestVersion is null,
                // version should be passed in as a parameter
                templateVersion = requestVersion;
            }

            // Ensure template version exists
            if (templateVersion == null) {
                throw new ApplicationException(
                        "NullTemplateVersion",
                        "Requested FormCode=" + form.getClientFormCode(),
                        "This form versions are not currently active. Please ensure that the form is available for use.",
                        "A request has been made for a template version that is not active. Please check with the Forms Administrator if this form should be activated.");
            }

            // TODO: MAE - check whether template version should be rolled over to new version

            endProfile("getTemplateVersion");

            // If a static PDF form don't create a seed document
            if (templateVersion.getFormType().equals(TemplateVersion.FORM_TYPE_STATIC_PDF_FORM)) {
                return "";
            }

            DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
            boolean isInProductionMode = deploymentPropertyDao.isProductionMode();

//            // If Form Template has no schema seed defined simply return the
//            // SystemProfile
//            if (templateVersion.getSchema() == null && !isInProductionMode) {
//                Document seedDocument = XmlUtils.parseDocumentFromString(EMPTY_SEED);
//                populateSystemProfile(seedDocument, form, userKey, requestLogKey, templateVersion);
//
//                return XmlUtils.toString(seedDocument.getDocumentElement());
//            }

            // Get or create a form deployment record and load the stored XML
            // seed data
            FormDeployXml formDeployXML = formXMLDao.getFormDeployXML(form, templateVersion);

            if (formDeployXML == null) {
                FormDeployService formDeployService = ServiceFactory.getFormDeployService();
                formDeployXML = formDeployService.createFormDeployXML(form, templateVersion);
            }

            // Get the XML data file
            String seedFileString = new String(formDeployXML.getFormDeployXmlData());
            Document seedDocument = XmlUtils.parseDocumentFromString(seedFileString, false, false);

            // Populate the SystemProfile header element in the XML document
            populateSystemProfile(seedDocument,
                                  form,
                                  request,
                                  userAccount,
                                  requestLogKey,
                                  referer,
                                  taskKey,
                                  templateVersion,
                                  formDeployXML);
            endProfile("populateSystemProfile");

            if (templateVersion.getSchema() != null || isInProductionMode) {

                // Populate the UserProfile section in the XML document
                if (userAccountPrefill) {
                    populateUserProfile(seedDocument, formDeployXML, userAccount, form);
                    endProfile("populateUserProfile");
                }

                // If requested or configured attempt to get XML form prefill data from Forms Client WS.
                // Note WS Get Form Prefill data overrides any POST XML data
                if (getFormPrefillData || form.isPrefillRequired() && formPrefillService != null) {
                    xmlPrefillData = formPrefillService.getFormPrefillData(form, request);
                }

                if (StringUtils.isNotBlank(xmlPrefillData)) {
                    List<XmlInDeployMap> xmlInDeployMaps = formDeployXML.getXmlInDeployMaps();

                    Document sourceDocument = XmlUtils.parseDocumentFromString(xmlPrefillData);

                    XmlPrefillService xmlPrefillService = new XmlPrefillService();
                    xmlPrefillService.mergeXmlData(sourceDocument, seedDocument, xmlInDeployMaps);

                    setRequestLogMetric(requestLogKey, xmlPrefillData);
                }

                endProfile("xmlPrefill");
            }
            commitChanges();

            transaction.commit();

            // Return the XML seed data
            String seedXml = XmlUtils.toString(seedDocument.getDocumentElement());

            return seedXml;

        } catch (Exception error) {
            try {
                transaction.rollback();

            } catch (Exception e) {
                getLogger().error("Error Rolling back transaction...", e);

            } finally {
                Transaction.bindThreadTransaction(null);
            }

            errorLogService.logException(error);

            if (error instanceof RuntimeException) {
                throw (RuntimeException) error;

            } else {
                String msg = "Unknown error: " + error.toString();
                throw new ApplicationException("FormService", error, msg, msg,
                        null);
            }

        } finally {
            Transaction.bindThreadTransaction(null);
        }
    }

    /**
     * Return a populated form seed XML document, using the input seed XML and adding the system profile
     * and user specific data
     */
    public String populateFormXml(
            Form form,
            HttpServletRequest request,
            UserAccount userAccount,
            String seedFileString,
            boolean userAccountPrefill,
            String requestLogKey,
            String referer,
            String taskKey)
            throws ApplicationException {

        Validate.notNull(form, "Null form parameter");
        Validate.notNull(requestLogKey, "Null formRequestNumber parameter");

        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction transaction = domain.createTransaction();
        Transaction.bindThreadTransaction(transaction);

        try {
            startProfile();

            // Ensure the form is active
            if (!form.isActive()) {
                throw new ApplicationException(
                        "FormIsNotActive",
                        "Requested FormCode=" + form.getClientFormCode(),
                        "This form is not currently active. Please check with support.",
                        "A request has been made for a form that is not active. Please check with the Forms Administrator if this form should be activated.");
            }

            // Now get the template
            Template template = form.getTemplate();

            // Ensure the template is active
            if (!template.isActive()) {
                throw new ApplicationException(
                        "TemplateIsNotActive",
                        "Requested FormCode=" + form.getClientFormCode(),
                        "This template is not currently active. Please check with support.",
                        "A request has been made for a template that is not active. Please check with the Forms Administrator if this form should be activated.");
            }

            TemplateVersion requestVersion = null;
            TemplateVersion templateVersion = null;

            // Get the template Version
            if (requestVersion == null) {
                // ensure that the latest version has been deployed.
                if (templateDao.setCurrentDeployVersion(template)) {
                    commitChanges();
                }

                templateVersion = template.getCurrentVersion();

            } else {
                // TODO: MAE 23/4/08 - the second code path will never be
                // executed, as
                // requestVersion is null,
                // version should be passed in as a parameter
                templateVersion = requestVersion;
            }

            // Ensure template version exists
            if (templateVersion == null) {
                throw new ApplicationException(
                        "NullTemplateVersion",
                        "Requested FormCode=" + form.getClientFormCode(),
                        "This form versions are not currently active. Please ensure that the form is available for use.",
                        "A request has been made for a template version that is not active. Please check with the Forms Administrator if this form should be activated.");
            }

            // TODO: MAE - check whether template version should be rolled over to new version
            endProfile("getTemplateVersion");

            // If a static PDF form don't create a seed document
            if (templateVersion.getFormType().equals(TemplateVersion.FORM_TYPE_STATIC_PDF_FORM)) {
                return "";
            }

            DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
            boolean isInProductionMode = deploymentPropertyDao.isProductionMode();

            // Get or create a form deployment record and load the stored XML
            // seed data
            FormDeployXml formDeployXML = formXMLDao.getFormDeployXML(form, templateVersion);

            if (formDeployXML == null) {
                FormDeployService formDeployService = ServiceFactory.getFormDeployService();
                formDeployXML = formDeployService.createFormDeployXML(form, templateVersion);
            }

            // Get the XML data file
            Document seedDocument = XmlUtils.parseDocumentFromString(seedFileString, false, false);

            // Populate the SystemProfile header element in the XML document
            populateSystemProfile(seedDocument,
                                  form,
                                  request,
                                  userAccount,
                                  requestLogKey,
                                  referer,
                                  taskKey,
                                  templateVersion,
                                  formDeployXML);
            endProfile("populateSystemProfile");

            if (templateVersion.getSchema() != null || isInProductionMode) {

                // Populate the UserProfile section in the XML document
                if (userAccountPrefill) {
                    populateUserProfile(seedDocument, formDeployXML, userAccount, form);
                    endProfile("populateUserProfile");
                }

                endProfile("xmlPrefill");
            }
            commitChanges();

            transaction.commit();

            // Return the XML seed data
            String seedXml = XmlUtils.toString(seedDocument.getDocumentElement());
            return seedXml;

        } catch (Exception error) {
            try {
                transaction.rollback();
            } catch (Exception e) {
                getLogger().error("Error Rolling back transaction...", e);
            } finally {
                Transaction.bindThreadTransaction(null);
            }

            errorLogService.logException(error);

            if (error instanceof RuntimeException) {
                throw (RuntimeException) error;
            } else {
                String msg = "Unknown error: " + error.toString();
                throw new ApplicationException("FormService", error, msg, msg, null);
            }
        } finally {
            Transaction.bindThreadTransaction(null);
        }
    }

    // Private Methods --------------------------------------------------------

    private void setRequestLogMetric(String requestLogKey, String prefillDataString){

        RequestLogDao requestLogDao = DaoFactory.getRequestLogDao();
        RequestLog requestLog = requestLogDao.getRequestLogFromKey(requestLogKey);
        if (requestLog != null) {
            requestLog.setPrefillDataFlag(true);

            RequestLogData requestLogData = requestLog.getRequestLogData();
            if (requestLogData == null) {
                requestLogData = new RequestLogData();
                getDataContext().registerNewObject(requestLogData);
                requestLog.setRequestLogData(requestLogData);
            }
            requestLogData.setPrefillDataString(prefillDataString);

        } else {
            getLogger().warn("request log not found, prefill not set");
        }
    }

    /**
     * TODO: ME - work through schema schema list and set the values into the
     * schema file. Need to do this in reverse order - ie start at the very top
     * and go down.
     */
    private void populateUserProfile(Document seedDocument, FormDeployXml formDeployXml, UserAccount userAccount, Form form) {

        Validate.notNull(formDeployXml, "Null formDeployXml parameter");
        Validate.notNull(seedDocument, "Null seedDocument parameter");

        XPath xpath = new XPath(seedDocument);

        // Load user profile information
        UserProfile userProfile = userProfileDao.getCurrentUserProfileForUser(userAccount);
        if (userProfile != null) {
            populateUserProperties(formDeployXml, xpath, userProfile);
        }

        // Populate user's client accounts
        String userProfileXPath = formDeployXml.getSchemaConfigXPath(SchemaConfigMap.NAME_USER_PROFILE);
        if (userProfileXPath == null) {
            String msg = "No " + SchemaConfigMap.NAME_USER_PROFILE
                    + " Schema Config Map defined for form code: "
                    + form.getClientFormCode();
            getLogger().debug(msg);
            return;
        }

        Element itemListElement =
            xpath.selectSingleNode(userProfileXPath + "/" + AvokaTemplateSchema.USER_PROFILE_ACCOUNTS_ITEM_LIST);
        if (itemListElement == null) {
            String msg = "No " + itemListElement + " element defined for form code: " + form.getClientFormCode();
            getLogger().debug(msg);
            return;
        }

        List<PaymentAccount> clientUserAccounts = userAccountDao.getUserClientAccounts(userAccount, form.getClient());
        for (PaymentAccount clientUserAccount : clientUserAccounts) {
            String accountNumber = clientUserAccount.getAccountNumber();

            Element itemElement = DOMUtil.createElement(itemListElement, AvokaTemplateSchema.ITEM);
            itemListElement.appendChild(itemElement);

            itemElement.appendChild(DOMUtil.createElementWithText(itemElement, AvokaTemplateSchema.ACCOUNT_NUMBER, accountNumber));
        }
    }

    /**
     * Populate the system profile information in the XML seed document.
     */
    private void populateSystemProfile(Document seedDocument,
            Form form,
            HttpServletRequest request,
            UserAccount userAccount,
            String requestLogKey,
            String referer,
            String taskKey,
            TemplateVersion templateVersion,
            FormDeployXml formDeployXml) {

        Validate.notNull(seedDocument, "Null seedDocument parameter");
        Validate.notNull(form, "Null form parameter");
        Validate.notNull(request, "Null request parameter");
        Validate.notNull(requestLogKey, "Null requestKey parameter");

        SystemProfileHelper systemProfileHelper = new SystemProfileHelper(seedDocument);

        systemProfileHelper.setFormCode(form.getClientFormCode());

        // Set it to submit by default. Form Developer can override if they want
        // it saved.
        systemProfileHelper.setSubmissionType(Submission.STATUS_Submitted);

        systemProfileHelper.setLocalSaveEnabledFlag(form.isSaveLocalFlag());

        DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
        Boolean globalOnlineSaveEnabled = deploymentPropertyDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_Online_Save_Enabled);
        if (Boolean.TRUE.equals(globalOnlineSaveEnabled)) {
            systemProfileHelper.setOnlineSaveEnabledFlag(form.getSaveOnlineFlag());
        } else {
            // online save globally disabled
            systemProfileHelper.setOnlineSaveEnabledFlag(Boolean.FALSE);
        }

        systemProfileHelper.setTemplateVersionOid(templateVersion.getId());

        systemProfileHelper.setReaderVersionRequired(templateVersion.getReaderVersionRequired());

        systemProfileHelper.setReferer(referer);

        systemProfileHelper.setRequestLogKey(requestLogKey);

        String redirectTarget = request.getParameter(Constants.PARAM_RedirectTarget);
        if (StringUtils.isNotBlank(redirectTarget)) {
            systemProfileHelper.setRedirectTarget(redirectTarget);
        }

        // Get incompatible reader path
        Portal portal = form.getPortal();
        if (portal != null) {
            String incompatibleReaderURL = PortalUtils.getIncompatibleReaderPath(portal);
            incompatibleReaderURL = StringUtils.replace(incompatibleReaderURL, "${portalContentPath}", portal.getContextPath());
            incompatibleReaderURL += "?" + Constants.PARAM_FormCode + "=" + form.getClientFormCode();
            systemProfileHelper.setIncompatibleReaderURL(incompatibleReaderURL);
        }

        systemProfileHelper.setTestMode(form.getTestEnabledFlag());

        String format = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Date_Format_Long);
        SimpleDateFormat sdf = new SimpleDateFormat(format);

        systemProfileHelper.setSubmissionNumber("");

        systemProfileHelper.setDisplayMode(SystemProfileHelper.MODE_ENTRY);

        systemProfileHelper.setServerBuildNumber(Constants.SERVER_Build);

        if (userAccount != null) {
            systemProfileHelper.setUserCode(userAccount.getUserKey());
        }

        // Calculate the submission expiry time
        Date expiryDate = form.getSubmissionExpiryDate();
        Integer expiryDays = form.getSubmissionExpiryDays();

        if (expiryDays == null) {
            // Always make it 1 day minimum. Submisison throws errors if there
            // is no
            // SubmissionExpiry Date
            expiryDays = new Integer(1);
        }

        if (expiryDays != null) {
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.add(Calendar.DATE, expiryDays.intValue());

            if (expiryDate != null) {
                if (expiryDate.after(calendar.getTime())) {
                    expiryDate = calendar.getTime();
                }
            } else {
                expiryDate = calendar.getTime();
            }
        }

        // System.out.println("Submission Expiry Date = " + expiryDate);
        // System.out.println("Submission Expiry Days = " + expiryDays);

        if (expiryDate != null) {
            systemProfileHelper.setSubmissionExpiryDate(sdf.format(expiryDate));
        }

        if (form.getSubmissionExpiryDays() != null) {
            systemProfileHelper.setSubmissionExpiryDuration(form.getSubmissionExpiryDays());
        }

        if (StringUtils.isNotEmpty(taskKey)) {
            systemProfileHelper.setTaskKey(taskKey);
        }

        // Set SubmissionMessage element from the "SubmissionMessage" form property
        PropertyDeployDao propertyDeployDao = DaoFactory.getPropertyDeployDao();
        String submissionMessage =
            propertyDeployDao.getPropertyDeployValue(formDeployXml.getId(), PropertyType.FORM_Property_Submission_Message);

        systemProfileHelper.setSubmissionMessage(submissionMessage);
    }

    /**
     * Populate user profile information in the XML seed document.
     *
     */
    private void populateUserProperties(FormDeployXml formDeployXml, XPath formXPath, UserProfile userProfile) {

        Validate.notNull(formDeployXml, "Null formDeployXml parameter");
        Validate.notNull(formXPath, "Null formXPath parameter");
        Validate.notNull(userProfile, "Null userProfile parameter");

        // Load user profile information
        List<Map> userProperties = userProfileDao.getUserProfilePropertyValues(formDeployXml, userProfile);

        for (Map row : userProperties) {
            String xpath = row.get("xpath").toString();
            String value = row.get("value").toString();

            formXPath.setNodeValue(xpath, value);
        }
    }

    private void startProfile() {
//        time = System.currentTimeMillis();
    }

    private void endProfile(String name) {
        // PRC - Please leave this as Info not debug
//        if (getLogger().isInfoEnabled()) {
//            getLogger().info(
//                    name + " took: " + (System.currentTimeMillis() - time)
//                            + " ms");
//            time = System.currentTimeMillis();
//        }
    }
}

package com.avoka.fc.core.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.PropertyComparator;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.MetadataValueDeployDao;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.MetadataValueDeploy;
import com.avoka.fc.core.service.BaseService;
import com.avoka.fc.core.service.FormDeployService;
import com.avoka.fc.core.service.FormMetaDataService;
import com.avoka.fc.core.service.MetaData;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.util.PortalUtils;

/**
 * Provides an AGLS implementation of the form meta data rendering service.
 *
 * @author medgar@avoka.com
 */
public class AGLSFormMetaDataService extends BaseService implements FormMetaDataService {

    private static final String TAG_Organization    = "AGLS Organization Name";
    private static final String TAG_Jurisdiction    = "AGLS Jurisdiction";
    private static final String TAG_Function        = "AGLS Function";
    private static final String TAG_Form_Name       = "AGLS Form Name";
    private static final String TAG_Description     = "AGLS Description";
    private static final String TAG_Service         = "AGLS Service";
    private static final String TAG_Date_Created    = "AGLS Date Created";
    private static final String TAG_Audience        = "AGLS Audience";
    private static final String TAG_Language        = "AGLS Language";
    private static final String TAG_Valid_From      = "AGLS Valid From";
    private static final String TAG_Valid_To        = "AGLS Valid To";
    private static final String TAG_Rights          = "AGLS Rights";

    private static final String HTML_ELEMENT_Creator = "DC.Creator";
    private static final String HTML_ELEMENT_Function = "AGLS.Function";
    private static final String HTML_ELEMENT_Title = "DC.Title";
    private static final String HTML_ELEMENT_Description = "DC.Description";
    private static final String HTML_ELEMENT_ServiceType = "DC.Type.serviceType";
    private static final String HTML_ELEMENT_DateCreated = "DC.Date.created";
    private static final String HTML_ELEMENT_DateValid = "DC.Date.valid";
    private static final String HTML_ELEMENT_Audience = "AGLS.Audience";
    private static final String HTML_ELEMENT_Language = "DC.Language";
    private static final String HTML_ELEMENT_Rights = "DC.Rights";

    private static final Map<String, String> tagToHtmlElementsMap = getTagToHtmlMap();
    private static final List<String> specialHtmlElements = getSpecialHtmlElements();
    /**
     * @see FormMetaDataService#getFormMetaData(Form)
     */
    public String renderHtmlMetaData(Form form) {
        List<MetaData> metaDataList = new ArrayList<MetaData>();
        Map<String, MetaData> specialElementMap = new HashMap<String, MetaData>();

        FormDeployService formDeployService = ServiceFactory.getFormDeployService();
        FormDeployXml formDeployXml = formDeployService.getOrCreateFormDeploy(form);

        MetadataValueDeployDao metadataValueDeployDao = DaoFactory.getMetadataValueDeployDao();

        List<MetadataValueDeploy> metadataValueList = metadataValueDeployDao.getMetadataValueDeployList(formDeployXml);

        for (MetadataValueDeploy metadataValue : metadataValueList) {
            MetaData metaData = new MetaData();

            String tagName = metadataValue.getName();
            String scheme = metadataValue.getScheme();

            if (tagToHtmlElementsMap.containsKey(tagName)) {
                String elementName = tagToHtmlElementsMap.get(tagName);

                if (specialHtmlElements.contains(elementName)) {
                    MetaData existingMetaData = specialElementMap.get(elementName);
                    metaData = handleSpecialElement(metadataValue, elementName, existingMetaData);
                    if (metaData != null) {
                        metaDataList.add(metaData);
                        specialElementMap.put(elementName, metaData);
                    }
                }
                else {
                    metaData.setName(elementName);
                    metaData.setScheme(scheme);
                    metaData.setContent(metadataValue.getValue());
                    metaDataList.add(metaData);
                }
            }
            else {
                metaData.setName(tagName);
                metaData.setScheme(scheme);
                metaData.setContent(metadataValue.getValue());
                metaDataList.add(metaData);
            }
        }

        // Add auto generated values
        MetaData metaData = null;

        // DC.Identifier
        if (form.getPortal () != null) {
            String path = PortalUtils.getFriendlyFormURL(form);

            metaData = new MetaData();
            metaData.setName("DC.Identifier");
            metaData.setScheme("URI");
            metaData.setContent(path);
            metaDataList.add(metaData);
        }

        // DC.Format
        metaData = new MetaData();
        metaData.setName("DC.Format");
        metaData.setScheme("IMT");
        if (form.getTemplate().getCurrentVersion().isFormGuide()) {
            metaData.setContent("application/x-shockwave-flash");
        } else {
            metaData.setContent("application/pdf");
        }
        metaDataList.add(metaData);

        // DC.Type.category
        metaData = new MetaData();
        metaData.setName("DC.Type.category");
        metaData.setScheme(null);
        metaData.setContent("service");
        metaDataList.add(metaData);

        Collections.sort(metaDataList, new PropertyComparator("name"));

        // Render HTML
        StringBuilder builder = new StringBuilder(512);

        // reference definitions
        builder.append("<link rel=\"schema.DCTERMS\" href=\"http://purl.org/dc/terms/\" />\n");
        builder.append("<link rel=\"schema.AGLSTERMS\" href=\"http://www.agls.gov.au/agls/terms/\" />\n");
        builder.append("<link rel=\"schema.DCMITYPE\" href=\"http://purl.org/dc/dcmitype/\" />\n");

        for (MetaData md : metaDataList) {
            builder.append("<meta name=\"");
            builder.append(md.getName());
            if (md.getScheme() != null) {
                builder.append("\" scheme=\"");
                builder.append(md.getScheme());
            }
            builder.append("\" content=\"");
            builder.append(md.getContent());
            builder.append("\"/>\n");
        }

        return builder.toString();
    }

    protected MetaData handleSpecialElement(MetadataValueDeploy sourceValue, String elementName, MetaData existingMetaData) {
        MetaData result = existingMetaData;
        if (existingMetaData == null || HTML_ELEMENT_Language.equals(elementName)) {
            result = new MetaData();
            result.setName(elementName);
            String scheme = sourceValue.getScheme();
            result.setScheme(scheme);
        }
        if (HTML_ELEMENT_Creator.equals(elementName)) {
            StringBuffer newValue = new StringBuffer();
            if (StringUtils.isNotEmpty(sourceValue.getValue())) {
                String tagName = sourceValue.getName();
                if (TAG_Organization.equals(tagName)) {
                    newValue.append("corporateName");
                    newValue.append("=");
                    newValue.append(sourceValue.getValue());
                    if (StringUtils.isNotEmpty(result.getContent())) {
                        newValue.append("; ");
                        newValue.append(result.getContent());
                    }
                }
                else if (TAG_Jurisdiction.equals(tagName)) {
                    if (StringUtils.isNotEmpty(result.getContent())) {
                        newValue.append(result.getContent());
                        newValue.append("; ");
                    }
                    newValue.append("jurisdiction");
                    newValue.append("=");
                    newValue.append(sourceValue.getValue());
                }
                else {
                    getLogger().warn("Unknown tag " + tagName + " encountered. Skipping tag.");
                    return result;
                }
                result.setContent(newValue.toString());
            }
        }
        else if (HTML_ELEMENT_DateValid.equals(elementName)) {
            StringBuffer newValue = new StringBuffer();
            if (StringUtils.isNotEmpty(sourceValue.getValue())) {
                String tagName = sourceValue.getName();
                if (TAG_Valid_From.equals(tagName)) {
                    newValue.append("start");
                    newValue.append("=");
                    newValue.append(sourceValue.getValue());
                    if (StringUtils.isNotEmpty(result.getContent())) {
                        newValue.append("; ");
                        newValue.append(result.getContent());
                    }
                }
                else if (TAG_Valid_To.equals(tagName)) {
                    if (StringUtils.isNotEmpty(result.getContent())) {
                        newValue.append(result.getContent());
                        if (StringUtils.isNotEmpty(sourceValue.getValue())) {
                            newValue.append("; ");
                        }
                    }
                    newValue.append("end");
                    newValue.append("=");
                    newValue.append(sourceValue.getValue());
                }
                else {
                    getLogger().warn("Unknown tag " + tagName + " encountered. Skipping tag.");
                    return result;
                }
                result.setContent(newValue.toString());
            }
        }
        else if (HTML_ELEMENT_Language.equals(elementName)) {
            String fullValue = sourceValue.getValue();
            String shortValue = fullValue.substring(fullValue.indexOf('(') + 1, fullValue.indexOf(')'));
            result.setContent(shortValue);
        }
        if (existingMetaData == null || HTML_ELEMENT_Language.equals(elementName)) {
            return result;
        }
        return null;
    }

    private static Map<String, String> getTagToHtmlMap() {
        Map<String, String> result = new HashMap<String, String>();
        result.put(TAG_Organization, HTML_ELEMENT_Creator);
        result.put(TAG_Jurisdiction, HTML_ELEMENT_Creator);
        result.put(TAG_Function, HTML_ELEMENT_Function);
        result.put(TAG_Form_Name, HTML_ELEMENT_Title);
        result.put(TAG_Description, HTML_ELEMENT_Description);
        result.put(TAG_Service, HTML_ELEMENT_ServiceType);
        result.put(TAG_Date_Created, HTML_ELEMENT_DateCreated);
        result.put(TAG_Audience, HTML_ELEMENT_Audience);
        result.put(TAG_Language, HTML_ELEMENT_Language);
        result.put(TAG_Valid_From, HTML_ELEMENT_DateValid);
        result.put(TAG_Valid_To, HTML_ELEMENT_DateValid);
        result.put(TAG_Rights, HTML_ELEMENT_Rights);
        return result;
    }

    private static List<String> getSpecialHtmlElements() {
        List<String> result = new ArrayList<String>();
        result.add(HTML_ELEMENT_Creator);
        result.add(HTML_ELEMENT_DateValid);
        result.add(HTML_ELEMENT_Language);
        return result;
    }
}

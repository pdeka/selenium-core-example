package com.avoka.fc.core.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.OfflineSubmissionFormDao;
import com.avoka.fc.core.dao.TemplateVersionDao;
import com.avoka.fc.core.dao.TemplateVersionDataDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.TemplateVersionData;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.SynchronizeTemplatesService;
import com.avoka.fc.core.util.FormUtils;

public class FileSystemSynchronizeTemplatesService extends CayenneService implements SynchronizeTemplatesService {

    private EventLogService eventLogService = ServiceFactory.getEventLogService();

    /**
     * @see SynchronizeTemplatesService#synchronizeTemplates()
     */
    public void synchronizeTemplates() {
        String directoryPath = getPublishDirectoryPath();
        if (directoryPath == null) {
            return;
        }

        long start = System.currentTimeMillis();

        // attempt to set the file size for all template versions where it is null
        setTemplateVersionFileSizes();

        TemplateVersionDataDao templateVersionDataDao = DaoFactory.getTemplateVersionDataDao();

        // Scan the file system for existing files
        Map<String, File> existingDirectories = new TreeMap<String, File>();

        File publishDirectory = new File(directoryPath);
        File[] directoryFiles = publishDirectory.listFiles();
        if (directoryFiles != null) {
            for (File directoryFile : directoryFiles) {

                // Skip directories containing offline submission forms
                if (directoryFile.isDirectory() && directoryFile.getName().startsWith(OfflineSubmissionForm.OSF_PREFIX)) {
                    continue;
                }
                if (directoryFile.isDirectory()) {
                    existingDirectories.put(directoryFile.getAbsolutePath(), directoryFile);

                } else {
                    // Delete unknown directory file
                    getLogger().debug("Deleting unknown directory file: " + directoryFile);
                    directoryFile.delete();
                }
            }
        }

        TemplateVersionDao templateVersionDao = DaoFactory.getTemplateVersionDao();

        List<TemplateVersion> templateVersionList = templateVersionDao.getAll();

        for (TemplateVersion templateVersion : templateVersionList) {
            if (templateVersion.getFileName() != null) {

                // make sure the template version directory is not deleted later on
                existingDirectories.remove(directoryPath + templateVersion.getId());

                if (!templateVersion.isFormGuide()) {
                    String filename = directoryPath + templateVersion.getId() + File.separator + templateVersion.getFileName();
                    File file = new File(filename);

                    if (!file.exists()
                        || !TemplateVersion.PUBLISH_STATUS_COMPLETE.equals(templateVersion.getPublishStatus())
                        || templateVersion.getFileSize() == null
                        || file.length() != templateVersion.getFileSize().longValue()) {

                        // Delete directory
                        File versionDirectory = file.getParentFile();
                        try {
                            FileUtils.deleteDirectory(versionDirectory);
                        }
                        catch (IOException ioe) {
                            getLogger().warn("Error deleting directory " + versionDirectory.getAbsolutePath() + ", error: " + ioe.toString());
                        }

                        // Write template version file
                        writeFile(directoryPath, filename, templateVersion);
                    }

                } else {
                    // Else a FormGuide ZIP file process all the children

                    String fileName = directoryPath + templateVersion.getId() + File.separator + templateVersion.getFileName();
                    File file = new File(fileName);

                    if (!file.exists()
                        || !TemplateVersion.PUBLISH_STATUS_COMPLETE.equals(templateVersion.getPublishStatus())
                        || templateVersion.getFileSize() == null
                        || file.length() != templateVersion.getFileSize().longValue()) {

                        // Delete directory
                        File versionDirectory = file.getParentFile();
                        try {
                            FileUtils.deleteDirectory(versionDirectory);
                        }
                        catch (IOException ioe) {
                            getLogger().warn("Error deleting directory " + versionDirectory.getAbsolutePath() + ", error: " + ioe.toString());
                        }

                        // republish form guide
                        TemplateVersionData templateVersionData = templateVersionDataDao.getDataForTemplateVersion(templateVersion);
                        if (templateVersionData == null || templateVersionData.getFileData() == null) {
                            eventLogService.logErrorEvent("Could not publish template version " + templateVersion.getId() + ". The template version data is not set.");
                            continue;
                        }
                        byte[] data = templateVersionData.getFileData();

                        ZipInputStream zis = null;
                        try {
                            zis = new ZipInputStream(new ByteArrayInputStream(data));

                            ZipEntry ze = null;
                            while ((ze = zis.getNextEntry()) != null) {
                                if (ze.isDirectory()) {
                                    continue;
                                }

                                String filename = directoryPath + templateVersion.getId() + File.separator + ze.getName();
                                filename = filename.replace('/', File.separatorChar);

                                byte[] fileData = getEntryByteArray(ze, zis);

                                writeFile(filename, fileData);
                            }

                        } catch (IOException ioe) {
                            getLogger().error(ioe.toString(), ioe);

                        } finally {
                            CoreUtils.close(zis);
                        }
                    }
                }

                templateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_COMPLETE);

            } else {
                getLogger().warn("File name is null for template version " + templateVersion.getId());
            }

            // clear the cache to avoid TemplateVersionData objects building up
            getDataContext().getObjectStore().getDataRowCache().clear();
        }

        // Deletions
        for (Iterator i = existingDirectories.values().iterator(); i.hasNext();) {
            File curDirectory = (File) i.next();
            try {
                FileUtils.deleteDirectory(curDirectory);
                getLogger().warn("Deleted unknown version folder: " + curDirectory);
            }
            catch (IOException ioe) {
                getLogger().warn("Error deleting directory " + curDirectory.getAbsolutePath() + ", error: " + ioe.toString());
            }
        }

        commitChanges();

        synchronizeOfflineSubmissionForms();

        long time = System.currentTimeMillis() - start;
        getLogger().info("Synchronize Form Templates in {} ms", NumberFormat.getInstance().format(time));
    }

    public void synchronizeOfflineSubmissionForms() {
        String directoryPath = getPublishDirectoryPath();
        if (directoryPath == null) {
            return;
        }

        // Scan the file system for exiting files
        Map<String, File> existingFiles = new TreeMap<String, File>();

        File publishDirectory = new File(directoryPath);
        File[] directoryFiles = publishDirectory.listFiles();
        if (directoryFiles != null) {
            for (File directoryFile : directoryFiles) {

                // Skip directories not containing offline submission forms
                if (directoryFile.isDirectory() && !directoryFile.getName().startsWith(OfflineSubmissionForm.OSF_PREFIX)) {
                    continue;
                }
                if (directoryFile.isDirectory()) {
                    File[] offlineSubmissionFormFiles = directoryFile.listFiles();
                    if (offlineSubmissionFormFiles != null) {
                        for (File offlineSubmissionFormFile : offlineSubmissionFormFiles) {
                            if (offlineSubmissionFormFile.isFile()) {
                                existingFiles.put(offlineSubmissionFormFile.getPath(), offlineSubmissionFormFile);

                            } else {
                                // Delete unknown directory
                                getLogger().warn("Deleting unknown offline submission form subdirectory: " + offlineSubmissionFormFile);
                                offlineSubmissionFormFile.delete();
                            }
                        }
                    }

                } else {
                    // Delete unknown directory file
                    getLogger().warn("Deleting unknown file: " + directoryFile);
                    directoryFile.delete();
                }
            }
        }

        OfflineSubmissionFormDao offlineSubmissionFormDao = new OfflineSubmissionFormDao();

        List<OfflineSubmissionForm> offlineSubmissionFormList = offlineSubmissionFormDao.getAll();

        for (OfflineSubmissionForm offlineSubmissionForm : offlineSubmissionFormList) {

            if (StringUtils.isEmpty(offlineSubmissionForm.getTemplateFileName())) {
                getLogger().warn("Cannot publish offline submission form " + offlineSubmissionForm.getId()
                                 + ": No form template defined.");
                continue;
            }

            String filename = directoryPath + OfflineSubmissionForm.OSF_PREFIX + offlineSubmissionForm.getId()
                + File.separator + offlineSubmissionForm.getTemplateFileName();

            File existingFile = existingFiles.get(filename);

            if (existingFile == null
                || existingFile.length() != offlineSubmissionForm.getFormTemplate().length) {

                // Deploy file
                writeFile(filename, offlineSubmissionForm.getFormTemplate());
                existingFiles.remove(filename);

                offlineSubmissionForm.setPublishStatus(TemplateVersion.PUBLISH_STATUS_COMPLETE);

            } else {
                existingFiles.remove(filename);
            }
        }

        // Deletions
        for (Iterator i = existingFiles.values().iterator(); i.hasNext();) {
            File file = (File) i.next();
            getLogger().warn("Deleting unknown offline submission form file: " + file);
            File parentDir = file.getParentFile();
            file.delete();
            // will only delete parent directory if it is empty
            parentDir.delete();
        }

        commitChanges();
    }

    // Private Methods ------------------------------------------------------------------------------------------------

    private String getPublishDirectoryPath() {
        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String directoryPath = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Publish_Templates_Directory);
        if (StringUtils.isBlank(directoryPath)) {
            String message = "SyncTemplateFilesJob: " + DeploymentProperty.PROPERTY_Publish_Templates_Directory + " is blank";
            eventLogService.logErrorEvent(message);
            getLogger().error(message);
            return null;
        }

        if (!directoryPath.endsWith("\\") && !directoryPath.endsWith("/")) {
            directoryPath += File.separator;
        }

        File publishDirectory = new File(directoryPath);
        if (!publishDirectory.exists()) {
            if (!publishDirectory.mkdirs()) {
                String message = "SyncTemplateFilesJob could not create directory: " + directoryPath;
                eventLogService.logErrorEvent(message);
                getLogger().error(message);
                return null;
            }
        }

        return directoryPath;
    }

    private void writeFile(String directoryPath, String filename, TemplateVersion templateVersion) {

        // Ensure template version directory exists
        File publishDirectory = new File(directoryPath + templateVersion.getId());
        if (!publishDirectory.exists()) {
            if (!publishDirectory.mkdirs()) {
                String message = "SyncTemplateFilesJob could not create directory: " + directoryPath;
                eventLogService.logErrorEvent(message);
                getLogger().error(message);
                return;
            }
        }

        // Delete any existing file
        File oldFile = new File(filename);
        if (oldFile.isFile()) {
            boolean status = oldFile.delete();
            getLogger().debug("Deleted existing template: " + oldFile + ", deleted=" + status);
            sleep();
        }

        // Write template data to the shared file system
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(filename);

            TemplateVersionDataDao templateVersionDataDao = DaoFactory.getTemplateVersionDataDao();
            TemplateVersionData templateVersionData = templateVersionDataDao.getDataForTemplateVersion(templateVersion);
            if (templateVersionData == null || templateVersionData.getFileData() == null) {
                eventLogService.logErrorEvent("Could not publish template version " + templateVersion.getId() + ". The template version data is not set.");
            }

            byte[] data = templateVersionData.getFileData();
            IOUtils.write(data, fos);

            getLogger().debug("Synched template file: " + filename);

        } catch (IOException ioe) {
            String message = "Could not write template data file: " + filename;
            getLogger().error(message, ioe);

        } finally {
            IOUtils.closeQuietly(fos);
        }
    }

    private void writeFile(String filename, byte[] fileData) {

        // Ensure template version directory exists
        File publishDirectory = new File(filename).getParentFile();
        if (!publishDirectory.exists()) {
            if (!publishDirectory.mkdirs()) {
                String message = "SyncTemplateFilesJob could not create directory: " + publishDirectory;
                eventLogService.logErrorEvent(message);
                getLogger().error(message);
                return;
            }
        }

        // Delete any existing file
        File oldFile = new File(filename);
        if (oldFile.isFile()) {
            boolean status = oldFile.delete();
            getLogger().debug("Deleted existing file: " + oldFile + ", deleted=" + status);
            // Sleep for 1 second to allow file system to complete the delete
            sleep();
        }

        // Write template data to the shared file system
        FileOutputStream fos = null;
        try {
            // Ensure parent directory exits.
            File fgFile = new File(filename);
            String dirPath = fgFile.getParent();
            File fgDir = new File(dirPath);
            if (!fgDir.exists()) {
                fgDir.mkdirs();
                sleep();
            }

            fos = new FileOutputStream(filename);
            IOUtils.write(fileData, fos);

            getLogger().debug("Synched template file: " + filename);

        } catch (IOException ioe) {
            String message = "Could not write template data file: " + filename;
            getLogger().error(message, ioe);

        } finally {
            IOUtils.closeQuietly(fos);
        }
    }


    private byte[] getEntryByteArray(ZipEntry entry, ZipInputStream zis) throws IOException {

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        byte[] buffer = new byte[1024];
        while (true) {
            int read = zis.read(buffer);
            if (read == -1 ) {
                break;
            }
            out.write(buffer, 0, read);
        }

        return out.toByteArray();
    }

    private void sleep() {
        try {
            Thread.sleep(250);
        } catch (InterruptedException ie) {
            // Do nothing
        }
    }

    private void setTemplateVersionFileSizes() {
        TemplateVersionDao templateVersionDao = DaoFactory.getTemplateVersionDao();
        TemplateVersionDataDao templateVersionDataDao = DaoFactory.getTemplateVersionDataDao();
        List<TemplateVersion> templateVersions = templateVersionDao.getTemplateVersionsWithNullFileSize();

        for (int i = 0; i < templateVersions.size(); i++) {
            TemplateVersion templateVersion = templateVersions.get(i);
            TemplateVersionData templateVersionData = templateVersionDataDao.getDataForTemplateVersion(templateVersion);
            if (templateVersionData == null || templateVersionData.getFileData() == null) {
                eventLogService.logErrorEvent("Template version data not found for template version " + templateVersion.getId());
                continue;
            }

            if (TemplateVersion.FORM_TYPE_FORM_GUIDE.equals(templateVersion.getFormType())) {
                // for form guides, we use the size of the xdp file
                Long xdpSize = FormUtils.getFormGuideFilesize(templateVersionData.getFileData());
                if (xdpSize == null) {
                    eventLogService.logErrorEvent("Formguide for template version " + templateVersion.getId() + " does not contain an xdp file.");
                }
                else {
                    templateVersion.setFileSize(xdpSize);
                }
            }
            else {
                // use the template version data size
                templateVersion.setFileSize(new Long(templateVersionData.getFileData().length));
            }
            commitChanges();
            getDataContext().getObjectStore().getDataRowCache().clear();
        }
    }
}

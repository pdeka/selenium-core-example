package com.avoka.fc.core.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.w3c.dom.Element;

import com.avoka.core.util.FileUtils;
import com.avoka.core.util.ServletUtils;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.RenderReceiptService;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.FormUtils;

public class DiisrRenderReceiptService extends DiisrRenderService implements RenderReceiptService {

    // Public Methods --------------------------------------------------------

    public void renderReceipt(
            final TemplateVersion templateVersion,
            final Form form,
            final String xmlData,
            final HttpServletRequest request,
            final HttpServletResponse response,
            final RequestLog requestLog) throws ApplicationException {

        // Perform the remote render
        remoteRender(templateVersion, getRootXmlData(xmlData), requestLog, new DiisrResponseHandler() {

            public void handleResponse(String remoteContentType, byte[] remoteByteArray) throws IOException {

                long clientResponseStart = System.currentTimeMillis();

                // If a HTML response an error has occurred. Otherwise set set the given headers.
                if ("text/html".equals(remoteContentType)) {
                    response.setContentType(remoteContentType);
                    response.setHeader("Content-Length", String.valueOf(remoteByteArray.length));

                    EventLogService eventLogService = new EventLogService();
                    eventLogService.logErrorEvent("Error rendering TemplateVersion OID " + templateVersion.getId());

                } else {
                    response.setHeader("Content-Length", String.valueOf(remoteByteArray.length));

                    // Setup response headers
                    response.setContentType("application/pdf");

                    // TODO: MAE 24/4/08 - "attachment;filename" performing very poorly on Firefox
                    String filename = FileUtils.changeFileExtension(templateVersion.getFileName(), "pdf");
                    response.setHeader("Content-Disposition", "inline;filename=" + filename);

                    ServletUtils.setNoCacheHeaders(request, response);
                }

                int duration = (int) (System.currentTimeMillis() - clientResponseStart);
                requestLog.setDurationClientResponse(new Integer(duration));

                // Write the form to the browser
                ServletUtils.renderByteArray(request, response, remoteByteArray);

                // Log duration of render to client response
                duration = (int) (System.currentTimeMillis() - clientResponseStart);
                requestLog.setDurationClientResponse(new Integer(duration));
            }
        });

    }

    public byte[] renderReceipt(TemplateVersion templateVersion, Form form, String xmlData)
            throws ApplicationException {

        final List bytesHolder = new ArrayList();

        // Perform the remote render
        remoteRender(templateVersion, getRootXmlData(xmlData), null, new DiisrResponseHandler() {

            public void handleResponse(String remoteContentType, byte[] remoteByteArray) throws IOException {
                bytesHolder.add(remoteByteArray);
            }
        });

        return (byte[]) bytesHolder.get(0);
    }

    // Protected Methods --------------------------------------------------------

    /**
     * @see DiisrRenderService#getTargetServlet()
     */
    protected String getTargetServlet() {
        return "servlet/RenderReceiptServlet";
    }

    /**
     * Ensure xmlData does not contain <xfa:datasets> elements.
     */
    private String getRootXmlData(String xmlData) {

        // MAE - note this is largely redundant now as the data should xfa clean at this point but we still
        // perform this check to support existing saved records
        if (xmlData.contains("<xfa:datasets")) {
            org.w3c.dom.Document document = XmlUtils.parseDocumentFromString(xmlData);
            Element dataElement = FormUtils.getRootDataElement(document);
            xmlData = XmlUtils.toString(dataElement);
        }

        return xmlData;
    }

}

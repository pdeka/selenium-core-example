/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service.impl;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.PaymentLogDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.PaymentLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.CardPaymentService;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ReceiptDataService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.SubmissionStatusService;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.PaymentResponseException;
import com.avoka.fc.core.util.TNSQueryDR;

public class TNSCardPaymentService extends CayenneService implements CardPaymentService {

    // Constants
    public static final String PARAM_PAYMENT_URL = "paymentUrl";
    public static final String PARAM_QUERY_URL = "queryUrl";
    public static final String PARAM_TIMEOUT = "timeout";

    public static final String PAYMENT_SERVICE_CODE_TNS = "TNS";

    static final String TEST_PAYMENT_AMOUNT = "TEST_PAYMENT_AMOUNT";

    // Request Parameter Names
    static final String VPC_ACCESS_CODE            = "vpc_AccessCode";
    static final String VPC_AMOUNT                 = "vpc_Amount";
    static final String VPC_COMMAND                = "vpc_Command";
    static final String VPC_MERCHANT            = "vpc_Merchant";
    static final String VPC_MERCH_TXN_REF         = "vpc_MerchTxnRef";
    static final String VPC_ORDER_INFO            = "vpc_OrderInfo";
    static final String VPC_VERSION                = "vpc_Version";

    static final String VPC_CARD_SECURITY_CODE     = "vpc_CardSecurityCode";
    static final String VPC_CARD_NUM             = "vpc_CardNum";
    static final String VPC_CARD_EXP             = "vpc_CardExp";

    static final String VPC_ACQ_RESPONSE_CODE    = "vpc_AcqResponseCode";
    static final String VPC_AUTHORIZED_ID        = "vpc_AuthorizeId";
    static final String VPC_BATCH_NO             = "vpc_BatchNo";
    static final String VPC_CARD                = "vpc_Card";
    static final String VPC_MESSAGE                = "vpc_Message";
    static final String VPC_RECEIPT_NO            = "vpc_ReceiptNo";
    static final String VPC_TAX_AMOUNT            = "vpc_TaxAmount";
    static final String VPC_TRANSACTION_NO        = "vpc_TransactionNo";
    static final String VPC_TXN_RESPONSE_CODE    = "vpc_TxnResponseCode";

    static final String VPC_USER                = "vpc_User";
    static final String VPC_PASSWORD            = "vpc_Password";

    static final String VPC_DR_EXISTS           = "vpc_DRExists";
    static final String VPC_FOUND_MULTIPLE_DRS  = "vpc_FoundMultipleDRs";

    static final String VPC_COMMAND_PAY         = "pay";
    static final String VPC_COMMAND_DRQUERY     = "queryDR";
    static final String VPC_VERSION_VALUE         = "1";
    static final String TXN_RESPONSE_CODE_SUCCESS_VALUE = "0";
    static final String TXN_RESPONSE_CODE_SERVER_ERROR_VALUE = "7";

    static final String    DR_QUERY_NOT_FOUND_MSG  = "Not Found by DR Query";

    // ----------------------------------------------------- Instance Variables

    private String paymentUrl;
    private String queryUrl;
    private String timeout;

    // --------------------------------------------------------- Public Methods

    /**
     * @see CardPaymentService#performPayment(Submission, String, String, String)
     */
    public PaymentLog performPayment(Submission submission, String cardNumber, String cardExpiryDate, String cardCsc, String ipAddress) {

        Validate.notNull(submission, "Null submission parameter");
        Validate.notNull(cardNumber, "Null cardNumber parameter");
        Validate.notNull(cardExpiryDate, "Null cardExpiryDate parameter");
        Validate.notNull(cardCsc, "Null cardCsc parameter");

        // If completed return first successful payment
        if (submission.isPaymentCompleted()) {
            List payments = submission.getPayments();
            for (Iterator i = payments.iterator(); i.hasNext();) {
                PaymentLog paymentLog = (PaymentLog) i.next();
                if (paymentLog.isPaymentCompleted()) {
                    return paymentLog;
                }
            }
            return (PaymentLog) payments.get(payments.size() - 1);
        }

        Client client = submission.getClient();

        // Client details
        String vpc_AccessCode = client.getPaymentAccessCode();
        String vpc_MerchantId = client.getPaymentMerchantId();

        // Get payment amount and convert to cents
        Integer vpc_Amount = getPaymentTotal(submission);

        // Test payment amount for testing system response to TNS errors
        DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
        if (deploymentPropertyDao.hasProperty(TEST_PAYMENT_AMOUNT)) {
            String paymentAmount = deploymentPropertyDao.getPropertyValue(TEST_PAYMENT_AMOUNT);
            if (StringUtils.isNotBlank(paymentAmount)) {
                vpc_Amount = new Integer(paymentAmount);
                getLogger().debug(TEST_PAYMENT_AMOUNT + ": " + vpc_Amount);
            }
        }

        // Create payment log record and complete DO fields
        PaymentLog paymentLog = (PaymentLog) createAndRegisterNewObject(PaymentLog.class);
        paymentLog.setDoTimestamp(new Date());
        paymentLog.setSubmission(submission);
        paymentLog.setPaymentServiceCode(PAYMENT_SERVICE_CODE_TNS);

        paymentLog.setDoAmount(vpc_Amount);
        paymentLog.setDoMerchant(vpc_MerchantId);
        paymentLog.setDoVersion(VPC_VERSION_VALUE);

        DeploymentPropertyDao dpDao = DaoFactory.getDeploymentPropertyDao();
        if (dpDao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_IP_Address_Logging)) {
            paymentLog.setUserIpAddress(ipAddress);
        }

        commitChanges();

        // Set merchant transaction reference to payment log id
        String vpc_MerchTxnRef = paymentLog.getId().toString();
        paymentLog.setDoMerchTxnRef(vpc_MerchTxnRef);

        commitChanges();

        // Order details
        String vpc_OrderInfo = paymentLog.getId().toString();

        // Create request URL
        Map<String, String> params = new HashMap<String, String>();

        params.put(VPC_ACCESS_CODE, vpc_AccessCode);
        params.put(VPC_AMOUNT, (vpc_Amount == null ? null : String.valueOf(vpc_Amount)));
        params.put(VPC_CARD_EXP, cardExpiryDate);
        params.put(VPC_CARD_NUM, cardNumber);

        if (StringUtils.isNotBlank(cardCsc)) {
            params.put(VPC_CARD_SECURITY_CODE, cardCsc);
        }

        params.put(VPC_COMMAND, VPC_COMMAND_PAY);
        params.put(VPC_MERCHANT, vpc_MerchantId);
        params.put(VPC_MERCH_TXN_REF, vpc_MerchTxnRef);
        params.put(VPC_ORDER_INFO, vpc_OrderInfo);
        params.put(VPC_VERSION, VPC_VERSION_VALUE);

        String requestURL = getPaymentUrl();

        TNSQueryDR queryDRConnector = new TNSQueryDR();

        try {
            Map responseMap = queryDRConnector.executeRequest(requestURL, params);

            return processPaymentReceipt(paymentLog, responseMap);

        } catch (IOException ioe) {
            // Log warning, and query the payment
            String msg = "First attempt at making card payment failed. Error: " + ioe.toString() + ", at " + requestURL;
            EventLogService eventLogService = ServiceFactory.getEventLogService();
            eventLogService.logWarnEvent(msg, submission);

            return queryPaymentStatus(queryDRConnector, params, paymentLog);
        }
        catch (PaymentResponseException pre) {
            String msg = "First attempt at making card payment failed. Error: " + pre.getUserMessage() + ", at " + requestURL;
            EventLogService eventLogService = ServiceFactory.getEventLogService();
            eventLogService.logWarnEvent(msg, submission);

            return queryPaymentStatus(queryDRConnector, params, paymentLog);
        }
    }

    /**
     * @see CardPaymentService#performQuery(PaymentLog)
     */
    public Map performQuery(PaymentLog paymentLog) {

        Submission submission = paymentLog.getSubmission();

        Client client = submission.getClient();

        Map errors = new TreeMap();

        String vpc_AccessCode = client.getPaymentAccessCode();
        if (StringUtils.isBlank(vpc_AccessCode)) {
            errors.put(Client.PAYMENT_ACCESS_CODE_PROPERTY, "not defined for " + client.getClientName());
        }

        String vpc_MerchantId = client.getPaymentMerchantId();
        if (StringUtils.isBlank(vpc_MerchantId)) {
            errors.put(Client.PAYMENT_MERCHANT_ID_PROPERTY, "not defined for " + client.getClientName());
        }

        String vpc_User = client.getPaymentMerchantUser();
        if (StringUtils.isBlank(vpc_User)) {
            errors.put(Client.PAYMENT_MERCHANT_USER_PROPERTY, "not defined for " + client.getClientName());
        }

        String vpc_Password = client.getPaymentMerchantPassword();
        if (StringUtils.isBlank(vpc_Password)) {
            errors.put(Client.PAYMENT_MERCHANT_PASSWORD_PROPERTY, "not defined for " + client.getClientName());
        }

        if (!errors.isEmpty()) {
            return errors;
        }

        String curQueryUrl = getQueryUrl();

        Map<String, String> requestFields = new TreeMap<String, String>();

        requestFields.put(VPC_VERSION, VPC_VERSION_VALUE);
        requestFields.put(VPC_COMMAND, VPC_COMMAND_DRQUERY);
        requestFields.put(VPC_ACCESS_CODE, vpc_AccessCode);
        requestFields.put(VPC_MERCHANT, vpc_MerchantId);
        requestFields.put(VPC_MERCH_TXN_REF, paymentLog.getDoMerchTxnRef());
        requestFields.put(VPC_USER, vpc_User);
        requestFields.put(VPC_PASSWORD, vpc_Password);

        TNSQueryDR queryDRConnector = new TNSQueryDR();

        try {
            return queryDRConnector.executeQueryDR(curQueryUrl, requestFields);

        } catch (IOException ioe) {
            String msg = "Error occured executing Query DR: " + ioe;
            throw new ApplicationException("QueryDR Error", ioe, msg, msg, null);
        }
    }

    /**
     * @see CardPaymentService#resolveOutstandingPayments()
     */
    public void resolveOutstandingPayments() {

        TNSQueryDR queryDRConnector = new TNSQueryDR();

        String curTimeoutString = getTimeout();
        int curTimeout = -1;
        try {
            curTimeout = Integer.parseInt(curTimeoutString);
        }
        catch (NumberFormatException nfe) {
            throw new ApplicationException("InvalidServiceParameter", "Error when attempting to resolve outstanding payments", "The service parameter " + PARAM_TIMEOUT + " is not set to a positive integer value", "Please configure the payment service.");
        }
        PaymentLogDao paymentLogDao = DaoFactory.getPaymentLogDao();
        List<PaymentLog> outstandingPayments = paymentLogDao.getOutstandingTransactions(curTimeout, PAYMENT_SERVICE_CODE_TNS);

        for (Iterator i = outstandingPayments.iterator(); i.hasNext();) {
            final PaymentLog paymentLog = (PaymentLog) i.next();

            Submission submission = paymentLog.getSubmission();

            // Determine whether payment has already been completed
            boolean paymentNotCompleted = true;

            // Check whether a payment has been successfully made
            for (Iterator j = submission.getPayments().iterator(); j.hasNext();) {
                PaymentLog subPaymentLog = (PaymentLog) j.next();
                if (PaymentLog.STATUS_Completed.equals(subPaymentLog.getPaymentStatus())) {
                    paymentNotCompleted = false;
                }
            }

            // Load client query login details
            Client client = submission.getClient();

            String vpc_AccessCode = client.getPaymentAccessCode();
            if (StringUtils.isBlank(vpc_AccessCode)) {
                String msg = "Error resolving outstanding payment form Submssion " + submission.getId()
                    + ". " + Client.PAYMENT_ACCESS_CODE_PROPERTY + " not defined for " + client.getClientName();
                EventLogService eventLogService = ServiceFactory.getEventLogService();
                eventLogService.logErrorEvent(msg);
                continue;
            }

            String vpc_MerchantId = client.getPaymentMerchantId();
            if (StringUtils.isBlank(vpc_MerchantId)) {
                String msg = "Error resolving outstanding payment form Submssion " + submission.getId()
                    + ". " + Client.PAYMENT_MERCHANT_ID_PROPERTY + " not defined for " + client.getClientName();
                EventLogService eventLogService = ServiceFactory.getEventLogService();
                eventLogService.logErrorEvent(msg);
                continue;
            }

            String vpc_User = client.getPaymentMerchantUser();
            if (StringUtils.isBlank(vpc_User)) {
                String msg = "Error resolving outstanding payment form Submssion " + submission.getId()
                    + ". " + Client.PAYMENT_MERCHANT_USER_PROPERTY + " not defined for " + client.getClientName();
                EventLogService eventLogService = ServiceFactory.getEventLogService();
                eventLogService.logErrorEvent(msg);
                continue;
            }

            String vpc_Password = client.getPaymentMerchantPassword();
            if (StringUtils.isBlank(vpc_Password)) {
                String msg = "Error resolving outstanding payment form Submssion " + submission.getId()
                    + ". " + Client.PAYMENT_MERCHANT_PASSWORD_PROPERTY + " not defined for " + client.getClientName();
                EventLogService eventLogService = ServiceFactory.getEventLogService();
                eventLogService.logErrorEvent(msg);
                continue;
            }

            String curQueryUrl = getQueryUrl();

            Map<String, String> requestFields = new TreeMap<String, String>();

            requestFields.put(VPC_VERSION, VPC_VERSION_VALUE);
            requestFields.put(VPC_COMMAND, VPC_COMMAND_DRQUERY);
            requestFields.put(VPC_ACCESS_CODE, vpc_AccessCode);
            requestFields.put(VPC_MERCHANT, vpc_MerchantId);
            requestFields.put(VPC_MERCH_TXN_REF, paymentLog.getDoMerchTxnRef());
            requestFields.put(VPC_USER, vpc_User);
            requestFields.put(VPC_PASSWORD, vpc_Password);

            try {
                Map responseFields = queryDRConnector.executeQueryDR(curQueryUrl, requestFields);

                if (getLogger().isDebugEnabled()) {
                    for (Iterator j = responseFields.keySet().iterator(); j.hasNext();) {
                        String name = j.next().toString();
                        String value = (String) responseFields.get(name);
                        getLogger().debug(name + "=" + value);
                    }
                }

                String drExits = (String) responseFields.get(VPC_DR_EXISTS);
                if ("Y".equalsIgnoreCase(drExits)) {

                    final String drFoundMultipleDrs = (String) responseFields.get(VPC_FOUND_MULTIPLE_DRS);
                    if ("Y".equalsIgnoreCase(drFoundMultipleDrs)) {
                        String eventMsg = "Found multiple QueryDR search results for (PaymentLog OID / "
                            + VPC_MERCH_TXN_REF + "):" + paymentLog.getDoMerchTxnRef();
                        EventLogService eventLogService = ServiceFactory.getEventLogService();
                        eventLogService.logWarnEvent(eventMsg);
                    }

                    final String drTxnResponseCode = (String) responseFields.get(VPC_TXN_RESPONSE_CODE);
                    final String drTxnResponseMsg = queryDRConnector.getTxnResponseDescription(drTxnResponseCode);

                    // If not response code then assume no transaction record was found
                    if (StringUtils.isBlank(drTxnResponseCode)) {
                        paymentLog.setPaymentStatus(PaymentLog.STATUS_Error);
                        paymentLog.setDrMessage(DR_QUERY_NOT_FOUND_MSG);

                        if (paymentNotCompleted) {
                            submission.setPaymentStatus(Submission.STATUS_Error);

                            SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                            submissionStatusService.updateStatus(submission);
                        }

                    // If an server error occured then, log an error event. Note
                    // we dont throw an exception here as other clients may have the correct
                    // AMA user accounts.
                    } else if (TXN_RESPONSE_CODE_SERVER_ERROR_VALUE.equals(drTxnResponseCode)) {
                        paymentLog.setDrTxnResponseCode(drTxnResponseCode);
                        paymentLog.setPaymentStatus(PaymentLog.STATUS_Error);
                        paymentLog.setDrMessage("System error occured");
                        paymentLog.setDrTxnResponseMsg(drTxnResponseMsg);

                        if (paymentNotCompleted) {
                            paymentLog.getSubmission().setPaymentStatus(Submission.STATUS_Error);

                            SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                            submissionStatusService.updateStatus(paymentLog.getSubmission());
                        }

                        String eventMsg =
                            "Credit Card Payment outstanding orders query failed. QueryDR response: "
                            + drTxnResponseMsg + ". Please check AMA privileges for TNS user: "
                            + vpc_User;
                        EventLogService eventLogService = ServiceFactory.getEventLogService();
                        eventLogService.logErrorEvent(eventMsg);

                    // Else process DR details
                    } else {

                        paymentLog.setDrTimestamp(new Date());
                        paymentLog.setDrAcqResponseCode(getQueryDrResponseValue(VPC_ACQ_RESPONSE_CODE, responseFields));
                        paymentLog.setDrAmount(getInteger(responseFields, VPC_AMOUNT));
                        paymentLog.setDrBatchNo(getInteger(responseFields, VPC_BATCH_NO));
                        paymentLog.setDrMerchTxnRef(getQueryDrResponseValue(VPC_MERCH_TXN_REF, responseFields));
                        paymentLog.setDrMessage(getQueryDrResponseValue(VPC_MESSAGE, responseFields));
                        paymentLog.setDrReceiptNo(getQueryDrResponseValue(VPC_RECEIPT_NO, responseFields));
                        paymentLog.setDrTransactionNo(getLong(responseFields, VPC_TRANSACTION_NO));
                        paymentLog.setDrTxnResponseCode(drTxnResponseCode);
                        paymentLog.setDrTxnResponseMsg(drTxnResponseMsg);

                        if ("0".equals(drTxnResponseCode) && paymentLog.getDrReceiptNo() != null) {
                            ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
                            receiptDataService.setPaymentReceiptDetails(submission, paymentLog.getDrReceiptNo(), paymentLog.getDrTimestamp());

                        } else {
                            paymentLog.setPaymentStatus(PaymentLog.STATUS_Error);

                            if (paymentNotCompleted) {
                                submission.setPaymentStatus(Submission.STATUS_Error);

                                SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                                submissionStatusService.updateStatus(submission);
                            }
                        }
                    }

                // Else transaction not found
                } else {
                    paymentLog.setPaymentStatus(PaymentLog.STATUS_Error);
                    paymentLog.setDrMessage(DR_QUERY_NOT_FOUND_MSG);

                    if (paymentNotCompleted) {
                        submission.setPaymentStatus(Submission.STATUS_Error);

                        SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                        submissionStatusService.updateStatus(submission);
                    }
                }

                paymentLog.setDrTimestamp(new Date());
                commitChanges();

                if (getLogger().isDebugEnabled()) {
                    String msg = "Payment processed, PaymentLog : " + paymentLog;
                    getLogger().debug(msg);
                }

            } catch (IOException ioe) {
                ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
                errorLogService.logException(ioe);
            }
        }
    }

    public String getPaymentUrl() {
        return paymentUrl;
    }

    public void setPaymentUrl(String newPaymentUrl) {
        paymentUrl = newPaymentUrl;
    }

    public String getQueryUrl() {
        return queryUrl;
    }

    public void setQueryUrl(String newQueryUrl) {
        queryUrl = newQueryUrl;
    }

    public String getTimeout() {
        return timeout;
    }

    public void setTimeout(String newTimeout) {
        timeout = newTimeout;
    }

    // ----------------------------------------------- Package Private Methods

    /**
     * Process the TNS VPC payment receipt parameters and return the
     * Submission object of the payment
     *
     * @param paymentLog the Payment Log record
     * @param params the VPC Digital Receipt (DR) payment receipt parameters
     */
    PaymentLog processPaymentReceipt(PaymentLog paymentLog, Map params) {
        Validate.notNull(paymentLog, "Null paymentLog parameter");
        Validate.notNull(params, "Null params parameter");

        paymentLog.setDrTimestamp(new Date());
        paymentLog.setDrAcqResponseCode(getString(params, VPC_ACQ_RESPONSE_CODE));
        paymentLog.setDrAmount(getInteger(params, VPC_AMOUNT));
        paymentLog.setDrBatchNo(getInteger(params, VPC_BATCH_NO));
        paymentLog.setDrMerchTxnRef(getString(params, VPC_MERCH_TXN_REF));
        paymentLog.setDrMessage(getString(params, VPC_MESSAGE));
        paymentLog.setDrReceiptNo(getString(params, VPC_RECEIPT_NO));
        paymentLog.setDrTaxAmount(getInteger(params, VPC_TAX_AMOUNT));
        paymentLog.setDrTransactionNo(getLong(params, VPC_TRANSACTION_NO));
        paymentLog.setDrTxnResponseCode(getString(params, VPC_TXN_RESPONSE_CODE));

        updateFormReceiptInfo(paymentLog);

        commitChanges();

        return paymentLog;
    }

    void updateFormReceiptInfo(PaymentLog paymentLog) {
        Submission submission = paymentLog.getSubmission();

        if (TXN_RESPONSE_CODE_SUCCESS_VALUE.equals(paymentLog.getDrTxnResponseCode())) {
            paymentLog.setDrTxnResponseMsg("Transaction approved");

            if (paymentLog.getDrReceiptNo() != null) {
                ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
                receiptDataService.setPaymentReceiptDetails(submission, paymentLog.getDrReceiptNo(), paymentLog.getDrTimestamp());
            }

            submission.setPaymentStatus(Submission.STATUS_Completed);
            paymentLog.setPaymentStatus(PaymentLog.STATUS_Completed);

        } else {
            String responseCode = paymentLog.getDrTxnResponseCode();
            paymentLog.setPaymentStatus(PaymentLog.STATUS_Error);
            submission.setPaymentStatus(Submission.STATUS_Error);

            if ("1".equals(responseCode)) {
                paymentLog.setDrTxnResponseMsg("Transaction could not be approved");

            } else if ("2".equals(responseCode)) {
                paymentLog.setDrTxnResponseMsg("Transaction declined - contact issuing bank");

            } else if ("2".equals(responseCode)) {
                paymentLog.setDrTxnResponseMsg("Transaction declined - contact issuing bank");

            } else if ("3".equals(responseCode)) {
                paymentLog.setDrTxnResponseMsg("No reply from processing host");

            } else if ("4".equals(responseCode)) {
                paymentLog.setDrTxnResponseMsg("Card has expired");

            } else if ("5".equals(responseCode)) {
                paymentLog.setDrTxnResponseMsg("Insufficient credit");

            } else if ("E".equals(responseCode)) {
                paymentLog.setDrTxnResponseMsg("Transaction declined - contact issuing bank");

            } else {
                paymentLog.setDrTxnResponseMsg("Unknown response code: " + responseCode);
            }
        }

        SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
        submissionStatusService.updateStatus(submission);
    }

    String getString(Map params, String key) {
        Object value = params.get(key);
        if (value != null) {
            return value.toString();

        } else {
            return null;
        }
    }

    Integer getInteger(Map params, String key) {
        Object value = params.get(key);
        if (value != null) {
            return Integer.valueOf(value.toString());

        } else {
            return null;
        }
    }

    Long getLong(Map params, String key) {
        Object value = params.get(key);
        if (value != null) {
            return Long.valueOf(value.toString());

        } else {
            return null;
        }
    }

    Integer getPaymentTotal(Submission submission) {
        try {
            Double paymentDouble = submission.getPaymentTotal();

            int paymentCents = (int) Math.round(paymentDouble.doubleValue() * 100);

            return new Integer(paymentCents);

        } catch (Exception e) {
            String msg = "Unexpected error occured determing payment amount";
            throw new ApplicationException("CardPaymentService", e, msg + ": " + e.getMessage(), msg, null);
        }
    }

    /**
     * This method takes a data String and returns a predefined value if empty If data Sting is
     * null, returns string "No Value Returned", else returns input
     *
     * @param name String containing the data String @return String containing the output String
     */
    String getQueryDrResponseValue(String name, Map responseFields) {
        if (responseFields.containsKey(name)) {
            return (String) responseFields.get(name);

        } else {
            return "No Value Returned";
        }
    }

    private PaymentLog queryPaymentStatus(TNSQueryDR queryDRConnector, Map<String, String> requestParameters, PaymentLog paymentLog) {
        Map<String, String> queryParams = getQueryParametersForPayment(requestParameters, paymentLog);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            // ignore
        }

        try {
            Map responseMap = queryDRConnector.executeQueryDR(getQueryUrl(), queryParams);

            return processPaymentReceipt(paymentLog, responseMap);

        } catch (IOException ioe) {
            String msg = "Error while querying payment. Message: " + ioe.toString() + ", at " + getQueryUrl();
            throw new PaymentResponseException("CardPaymentService", ioe, msg, msg, null);
        }
    }

    private Map<String, String> getQueryParametersForPayment(Map<String, String> paymentParameters, PaymentLog paymentLog) {
        Map<String, String> queryParameters = new HashMap<String, String>();
        queryParameters.put(VPC_VERSION, VPC_VERSION_VALUE);
        queryParameters.put(VPC_COMMAND, VPC_COMMAND_DRQUERY);
        queryParameters.put(VPC_ACCESS_CODE, paymentParameters.get(VPC_ACCESS_CODE));
        queryParameters.put(VPC_MERCHANT, paymentParameters.get(VPC_MERCHANT));
        queryParameters.put(VPC_MERCH_TXN_REF, paymentLog.getDoMerchTxnRef());

        Submission submission = paymentLog.getSubmission();
        Client client = submission.getClient();
        String vpc_User = client.getPaymentMerchantUser();
        if (StringUtils.isBlank(vpc_User)) {
            throw new ApplicationException("InvalidPaymentConfiguration", "Error when querying payment", "The payment configuration is incomplete.", "Please contact an administrator.");
        }

        String vpc_Password = client.getPaymentMerchantPassword();
        if (StringUtils.isBlank(vpc_Password)) {
            throw new ApplicationException("InvalidPaymentConfiguration", "Error when querying payment", "The payment configuration is incomplete.", "Please contact an administrator.");
        }

        queryParameters.put(VPC_USER, vpc_User);
        queryParameters.put(VPC_PASSWORD, vpc_Password);

        return queryParameters;
    }
 }

package com.avoka.fc.core.service.impl;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.ServletUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.RenderFormService;
import com.avoka.fc.core.util.ApplicationException;

public class DiisrRenderFormService extends DiisrRenderService implements RenderFormService {

    /** The form xml seed data request parameter. */
    public static final String PARAM_READER_EXTEND = "readerExtend";

    /** The target submission URL to be rendered in the form, e.g. /servlet/SubmissionServlet */
    public static final String PARAM_SUBMIT_URL = "submitURL";

    /** The target submission web root to be rendered in the form, e.g. http://localhost:8080/test/ */
    public static final String PARAM_SUBMIT_WEB_ROOT = "submitWebRoot";

    // Public Methods ---------------------------------------------------------

    /**
     * @see RenderFormService#renderForm(TemplateVersion, Form, String, HttpServletRequest, HttpServletResponse, String, RequestLog)
     */
    public void renderForm(
            final TemplateVersion templateVersion,
            final Form form,
            final String xmlData,
            final HttpServletRequest request,
            final HttpServletResponse response,
            final String targetUrl,
            final RequestLog requestLog) throws ApplicationException {

        assert(form.getPortal() != null);

        // Determine whether form should be reader extended
        String readerExtended = Boolean.FALSE.toString();;
        if (templateVersion.getReaderExtendFlag() != null && templateVersion.getReaderExtendFlag().booleanValue()) {
            readerExtended = Boolean.TRUE.toString();
        }
        getRequestParams().put(PARAM_READER_EXTEND, readerExtended);

        getRequestParams().put(PARAM_SUBMIT_URL, targetUrl);

        String contextPath = form.getPortal().getContextPath();
        if (contextPath.endsWith("/")) {
            contextPath = contextPath.substring(0, contextPath.length()-1);
        }

        getRequestParams().put(PARAM_SUBMIT_WEB_ROOT, contextPath);

        // Perform the remote render
        remoteRender(templateVersion,
                     xmlData,
                     requestLog,
                     new DiisrResponseHandler() {

            public void handleResponse(String remoteContentType, byte[] remoteByteArray) throws IOException {

                long clientResponseStart = System.currentTimeMillis();

                // If a HTML response an error has occurred. Otherwise set set the given headers.
                if ("text/html".equals(remoteContentType)) {
                    response.setContentType(remoteContentType);
                    response.setHeader("Content-Length", String.valueOf(remoteByteArray.length));

                    EventLogService eventLogService = new EventLogService();
                    eventLogService.logErrorEvent("Error rendering TemplateVersion OID " + templateVersion.getId());

                } else {
                    response.setContentType("application/pdf");
                    boolean saveAsAttachment = false;
                    String renderModeParam = request.getParameter(Constants.PARAM_RenderMode);
                    if (StringUtils.isNotBlank(renderModeParam) && Constants.PARAM_RenderMode_File.equals(renderModeParam)) {
                        saveAsAttachment = true;
                    }

                    ServletUtils.setContentDisposition
                        (request, response, "application/pdf", templateVersion.getFileName(), saveAsAttachment);

                    ServletUtils.setNoCacheHeaders(request, response);
                }

                int duration = (int) (System.currentTimeMillis() - clientResponseStart);
                requestLog.setDurationClientResponse(new Integer(duration));

                // Write the form to the browser
                ServletUtils.renderByteArray(request, response, remoteByteArray);

                // Log duration of render to client response
                duration = (int) (System.currentTimeMillis() - clientResponseStart);
                requestLog.setDurationClientResponse(new Integer(duration));
            }
        });
    }

    // Protected Methods --------------------------------------------------------

    /**
     * @see DiisrRenderService#getTargetServlet()
     */
    protected String getTargetServlet() {
        return "servlet/RenderFormServlet";
    }

}

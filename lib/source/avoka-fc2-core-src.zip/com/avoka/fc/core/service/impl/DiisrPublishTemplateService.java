package com.avoka.fc.core.service.impl;

import java.io.InputStream;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.ByteArrayPartSource;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.PublishTemplateService;
import com.avoka.fc.core.service.ServiceDefinitionAware;
import com.avoka.fc.core.util.ApplicationException;

public class DiisrPublishTemplateService extends CayenneService implements ServiceDefinitionAware, PublishTemplateService {

    /** The security hash to access this service. */
    public static final String PARAM_SECURITY_HASH = "securityHash";

    /** The form file data request parameter. */
    public static final String PARAM_FORM_DATA = "formData";

    /** The form name request parameter. */
    public static final String PARAM_FORM_NAME = "formName";

    /** The form deployment folder path request parameter. */
    public static final String PARAM_FORM_PATH = "formPath";

    // Variables --------------------------------------------------------------

    /** The service definition. */
    private ServiceDefinition  serviceDefinition;

    private EventLogService eventLogService = new EventLogService();

    // Public Methods ---------------------------------------------------------

    /**
     * @see ServiceDefinitionAware#setServiceDefinition(ServiceDefinition)
     */
    public void setServiceDefinition(ServiceDefinition serviceDefinition){
        this.serviceDefinition = serviceDefinition;
    }

    /**
     * @see ServiceDefinitionAware#getServiceDefinition()
     */
    public ServiceDefinition getServiceDefinition(){
        return serviceDefinition;
    }

    /**
     * @see PublishTemplateService#publishTemplate(TemplateVersion)
     */
    public void publishTemplate(TemplateVersion templateVersion) {

        Validate.notNull(templateVersion, "Null templateVersion paraemter");

        if (templateVersion.getFileName() == null || templateVersion.getTemplateVersionData() == null) {
            return;
        }

        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String basePath = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Render_Service_Base_Path);
        if (StringUtils.isBlank(basePath)) {
            String context = DeploymentProperty.PROPERTY_Render_Service_Base_Path + " is not defined";
            String userMessage = "Remote Render Service Base Path has not been configured";
            String solution = "Configure the DeploymentProperty: " + DeploymentProperty.PROPERTY_Render_Service_Base_Path;
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        ServiceConnection serviceConnection = getServiceDefinition().getConnection();
        if (serviceConnection == null) {
            String context = "ServiceDefinition.ServiceName=" + getServiceDefinition().getServiceName();
            String userMessage = "ServiceConnection has not been configured for ServiceDefinition";
            String solution = "Configure the ServiceConnection for the ServiceDefinition";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        String password = serviceConnection.getPassword();
        if (StringUtils.isBlank(password)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection password is blank";
            String solution = "Configure the ServiceConnection Password";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        // Get the target server URL
        String requestTarget = serviceConnection.getEndpointValue();
        if (StringUtils.isBlank(requestTarget)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection EndPointValue has not been configured";
            String solution = "Configure the ServiceConnection EndPointValue";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }
        if (requestTarget.endsWith("/")) {
            requestTarget += "servlet/AddFormServlet";
        } else {
            requestTarget += "/servlet/AddFormServlet";
        }

        // Get the form name
        String formName = templateVersion.getFileName();

        // Get the form path
        String formPath = basePath + '/' + templateVersion.getId();

        ByteArrayPartSource baps =
            new ByteArrayPartSource(formName, templateVersion.getTemplateVersionData().getFileData());

        Part[] parts = {
                new StringPart(PARAM_SECURITY_HASH, password),
                new StringPart(PARAM_SECURITY_HASH, password),
                new StringPart(PARAM_FORM_NAME, formName),
                new StringPart(PARAM_FORM_PATH, formPath),
                new FilePart(PARAM_FORM_DATA, baps)
        };

        PostMethod postMethod = new PostMethod(requestTarget);
        postMethod.setRequestEntity(new MultipartRequestEntity(parts, postMethod.getParams()));
        HttpClient httpClient = new HttpClient();

        InputStream responseStream = null;
        try {
            httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(5000);

            final int status = httpClient.executeMethod(postMethod);

            responseStream = postMethod.getResponseBodyAsStream();

            byte[] byteArray = IOUtils.toByteArray(responseStream);

            final String responseBody = new String(byteArray);

            if (status == HttpStatus.SC_OK) {

                templateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_COMPLETE);
                commitChanges();

                getLogger().info("Published Template Version [" + templateVersion.getId() + "] : " + responseBody);

            } else {
                templateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_ERROR);
                commitChanges();

                String msg = "Unable to published Template Version [" + templateVersion.getId()
                    + "] : " + HttpStatus.getStatusText(status) + " : " + responseBody;

                getLogger().info(msg);
                eventLogService.logWarnEvent(msg);
            }

        } catch (Exception e) {
            ErrorLogService errorLogService = new ErrorLogService();
            errorLogService.logException(e);

            templateVersion.setPublishStatus(TemplateVersion.PUBLISH_STATUS_ERROR);
            commitChanges();

        } finally {
            IOUtils.closeQuietly(responseStream);
            postMethod.releaseConnection();
        }

    }

    public void publishOfflineSubmissionForm(OfflineSubmissionForm offlineSubmissionForm) {

        Validate.notNull(offlineSubmissionForm, "Null templateVersion paraemter");

        if (offlineSubmissionForm.getTemplateFileName() == null || offlineSubmissionForm.getFormTemplate() == null) {
            return;
        }

        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String basePath = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Render_Service_Base_Path);
        if (StringUtils.isBlank(basePath)) {
            String context = DeploymentProperty.PROPERTY_Render_Service_Base_Path + " is not defined";
            String userMessage = "Remote Render Service Base Path has not been configured";
            String solution = "Configure the DeploymentProperty: " + DeploymentProperty.PROPERTY_Render_Service_Base_Path;
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        ServiceConnection serviceConnection = getServiceDefinition().getConnection();
        if (serviceConnection == null) {
            String context = "ServiceDefinition.ServiceName=" + getServiceDefinition().getServiceName();
            String userMessage = "ServiceConnection has not been configured for ServiceDefinition";
            String solution = "Configure the ServiceConnection for the ServiceDefinition";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        String password = serviceConnection.getPassword();
        if (StringUtils.isBlank(password)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection password is blank";
            String solution = "Configure the ServiceConnection Password";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }

        // Get the target server URL
        String requestTarget = serviceConnection.getEndpointValue();
        if (StringUtils.isBlank(requestTarget)) {
            String context = "ServiceConnection.Name=" + serviceConnection.getName();
            String userMessage = "ServiceConnection EndPointValue has not been configured";
            String solution = "Configure the ServiceConnection EndPointValue";
            throw new ApplicationException(getClass().getSimpleName(), context, userMessage, solution);
        }
        if (requestTarget.endsWith("/")) {
            requestTarget += "servlet/AddFormServlet";
        } else {
            requestTarget += "/servlet/AddFormServlet";
        }

        // Get the form name
        String formName = offlineSubmissionForm.getTemplateFileName();

        // Get the form path
        String formPath = basePath + '/' + "osf_" + offlineSubmissionForm.getId();

        ByteArrayPartSource baps =
            new ByteArrayPartSource(formName, offlineSubmissionForm.getFormTemplate());

        Part[] parts = {
                new StringPart(PARAM_SECURITY_HASH, password),
                new StringPart(PARAM_SECURITY_HASH, password),
                new StringPart(PARAM_FORM_NAME, formName),
                new StringPart(PARAM_FORM_PATH, formPath),
                new FilePart(PARAM_FORM_DATA, baps)
        };

        PostMethod postMethod = new PostMethod(requestTarget);
        postMethod.setRequestEntity(new MultipartRequestEntity(parts, postMethod.getParams()));
        HttpClient httpClient = new HttpClient();

        InputStream responseStream = null;
        try {
            httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(5000);

            final int status = httpClient.executeMethod(postMethod);

            responseStream = postMethod.getResponseBodyAsStream();

            byte[] byteArray = IOUtils.toByteArray(responseStream);

            final String responseBody = new String(byteArray);

            if (status == HttpStatus.SC_OK) {

                offlineSubmissionForm.setPublishStatus(TemplateVersion.PUBLISH_STATUS_COMPLETE);
                commitChanges();

                getLogger().info("Published Offline Submission Form [" + offlineSubmissionForm.getId() + "] : " + responseBody);

            } else {
                offlineSubmissionForm.setPublishStatus(TemplateVersion.PUBLISH_STATUS_ERROR);
                commitChanges();

                String msg = "Unable to publish Offline Submission Form [" + offlineSubmissionForm.getId()
                    + "] : " + HttpStatus.getStatusText(status) + " : " + responseBody;

                getLogger().info(msg);
                eventLogService.logWarnEvent(msg);
            }

        } catch (Exception e) {
            ErrorLogService errorLogService = new ErrorLogService();
            errorLogService.logException(e);

            offlineSubmissionForm.setPublishStatus(TemplateVersion.PUBLISH_STATUS_ERROR);
            commitChanges();

        } finally {
            IOUtils.closeQuietly(responseStream);
            postMethod.releaseConnection();
        }
    }
}

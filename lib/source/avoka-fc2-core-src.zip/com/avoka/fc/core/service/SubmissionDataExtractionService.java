/*
 * Copyright (c) 2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import javax.servlet.http.HttpServletRequest;

import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides a service to extract the XML data document from the form submission.
 *
 * @author pcopeland@avoka.com
 */
public interface SubmissionDataExtractionService {

    public static final String CONTENT_TYPE_APPLICATION_PDF     = "application/pdf";
    public static final String CONTENT_TYPE_APPLICATION_XDP_XML = "application/vnd.adobe.xdp+xml";
    public static final String CONTENT_TYPE_APPLICATION_XML     = "application/xml";
    public static final String CONTENT_TYPE_TEXT_XML            = "text/xml";

    public static final String[] CONTENT_TYPES = {
        CONTENT_TYPE_APPLICATION_PDF,
        CONTENT_TYPE_APPLICATION_XDP_XML,
        CONTENT_TYPE_APPLICATION_XML,
        CONTENT_TYPE_TEXT_XML
    };

    /**
     * Return the submission data for the given form submission request.
     *
     * @param request the servlet request
     */
    public SubmissionDataBean extractData(HttpServletRequest request) throws ApplicationException;

}

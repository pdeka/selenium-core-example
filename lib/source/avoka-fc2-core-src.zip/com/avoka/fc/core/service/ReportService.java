
package com.avoka.fc.core.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.ReportDao;
import com.avoka.fc.core.dao.ReportScheduleDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Report;
import com.avoka.fc.core.entity.ReportClient;
import com.avoka.fc.core.entity.ReportLog;
import com.avoka.fc.core.entity.ReportParameter;
import com.avoka.fc.core.entity.ReportSchedule;
import com.avoka.fc.core.util.ApplicationException;

public class ReportService extends CayenneService {

    public static final String REPORTS_DIR = "reports";
    public static final String TEMPLATES_DIR = "templates";
    public static final String OUTPUT_DIR = "output";

    private DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
    private ReportScheduleDao     reportScheduleDao     = new ReportScheduleDao();
    private EmailService          emailService          = new EmailService();

    public String getViewUrl(ReportClient reportClient) {
        Report report = reportClient.getReport();
        Client client = reportClient.getClient();

        return getViewUrl(report, client);
    }

    public String getViewUrl(Report report, Client client) {
        // Report Directory Path
        String directoryPath = deploymentPropertyDao.getConfigSubDirectory(REPORTS_DIR);

        if (!directoryPath.endsWith("/") && !directoryPath.endsWith("\\")) {
            directoryPath += File.separator;
        }

        String reportFileName = directoryPath + TEMPLATES_DIR + File.separator + report.getId() + File.separator + report.getFileName();

        String reportRunUrl = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Report_URL);

        StringBuffer buf = new StringBuffer();
        if (client != null) {
            List parameterList = report.getParameters();
            for (Iterator iter = parameterList.iterator(); iter.hasNext();) {
                ReportParameter param = (ReportParameter) iter.next();
                String name = param.getName();
                if (name.equalsIgnoreCase("client_oid")) {
                    // we append the client code and will later have the servlet substitute in the client oid to make it harder for non-global admins to see data for other clients
                    buf.append("&");
                    buf.append(Client.CLIENT_KEY_PROPERTY);
                    buf.append("=");
                    buf.append(client.getClientKey());
                    buf.append("&");
                    buf.append(name);
                    buf.append("=");
                    buf.append(client.getId());
                }
            }
        }
        return reportRunUrl + "frameset?__report=" + reportFileName + buf.toString();
    }

    public String getExternalExecuteReportUrl(String scheduleId) {
        return getExecuteReportUrl(scheduleId, DeploymentProperty.PROPERTY_Report_URL);
    }

    public String getInternalExecuteReportUrl(String scheduleId) {
        return getExecuteReportUrl(scheduleId, DeploymentProperty.PROPERTY_Report_Internal_URL);
    }

    private String getExecuteReportUrl(String scheduleId, String deploymentProperty) {
        String reportRunUrl = deploymentPropertyDao.getPropertyValue(deploymentProperty);
        StringBuilder buf = new StringBuilder();
        buf.append("execute?");
        buf.append("scheduleId");
        buf.append('=');
        buf.append(scheduleId);
        String url = reportRunUrl + buf.toString();
        getLogger().debug("URL = " + url);
        return url;
    }

    public void startReportExecution(ReportSchedule schedule) {
        schedule.setRunStatus(ReportSchedule.STATUS_Running);
        commitChanges();
    }

    public ReportLog endReportExecution(ReportSchedule schedule) {
        ReportLog log = (ReportLog) createAndRegisterNewObject(ReportLog.class);
        schedule.addToReportLog(log);
        log.setSchedule(schedule);
        log.setRunTimestamp(new Date());
        reportScheduleDao.calculateTimes(schedule);
        schedule.setRunStatus(ReportSchedule.STATUS_Scheduled);
        commitChanges();
        return log;
    }

    public void emailReport(ReportSchedule schedule, File report) {
        String toAddress = schedule.getDeliveryEmail();
        if (StringUtils.isNotBlank(toAddress)) {
            Map model = new HashMap();
            model.put("schedule", schedule);
            String subject = emailService.renderTemplate(DeploymentProperty.PROPERTY_Email_Report_Subject, model);
            String message = emailService.renderTemplate(DeploymentProperty.PROPERTY_Email_Report_Message, model);
            String from = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Report_Sender);
            if (report != null) {
                List attachmentList = new ArrayList();
                attachmentList.add(report);
                emailService.sendMessage(subject, message, from, toAddress, null, attachmentList);
            } else {
                emailService.sendMessage(subject, message, from, toAddress);
            }
        }
    }

    public String calcBatchId(ReportSchedule schedule) {
        if (schedule.getReportClient() == null || schedule.getReportClient().getClient() == null) {
            return null;
        }
        Client client = schedule.getReportClient().getClient();
        String cutOffTime = client.getPaymentBatchCutoffTime();
        GregorianCalendar todaysCutOffCalendar = reportScheduleDao.constructDayTime(new Date(), cutOffTime);
        GregorianCalendar batchCalendar = new GregorianCalendar();
        if (batchCalendar.before(todaysCutOffCalendar)) {
            // Set batch to yesterday if it's currently before the cut off time.
            batchCalendar.add(GregorianCalendar.DATE, -1);
        }
        SimpleDateFormat batchIdFormat = new SimpleDateFormat("yyyyMMdd");
        return batchIdFormat.format(batchCalendar.getTime());
    }

    public void synchronizeReports() {
        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String directoryPath = deploymentPropertyDao.getConfigSubDirectory(REPORTS_DIR);
        if (StringUtils.isBlank(directoryPath)) {
            throw new ApplicationException("Config directory not configured", "Deployment property: " + deploymentPropertyDao.getProperty(DeploymentProperty.PROPERTY_Config_Directory).getDescription(),
                    "The location to write report files to is not defined", "Set the deployment property for the configuration directory");
        }

        if (!directoryPath.endsWith("\\") && !directoryPath.endsWith("/")) {
            directoryPath += File.separator;
        }
        directoryPath += TEMPLATES_DIR + File.separator;

        File reportRoot = new File(directoryPath);
        if (!reportRoot.exists()) {
            if (!reportRoot.mkdir()) {
                throw new ApplicationException("Could not create directory", "Path: " + directoryPath,
                        "The report directory could not be created", "Make sure that the path is correct and FormCenter has been granted write access.");
            }
        }

        // Delete the old contents
        try {
            FileUtils.cleanDirectory(reportRoot);
        }
        catch (IOException ioe) {
            throw new ApplicationException("Could not delete files", "Error type: " + ioe.getClass(),
                    "The report directory could not be purged. Message: " + ioe.getMessage(), "Resolve the error and try again");
        }

        ReportDao reportDao = DaoFactory.getReportDao();

        List<Report> reportList = reportDao.getReportList(null, null, 0);

        for (Report report : reportList) {
            if (report.getFileName() != null) {
                String reportDirectory = directoryPath + report.getId() + File.separator;
                File dirFile = new File(reportDirectory);
                if (!dirFile.exists()) {
                    dirFile.mkdirs();
                }

                saveReportFile(report, reportDirectory);

            } else {
                getLogger().info("No file name specified for report: " + report.getId());
            }
        }
    }

    public void saveReportFile(Report report) {
        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String directoryPath = deploymentPropertyDao.getConfigSubDirectory(REPORTS_DIR);
        if (StringUtils.isBlank(directoryPath)) {
            throw new ApplicationException("Config directory not configured", "Deployment property: " + deploymentPropertyDao.getProperty(DeploymentProperty.PROPERTY_Config_Directory).getDescription(),
                    "The location to write report files to is not defined", "Set the deployment property for the configuration directory");
        }

        if (!directoryPath.endsWith("\\") && !directoryPath.endsWith("/")) {
            directoryPath += File.separator;
        }
        directoryPath += TEMPLATES_DIR + File.separator + report.getId() + File.separator;

        if (report.getFileName() == null || report.getReportData() == null) {
            return;
        }

        File dirFile = new File(directoryPath);
        if (!dirFile.exists()) {
            if (!dirFile.mkdirs()) {
                throw new ApplicationException("Could not create directory", "Path: " + directoryPath,
                        "The report directory could not be created", "Make sure that the path is correct and FormCenter has been granted write access.");
            }
        }

        // Delete any existing files
        boolean fileDeleted = false;
        File[] reportDirFiles = dirFile.listFiles();
        if (reportDirFiles != null) {
            for (File file : reportDirFiles) {
                if (file.isFile()) {
                    // Delete any existing file
                    fileDeleted = true;
                    file.delete();
                }
            }
        }

        // Sleep for 1 second to allow file system to complete the delete
        if (fileDeleted) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ie) {
                // Do nothing
            }
        }

        saveReportFile(report, directoryPath);
    }

    private void saveReportFile(Report report, String directoryPath) {
        if (!directoryPath.endsWith("\\") && !directoryPath.endsWith("/")) {
            directoryPath += File.separator;
        }
        FileOutputStream fos = null;
        try {
            String targetPath = directoryPath + report.getFileName();

            // Write template data to the shared file system
            fos = new FileOutputStream(targetPath);
            byte[] data = report.getReportData();
            IOUtils.write(data, fos);

        } catch (Exception ioe) {
            throw new ApplicationException("An I/O error has occurred", "Error Type: " + ioe.getClass(),
                    "Message: " + ioe.getMessage(), "Resolve the error and try again.");

        } finally {
            CoreUtils.close(fos);
        }
    }
}

package com.avoka.fc.core.service;

public interface LogPurgeService {

    /**
     * Purge database records which are due to purged (deleted) from the database.
     */
    public void purgeDatabaseRecords();

}

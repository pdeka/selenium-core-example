package com.avoka.fc.core.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.cayenne.access.DataContext;
import org.w3c.dom.Document;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.util.XmlUtils;
import com.avoka.core.xml.importer.IAddEntityListener;
import com.avoka.core.xml.importer.ImportExportException;
import com.avoka.core.xml.importer.ImportSummaryData;
import com.avoka.core.xml.importer.RowBean;
import com.avoka.core.xml.importer.XMLReader;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.FormCenterEntityValidator;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

public class ImportService extends BaseService implements IAddEntityListener {

    FC2CayenneMetaData fc2CayenneMetaData = new FC2CayenneMetaData();

    protected List<FormDeployXml> importedDeployXmls;

    public void importData(String importFile){
        importedDeployXmls = new ArrayList<FormDeployXml>();

        XMLReader reader = new XMLReader();
        DeploymentPropertyDao deploymentDao = new DeploymentPropertyDao();
        String importDir = deploymentDao.getPropertyValue(DeploymentProperty.PROPERTY_Import_Directory);
        String productionMode = deploymentDao.getPropertyValue(DeploymentProperty.PROPERTY_Production_Mode);
        boolean modeProductionFlag;

        if (productionMode.equalsIgnoreCase(DeploymentProperty.PRODUCTION_Mode_Production)) {
            modeProductionFlag = true;
        } else {
            modeProductionFlag = false;
        }

        ZipInputStream zipInputStream = null;
        boolean locatedXMLFlag = false;
        try {
            zipInputStream = new ZipInputStream(new FileInputStream(importFile));

            ZipEntry entry = null;
            while ((entry = zipInputStream.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                String filename = entry.getName();
                String lcname = filename.toLowerCase();
                if (lcname.equals("manifest.mf")) {
                    // ignore the manifest file if it exists
                    continue;
                }
                if (lcname.endsWith(".xml")) {
                    FormCenterEntityValidator validator = new FormCenterEntityValidator();

                    reader.addAddEntityListener(this);
                    reader.addAddEntityListener(validator);
                    reader.addValidator(validator);
                    reader.importXml(zipInputStream, fc2CayenneMetaData, importDir, modeProductionFlag);
                    reader.removeAddEntityListener(this);
                    reader.removeAddEntityListener(validator);
                    reader.removeValidator(validator);

                    updateFormDeployIDs(importedDeployXmls);
                    return;

                }
                zipInputStream.closeEntry();
            }
            if (locatedXMLFlag == false) {
                getLogger().warn("Unable to locate XML entry in import file. File=" + importFile);
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ImportExportException re) {
            Throwable cause = re.getCause();
            throw new ApplicationException(re.getName(), cause, re.getContext(), re.getUserMessage(), re.getSolution());
        } finally {
            if (zipInputStream != null) {
                try {
                    zipInputStream.close();
                } catch (IOException e) {
                }
            }
        }
    }

    /**
     * Parse the import file and get the header details.
     *
     * @param importFile
     * @return
     */
    public ImportSummaryData getImportSumaryData(String importFile){

        XMLReader reader = new XMLReader();

        ZipInputStream zipInputStream = null;
        try {
            zipInputStream = new ZipInputStream(new FileInputStream(importFile));

            ZipEntry entry = null;
            boolean locatedXMLFlag = false;
            while ((entry = zipInputStream.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                String filename = entry.getName();
                String lcname = filename.toLowerCase();
                if (lcname.equals("manifest.mf")) {
                    // ignore the manifest file if it exists
                    continue;
                }
                getLogger().info("Entry=" + lcname);
                if (lcname.endsWith(".xml")) {

                    getLogger().info("Found XML Input file.");

                    return reader.getSummaryData(zipInputStream);
                }
                zipInputStream.closeEntry();
            }
            if (locatedXMLFlag == false) {
                getLogger().warn("Unable to locate XML entry in import file. File=" + importFile);
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            if (zipInputStream != null) {
                try {
                    zipInputStream.close();
                } catch (IOException e) {

                }
            }
        }
        return null;
    }

    public void preAddEntity(RowBean newRow) {
        // do nothing
    }

    public void postAddEntity(BaseEntity newEntity) {
        if (newEntity instanceof FormDeployXml) {
            FormDeployXml newDeployXml = (FormDeployXml) newEntity;
            importedDeployXmls.add(newDeployXml);
        }
    }

    @SuppressWarnings("deprecation")
    protected void updateFormDeployIDs(List<FormDeployXml> deployXmls) {
        if (deployXmls != null) {
            for (int i = 0; i < deployXmls.size(); i++) {
                FormDeployXml deployXml = deployXmls.get(i);
                String deployXmlID = deployXml.getId().toString();
                String deployXmlContents = new String(deployXml.getFormDeployXmlData());

                Document document = XmlUtils.parseDocumentFromString(deployXmlContents, false, false);
                SystemProfileHelper systemProfileHelper = new SystemProfileHelper(document);
                systemProfileHelper.setFormDeployOid(deployXmlID);

                deployXmlContents = XmlUtils.toString(document);
                deployXml.setFormDeployXmlData(deployXmlContents.getBytes());
            }
            DataContext.getThreadDataContext().commitChanges();
        }
    }
}

package com.avoka.fc.core.service.impl;

import java.text.MessageFormat;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;

import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ReceiptDataService;
import com.avoka.fc.core.service.RenderReceiptService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SubmissionReceiptService;
import com.avoka.fc.core.service.SubmissionStatusService;
import com.avoka.fc.core.util.ApplicationException;

public class SubmissionReceiptServiceImpl extends CayenneService implements SubmissionReceiptService {

    public static final String PARAM_RETRY_DELAY = "retryDelay";

    private String retryDelay;

    private int numberOfSubmissionsToProcess = 100;

    /**
     * @see SubmissionReceiptService#getNumberSubmissionsToProcess()
     */
    public int getNumberSubmissionsToProcess() {
        return numberOfSubmissionsToProcess;
    }

    /**
     * @see SubmissionReceiptService#setNumberSubmissionsToProcess(int)
     */
    public void setNumberSubmissionsToProcess(int value) {
        this.numberOfSubmissionsToProcess = value;
    }

    /**
     * @see SubmissionReceiptService#createReceiptPdf(Submission)
     */
    public void createReceiptPdf(Submission submission) {
        if (Submission.STATUS_Completed.equals(submission.getReceiptStatus())) {
            return;
        }

        if (submission.isReceiptError() && !isDueForRetry(submission)) {
            return;
        }

        ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
        if (receiptDataService.hasReceiptXml(submission)) {
            String seedXmlString = receiptDataService.getReceiptXml(submission);

            TemplateVersion templateVersion = submission.getVersion();

            ServiceDefinition sd = templateVersion.getReceiptRenderService();
            RenderReceiptService renderReceiptService = (RenderReceiptService)
                ServiceLocator.getServiceForDefinitionOrType(sd, ServiceDefinition.SERVICE_TYPE_RENDER_RECEIPT);

            try {
                long renderStart = System.currentTimeMillis();

                byte[] formBytes = renderReceiptService.renderReceipt(templateVersion, submission.getForm(), seedXmlString);

                int renderDuration = (int) (System.currentTimeMillis() - renderStart);
                submission.setReceiptRenderDuration(renderDuration);

                SubmissionData submissionData = submission.getSubmissionData();
                if (submissionData == null) {
                    submissionData = new SubmissionData();
                    registerNewObject(submissionData);
                    submissionData.setSubmission(submission);
                }
                submissionData.setReceiptData(formBytes);

                submission.setReceiptStatus(Submission.STATUS_Completed);
                submission.setReceiptRenderTime(new Date());

                SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
                submissionStatusService.updateStatus(submission);

                commitChanges();

                final long sizeKB = formBytes.length / 1024;
                Object[] args = { templateVersion.getFileName(), sizeKB, renderDuration };
                String msg = MessageFormat.format("Rendered receipt ''{0}'' ({1} KB) in {2} ms", args);
                getLogger().info(msg);

            } catch (ApplicationException ae) {
                submission.setReceiptStatus(Submission.STATUS_Error);

                int retryDelayInt = 10;
                try {
                    retryDelayInt = Integer.parseInt(getRetryDelay());
                } catch (NumberFormatException nfe) {
                    String msg = "SubmissionReceipt: Invalid value for service parameter: '" + getRetryDelay() + "'. Please change the value to a positive integer. A default value of '" + retryDelayInt + "' will be used.";

                    EventLogService eventLogService = new EventLogService();
                    eventLogService.logWarnEvent(msg);
                }
                Date nextRetryTime = DateUtils.addMinutes(new Date(), retryDelayInt);
                submission.setNextReceiptRenderTime(nextRetryTime);
                submission.setReceiptRenderTime(new Date());

                ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
                errorLogService.logExceptionNoRollback(ae, submission);

                commitChanges();

                String msg = "Error rendering submission " + submission.getId() + " receipt: " + ae.getMessage();
                getLogger().error(msg);
            }
        } else {
            // no form xml available
            submission.setReceiptStatus(Submission.STATUS_Error_No_Data);
            commitChanges();
        }
    }

    public String getRetryDelay() {
        return retryDelay;
    }

    public void setRetryDelay(String newRetryDelay) {
        retryDelay = newRetryDelay;
    }

    private boolean isDueForRetry(Submission submission) {
        if (!submission.isReceiptError()) {
            return false;
        }
        Date dueTime = submission.getNextReceiptRenderTime();
        Date curTime = new Date();
        return (dueTime == null || dueTime.compareTo(curTime) < 0);
    }

}

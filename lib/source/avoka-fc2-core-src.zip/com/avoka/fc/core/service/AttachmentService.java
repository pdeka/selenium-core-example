/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.service;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.cayenne.exp.ExpressionFactory;
import org.apache.cayenne.map.DbAttribute;
import org.apache.cayenne.map.ObjAttribute;
import org.apache.cayenne.map.ObjEntity;
import org.apache.cayenne.query.SelectQuery;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FileUploadDao;
import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.FileUploadData;
import com.avoka.fc.core.entity.RequiredAttachment;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.ApplicationFileUploadException;
import com.avoka.fc.forms.api.utils.DataHashUtils;

/**
 * Provides user document service for managing uploaded file attachments.
 *
 * <ul>
 * <li>commons-fileupload-1.1.jar</li>
 * </ul>
 *
 * @author medgar@avoka.com
 */
public class AttachmentService extends CayenneService{

    /**
     * Associate the uploaded fileItem for form submission requiredAttachmet.
     *
     * @param fileUpload the uploaded file
     * @param requiredAttachment the associated required attachment
     */
    public void associateFileUpload(FileUpload fileUpload, RequiredAttachment requiredAttachment){

        Validate.notNull(fileUpload);
        Validate.notNull(fileUpload.getFileUploadData());
        Validate.notNull(fileUpload.getFileName());
        Validate.notNull(requiredAttachment);

        // TODO: MAE - 15/6/2009 NOTE this method is not referenced

        // Test the file size
        checkAttachmentSize(requiredAttachment, fileUpload.getFileUploadData().getFileUploadData(), fileUpload.getFileName());

        // Test the file type
        checkAttachmentType(requiredAttachment, fileUpload.getFileName());

        Submission submission = requiredAttachment.getSubmission();

        String fileUploadHash = DataHashUtils.toSHA256Hash(fileUpload.getFileUploadData().getFileUploadData());
        fileUpload.setFileDataHash(fileUploadHash);

        Attachment attachment = (Attachment) createAndRegisterNewObject(Attachment.class);
        attachment.setFileUpload(fileUpload);

        attachment.setAttachmentKey(CoreUtils.createAltKey());

        // If there is a required attachment that has been submitted manually, there will be an attachment with no
        // associated file_upload to support WS delivery of this required attachment data. We need to remove this
        // attachment record with no associated file_upload
        if (requiredAttachment.isSubmittedManually()) {
            List<Attachment> attachments = requiredAttachment.getAttachments();
            deleteObjects(attachments);
        }

        requiredAttachment.addToAttachments(attachment);
        requiredAttachment.setSubmitManuallyFlag(Boolean.FALSE);
        submission.addToAttachments(attachment);

        commitChanges();

        updateSubmissionAttachmentsStatus(submission);

        commitChanges();
    }

    /**
     * Remove this attachment (Break link between a required attachment, Submission and File upload.
     *
     * @param attachmentId
     */
    public void removeAttachment(Object attachmentId){
        Validate.notNull(attachmentId, "Null attachmentId parameter");

        Attachment attachment = (Attachment) getObjectForPK(Attachment.class, attachmentId);

        Submission submission = attachment.getSubmission();

        getDataContext().deleteObject(attachment);

        commitChanges();

        updateSubmissionAttachmentsStatus(submission);

        commitChanges();
    }

    public boolean deleteFileUpload(FileUpload fileUpload){
        Validate.notNull(fileUpload, "Null fileUpload parameter");

        deleteObject(fileUpload);

        commitChanges();

        return true;
    }

    /**
     * The given attachment will be submitted manually.
     *
     * @param requiredAttachment
     */
    public void submitManually(Object requiredAttachmentId){
        Validate.notNull(requiredAttachmentId, "Null requiredAttachmentId parameter");

        // Set the required attachment to submit manually.
        RequiredAttachment requiredAttachment = getRequiredAttachment(requiredAttachmentId);
        requiredAttachment.setSubmitManuallyFlag(Boolean.TRUE);

        // Remove any existing file attachments
        Submission submission = requiredAttachment.getSubmission();

        SelectQuery query = new SelectQuery(Attachment.class);
        query.andQualifier(ExpressionFactory.matchExp(Attachment.SUBMISSION_PROPERTY, submission));
        query.andQualifier(ExpressionFactory.matchExp(Attachment.REQUIRED_ATTACHMENT_PROPERTY, requiredAttachment));

        List<Attachment> attachments = performQuery(query);
        deleteObjects(attachments);

        // Create new attachment association.
        Attachment attachment = new Attachment();
        registerNewObject(attachment);
        attachment.setSubmission(submission);
        attachment.setRequiredAttachment(requiredAttachment);
        attachment.setAttachmentKey(CoreUtils.createAltKey());

        commitChanges();

        updateSubmissionAttachmentsStatus(submission);

        commitChanges();
    }

    /**
     * Return the required attachment for the given required attachment id.
     *
     * @param id
     *            the required attachment id
     * @return the required attachment for the given required attachment id
     */
    public RequiredAttachment getRequiredAttachment(Object id){
        return (RequiredAttachment) getObjectForPK(RequiredAttachment.class, id);
    }

    public void saveEmbeddedAttachmentForSubmission(EmbeddedAttachment embeddedAttachment, Submission submission) {

        Validate.notNull(embeddedAttachment);
        Validate.notNull(embeddedAttachment.getFilename());
        Validate.notNull(embeddedAttachment.getFileBytes());
        Validate.notNull(submission);

        String fileName = embeddedAttachment.getFilename();
        byte[] fileData = embeddedAttachment.getFileBytes();
        String description = (embeddedAttachment.isPDFForm()) ? "Submitted PDF Form" : "Embedded Attachment";

        // If virus found, set virus status to indicate virus found, and file data is set to null
        // so that the corrupted file data is not stored in the database
        FileUpload fileUpload = new FileUpload();

        if (ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN)) {

            VirusScanService virusScanService = (VirusScanService)
                ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN);

            try {
                if (!virusScanService.isFileVirusFree(fileName, fileData)) {
                    if (embeddedAttachment.isPDFForm()) {
                        String name = "Submitted Form Virus";
                        String context = "Form Name: " + submission.getForm().getFormName();
                        String usrMsg = "The submitted form is infected with a virus.";
                        String solution = "Please get a new copy of the form and resubmit your form.";
                        throw new ApplicationFileUploadException(name, context, usrMsg, solution);

                    } else {
                        String name = "File Attachment Virus";
                        String context = "File Name: " + fileName + ", Form Name: " + submission.getForm().getFormName();
                        String usrMsg = "The submitted form contains a file infected with a virus '" + fileName + "'.";
                        String solution = "Please remove the virus from this file, or upload another file and resubmit your form.";
                        throw new ApplicationFileUploadException(name, context, usrMsg, solution);
                    }

                } else {
                    fileUpload.setVirusStatus(FileUpload.VIRUS_STATUS_CLEAN);
                }

            } catch (VirusScanException vse) {
                ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
                errorLogService.logExceptionNoRollback(vse, submission);

                fileUpload.setVirusStatus(FileUpload.VIRUS_STATUS_SCAN_ERROR);
            }
        }

        registerNewObject(fileUpload);

        // Store these values now because if fileData contains a virus we will null it out.
        final long fileDataLength = fileData.length;
        final String fileUploadHash = DataHashUtils.toSHA256Hash(fileData);

        fileUpload.setFileName(getTrimmedFileName(fileName));
        fileUpload.setDescription(description);

        UserAccount user = submission.getUser();
        if (user != null) {
            fileUpload.setUser(user);
        }
        fileUpload.setSize(fileDataLength);
        fileUpload.setUploadTimestamp(new Date());

        if (fileData != null) {
            FileUploadData fileUploadData = new FileUploadData();
            registerNewObject(fileUploadData);
            fileUploadData.setFileUpload(fileUpload);
            fileUploadData.setFileUploadData(fileData);

            fileUpload.setFileUploadData(fileUploadData);
        }

        fileUpload.setFileDataHash(fileUploadHash);

        Attachment attachment = (Attachment) createAndRegisterNewObject(Attachment.class);
        attachment.setFileUpload(fileUpload);

        attachment.setAttachmentKey(CoreUtils.createAltKey());

        // FCT-527 - don't want embedded attachments setting attachment status to "Optional"
        submission.addToAttachments(attachment);

        commitChanges();
    }

    /**
     * Save the uploaded fileItem for form submission requiredAttachmet.
     *
     * @param fileItem the uploaded file item
     * @param description the description of the file
     * @param requiredAttachment the associated required attachment
     * @throws ApplicationException if the document directory could not be determined
     * @throws IOException if an IO error occurs
     */
    public void saveFileForRequiredAttachment(
            String fileName,
            byte[] fileData,
            String description,
            RequiredAttachment requiredAttachment) throws ApplicationException, IOException{

        Validate.notNull(fileName);
        Validate.notNull(fileData);
        Validate.notNull(requiredAttachment);
        Validate.notNull(requiredAttachment.getSubmission());

        final Submission submission = requiredAttachment.getSubmission();

        // If virus found, set virus status to indicate virus found, and file data is set to null
        // so that the corrupted file data is not stored in the database
        FileUpload fileUpload = new FileUpload();

        if (ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN)) {

            VirusScanService virusScanService = (VirusScanService)
                ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN);

            try {
                if (!virusScanService.isFileVirusFree(fileName, fileData)) {
                    String name = "File Attachment Virus";
                    String context = "File Name: " + fileName;
                    String usrMsg = "The file '" + fileName + "' is infected with a virus.";
                    String solution = "Please remove the virus from this file, or upload another file.";
                    throw new ApplicationFileUploadException(name, context, usrMsg, solution);

                } else {
                    fileUpload.setVirusStatus(FileUpload.VIRUS_STATUS_CLEAN);
                }

            } catch (VirusScanException vse) {
                ErrorLogService errorLogService = ServiceFactory.getErrorLogService();
                errorLogService.logExceptionNoRollback(vse, submission);

                fileUpload.setVirusStatus(FileUpload.VIRUS_STATUS_SCAN_ERROR);
            }
        }

        // Test the file size
        checkAttachmentSize(requiredAttachment, fileData, fileName);

        // Test the file type
        checkAttachmentType(requiredAttachment, fileName);

        registerNewObject(fileUpload);

        // Store these values now because if fileData contains a virus we will null it out.
        final long fileDataLength = fileData.length;
        final String fileUploadHash = DataHashUtils.toSHA256Hash(fileData);

        fileUpload.setFileName(getTrimmedFileName(fileName));
        fileUpload.setDescription(description);

        UserAccount user = submission.getUser();
        if (user != null) {
            fileUpload.setUser(user);
        }
        fileUpload.setSize(fileDataLength);
        fileUpload.setUploadTimestamp(new Date());

        FileUploadData fileUploadData = new FileUploadData();
        registerNewObject(fileUploadData);
        fileUploadData.setFileUpload(fileUpload);
        fileUploadData.setFileUploadData(fileData);

        fileUpload.setFileUploadData(fileUploadData);
        fileUpload.setFileDataHash(fileUploadHash);

        // If there is a required attachment that has been submitted manually, there will be an attachment with no
        // associated file_upload to support WS delivery of this required attachment data. We need to remove this
        // attachment record with no associated file_upload
        if (requiredAttachment.isSubmittedManually()) {
            List<Attachment> attachments = requiredAttachment.getAttachments();
            deleteObjects(attachments);
        }

        Attachment attachment = (Attachment) createAndRegisterNewObject(Attachment.class);
        attachment.setFileUpload(fileUpload);

        attachment.setAttachmentKey(CoreUtils.createAltKey());

        requiredAttachment.addToAttachments(attachment);
        requiredAttachment.setSubmitManuallyFlag(Boolean.FALSE);
        submission.addToAttachments(attachment);
        updateSubmissionAttachmentsStatus(submission);

        commitChanges();
    }

    /**
     * Save the uploaded fileItem for the given user.
     *
     * @param fileItem the uploaded file item
     * @param description the description of the file
     * @param user the user to save the file to
     * @throws ApplicationException if the document directory could not be determined
     * @throws IOException if an IO error occurs
     */
    public void saveFileItemForUser(FileItem fileItem, String description, UserAccount user) throws ApplicationException,
            IOException{

        Validate.notNull(fileItem, "Null fileItem parameter");
        Validate.notNull(user, "Null user parameter");

        FileUpload fileUpload = (FileUpload) createAndRegisterNewObject(FileUpload.class);

        String filename = fileItem.getName();
        int index = filename.lastIndexOf(File.separator);
        if (index != 1) {
            filename = CoreUtils.getFileName(filename.substring(index + 1));
            filename = CoreUtils.limitLength(filename, 40);
        }

        fileUpload.setFileName(filename);
        fileUpload.setDescription(description);
        fileUpload.setUser(user);
        fileUpload.setSize(new Long(fileItem.getSize()));
        fileUpload.setUploadTimestamp(new Date());
        fileUpload.setSharedFlag(Boolean.TRUE);

        byte[] fileData = fileItem.get();
        FileUploadData fileUploadData = new FileUploadData();
        registerNewObject(fileUploadData);
        fileUploadData.setFileUpload(fileUpload);
        fileUploadData.setFileUploadData(fileData);

        fileUpload.setFileUploadData(fileUploadData);

        String fileUploadHash = DataHashUtils.toSHA256Hash(fileData);
        fileUpload.setFileDataHash(fileUploadHash);

        commitChanges();
    }

    public void setAttachmentsComplete(Submission submission) {
        FileUploadDao fileUploadDao = DaoFactory.getFileUploadDao();
        List<FileUpload> fileUploads = fileUploadDao.getFileUploadsForSubmission(submission);
        if (fileUploads != null) {
            for (int i = 0; i < fileUploads.size(); i++) {
                FileUpload curFileUpload = fileUploads.get(i);
                curFileUpload.setSubmissionAuditStatus(Submission.STATUS_Ready);
            }
        }

        submission.setAttachmentsStatus(Submission.STATUS_Completed);

        SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
        submissionStatusService.updateStatus(submission);

        commitChanges();
    }

    // Private Methods --------------------------------------------------------

    private String getTrimmedFileName(String fileName) {
        Validate.notNull(fileName);

        fileName = CoreUtils.getFileName(fileName);

        // Get maximum file name length
        ObjEntity objEntity = getDataContext().getEntityResolver().lookupObjEntity(FileUpload.class);
        ObjAttribute objAttribute = (ObjAttribute) objEntity.getAttribute(FileUpload.FILE_NAME_PROPERTY);
        DbAttribute dbAttribute = objAttribute.getDbAttribute();
        final int maxFileNameLength = dbAttribute.getMaxLength();

        // Truncate the filename if too long, and preserve the extension
        if (fileName.length() > maxFileNameLength) {
            int dotIndex = fileName.lastIndexOf(".");
            if (dotIndex > -1) {
                String extension = fileName.substring(dotIndex, fileName.length());
                fileName = CoreUtils.limitLength(fileName, maxFileNameLength, extension);

            } else {
                fileName = CoreUtils.limitLength(fileName, maxFileNameLength);
            }
        }

        return fileName;
    }

    private void updateSubmissionAttachmentsStatus(Submission submission){
        // Check whether all require attachments have been added.

        // Create a set of required attachment ids
        Set requiredAttachmentSet = new HashSet();
        Set allAttachmentSet = new HashSet();
        for (Iterator i = submission.getRequiredAttachments().iterator(); i.hasNext();) {
            RequiredAttachment ra = (RequiredAttachment) i.next();
            allAttachmentSet.add(ra.getId());
            if (ra.isRequired()) {
                requiredAttachmentSet.add(ra.getId());
            }
        }

        // Create a set of manually submitted attachments
        Set manualSubmitSet = new HashSet();
        for (Iterator i = submission.getRequiredAttachments().iterator(); i.hasNext();) {
            RequiredAttachment ra = (RequiredAttachment) i.next();
            if (ra.isSubmittedManually()) {
                manualSubmitSet.add(ra.getId());
            }
        }

        // Remove any submission attachment's associated required attachments from the set
        for (Iterator i = submission.getAttachments().iterator(); i.hasNext();) {
            Attachment a = (Attachment) i.next();
            RequiredAttachment ra = a.getRequiredAttachment();
            if (ra != null) {
                requiredAttachmentSet.remove(ra.getId());
                allAttachmentSet.remove(ra.getId());
            }
        }

        requiredAttachmentSet.removeAll(manualSubmitSet);
        allAttachmentSet.removeAll(manualSubmitSet);

        if (allAttachmentSet.isEmpty() || requiredAttachmentSet.isEmpty()) {
            submission.setAttachmentsStatus(Submission.STATUS_Optional);
        }
        else {
            submission.setAttachmentsStatus(Submission.STATUS_Required);
        }

        SubmissionStatusService submissionStatusService = ServiceFactory.getSubmissionStatusService();
        submissionStatusService.updateStatus(submission);
    }

    public int getMaxSizeForString(String maxSizeString) {
        if (SpecifiedAttachment.MAX_SIZE_500KB.equals(maxSizeString)) {
            return 512 * 1024;
        }
        else if (SpecifiedAttachment.MAX_SIZE_1MB.equals(maxSizeString)) {
            return 1024 * 1024;
        }
        else if (SpecifiedAttachment.MAX_SIZE_2MB.equals(maxSizeString)) {
            return 2 * 1024 * 1024;
        }
        else if (SpecifiedAttachment.MAX_SIZE_3MB.equals(maxSizeString)) {
            return 3 * 1024 * 1024;
        }
        else if (SpecifiedAttachment.MAX_SIZE_5MB.equals(maxSizeString)) {
            return 5 * 1024 * 1024;
        }
        else if (SpecifiedAttachment.MAX_SIZE_10MB.equals(maxSizeString)) {
            return 10 * 1024 * 1024;
        }
        else {
            throw new IllegalArgumentException("Unsupported max size: " + maxSizeString);
        }
    }

    public String getStringForMaxSize(int maxSize) {
        switch (maxSize) {
            case 512 * 1024:        return SpecifiedAttachment.MAX_SIZE_500KB;
            case 1024 * 1024:       return SpecifiedAttachment.MAX_SIZE_1MB;
            case 2 * 1024 * 1024:   return SpecifiedAttachment.MAX_SIZE_2MB;
            case 3 * 1024 * 1024:   return SpecifiedAttachment.MAX_SIZE_3MB;
            case 5 * 1024 * 1024:   return SpecifiedAttachment.MAX_SIZE_5MB;
            case 10 * 1024 * 1024:  return SpecifiedAttachment.MAX_SIZE_10MB;
        }
        return null;
    }

    private void checkAttachmentSize(RequiredAttachment requiredAttachment, byte[] fileData, String fileName) {
        Integer maxSize = requiredAttachment.getMaxSize();
        if (maxSize == null) {
            EventLogService eventLogService = new EventLogService();
            eventLogService.logWarnEvent("File size for required attachment " + requiredAttachment.getId() + " is not constrained.", requiredAttachment.getSubmission());
        }
        if (maxSize != null && fileData != null && fileData.length > maxSize) {
            long fileSizeKB = fileData.length / 1024;
            long maxSizeKB = maxSize.longValue() / 1024;

            String name = "Maximum attachment size exceeded";
            String context = "Error when attempting to upload file";
            String usrMsg = "The file '" + fileName + "' (" + fileSizeKB + " KB) exceeds the maximum allowable size of " + maxSizeKB + " KB.";
            String solution = "Please upload a smaller file.";
            throw new ApplicationFileUploadException(name, context, usrMsg, solution);
        }
    }

    private void checkAttachmentType(RequiredAttachment requiredAttachment, String fileName) {
        String fileTypes = requiredAttachment.getMimeOrFileTypes();
        if (StringUtils.isNotBlank(fileTypes)) {
            int dotIndex = fileName.lastIndexOf(".");
            if (dotIndex > -1) {
                final String fileExtension = fileName.substring(dotIndex, fileName.length()).toLowerCase();

                boolean found = false;
                String[] types = fileTypes.split(", ");
                for(String type : types) {
                    if (type.toLowerCase().contains(fileExtension)) {
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    String name = "Invalid file type";
                    String context = "Error when attempting to upload file";
                    String usrMsg = "The file '" + fileName + "' is not a " + fileTypes + " file type.";
                    String solution = "Please upload a file with a valid type.";
                    throw new ApplicationFileUploadException(name, context, usrMsg, solution);
                }
            }
        }
    }
}

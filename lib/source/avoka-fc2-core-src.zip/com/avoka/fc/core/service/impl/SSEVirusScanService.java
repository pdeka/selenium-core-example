package com.avoka.fc.core.service.impl;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.service.BaseService;
import com.avoka.fc.core.service.ServiceDefinitionAware;
import com.avoka.fc.core.service.VirusScanException;
import com.avoka.fc.core.service.VirusScanService;

/**
 * Provides an Symantec Scan Engine Virus Scan Service.
 */
public class SSEVirusScanService extends BaseService implements VirusScanService, ServiceDefinitionAware  {

    private ServiceDefinition serviceDefinition;

    /** Enable mock testing of has virus behaviour. */
    private String mockTestScanVirus;

    /** Enable mock testing of has virus behaviour. */
    private String mockTestScanClean;

    /**
     * @see VirusScanService#isFileVirusFree(String, byte[])
     */
    public boolean isFileVirusFree(String filename, byte[] fileData) throws VirusScanException {
        Validate.notNull(filename, "Null filename parameter");
        Validate.notNull(fileData, "Null fileData parameter");

        getLogger().debug("Scanning '" + filename + "', file length=" + fileData.length);

        // Provide mock test for virus scanning
        if ("true".equalsIgnoreCase(getMockTestScanVirus())) {
            return false;
        }
        if ("true".equalsIgnoreCase(getMockTestScanClean())) {
            return true;
        }

        boolean isVirusFree = true;

        ServiceConnection serviceConnection = serviceDefinition.getConnection();
        if (serviceConnection == null) {
            String msg = ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN + " Service configuration error, no ServiceDefinition.Connection defined";
            String context = "ServiceDefinition.Connection=null";
            String solution = "Associate ServiceConnection with '" + serviceDefinition.getServiceName() + "' ServiceDefinition";
            throw new VirusScanException(msg, context, solution);
        }

        // Finding the Symantec Scan Engine location
        String connectionEndpoint = serviceConnection.getEndpointValue();
        if (StringUtils.isBlank(connectionEndpoint)) {
            String msg = ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN + " Service configuration error, no Connection.EndpointValue defined";
            String context = "Connection.EndpointValue=" + connectionEndpoint;
            // TODO: define config solution
            throw new VirusScanException(msg, context);
        }

        int lastColonLocation = connectionEndpoint.lastIndexOf(":");
        if (lastColonLocation == -1) {
            String msg = ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN + " Service configuration error, invalid Connection.EndpointValue value: " + connectionEndpoint;
            String context = "Connection.EndpointValue=" + connectionEndpoint;
            // TODO: define config solution
            throw new VirusScanException(msg, context);
        }

        // Finally getting the SSEServer string
        String hostname = connectionEndpoint.substring(0, lastColonLocation);
        if ((hostname == null) || (hostname.length()==0)) {
            String msg = ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN + " Service configuration error, not invalid Connection.EndpointValue hostname defined: " + connectionEndpoint;
            String context = "Connection.EndpointValue=" + connectionEndpoint;
            // TODO: define config solution
            throw new VirusScanException(msg, context);
        }

        int port = -1;
        String portValue = connectionEndpoint.substring(lastColonLocation + 1);
        if (NumberUtils.isNumber(portValue)) {
            port = Integer.parseInt(portValue);

        } else {
            String msg = ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN + " Service configuration error, not invalid Connection.EndpointValue port defined: " + connectionEndpoint;
            String context = "port=" + portValue;
            // TODO: define config solution
            throw new VirusScanException(msg, context);
        }

        // Create scan client
        SSEClient sseClient = new SSEClient(hostname, port);

        // Scan the file
        isVirusFree = sseClient.scanFile(filename, fileData);

        getLogger().debug("File '" + filename + "' virus free status=" + isVirusFree);

        return isVirusFree;
    }

    /**
     * @see ServiceDefinitionAware#getServiceDefinition()
     */
    public ServiceDefinition getServiceDefinition() {
        return serviceDefinition;
    }

    /**
     * @see ServiceDefinitionAware#setServiceDefinition(ServiceDefinition)
     */
    public void setServiceDefinition(ServiceDefinition serviceDefinition) {
        this.serviceDefinition = serviceDefinition;
    }

    public String getMockTestScanVirus() {
        return mockTestScanVirus;
    }

    public void setMockTestScanVirus(String mockTestScanVirus) {
        this.mockTestScanVirus = mockTestScanVirus;
    }

    public String getMockTestScanClean() {
        return mockTestScanClean;
    }

    public void setMockTestScanClean(String mockTestScanClean) {
        this.mockTestScanClean = mockTestScanClean;
    }

}


package com.avoka.fc.core.service;

import java.io.OutputStream;
import java.util.List;

import com.avoka.core.xml.export.ExportManager;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.PortalDao;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalPage;
import com.avoka.fc.core.entity.PortalProperty;
import com.avoka.fc.core.entity.PortalResource;

public class ExportPortalService {

    public static final String EXPORT_Type_Portal = "Portal Export";

    public void exportPortal(String portalName,
            OutputStream exportOutStream,
            String description,
            String environmentName){

        ExportManager exportManager = new ExportManager(new FC2CayenneMetaData());

        PortalDao portalDao = DaoFactory.getPortalDao();
        Portal portal = portalDao.getPortalByName(portalName);

        // TODO anything to blank out with Portal???
        // Blank out the client key so it will be regenerated

        exportManager.addRow(portal, true, true);

        List<PortalPage> portalPageList = portal.getPortalPages();
        for (PortalPage portalPage : portalPageList) {
            exportManager.addRow(portalPage, true, true);
            System.out.println("Adding Portal Page: " + portalPage.getName());

        }

        List<PortalResource> portalResourceList = portal.getPortalResources();
        for (PortalResource portalResource : portalResourceList) {
            exportManager.addRow(portalResource, true, true);
            System.out.println("Adding Portal Resource: " + portalResource.getPath());
        }

        List<PortalProperty> portalPropertyList = portal.getPortalProperties();
        for (PortalProperty portalProperty : portalPropertyList) {
            exportManager.addRow(portalProperty, true, true);
            System.out.println("Adding Portal Property: " + portalProperty.getName());
        }

        List<Permission> portalPermissionList = portal.getPermissions();
        for (Permission permission : portalPermissionList) {
            exportManager.addRow(permission, true, true);
            System.out.println("Adding Permission: " + permission.getPermissionName());
        }

        exportManager.writeXml(exportOutStream, EXPORT_Type_Portal, portalName, description, environmentName);

        // TODO Portal Users???
    }

}

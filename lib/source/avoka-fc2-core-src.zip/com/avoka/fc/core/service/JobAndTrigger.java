package com.avoka.fc.core.service;

import java.util.Iterator;

import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;

/**
 * Job and Trigger holder object.
 */
public class JobAndTrigger {

    private static final long MS_TO_SECS = 1000L;
    private static final long MS_TO_MINS = 1000L * 60;

    private final JobDetail jobDetail;
    private final SimpleTrigger trigger;
    private final Scheduler scheduler;

    public JobAndTrigger(JobDetail jobDetail, SimpleTrigger trigger, Scheduler scheduler) {
        this.jobDetail = jobDetail;
        this.trigger = trigger;
        this.scheduler = scheduler;
    }

    public JobDetail getJob() {
        return jobDetail;
    }

    public SimpleTrigger getTrigger() {
        return trigger;
    }

    public int getTriggerState(){
        try {
            return scheduler.getTriggerState(trigger.getName(), trigger.getGroup());
        } catch(Throwable th) {
            return Trigger.STATE_NONE;
        }
    }

    public String getTriggerStateAsString(){
        switch(getTriggerState()){
        case Trigger.STATE_NONE:
            return "None";
        case Trigger.STATE_NORMAL:
            return "Normal";
        case Trigger.STATE_PAUSED:
            return "Paused";
        case Trigger.STATE_BLOCKED:
            return "Running";
        case Trigger.STATE_COMPLETE:
            return "Complete";
        case Trigger.STATE_ERROR:
            return "Error";
        }
        return "Unknown";
    }

    public String getRepeat() {
        long count = trigger.getRepeatCount();

        if (count == -1) {
            return "Continously";

        } else if (count == 0) {
            return "Run once";

        } else if (count == 1) {
            return "Repeat once";

        } else {
            return "Repeat " + count;
        }
    }

    public String getInterval() {

        long intervalSec = trigger.getRepeatInterval() / MS_TO_SECS;
        if (intervalSec < 60) {
            return "" + intervalSec + " secs";
        }

        long intervalMin = trigger.getRepeatInterval() / MS_TO_MINS;

        if (intervalMin == 1) {
            return "1 min";

        } else if (intervalMin < 60) {
            return "" + intervalMin + " mins";

        } else if (intervalMin == 60) {
            return "1 hour";

        } else {
            return "" + intervalMin / 60 + " hours";
        }
    }

    @SuppressWarnings("unchecked")
    public boolean isExecuting() throws SchedulerException {
        for (Iterator i = scheduler.getCurrentlyExecutingJobs().iterator(); i.hasNext();) {
            JobExecutionContext context = (JobExecutionContext) i.next();
            if (context.getJobDetail().getFullName().equals(jobDetail.getFullName())) {
                return true;
            }
        }
        return false;
    }
}

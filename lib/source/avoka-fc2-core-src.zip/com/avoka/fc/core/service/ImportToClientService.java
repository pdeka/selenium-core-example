package com.avoka.fc.core.service;

import com.avoka.core.xml.importer.IAddEntityListener;
import com.avoka.core.xml.importer.RowBean;
import com.avoka.fc.core.entity.Client;

public class ImportToClientService extends ImportService implements IAddEntityListener {

    private String clientName;
    private String clientCode;

    public ImportToClientService(String clientName, String clientCode) {
        super();
        this.clientName = clientName;
        this.clientCode = clientCode;
    }

    @Override
    public void preAddEntity(RowBean newRow) {
        String tableName = null;
        if (newRow.getTableBean() != null) {
            tableName = newRow.getTableBean().getTableName();
        }

        if ("Client".equalsIgnoreCase(tableName)) {
            newRow.setColumn(Client.CLIENT_NAME_PROPERTY, clientName);
            newRow.setColumn(Client.CLIENT_CODE_PROPERTY, clientCode);
        }
    }
}

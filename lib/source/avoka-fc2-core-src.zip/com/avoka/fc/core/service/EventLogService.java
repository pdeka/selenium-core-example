package com.avoka.fc.core.service;

import java.util.Date;

import org.apache.cayenne.DataObjectUtils;
import org.apache.cayenne.access.DataContext;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.EventLog;
import com.avoka.fc.core.entity.Submission;

public class EventLogService extends BaseService {

    // --------------------------------------------------------- Public Methods

    public void logErrorEvent(String message) {
        logEvent(EventLog.EVENT_TYPE_ERROR, message, null);
    }

    public void logErrorEvent(String message, Submission submission) {
        logEvent(EventLog.EVENT_TYPE_ERROR, message, submission);
    }

    public void logWarnEvent(String message) {
        logEvent(EventLog.EVENT_TYPE_WARNING, message, null);
    }

    public void logWarnEvent(String message, Submission submission) {
        logEvent(EventLog.EVENT_TYPE_WARNING, message, submission);
    }

    public void logInfoEvent(String message) {
        logEvent(EventLog.EVENT_TYPE_INFO, message, null);
    }

    public void logInfoEvent(String message, Submission submission) {
        logEvent(EventLog.EVENT_TYPE_INFO, message, submission);
    }

    // ------------------------------------------------------ Protected Methods

    protected void logEvent(String type, String message, Submission submission) {

        DataContext dataContext = DataContext.createDataContext(false);

        EventLog eventLog = new EventLog();
        dataContext.registerNewObject(eventLog);
        eventLog.setEventTime(new Date());
        eventLog.setEventType(type);
        eventLog.setMessage(CoreUtils.limitLength(message, 500));

        if (submission != null) {
            // Associate submission with new data context
            submission = (Submission) DataObjectUtils.objectForPK(dataContext, Submission.class, submission.getId());
            eventLog.setSubmission(submission);
        }

        if (EventLog.EVENT_TYPE_ERROR.equals(type)) {
            getLogger().error("Logged Event. Message " + message);
        }
        else if (EventLog.EVENT_TYPE_WARNING.equals(type)) {
            getLogger().warn("Logged Event. Message " + message);
        }
        else if (EventLog.EVENT_TYPE_INFO.equals(type)) {
            getLogger().info("Logged Event. Message " + message);
        }
        else {
            getLogger().info("Logged Event. Message " + message);
        }

        dataContext.commitChanges();
    }

}

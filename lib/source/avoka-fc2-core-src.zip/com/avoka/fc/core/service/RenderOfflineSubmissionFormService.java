package com.avoka.fc.core.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.util.ApplicationException;

public interface RenderOfflineSubmissionFormService {

    /**
     * Render the offline submission form using the given form and XML data
     * to the response.
     *
     * @param offlineSubmissionForm - the form to render
     * @param xmlData - the XML form data seed document
     * @param request - the users Http servlet request
     * @param response - the Http servlet response to render to
     * @throws ApplicationException if an error occurs
     */
    public void renderOfflineSubmissionForm(OfflineSubmissionForm offlineSubmissionForm,
                              String xmlData,
                              HttpServletRequest request,
                              HttpServletResponse response)
            throws ApplicationException;

}

package com.avoka.fc.core.service;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.avoka.core.xml.export.ExportManager;
import com.avoka.fc.core.dao.MetadataListValueDao;
import com.avoka.fc.core.dao.MetadataTagDao;
import com.avoka.fc.core.entity.MetadataListValue;
import com.avoka.fc.core.entity.MetadataTag;

public class ExportMetadataTagService{

    public static final String EXPORT_Type     = "Metadata Tag Export";

    public void exportMetadataTags(OutputStream exportOutStream, String exportName, String description, String environmentName){

        ExportManager exportManager = new ExportManager(new FC2CayenneMetaData());

        MetadataTagDao metadataTagDao = new MetadataTagDao();
        List<MetadataTag> tagList = metadataTagDao.getMetadataTagListForClient(null);
        for (MetadataTag tag : tagList) {
            exportManager.addRow(tag, true, true);
            MetadataListValueDao metadataListValueDao = new MetadataListValueDao();
            List<MetadataListValue> rootValueList = metadataListValueDao.getRootValues(tag.getId().toString());
            List<MetadataListValue> metadataListValueList = new ArrayList<MetadataListValue>();
            for (MetadataListValue listValue : rootValueList) {
                metadataListValueList.addAll(metadataListValueDao.getValueTree(listValue.getId().toString()));
            }
            for (MetadataListValue listValue : metadataListValueList) {
                exportManager.addRow(listValue, true, true);
            }
        }

        exportManager.writeXml(exportOutStream, EXPORT_Type, exportName, description, environmentName);
    }

}

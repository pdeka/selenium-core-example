package com.avoka.fc.core.service.finder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;

import com.avoka.core.util.HSSFUtils;
import com.avoka.fc.core.entity.FinderCategory;
import com.avoka.fc.core.util.ApplicationException;

class CategoryWorksheetMetaData {

    private static final String[] columnHeaders = { "A", "B", "C", "D", "E", "F" };

    private String categoryCode;
    private List<String> columnNames = new ArrayList<String>();
    private String tableName;
    private List<String> tableColumnNames = new ArrayList<String>();
    private Map<String, Integer> tableColumnWidths = new HashMap<String, Integer>();

    /**
     * Create category meta data from the category data worksheet.
     */
    public CategoryWorksheetMetaData(FinderCategory category, HSSFSheet categoryDataWorksheet) {

        Set<String> columnNameSet = new HashSet<String>();

        // Read Header Row
        HSSFRow row = categoryDataWorksheet.getRow(0);
        for (int i = 0; i < row.getLastCellNum() + 1; i++) {

            // Ensure category and service columns are valid
            assertColumnName(i, row);

            if (row.getCell((short)i) == null) {
                continue;
            }

            String column = HSSFUtils.getCellValue(row, i);
            if (!StringUtils.isEmpty(column)) {

                // Ensure column is not duplicated
                String normalizeColumn = column.trim().toLowerCase();
                if (columnNameSet.contains(normalizeColumn)) {
                    String name = "Category Data Import Error";
                    String context = "columnName=" + column;
                    String userMsg = "Column name '" + column + "' is duplicated in spreadsheet";
                    String solution = "Revise spreadsheet to remove duplicated column (case insenstive)";
                    throw new ApplicationException(name, context, userMsg, solution);
                }
                columnNameSet.add(normalizeColumn);

                columnNames.add(column.trim());
            }
        }

        this.categoryCode = category.getCategoryCode();

        // Determine the table name
        tableName = categoryCode.trim().toLowerCase().replace(" ", "_");
        tableName = "finder_" + tableName + "_data";

        // Determine the table column names
        for (String columnName : columnNames) {
            String tableColumnName = columnName.trim().toLowerCase().replace(" ", "_");
            tableColumnNames.add(tableColumnName);
        }

        // Determine the table column widths
        calculateMaxTableColumnWidths(categoryDataWorksheet);
    }

    /**
     * Return the category code.
     */
    public String getCategoryCode() {
        return categoryCode;
    }

    /**
     * Return the category column names.
     */
    public List<String> getColumnNames() {
        return columnNames;
    }

    /**
     * Return the normalised table column names.
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * Return the normalised table column names.
     */
    public List<String> getTableColumnNames() {
        return tableColumnNames;
    }

    /**
     * Return the maximum width of the table column.
     */
    public Integer getTableColumnWidth(String columnName) {
        Integer width = tableColumnWidths.get(columnName);

        return (width != null) ? width : 200;
    }

    // Private Methods --------------------------------------------------------

    private void assertColumnName(int index, HSSFRow row) {
        String columnName = HSSFUtils.getCellValue(row, index);

        if (index < CategoryDataContants.REQUIRED_COLUMN_NAMES.length) {

            String requiredName = CategoryDataContants.REQUIRED_COLUMN_NAMES[index];

            if (!requiredName.equalsIgnoreCase(columnName.trim())) {
                String name = "Category Data Import Error";
                String context = "Column " + columnHeaders[index] + " Row 1 value is " + columnName;
                String userMsg = "Column " + columnHeaders[index] + " Row 1 must have the value '" + requiredName + "'";
                String solution = "Revise spreadsheet to correct error column name error";
                throw new ApplicationException(name, context, userMsg, solution);
            }
        }
    }

    private void calculateMaxTableColumnWidths(HSSFSheet categoryDataWorksheet) {
        // Read Data Rows
        int lastRow = categoryDataWorksheet.getLastRowNum();

        for (int rowIndex = 1; rowIndex <= lastRow; rowIndex++) {
            HSSFRow row = categoryDataWorksheet.getRow(rowIndex);

            // Ignore blank rows
            if (row == null) {
                continue;

            } else {
                // If there is not data in the required columns data, then continue as its
                // most probably a blank row
                boolean foundValue = false;
                for (int j = 0; j < CategoryDataContants.REQUIRED_COLUMN_NAMES.length; j++) {
                    if (!HSSFUtils.isEmptyCell(row, j)) {
                        foundValue = true;
                        break;
                    }
                }
                if (!foundValue) {
                    continue;
                }
            }

            for (int columnIndex = 0; columnIndex < row.getLastCellNum() + 1; columnIndex++) {
                if (!HSSFUtils.isEmptyCell(row, columnIndex)) {
                    String columnName = getTableColumnNames().get(columnIndex);
                    String value = HSSFUtils.getCellValue(row, columnIndex);

                    Integer width = value.trim().length();

                    // Ensure data is not too large
                    if (width > CategoryDataContants.MAX_COLUMN_WIDTH) {
                        String reference = "'" + getColumnNames().get(rowIndex) + "' cell " +
                            columnHeaders[columnIndex] + (rowIndex + 1);

                        String name = "Category Data Import Error";
                        String context = reference + " value length is " + width + " characters";
                        String userMsg = reference + " value must be shorter than "
                            + CategoryDataContants.MAX_COLUMN_WIDTH + " characters";
                        String solution = "Revise spreadsheet to correct error row value error";
                        throw new ApplicationException(name, context, userMsg, solution);
                    }

                    Integer maxWidth = tableColumnWidths.get(columnName);
                    if (maxWidth == null || maxWidth < width) {
                        tableColumnWidths.put(columnName, width);
                    }
                }
            }
        }
    }
}

package com.avoka.fc.core.service.selenium;

import javax.servlet.http.HttpServletRequest;

import org.w3c.dom.Document;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.service.SubmissionDataBean;
import com.avoka.fc.core.service.SubmissionDataExtractionService;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides a data extraction service for Selenium testing which extracts the PDF XML
 * data via a request parameter.
 * <p/>
 * SeleniumTestRenderFormService will render an HTML form that automatically
 * submits XML data under the parameter key: {@link #TEST_DATA}.
 *
 * @see SeleniumTestRenderFormService
 */
public class SeleniumSubmissionDataExtractionService implements SubmissionDataExtractionService {

    public static final String TEST_DATA_PARAM = "testdata";

    public SubmissionDataBean extractData(HttpServletRequest request)
            throws ApplicationException {

        String xml = request.getParameter(TEST_DATA_PARAM);
        Document document = XmlUtils.parseDocumentFromString(xml);
        SubmissionDataBean data = new SubmissionDataBean(document);
        return data;
    }
}

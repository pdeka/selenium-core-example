package com.avoka.fc.core.service;

/**
 * Provides a meta data element bean.
 *
 * @author medgar@avoka.com
 */
public class MetaData {

    /** The name of the meta data element. */
    private String name;

    /** The scheme of the meta data element. */
    private String scheme;

    /** The content of the meta data element. */
    private String content;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}

package com.avoka.fc.core.service.finder;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.avoka.core.sql.StatementExecutor;
import com.avoka.core.util.HSSFUtils;
import com.avoka.fc.core.dao.NamedQueries;
import com.avoka.fc.core.entity.FinderCategory;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.util.ApplicationException;

public class CategoryDataService extends CayenneService {

    public void importCategoryData(FinderCategory category, InputStream inputStream) throws IOException, SQLException {
        Validate.notNull(category);
        Validate.notNull(inputStream);

        POIFSFileSystem fs = new POIFSFileSystem(inputStream);

        HSSFWorkbook wb = new HSSFWorkbook(fs);
        HSSFSheet categoryWorksheet = wb.getSheet(CategoryDataContants.WORKSHEET_CATEGORY_DATA);

        CategoryWorksheetMetaData categoryMetaData = new CategoryWorksheetMetaData(category, categoryWorksheet);

        dropCategoryDataTable(category);

        createCategoryTable(categoryMetaData);

        loadCategoryData(categoryMetaData, categoryWorksheet);

        category.setDataLoadedDatetime(new Date());
        commitChanges();
    }

    public void dropCategoryDataTable(FinderCategory category) {
        Validate.notNull(category);

        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        ResourceBundle resources = ResourceBundle.getBundle(getClass().getName(), Locale.getDefault(), classLoader);

        String dropTableKey = "drop-table-" + getDatabaseDialect();

        String tableName = category.getCategoryCode().trim().toLowerCase().replace(" ", "_");
        tableName = "finder_" + tableName + "_data";

        String dropStatement = MessageFormat.format(resources.getString(dropTableKey), tableName);

        StatementExecutor statementExecutor = new StatementExecutor();
        statementExecutor.execute(dropStatement);
    }

    // Private Methods --------------------------------------------------------

    /**
     * Return the database dialect [sqlserver | mysql]
     */
    private String getDatabaseDialect() {
        List<Map> databaseDialectResult = performNamedQuery(NamedQueries.DATABASE_DIALECT, true);
        String databaseDialect = null;

        if (databaseDialectResult.size() > 0) {
            Map resultRow = databaseDialectResult.get(0);
            databaseDialect = (String) resultRow.get("db_dialect");

            if (!StringUtils.isEmpty(databaseDialect) && !"unknown".equalsIgnoreCase(databaseDialect)) {
                return databaseDialect;
            }
        }

        throw new ApplicationException("UnknownDbProduct", "Attempting to determine database dialect", "Unknown database dialect: " + databaseDialect, null);
    }

    private void createCategoryTable(CategoryWorksheetMetaData categoryMetaData) throws SQLException {

        // Build create table SQL
        final StringBuilder tableCreateSQL = new StringBuilder();
        tableCreateSQL.append("create table ");
        tableCreateSQL.append(categoryMetaData.getTableName());
        tableCreateSQL.append(" (");

        Iterator<String> columnNames = categoryMetaData.getTableColumnNames().iterator();
        while (columnNames.hasNext()) {
            String columnName = columnNames.next();
            tableCreateSQL.append(" ");
            tableCreateSQL.append(columnName);
            tableCreateSQL.append(" varchar(");
            tableCreateSQL.append(categoryMetaData.getTableColumnWidth(columnName));
            tableCreateSQL.append(") null");
            if (columnNames.hasNext()) {
                tableCreateSQL.append(",");
            }
        }

        tableCreateSQL.append(");");

        // Execute create table SQL
        StatementExecutor statementExecutor = new StatementExecutor();
        statementExecutor.execute(tableCreateSQL.toString());

        // Create the column indexes
        for (String columnName : categoryMetaData.getTableColumnNames()) {
            int columnWidth = categoryMetaData.getTableColumnWidth(columnName);

            if (columnWidth <= 900) {
                StringBuilder createIndexSQL = new StringBuilder();
                createIndexSQL.append("create index ixf_");
                String tableName = categoryMetaData.getCategoryCode().trim().toLowerCase().replace(" ", "_");
                createIndexSQL.append(tableName);
                createIndexSQL.append("_");
                createIndexSQL.append(columnName);
                createIndexSQL.append(" on ");
                createIndexSQL.append(categoryMetaData.getTableName());
                createIndexSQL.append("(");
                createIndexSQL.append(columnName);
                createIndexSQL.append(")");

                statementExecutor = new StatementExecutor();
                statementExecutor.execute(createIndexSQL.toString());

            } else {
                String msg = "Could not create index on column '" + columnName +
                    "' as it's width is greater than 900 chars";
                getLogger().warn(msg);
            }
        }
    }

    private void loadCategoryData(CategoryWorksheetMetaData categoryMetaData, HSSFSheet categoryDataWorksheet)
        throws SQLException {

        // Read Data Rows
        int lastRow = categoryDataWorksheet.getLastRowNum();

        for (int i = 1; i <= lastRow; i++) {
            HSSFRow row = categoryDataWorksheet.getRow(i);

            // Ignore blank rows
            if (row == null) {
                continue;

            } else {
                // If there is not data in the required columns data, then continue as its
                // most probably a blank row
                boolean foundValue = false;
                for (int j = 0; j < CategoryDataContants.REQUIRED_COLUMN_NAMES.length; j++) {
                    if (!HSSFUtils.isEmptyCell(row, j)) {
                        foundValue = true;
                        break;
                    }
                }
                if (!foundValue) {
                    continue;
                }
            }

            DataRow dataRow = new DataRow(i, row, categoryMetaData);

            String insertSQL = dataRow.createInsertStatement();
            StatementExecutor statementExecutor = new StatementExecutor();
            statementExecutor.execute(insertSQL);
        }
    }

}

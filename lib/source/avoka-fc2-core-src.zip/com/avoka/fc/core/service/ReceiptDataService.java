package com.avoka.fc.core.service;

import java.text.DateFormat;
import java.util.Date;

import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.AvokaTemplateSchema;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.dao.FormDeployXmlDao;
import com.avoka.fc.core.dao.TemplateVersionDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.XPath;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

public class ReceiptDataService extends CayenneService {


    /**
     * Returns whether a submission has receipt data
     * Note: If a submission has been deleted, this will return false. If a submission has no receipt data but does have submission data, the receipt data can be generated from the form data.
     *
     * @param submission the submission
     * @return whether receipt data is available for the submission
     */
    public boolean hasReceiptXml(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        if (submission.isDeleted()) {
            return false;
        }
        SubmissionData submissionData = submission.getSubmissionData();
        return (submissionData != null && submissionData.getSubmissionData() != null && submissionData.getSubmissionData().length > 0);
    }

    /**
     * Returns the receipt xml data for a submission
     * If a submission has no receipt data but does have submission data, the receipt data will be generated from the form data.
     *
     * If receipt data has to be generated from form data, this method stores and commits the receipt data.
     *
     * @param submission the submission
     * @return whether receipt data is available for the submission
     * @throws ApplicationException if the submission is deleted or has neither submission nor receipt data
     */
    public String getReceiptXml(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        SubmissionData submissionData = submission.getSubmissionData();
        if (submission.isDeleted() || submissionData == null || submissionData.getSubmissionData() == null || submissionData.getSubmissionData().length == 0) {
            // no receipt data available
            String context = "Submission=" + submission.getId();
            String message = "Submission contains no receipt data";
            throw new ApplicationException("ReceiptDataService", context, message, null);
        }

        String receiptXml = submissionData.getSubmissionDataString();
        return receiptXml;
    }

    /**
     * Allows to set the receipt number and payment date to be written in to the Receipt section
     * The Receipt section is looked up using the schema config map for the submission's form deploy
     * Note that this method does NOT commit the changes, it merely writes them into the submission's receipt data.
     *
     * @param submission the submission
     * @param receiptNo the receipt number to be used
     * @param paymentDate the date and time of payment
     */
    public void setPaymentReceiptDetails(Submission submission, String receiptNo, Date paymentDate) {
        Validate.notNull(submission, "Null submission parameter");
        Validate.notEmpty(receiptNo, "Empty receiptNo parameter");
        Validate.notNull(paymentDate, "Null paymentDate parameter");

        String receiptXml = getReceiptXml(submission);

        Document document = XmlUtils.parseDocumentFromString(receiptXml, false, false);
        SystemProfileHelper systemProfileHelper = new SystemProfileHelper(document);
        String receiptXPath = getReceiptXPath(systemProfileHelper);

        if (receiptXPath != null) {
            if (submission.isDeliveryCompleted() || Submission.STATUS_Sent_WS.equalsIgnoreCase(submission.getDeliveryStatus())) {
                // do not modify the form xml if the submission has already been delivered or delivery to FCIC has been attempted
                // this should not happen since delivery should happen only after payment has completed
                EventLogService eventLogService = ServiceFactory.getEventLogService();
                eventLogService.logWarnEvent("Ignored attempt to modify submission after delivery has been initiated", submission);

            } else {
                XPath formXPath = new XPath(document);
                formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_RECEIPT_NO, receiptNo);

                DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();
                DateFormat dateFormat = deploymentPropertyDao.getPropertyDateFormat(DeploymentProperty.PROPERTY_Date_Time_Format_Long);
                String dateTime = dateFormat.format(paymentDate);
                formXPath.setNodeValue(receiptXPath + "/" + AvokaTemplateSchema.RECEIPT_RECEIPT_DATE_TIME, dateTime);

                receiptXml = XmlUtils.toString(document);

                SubmissionData submissionData = submission.getSubmissionData();
                if (submissionData == null) {
                    submissionData = new SubmissionData();
                    registerNewObject(submissionData);
                    submissionData.setSubmission(submission);
                }
                submissionData.setSubmissionDataString(receiptXml);

                submission.calculateFormXmlHash();
            }
        }
    }

    public byte[] getReceiptPdf(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        SubmissionData submissionData = submission.getSubmissionData();
        if (submission.isDeleted() || submissionData == null || submissionData.getReceiptData() == null || submissionData.getReceiptData().length == 0) {
            // no receipt data available
            String context = "Submission=" + submission.getId();
            String message = "Submission contains no receipt data";
            throw new ApplicationException("ReceiptDataService", context, message, null);
        }

        return submissionData.getReceiptData();
    }

    protected String generateReceiptFromFormXml(String formXml) {
        // set the display mode
        Document document = XmlUtils.parseDocumentFromString(formXml, false, false);
        SystemProfileHelper receiptSystemProfileHelper = new SystemProfileHelper(document);
        receiptSystemProfileHelper.setDisplayMode(SystemProfileHelper.MODE_RECEIPT);

        String receiptXml = XmlUtils.toString(document);
        return receiptXml;
    }

    /**
     * Return the Receipt XPath for the given submission SystemProfile.
     *
     * @param systemProfileHelper submission SystemProfileHelper
     * @return the form receipt XPath
     */
    protected String getReceiptXPath(SystemProfileHelper systemProfileHelper) {

        // attempt to retrieve the form deploy
        String formDeployOid = systemProfileHelper.getFormDeployOid();
        FormDeployXmlDao formDeployXMLDao = new FormDeployXmlDao();
        FormDeployXml formDeployXml = formDeployXMLDao.getFormDeployXmlFromPK(formDeployOid);

        if (formDeployXml == null) {
            // most likely means we're on a system in non-production mode and the form deploy has been regenerated
            String formCode = systemProfileHelper.getFormCode();
            FormDao formDao = DaoFactory.getFormDao();
            Form form = formDao.getFormByFormCode(formCode);
            String templateVersionOid = systemProfileHelper.getTemplateVersionOid();
            TemplateVersionDao templateVersionDao = DaoFactory.getTemplateVersionDao();
            TemplateVersion templateVersion = templateVersionDao.getTemplateVersionFromPK(templateVersionOid);
            formDeployXml = formDeployXMLDao.getFormDeployXML(form, templateVersion);
        }

        if (formDeployXml == null) {
            // no form deploy could be found - hence no receipt path
            String formCode = systemProfileHelper.getFormCode();
            EventLogService eventLogService = ServiceFactory.getEventLogService();
            eventLogService.logWarnEvent("No form deploy found for form " + formCode + ". The receipt section cannot be populated.");

            return null;
        }

        String receiptXPath = formDeployXml.getSchemaConfigXPath(SchemaConfigMap.NAME_RECEIPT);
        if (receiptXPath != null) {
            return receiptXPath;

        } else {
            String msg = "No " + SchemaConfigMap.NAME_RECEIPT + " Schema Config Map defined for"
                + " Submission ID: " + systemProfileHelper.getSubmissionNumber();
            throw new ApplicationException("CardPayment", msg, msg, null);
        }
    }
}

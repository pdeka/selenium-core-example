package com.avoka.fc.core.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.entity.XmlInDeployMap;

public class XmlPrefillService {

    public void mergeXmlData(Document sourceDocument, Document targetDocument, List<XmlInDeployMap> xmlInDeployMaps) {

        for (XmlInDeployMap xmlInDeployMap : xmlInDeployMaps) {
            Element sourceElement = XmlUtils.getXPathElement(sourceDocument, xmlInDeployMap.getInXpath());

            if (sourceElement != null) {
                Element targetElement = getOrCreateElement(targetDocument, xmlInDeployMap.getOutXpath());

                copy(sourceElement, targetDocument, targetElement);
            }
        }
    }

    // Protected Methods --------------------------------------------------------

    private void copy(Element sourceElement, Document targetDocument, Element targetElement) {

        copyAttributes(sourceElement, targetElement);

        Map<String, Element> previousElementMap = new HashMap<String, Element>();

        for (int i = 0; i < sourceElement.getChildNodes().getLength(); i++) {

            Node childNode = sourceElement.getChildNodes().item(i);

            if (childNode.getNodeType() == Node.TEXT_NODE) {
                String textValue = String.valueOf(childNode.getNodeValue());

                if (targetElement.getFirstChild() != null && (targetElement.getFirstChild() instanceof Text)) {
                    Text textNode = (Text) targetElement.getFirstChild();
                    textNode.setData(textValue);

                } else {
                    Text textNode = targetDocument.createTextNode(textValue);
                    targetElement.appendChild(textNode);
                }

            } else {
                Element targetChildElement = XmlUtils.getLastChild(targetElement, childNode.getNodeName());

                // If not found create a new element
                if (targetChildElement == null) {
                    targetChildElement = targetDocument.createElement(childNode.getNodeName());
                    targetElement.appendChild(targetChildElement);

                } else {
                    // If found then check whether this element has already been processed
                    Element previousElement = previousElementMap.get(childNode.getNodeName());

                    // If already processed then create a new element
                    if (previousElement == targetChildElement) {
                        targetChildElement = targetDocument.createElement(childNode.getNodeName());
                        targetElement.appendChild(targetChildElement);
                    }
                }

                previousElementMap.put(childNode.getNodeName(), targetChildElement);

                Element newSourceElement = (Element) childNode;
                copy(newSourceElement, targetDocument, targetChildElement);
            }
        }
    }

    private void copyAttributes(Element sourceElement, Element targetElement) {

        NamedNodeMap sourceAttributesMap = sourceElement.getAttributes();

        for (int i = 0; i < sourceAttributesMap.getLength(); i++) {
            Node sourceAttribute = sourceAttributesMap.item(i);
            String name = sourceAttribute.getNodeName();
            String value = sourceAttribute.getNodeValue();

            targetElement.setAttribute(name, value);
        }
    }

    private Element getOrCreateElement(Document document, String elementXPath) {
        Validate.notNull(document, "Null document parameter");
        Validate.notNull(elementXPath, "Null elementXPath parameter");

        Element element = getElement(document, elementXPath);

        if (element != null) {
            return element;

        } else {
            // Else create the element using the provided element xpath

            // First strip off leading and trailing //.
            if (elementXPath.startsWith("//")) {
                elementXPath = elementXPath.substring(2, elementXPath.length());
            }
            if (elementXPath.endsWith("/")) {
                elementXPath = elementXPath.substring(0, elementXPath.length() - 1);
            }

            String[] elements = elementXPath.split("/");

            Element parent = document.getDocumentElement();

            for (String value : elements) {
                Element childElement = XmlUtils.getChild(parent, value);

                if (childElement != null) {
                    parent = childElement;

                } else {
                    Element valueElement = document.createElement(value);
                    parent.appendChild(valueElement);
                    parent = valueElement;
                }
            }

            // Return the last element created
            return parent;
        }
    }

    /**
     * Return the configured schema element for the given schema config name and XML document.
     *
     * @param document the XML document
     * @param schema the XML schema definition
     * @param name the name of the schema config xpath
     * @return the configured schema element for the given schema config name and XML document
     */
    private Element getElement(Document document, String elementXPath) {
        Validate.notNull(document, "Null document parameter");
        Validate.notNull(elementXPath, "Null elementXPath parameter");

        if (elementXPath.endsWith("/")) {
            elementXPath = elementXPath.substring(0, elementXPath.length() - 1);
        }

        try {
            XPathFactory factory = XPathFactory.newInstance();
            XPath xpath = factory.newXPath();

            XPathExpression expr = xpath.compile(elementXPath);

            Object result = expr.evaluate(document, XPathConstants.NODESET);

            NodeList nodes = (NodeList) result;
            if (nodes.getLength() > 0) {
                return (Element) nodes.item(0);

            } else {
                return null;
            }

        } catch (XPathExpressionException xee) {
            String msg = "XPath expression error for xpath '" + elementXPath + "'";
            throw new RuntimeException(msg, xee);
        }
    }

}

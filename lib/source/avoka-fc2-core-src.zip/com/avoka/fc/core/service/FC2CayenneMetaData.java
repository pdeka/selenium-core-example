package com.avoka.fc.core.service;

import com.avoka.core.xml.export.MetaDataManager;
import com.avoka.core.xml.export.MetaDataTableBean;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.DocumentType;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.FormPdfParams;
import com.avoka.fc.core.entity.FormProperty;
import com.avoka.fc.core.entity.MetadataListValue;
import com.avoka.fc.core.entity.MetadataTag;
import com.avoka.fc.core.entity.MetadataValue;
import com.avoka.fc.core.entity.MetadataValueDeploy;
import com.avoka.fc.core.entity.PaymentAccount;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalPage;
import com.avoka.fc.core.entity.PortalProperty;
import com.avoka.fc.core.entity.PortalResource;
import com.avoka.fc.core.entity.PromotionLog;
import com.avoka.fc.core.entity.PropertyDeploy;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.PropertyTypeMap;
import com.avoka.fc.core.entity.Report;
import com.avoka.fc.core.entity.ReportClient;
import com.avoka.fc.core.entity.ReportParameter;
import com.avoka.fc.core.entity.ReportSchedule;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.Role;
import com.avoka.fc.core.entity.RolePermission;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.SchemaDeployMap;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.ServiceConnection;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.SpecifiedAttachmentDeploy;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SupportLog;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.TemplateVersionData;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.entity.UserDeployMap;
import com.avoka.fc.core.entity.XmlInDeployMap;
import com.avoka.fc.core.entity.XmlInputMap;
import com.avoka.fc.core.entity.XmlInputVersion;

public class FC2CayenneMetaData extends MetaDataManager{

    public FC2CayenneMetaData(){
        loadMetaData();
    }

    public void loadMetaData(){

        // TODO PRC Make sure that all alternate keys have unique indexs defined

        // Sequence is important!
        MetaDataTableBean tableBean = new MetaDataTableBean(Client.class, true, true);
        tableBean.addAlternateKey(Client.CLIENT_CODE_PROPERTY);
        tableBean.addDependantEntity(Client.CLIENT_PROPERTIES_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(PropertyType.class, true, true);
        tableBean.addAlternateKey(PropertyType.NAME_PROPERTY);
        tableBean.addAlternateKey(PropertyType.SCOPE_PROPERTY);
        tableBean.addAlternateKey(PropertyType.CLIENT_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(ClientProperty.class, false, false);
        tableBean.addAlternateKey(ClientProperty.CLIENT_PROPERTY);
        tableBean.addAlternateKey(ClientProperty.PROPERTY_TYPE_PROPERTY);
        tableBean.addAlternateKey(ClientProperty.SEQUENCE_PROPERTY);
        tableBean.addAlternateKey(ClientProperty.VALUE_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(PaymentAccount.class, true, true);
        tableBean.addAlternateKey(PaymentAccount.USER_PROPERTY);
        tableBean.addAlternateKey(PaymentAccount.CLIENT_PROPERTY);
        tableBean.addAlternateKey(PaymentAccount.ACCOUNT_NUMBER_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(ServiceConnection.class, false, true);
        tableBean.addAlternateKey(ServiceConnection.NAME_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(ServiceDefinition.class, true, true);
        tableBean.addAlternateKey(ServiceDefinition.SERVICE_NAME_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(DeliveryDetails.class, true, true);
        tableBean.addAlternateKey(DeliveryDetails.NAME_PROPERTY);
        tableBean.addAlternateKey(DeliveryDetails.CLIENT_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(SchemaSeed.class, false, true);
        tableBean.addAlternateKey(SchemaSeed.NAME_PROPERTY);
        tableBean.addAlternateKey(SchemaSeed.CLIENT_PROPERTY);
        tableBean.addDependantEntity(SchemaSeed.SCHEMA_CONFIG_MAPS_PROPERTY);
        tableBean.addDependantEntity(SchemaSeed.XML_INPUT_VERSIONS_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(SchemaConfigMap.class, false, true);
        tableBean.addAlternateKey(SchemaConfigMap.NAME_PROPERTY);
        tableBean.addAlternateKey(SchemaConfigMap.SCHEMA_PROPERTY);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(XmlInputVersion.class, false, true);
        tableBean.addAlternateKey(XmlInputVersion.SCHEMA_PROPERTY);
        tableBean.addAlternateKey(XmlInputVersion.VERSION_NAME_PROPERTY);
        tableBean.addDependantEntity(XmlInputVersion.XML_INPUT_MAP_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(Template.class, true, true);
        tableBean.addAlternateKey(Template.TEMPLATE_CODE_PROPERTY);
        tableBean.addAlternateKey(Template.CLIENT_PROPERTY);
        tableBean.addLateResolveFK(Template.CURRENT_VERSION_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(TemplateVersionData.class, true, false);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(TemplateVersion.class, true, true);
        tableBean.addAlternateKey(TemplateVersion.TEMPLATE_PROPERTY);
        tableBean.addAlternateKey(TemplateVersion.VERSION_NUMBER_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(Portal.class, true, true);
        tableBean.addAlternateKey(Portal.NAME_PROPERTY);
        tableBean.addDependantEntity(Portal.PORTAL_PAGES_PROPERTY);
        tableBean.addDependantEntity(Portal.PORTAL_RESOURCES_PROPERTY);
        tableBean.addDependantEntity(Portal.PORTAL_PROPERTIES_PROPERTY);
        tableBean.addDependantEntity(Portal.PERMISSIONS_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(PortalPage.class, true, true);
        tableBean.addAlternateKey(PortalPage.PORTAL_PROPERTY);
        tableBean.addAlternateKey(PortalPage.NAME_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(PortalResource.class, true, true);
        tableBean.addAlternateKey(PortalResource.PORTAL_PROPERTY);
        tableBean.addAlternateKey(PortalResource.PATH_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(PortalProperty.class, true, true);
        tableBean.addAlternateKey(PortalProperty.PORTAL_PROPERTY);
        tableBean.addAlternateKey(PortalProperty.NAME_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(Form.class, true, true);
        tableBean.addAlternateKey(Form.CLIENT_FORM_CODE_PROPERTY);
        tableBean.addDependantEntity(Form.FORM_PROPERTIES_PROPERTY);
        tableBean.addDependantEntity(Form.PDF_PARAMS_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(FormPdfParams.class, true, true);
        tableBean.addAlternateKey(FormPdfParams.FORM_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(FormProperty.class, false, false);
        tableBean.addAlternateKey(FormProperty.FORM_PROPERTY);
        tableBean.addAlternateKey(FormProperty.PROPERTY_TYPE_PROPERTY);
        tableBean.addAlternateKey(FormProperty.SEQUENCE_PROPERTY);
        tableBean.addAlternateKey(FormProperty.VALUE_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(FormDeployXml.class, true, true);
        tableBean.addAlternateKey(FormDeployXml.FORM_PROPERTY);
        tableBean.addAlternateKey(FormDeployXml.TEMPLATE_VERSION_PROPERTY);
        tableBean.addDependantEntity(FormDeployXml.SCHEMA_DEPLOY_MAPS_PROPERTY);
        tableBean.addDependantEntity(FormDeployXml.USER_DEPLOY_MAPS_PROPERTY);
        tableBean.addDependantEntity(FormDeployXml.XML_IN_DEPLOY_MAPS_PROPERTY);
        tableBean.addDependantEntity(FormDeployXml.METADATA_CONTENT_LIST_PROPERTY);
        tableBean.addDependantEntity(FormDeployXml.PROPERTY_DEPLOY_LIST_PROPERTY);
        tableBean.addDependantEntity(FormDeployXml.SPECIFIED_ATTACHMENT_DEPLOY_LIST_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(SchemaDeployMap.class, true, false);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(UserDeployMap.class, true, false);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(XmlInDeployMap.class, true, false);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(MetadataValueDeploy.class, true, false);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(PropertyDeploy.class, true, false);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(SpecifiedAttachmentDeploy.class, true, false);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(MetadataTag.class, true, true);
        tableBean.addAlternateKey(MetadataTag.NAME_PROPERTY);
        tableBean.addAlternateKey(MetadataTag.CLIENT_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(MetadataListValue.class, true, false);
        tableBean.addAlternateKey(MetadataListValue.METADATA_TAG_PROPERTY);
        tableBean.addAlternateKey(MetadataListValue.PARENT_VALUE_PROPERTY);
        tableBean.addAlternateKey(MetadataListValue.VALUE_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(MetadataValue.class, true, false);
        tableBean.addAlternateKey(MetadataValue.METADATA_TAG_PROPERTY);
        tableBean.addAlternateKey(MetadataValue.CLIENT_PROPERTY);
        tableBean.addAlternateKey(MetadataValue.FORM_PROPERTY);
        tableBean.addAlternateKey(MetadataValue.TEMPLATE_PROPERTY);
        tableBean.addAlternateKey(MetadataValue.VALUE_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(PropertyTypeMap.class, false, false);
        tableBean.addAlternateKey(PropertyTypeMap.PROPERTY_TYPE_PROPERTY);
        tableBean.addAlternateKey(PropertyTypeMap.SCHEMA_PROPERTY);
        tableBean.addAlternateKey(PropertyTypeMap.XPATH_PROPERTY);
        addEntity(tableBean);

        tableBean = new MetaDataTableBean(XmlInputMap.class, false, false);
        tableBean.setDependantEntityFlag(true);
        tableBean.addAlternateKey(XmlInputMap.XML_INPUT_VERSION_PROPERTY);
        tableBean.addAlternateKey(XmlInputMap.IN_XPATH_PROPERTY);
        tableBean.addAlternateKey(XmlInputMap.OUT_XPATH_PROPERTY);
        addEntity(tableBean);

        // Document Type
        tableBean = new MetaDataTableBean(DocumentType.class, false, true);
        tableBean.addAlternateKey(DocumentType.CODE_PROPERTY);
        tableBean.addAlternateKey(DocumentType.CLIENT_PROPERTY);
        addEntity(tableBean);

        // Specified attachments
        tableBean = new MetaDataTableBean(SpecifiedAttachment.class, false, true);
        tableBean.addAlternateKey(SpecifiedAttachment.ATTACHMENT_NAME_PROPERTY);
        // PRC 31/5/2008 Note that it will be either form or template
        tableBean.addAlternateKey(SpecifiedAttachment.FORM_PROPERTY);
        tableBean.addAlternateKey(SpecifiedAttachment.TEMPLATE_PROPERTY);
        addEntity(tableBean);

        // PromotionLog (Used for Delete)
        tableBean = new MetaDataTableBean(PromotionLog.class, true, true);
        tableBean.addAlternateKey(PromotionLog.FORM_PROPERTY);
        tableBean.addAlternateKey(PromotionLog.VERSION_PROPERTY);
        addEntity(tableBean);

        // RequestLog (Used for Delete)
        tableBean = new MetaDataTableBean(RequestLog.class, true, false);
        tableBean.addAlternateKey(RequestLog.FORM_PROPERTY);
        tableBean.addAlternateKey(RequestLog.TEMPLATE_VERSION_PROPERTY);
        addEntity(tableBean);

        // SubmissionLog (Used for Delete)
        tableBean = new MetaDataTableBean(Submission.class, true, false);
        addEntity(tableBean);

        // SupportLog (Used for Delete)
        tableBean = new MetaDataTableBean(SupportLog.class, true, false);
        addEntity(tableBean);


        // Admin
        tableBean = new MetaDataTableBean(UserAccount.class, true, false);
        tableBean.addAlternateKey(UserAccount.LOGIN_NAME_PROPERTY);
        addEntity(tableBean);

        // Permission
        tableBean = new MetaDataTableBean(Permission.class, true, false);
        tableBean.addAlternateKey(Permission.PORTAL_PROPERTY);
        tableBean.addAlternateKey(Permission.PERMISSION_NAME_PROPERTY);
        addEntity(tableBean);

        // Role
        tableBean = new MetaDataTableBean(Role.class, true, false);
        tableBean.addAlternateKey(Role.ROLE_NAME_PROPERTY);
        addEntity(tableBean);

        // RolePermission
        tableBean = new MetaDataTableBean(RolePermission.class, true, false);
        tableBean.addAlternateKey(RolePermission.PERMISSION_PROPERTY);
        tableBean.addAlternateKey(RolePermission.ROLE_PROPERTY);
        addEntity(tableBean);

        // Report
        tableBean = new MetaDataTableBean(Report.class, true, false);
        tableBean.addAlternateKey(Report.NAME_PROPERTY);
        tableBean.addDependantEntity(Report.PARAMETERS_PROPERTY);
        addEntity(tableBean);

        // ReportParameter
        tableBean = new MetaDataTableBean(ReportParameter.class, true, false);
        tableBean.setDependantEntityFlag(true);
        addEntity(tableBean);

        // ReportClient
        tableBean = new MetaDataTableBean(ReportClient.class, true, true);
        tableBean.addAlternateKey(ReportClient.CLIENT_PROPERTY);
        tableBean.addAlternateKey(ReportClient.REPORT_PROPERTY);
        tableBean.addDependantEntity(ReportClient.SCHEDULED_REPORTS_PROPERTY);
        addEntity(tableBean);

        // ReportSchedule
        tableBean = new MetaDataTableBean(ReportSchedule.class, true, false);
        tableBean.setDependantEntityFlag(true);
        tableBean.addAlternateKey(ReportSchedule.REPORT_CLIENT_PROPERTY);
        tableBean.addAlternateKey(ReportSchedule.SYSTEM_REPORT_PROPERTY);
        tableBean.addAlternateKey(ReportSchedule.DELIVERY_EMAIL_PROPERTY);
        tableBean.addAlternateKey(ReportSchedule.OUTPUT_FORMAT_TYPE_PROPERTY);
        addEntity(tableBean);



    }
}

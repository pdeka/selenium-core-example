/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service.impl;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.PaymentLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.service.CardPaymentService;

public class DemoCardPaymentService extends TNSCardPaymentService {

    // --------------------------------------------------------- Public Methods

    public static final String PAYMENT_SERVICE_CODE_DEMO = "DEMO";

    /**
     * @see CardPaymentService#performPayment(Submission, String, String, String, String)
     */
    public PaymentLog performPayment(Submission submission, String cardNumber, String cardExpiryDate, String cardCsc, String ipAddress) {

        Validate.notNull(submission, "Null submission parameter");
        Validate.notNull(cardNumber, "Null cardNumber parameter");
        Validate.notNull(cardExpiryDate, "Null cardExpiryDate parameter");
        Validate.notNull(cardCsc, "Null cardCsc parameter");

        // If completed return first successful payment
        if (submission.isPaymentCompleted()) {
            List payments = submission.getPayments();
            for (Iterator i = payments.iterator(); i.hasNext();) {
                PaymentLog paymentLog = (PaymentLog) i.next();
                if (paymentLog.isPaymentCompleted()) {
                    return paymentLog;
                }
            }
            return (PaymentLog) payments.get(payments.size() - 1);
        }

        Client client = submission.getClient();

        // Client details
        String vpc_AccessCode = client.getPaymentAccessCode();
        String vpc_MerchantId = client.getPaymentMerchantId();

        // Get payment amount and convert to cents
        Integer vpc_Amount = getPaymentTotal(submission);

        // Create payment log record and complete DO fields
        PaymentLog paymentLog = (PaymentLog) createAndRegisterNewObject(PaymentLog.class);
        paymentLog.setDoTimestamp(new Date());
        paymentLog.setSubmission(submission);
        paymentLog.setPaymentServiceCode(PAYMENT_SERVICE_CODE_DEMO);

        paymentLog.setDoAmount(vpc_Amount);
        paymentLog.setDoMerchant(vpc_MerchantId);
        paymentLog.setDoVersion(VPC_VERSION_VALUE);

        commitChanges();

        // Set merchant transaction reference to payment log id
        String vpc_MerchTxnRef = paymentLog.getId().toString();
        paymentLog.setDoMerchTxnRef(vpc_MerchTxnRef);

        commitChanges();

        // Order details
        String vpc_OrderInfo = paymentLog.getId().toString();

        // Create request URL
        Map params = new HashMap();

        params.put(VPC_ACCESS_CODE, vpc_AccessCode);
        params.put(VPC_AMOUNT, vpc_Amount);
        params.put(VPC_CARD_EXP, cardExpiryDate);
        params.put(VPC_CARD_NUM, cardNumber);

        if (StringUtils.isNotBlank(cardCsc)) {
            params.put(VPC_CARD_SECURITY_CODE, cardCsc);
        }

        params.put(VPC_COMMAND, VPC_COMMAND_PAY);
        params.put(VPC_MERCHANT, vpc_MerchantId);
        params.put(VPC_MERCH_TXN_REF, vpc_MerchTxnRef);
        params.put(VPC_ORDER_INFO, vpc_OrderInfo);
        params.put(VPC_VERSION, VPC_VERSION_VALUE);

        String paymentAmount = submission.getPaymentTotal().toString();
        String txnResponseCode = TXN_RESPONSE_CODE_SUCCESS_VALUE;
        if (paymentAmount.endsWith(".10")) {
            txnResponseCode = "1";
        } else if (paymentAmount.endsWith(".01")) {
            txnResponseCode = "E";
        } else if (paymentAmount.endsWith(".05")) {
            txnResponseCode = "2";
        } else if (paymentAmount.endsWith(".68")) {
            txnResponseCode = "3";
        } else if (paymentAmount.endsWith(".54")) {
            txnResponseCode = "4";
        } else if (paymentAmount.endsWith(".51")) {
            txnResponseCode = "5";
        }
        params.put(VPC_TXN_RESPONSE_CODE, txnResponseCode);

        if (txnResponseCode.equals(TXN_RESPONSE_CODE_SUCCESS_VALUE)) {
            String receiptNumber = StringUtils.reverse(submission.getId().toString());
            params.put(VPC_RECEIPT_NO, receiptNumber);
        }

        return processPaymentReceipt(paymentLog, params);
    }

    /**
     * @see CardPaymentService#performQuery(PaymentLog)
     */
    public Map performQuery(PaymentLog paymentLog) {
        return Collections.EMPTY_MAP;
    }

    /**
     * @see CardPaymentService#resolveOutstandingPayments()
     */
    public void resolveOutstandingPayments() {
    }

    // ----------------------------------------------- Package Private Methods

//    /**
//     * @see DialectCardPaymentService#updateFormReceiptInfo(PaymentLog)
//     */
//    void updateFormReceiptInfo(PaymentLog paymentLog) {
//        Submission submission = paymentLog.getSubmission();
//
//        paymentLog.setDrTxnResponseMsg("Transaction approved");
//
//        ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
//        receiptDataService.setPaymentReceiptDetails(submission, paymentLog.getId().toString(), new Date());
//
//        submission.setPaymentStatus(Submission.STATUS_Completed);
//        paymentLog.setPaymentStatus(PaymentLog.STATUS_Completed);
//    }

}

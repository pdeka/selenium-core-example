/*
 * Copyright (c) 2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service.impl;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.core.util.FileUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.DeliveryProcessService;
import com.avoka.fc.core.service.EmailService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.EventLogService;
import com.avoka.fc.core.service.ReceiptDataService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.service.ServiceLocator;
import com.avoka.fc.core.service.SubmissionDeliveryService;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.RemoteUserProvider;
import com.avoka.fc.core.util.StringTemplate;
import com.avoka.fc.core.util.SubmissionBeanUtils;
import com.avoka.fc.forms.api.AttachmentConfirmation;
import com.avoka.fc.forms.api.FormsClientWebService;
import com.avoka.fc.forms.api.SubmissionConfirmation;
import com.avoka.fc.forms.api.utils.DataHashUtils;

/**
 * Provides a SubmissionDeliveryService object.
 */
public class SubmissionDeliveryServiceImpl extends CayenneService implements SubmissionDeliveryService {

    // Constants --------------------------------------------------------------

    public static final String PARAM_EMAIL_DELIVERY_SENDER = "deliveryEmailSender";
    public static final String PARAM_EMAIL_ESCALATION_SUBJECT = "deliveryEmailEscalationSubject";
    public static final String PARAM_EMAIL_ESCALATION_MESSAGE = "deliveryEmailEscalationMessage";
    public static final String PARAM_EMAIL_ESCALATION_AGE = "deliveryEmailEscalationAgeHours";

    // Constants related to standard email delivery
    public static final String PARAM_STANDARD_EMAIL_DELIVERY_SUBJECT = "standardEmailDeliverySubject";
    public static final String PARAM_STANDARD_EMAIL_DELIVERY_MESSAGE = "standardEmailDeliveryMessage";

    // Constants related to secure email delivery
    public static final String PARAM_SECURE_EMAIL_DELIVERY_SUBJECT = "secureEmailDeliverySubject";
    public static final String PARAM_SECURE_EMAIL_DELIVERY_MESSAGE = "secureEmailDeliveryMessage";
    public static final String PARAM_SECURE_EMAIL_REMINDER_SUBJECT = "secureEmailReminderSubject";
    public static final String PARAM_SECURE_EMAIL_REMINDER_MESSAGE = "secureEmailReminderMessage";
    public static final String PARAM_SECURE_EMAIL_REMINDER_AGE = "secureEmailReminderAgeHours";

    // Private Variables ------------------------------------------------------

    protected DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
    protected ErrorLogService       errorLogService       = new ErrorLogService();
    protected EventLogService       eventLogService       = new EventLogService();

    private String deliveryEmailSender;
    private String deliveryEmailEscalationSubject;
    private String deliveryEmailEscalationMessage;
    private String deliveryEmailEscalationAgeHours;

    private String standardEmailDeliveryMessage;
    private String standardEmailDeliverySubject;

    private String secureEmailDeliverySubject;
    private String secureEmailDeliveryMessage;
    private String secureEmailReminderSubject;
    private String secureEmailReminderMessage;
    private String secureEmailReminderAgeHours;

    // Public Properties ------------------------------------------------------

    public String getDeliveryEmailSender() {
        return deliveryEmailSender;
    }

    public void setDeliveryEmailSender(String newSender) {
        deliveryEmailSender = newSender;
    }

    public String getDeliveryEmailEscalationSubject() {
        return deliveryEmailEscalationSubject;
    }

    public void setDeliveryEmailEscalationSubject(String newSubject) {
        deliveryEmailEscalationSubject = newSubject;
    }

    public String getDeliveryEmailEscalationMessage() {
        return deliveryEmailEscalationMessage;
    }

    public void setDeliveryEmailEscalationMessage(String newMessage) {
        deliveryEmailEscalationMessage = newMessage;
    }

    public String getDeliveryEmailEscalationAgeHours() {
        return deliveryEmailEscalationAgeHours;
    }

    public void setDeliveryEmailEscalationAgeHours(String newAge) {
        deliveryEmailEscalationAgeHours = newAge;
    }

    public String getStandardEmailDeliveryMessage() {
        return standardEmailDeliveryMessage;
    }

    public void setStandardEmailDeliveryMessage(String newMessage) {
        standardEmailDeliveryMessage = newMessage;
    }

    public String getStandardEmailDeliverySubject() {
        return standardEmailDeliverySubject;
    }

    public void setStandardEmailDeliverySubject(String newSubject) {
        standardEmailDeliverySubject = newSubject;
    }

    public String getSecureEmailDeliverySubject() {
        return secureEmailDeliverySubject;
    }

    public void setSecureEmailDeliverySubject(String newSubject) {
        secureEmailDeliverySubject = newSubject;
    }

    public String getSecureEmailDeliveryMessage() {
        return secureEmailDeliveryMessage;
    }

    public void setSecureEmailDeliveryMessage(String newMessage) {
        secureEmailDeliveryMessage = newMessage;
    }

    public String getSecureEmailReminderSubject() {
        return secureEmailReminderSubject;
    }

    public void setSecureEmailReminderSubject(String newSubject) {
        secureEmailReminderSubject = newSubject;
    }

    public String getSecureEmailReminderMessage() {
        return secureEmailReminderMessage;
    }

    public void setSecureEmailReminderMessage(String newMessage) {
        secureEmailReminderMessage = newMessage;
    }

    public String getSecureEmailReminderAgeHours() {
        return secureEmailReminderAgeHours;
    }

    public void setSecureEmailReminderAgeHours(String newAge) {
        secureEmailReminderAgeHours = newAge;
    }

    // Public Methods ---------------------------------------------------------

    /**
     * @see SubmissionDeliveryService#deliverSubmission(Submission)
     */
    public String deliverSubmission(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        Form form = submission.getForm();

        // Get the appropriate delivery details
        DeliveryDetails deliveryDetails = null;
        if (submission.isTestMode()) {
            deliveryDetails = form.getDeliveryTest();
        } else {
            deliveryDetails = form.getDeliveryProd();
        }

        if (deliveryDetails == null) {
            return "No delivery details defined for " + form.getFormName();
        }

        // Ensure delivery method and WebService delivery mode is valid
        final String deliveryMethod = deliveryDetails.getDeliveryMethod();
        final String deliveryWsMode = deliveryDetails.getDeliveryWsMode();

        // Ensure delivery is not completed
        if (submission.isDeliveryCompleted()
            && !DeliveryDetails.METHOD_EMAIL.equals(deliveryMethod)
            && !DeliveryDetails.METHOD_EMAIL_SECURE.equals(deliveryMethod)) {

            return "Delivery has already been completed";
        }

        // Ensure submission has not been marked as undeliverable
        if (Submission.STATUS_Undeliverable.equalsIgnoreCase(submission.getDeliveryStatus())) {
            return "Submission has been marked as undeliverable. Delivery will not be attempted.";
        }

        SubmissionData submissionData = submission.getSubmissionData();
        if (submissionData == null || submissionData.getSubmissionData() == null || submissionData.getSubmissionData().length == 0) {
            submission.setDeliveryStatus(Submission.STATUS_Undeliverable);
            commitChanges();
            eventLogService.logWarnEvent("Submission data unavailable. Delivery will not be attempted.", submission);
            return "Submission XML data is not available. Submission has been marked as undeliverable.";
        }

        if (DeliveryDetails.METHOD_EMAIL.equals(deliveryMethod)
            || DeliveryDetails.METHOD_EMAIL_SECURE.equals(deliveryMethod)) {
            // Continue

        } else if (DeliveryDetails.METHOD_WEB_SERVICE.equals(deliveryMethod)) {

            if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_1.equals(deliveryWsMode)) {
                // Continue

            } else if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_2.equals(deliveryWsMode)) {
                // Continue

            } else if (DeliveryDetails.DELIVERY_WS_MODE_PULL.equals(deliveryWsMode)) {
                return "Delivery will be performed using Client Pull WebService";

            } else {
                return "Delivery WS Mode is invalid: " + deliveryWsMode;
            }

        } else if (DeliveryDetails.METHOD_LC_PROCESS.equals(deliveryMethod)) {
            // Continue

        } else {
            // Should never get here
            return "Delivery Method is invalid: " + deliveryMethod;
        }

        // Setup transaction for main block of work
        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction transaction = domain.createTransaction();

        Transaction.bindThreadTransaction(transaction);
        try {
            long startTime = System.currentTimeMillis();
            submission.setDeliveryTime(new Date());

            getLogger().debug("Delivery starting for Submission " + submission.getId() + " via " + deliveryMethod);

            String message = null;
            if (DeliveryDetails.METHOD_EMAIL.equals(deliveryDetails.getDeliveryMethod())) {
                message = deliverViaEmail(submission, deliveryDetails);

            } else if (DeliveryDetails.METHOD_EMAIL_SECURE.equals(deliveryDetails.getDeliveryMethod())) {
                message = deliverViaEmailSecure(submission, deliveryDetails);

            } else if (DeliveryDetails.METHOD_LC_PROCESS.equals(deliveryDetails.getDeliveryMethod())) {
                message = deliverViaLiveCycleProcess(submission, deliveryDetails);

            } else if (DeliveryDetails.METHOD_WEB_SERVICE.equals(deliveryDetails.getDeliveryMethod())) {
                message = deliverViaWebServicePush(submission, deliveryDetails);

            } else {
                // Should never reach here
                assert(false);
            }

            commitChanges();

            transaction.commit();

            Transaction.bindThreadTransaction(null);

            if (startTime > 0) {
                message = message + ". Took "  + (System.currentTimeMillis() - startTime) + "ms";
            }

            return message;

        } catch (Exception error) {
            try {
                transaction.rollback();

            } catch (Exception e) {
                getLogger().error("Error Rolling back transaction...", e);

            } finally {
                Transaction.bindThreadTransaction(null);
            }

            errorLogService.logException(error, null, false, submission);

            String errorMessage = error.getMessage();
            if (StringUtils.isBlank(errorMessage)) {
                errorMessage = error.toString();
            }
            if (error instanceof ApplicationException) {
                ApplicationException ae = (ApplicationException) error;
                errorMessage = ae.getUserMessage();
            }

            submission.setDeliveryMessage(CoreUtils.limitLength(errorMessage, 200));
            submission.setDeliveryStatus(Submission.STATUS_Error);
            submission.setDeliveryTime(new Date());
            setDeliveryMethod(submission, deliveryDetails);

            eventLogService.logErrorEvent(errorMessage, submission);

            commitChanges();

            return "Delivery Error: " + errorMessage;

        } finally {
             Transaction.bindThreadTransaction(null);
        }
    }

    /**
     * @see SubmissionDeliveryService#setAttachmentDeliveryCompleted(Attachment, String)
     */
    public void setAttachmentDeliveryCompleted(Attachment attachment, String dataHash) {
        Validate.notNull(attachment, "Null attachment parameter");

        FileUpload fileUpload = attachment.getFileUpload();

        // If there is an associated file upload
        if (fileUpload != null) {

            // Upgrade any records missing a file XML hash.
            if (fileUpload.getFileDataHash() == null && fileUpload.getFileUploadData() != null) {
                String fileUploadHash = DataHashUtils.toSHA256Hash(fileUpload.getFileUploadData().getFileUploadData());
                fileUpload.setFileDataHash(fileUploadHash);
            }

            // check the hash unless the file was discovered to have a virus, in which case its contents most likely weren't delivered
            if (!FileUpload.VIRUS_STATUS_VIRUS.equals(fileUpload.getVirusStatus())) {
                // Else check the provided file content data hash.
                String fileDataHash = fileUpload.getFileDataHash();

                if (fileDataHash.equalsIgnoreCase(dataHash)) {
                    fileUpload.setDeliveryStatus(com.avoka.fc.core.entity.Submission.STATUS_Completed);
                    fileUpload.setDeliveryAuditStatus(com.avoka.fc.core.entity.Submission.STATUS_Ready);

                } else {
                    fileUpload.setDeliveryStatus(com.avoka.fc.core.entity.Submission.STATUS_Error);

                    String msg = "Data hash mismatch when confirming attachment delivery (Attachnent ID "
                        + attachment.getId() + "'. Server SHA-256 hash: '" + fileDataHash + "' client SHA-256 hash: '"
                        + dataHash + "'";

                    ServiceFactory.getEventLogService().logErrorEvent(msg, attachment.getSubmission());
                }
            }

            commitChanges();
        }
    }

    /**
     * @see SubmissionDeliveryService#setSubmissionDeliveryCompleted(Submission, String)
     */
    public void setSubmissionDeliveryCompleted(Submission submission, String dataHash) {
        Validate.notNull(submission, "Null submission parameter");

        Form form = submission.getForm();

        // Get the appropriate delivery details
        DeliveryDetails deliveryDetails = null;
        if (submission.isTestMode()) {
            deliveryDetails = form.getDeliveryTest();
        } else {
            deliveryDetails = form.getDeliveryProd();
        }

        if (deliveryDetails == null) {
            String context = "Submission=" + submission.getSessionId() + ",ClientFormCode=" + form.getClientFormCode();
            String message = "No delivery details defined for " + form.getFormName();
            String solution = "Configure DeliveryDetails for ClientFormCode=" + form.getClientFormCode();
            throw new ApplicationException("DeliveryService", context, message, solution);
        }

        if (deliveryDetails.isEmailDeliveryMethod() || deliveryDetails.isEmailSecureDeliveryMethod()) {
            // Should never reach here
            assert(false);
        }

        // Check to ensure all the attachments delivery has been completed
        boolean attachmentsCompleted = true;

        List<Attachment> attachments = submission.getAttachments();
        for (Attachment attachment: attachments) {
            FileUpload fileUpload = attachment.getFileUpload();
            if (fileUpload != null && !Submission.STATUS_Completed.equals(fileUpload.getDeliveryStatus())) {
                attachmentsCompleted = false;
                break;
            }
        }

        if (attachmentsCompleted) {
            if (submission.getFormXmlHash() != null) {
                if (submission.getFormXmlHash().equalsIgnoreCase(dataHash)) {

                    String deliveryMessage = getDeliveryMessage(deliveryDetails);

                    submission.setDeliveryMessage(deliveryMessage);
                    submission.setDeliveryStatus(Submission.STATUS_Completed);
                    submission.setDeliveryTime(new Date());
                    submission.setDeliveryAuditStatus(Submission.STATUS_Ready);

                    // update any relevent metrics
                    setDeliveryMethod(submission, deliveryDetails);

                    ServiceFactory.getEventLogService().logInfoEvent(deliveryMessage, submission);

                } else {
                    submission.setDeliveryStatus(Submission.STATUS_Error);
                    submission.setDeliveryMessage("Data hash mismatch when confirming submission delivery");
                    submission.setDeliveryTime(new Date());

                    String msg = "Data hash mismatch when confirming submission delivery. Server SHA-256 hash: '"
                        + submission.getFormXmlHash() + "' client SHA-256 hash: '" + dataHash + "'";
                    ServiceFactory.getEventLogService().logErrorEvent(msg, submission);
                }

            } else {
                String msg = "Submission Form XML Hash not defined, cannot confirm submission delivery";

                submission.setDeliveryStatus(Submission.STATUS_Error);
                submission.setDeliveryMessage(msg);
                submission.setDeliveryTime(new Date());

                ServiceFactory.getEventLogService().logErrorEvent(msg, submission);
            }

        } else {
            submission.setDeliveryStatus(Submission.STATUS_Error);
            submission.setDeliveryMessage("Not all submission attachments have been confirmed as delivered");
            submission.setDeliveryTime(new Date());

            String msg = "Attachments delivery not completed for form Submission";
            ServiceFactory.getEventLogService().logErrorEvent(msg, submission);
        }

        commitChanges();
    }

//    public boolean setSubmissionDeliveryReady(Submission submission) {
//        Validate.notNull(submission, "Null submission parameter");
//
//        // Can't reset non completed deliveries or when submission data has been delivered
//        if (!submission.isDeliveryCompleted() || submission.isDeleted()) {
//            return false;
//        }
//
//        // Can't reset status if file attachments have been deleted
//        for (Attachment attachment : submission.getAttachments()) {
//            FileUpload fileUpload = attachment.getFileUpload();
//            if (fileUpload != null && fileUpload.isDeleted()) {
//                return false;
//            }
//        }
//
//        submission.setDeliveryStatus(Submission.STATUS_Ready);
//        submission.setDeliveryMessage(null);
//        submission.setDeliveryMethod(null);
//        submission.setDeliveryTime(null);
//
//        for (Attachment attachment : submission.getAttachments()) {
//            FileUpload fileUpload = attachment.getFileUpload();
//            if (fileUpload != null) {
//                fileUpload.setDeliveryStatus(Submission.STATUS_Ready);
//                fileUpload.setDeletedTimestamp(null);
//            }
//        }
//
//        SubmissionStatusService submissionStatusService = new SubmissionStatusService();
//        submissionStatusService.updateStatus(submission);
//
//        String user = RemoteUserProvider.getRemoteUser();
//        String msg = "Submission Delivery Status set to '" + Submission.STATUS_Ready + "' by " + user;
//        ServiceFactory.getEventLogService().logInfoEvent(msg, submission);
//
//        return true;
//    }

    /**
     * @see SubmissionDeliveryService#setEmailSubmissionDeliveryCompleted(Submission)
     */
    public void setEmailSubmissionDeliveryCompleted(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        Form form = submission.getForm();

        // Get the appropriate delivery details
        DeliveryDetails deliveryDetails = null;
        if (submission.isTestMode()) {
            deliveryDetails = form.getDeliveryTest();
        } else {
            deliveryDetails = form.getDeliveryProd();
        }

        if (deliveryDetails == null) {
            String context = "Submission=" + submission.getSessionId() + ",ClientFormCode=" + form.getClientFormCode();
            String message = "No delivery details defined for " + form.getFormName();
            String solution = "Configure DeliveryDetails for ClientFormCode=" + form.getClientFormCode();
            throw new ApplicationException("DeliveryService", context, message, solution);
        }

        if (!deliveryDetails.isEmailDeliveryMethod() && !deliveryDetails.isEmailSecureDeliveryMethod()) {
            // Should never reach here
            assert(false);
        }

        String deliveryMessage = getDeliveryMessage(deliveryDetails);

        submission.setDeliveryStatus(Submission.STATUS_Completed);
        submission.setDeliveryMessage(deliveryMessage);
        submission.setDeliveryTime(new Date());

        // set metrics
        setDeliveryMethod(submission, deliveryDetails );

        if (deliveryDetails.isEmailSecureDeliveryMethod()) {
            submission.setDeliveryAuditStatus(Submission.STATUS_Ready);

            // Set delivery completed for file attachments.
            for (Attachment attachment : submission.getAttachments()) {
                FileUpload fileUpload = attachment.getFileUpload();
                if (fileUpload != null) {
                    fileUpload.setDeliveryStatus(Submission.STATUS_Completed);
                    fileUpload.setDeliveryAuditStatus(Submission.STATUS_Ready);
                }
            }
        }

        ServiceFactory.getEventLogService().logInfoEvent(deliveryMessage, submission);

        commitChanges();
    }

    /**
     * @see SubmissionDeliveryService#setSubmissionDeliveryCompletedByAdmin(Submission, String)
     */
    public void setSubmissionDeliveryCompletedByAdmin(Submission submission, String userName) {
        Validate.notNull(submission, "Null submission parameter");
        Validate.notNull(userName, "Null userName parameter");

        String format = "Delivery manually set to ''{0}'' by {1}";
        String deliveryMessage = MessageFormat.format(format, new Object[] { Submission.STATUS_Completed, userName});

        submission.setDeliveryStatus(Submission.STATUS_Completed);
        submission.setDeliveryMessage(CoreUtils.limitLength(deliveryMessage, 200));
        submission.setDeliveryTime(new Date());

        // set metrics delivery method
        submission.setDeliveryMethod(Submission.DELIVERY_MANUAL);

        // Set delivery completed for file attachments.
        for (Attachment attachment : submission.getAttachments()) {
            FileUpload fileUpload = attachment.getFileUpload();
            if (fileUpload != null) {
                fileUpload.setDeliveryStatus(Submission.STATUS_Completed);
            }
        }

        ServiceFactory.getEventLogService().logInfoEvent(deliveryMessage, submission);

        commitChanges();
    }

    /**
     * @see SubmissionDeliveryService#sendEmailReminder(Submission)
     */
    public void sendEmailReminder(Submission submission) {
        if (submission != null) {
            Form form = submission.getForm();

            // Get the appropriate delivery details
            DeliveryDetails deliveryDetails = null;
            if (submission.isTestMode()) {
                deliveryDetails = form.getDeliveryTest();
            } else {
                deliveryDetails = form.getDeliveryProd();
            }

            if (deliveryDetails == null
                    || DeliveryDetails.METHOD_EMAIL_SECURE.equals(deliveryDetails.getDeliveryMethod())) {

                EventLogService eventLogService = ServiceFactory.getEventLogService();
                eventLogService.logWarnEvent("Cannot send reminder for Email Secure delivery because the delivery details have changed.", submission);
                return;
            }

            String toAddress = deliveryDetails.getEmailAddresses();

            // If email address not defined lookup relevant client administrators
            if (StringUtils.isBlank(toAddress)) {
                String clientId = form.getClient().getId().toString();
                List<UserAccount> recipients = DaoFactory.getUserAccountDao().getUserSubscribedToSubmissionAlerts(clientId);

                // Log warning message if there is no one to remind
                if (recipients == null || recipients.size() == 0) {
                    String clientName = submission.getClient().getClientName();
                    String msg = "Delivery Reminder Job: No administrator is currently set up to receive reminders for " + clientName;

                    EventLogService eventLogService = new EventLogService();
                    eventLogService.logWarnEvent(msg);
                    return;

                } else {
                    toAddress = getEmailAddresses(recipients);
                }
            }

            String ccAddress = deliveryDetails.getEmailCcAddresses();

            EmailService emailService = new EmailService();

            String senderEmail = getDeliveryEmailSender();

            String context = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Context);

            InetAddress localHost = null;
            try {
                localHost = InetAddress.getLocalHost();
            } catch (UnknownHostException uhe) {
                getLogger().error("Unknown Host Exexption.", uhe);
            }
            String hostName = localHost.getHostName();
            String ipaddress = localHost.getHostAddress();

            Map model = new HashMap();
            model.put("context", context);
            model.put("submission", submission);
            model.put("hostName", hostName);
            model.put("ipaddress", ipaddress);

            String subject = renderTemplateString(getSecureEmailReminderSubject(), model);
            String message = renderTemplateString(getSecureEmailReminderMessage(), model);

            emailService.sendMessage(subject, message, senderEmail, toAddress, ccAddress);
        }
    }


    /**
     * @see SubmissionDeliveryService#sendEmailEscalation(Submission)
     */
    public void sendEmailEscalation(Submission submission) {
        if (submission != null) {
            UserAccountDao adminDetailsDao = new UserAccountDao();
            String clientID = submission.getClient().getId().toString();
            List<UserAccount> recipients = adminDetailsDao.getUserSubscribedToSubmissionAlerts(clientID);

            // Log warning message if there is no one to remind
            if (recipients == null || recipients.size() == 0) {
                String clientName = submission.getClient().getClientName();
                String msg = "Delivery Escalation Job: No administrator is currently set up to receive reminders for " + clientName;

                EventLogService eventLogService = new EventLogService();
                eventLogService.logWarnEvent(msg);
            }
            else {
                EmailService emailService = new EmailService();

                String toAddress = getEmailAddresses(recipients);

                String senderEmail = getDeliveryEmailSender();

                String context = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Context);

                InetAddress localHost = null;
                try {
                    localHost = InetAddress.getLocalHost();
                } catch (UnknownHostException uhe) {
                    getLogger().error("Unknown Host Exexption.", uhe);
                }
                String hostName = localHost.getHostName();
                String ipaddress = localHost.getHostAddress();

                Map model = new HashMap();
                model.put("context", context);
                model.put("submission", submission);
                model.put("hostName", hostName);
                model.put("ipaddress", ipaddress);

                String subject = renderTemplateString(getDeliveryEmailEscalationSubject(), model);
                String message = renderTemplateString(getDeliveryEmailEscalationMessage(), model);

                emailService.sendMessage(subject, message, senderEmail, toAddress);
            }
        }
    }

    // Protected Methods ------------------------------------------------------

    /**
     * Deliver the given submission via email using the delivery details provided.
     */
    protected String deliverViaEmail(Submission submission, DeliveryDetails deliveryDetails) {
        getLogger().debug("deliverViaEmail");

        List<File> attachmentFileList = new ArrayList<File>();

        if (deliveryDetails.isDeliverPdf()) {
            attachmentFileList.add(createPDFReceiptFile(submission));
        }

        if (deliveryDetails.isDeliverXml()) {
            attachmentFileList.add(createXMLForDelivery(submission));
        }

        if (deliveryDetails.isDeliverTransformXml()) {
            attachmentFileList.add(createTransformXMLForDelivery(deliveryDetails.getTransformXsltData(), submission));
        }

        EmailService emailService = new EmailService();

        String toAddress = deliveryDetails.getEmailAddresses();
        String ccAddress = deliveryDetails.getEmailCcAddresses();

        String senderEmail = getDeliveryEmailSender();

        InetAddress localHost = null;
        try {
            localHost = InetAddress.getLocalHost();
        } catch (UnknownHostException uhe) {
            getLogger().error("Unknown Host Exception.", uhe);
        }
        String hostName = localHost.getHostName();
        String ipaddress = localHost.getHostAddress();

        String context = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Context);

        Map model = new HashMap();
        model.put("context", context);
        model.put("submission", submission);
        model.put("testMode", submission.getTestMode());
        model.put("hostName", hostName);
        model.put("ipaddress", ipaddress);

        String subject = renderTemplateString(getStandardEmailDeliverySubject(), model);
        String message = renderTemplateString(getStandardEmailDeliveryMessage(), model);

        emailService.sendMessage(subject, message, senderEmail, toAddress, ccAddress, attachmentFileList);

        setEmailSubmissionDeliveryCompleted(submission);

        // Delete any file attachments from the file system
        for (File attachment : attachmentFileList) {
            attachment.delete();
        }

        return "Delivery completed for Submission " + submission.getId();
    }

    /**
     * Deliver the given submission via email using the delivery details provided.
     */
    protected String deliverViaEmailSecure(Submission submission, DeliveryDetails deliveryDetails) {
        getLogger().debug("deliverViaEmailSecure");

        EmailService emailService = new EmailService();

        String toAddress = deliveryDetails.getEmailAddresses();
        String ccAddress = deliveryDetails.getEmailCcAddresses();

        String senderEmail = getDeliveryEmailSender();

        InetAddress localHost = null;
        try {
            localHost = InetAddress.getLocalHost();
        } catch (UnknownHostException uhe) {
            getLogger().error("Unknown Host Exception.", uhe);
        }
        String hostName = localHost.getHostName();
        String ipaddress = localHost.getHostAddress();

        String context = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Context);

        Map model = new HashMap();
        model.put("context", context);
        model.put("submission", submission);
        model.put("testMode", submission.getTestMode());
        model.put("hostName", hostName);
        model.put("ipaddress", ipaddress);

        String subject = renderTemplateString(getSecureEmailDeliverySubject(), model);
        String message = renderTemplateString(getSecureEmailDeliveryMessage(), model);

        emailService.sendMessage(subject, message, senderEmail, toAddress, ccAddress);

        submission.setDeliveryStatus(Submission.STATUS_Sent_Email);
        submission.setDeliveryTime(new Date());
        submission.setDeliveryMessage("");

        String msg = "Submission email notification sent to: " + toAddress;

        ServiceFactory.getEventLogService().logInfoEvent(msg, submission);

        return msg;
    }

    /**
     * Deliver the given submission via Delivery Process using the delivery details provided.
     */
    protected String deliverViaLiveCycleProcess(Submission submission, DeliveryDetails deliveryDetails) throws Exception {
        getLogger().debug("deliverViaOrchestration");

        if (deliveryDetails.getDeliveryProcessService() == null) {
            String userMsg = "Delivery Process not configured in delivery details";
            String context = "DeliveryDetails.Name=" + deliveryDetails.getName()
                + ",Submission.Id=" + submission.getId()
                + ",Client.Name=" + submission.getClient().getClientName();
            String solution = "Configure Delivery Process service in Delivery Details: " + deliveryDetails.getName();
            throw new ApplicationException("SubmissionDelivery", context, userMsg, solution);
        }

        DeliveryProcessService dos = (DeliveryProcessService)
            ServiceLocator.getServiceForDefinition(deliveryDetails.getDeliveryProcessService());

        String invocationId = dos.deliverSubmission(submission, deliveryDetails);

        String msg = "Submission delivered via delivery orchestration: "
            + deliveryDetails.getDeliveryProcessService().getServiceName();

        submission.setDeliveryInvocationId(invocationId);
        submission.setDeliveryStatus(Submission.STATUS_Completed);
        setDeliveryMethod(submission, deliveryDetails);
        submission.setDeliveryTime(new Date());
        submission.setDeliveryMessage(msg);

        ServiceFactory.getEventLogService().logInfoEvent(msg, submission);

        return msg;
    }

    /**
     * Deliver the given submission via Delivery WebService with Push Mode using the delivery details provided.
     */
    protected String deliverViaWebServicePush(Submission submission, DeliveryDetails deliveryDetails) throws Exception {
        getLogger().debug("deliverViaWebServicePush");

        final long startTime = System.currentTimeMillis();

        FormsClientWebService formsClientWS =
            ServiceFactory.getFormsClientService(deliveryDetails.getDeliveryWsAddress());

        for (Attachment attachment : submission.getAttachments()) {
            FileUpload fileUpload = attachment.getFileUpload();
            if (fileUpload != null && fileUpload.getFileDataHash() == null && fileUpload.getFileUploadData() != null && fileUpload.getFileUploadData().getFileUploadData() != null) {
                String fileUploadHash = DataHashUtils.toSHA256Hash(fileUpload.getFileUploadData().getFileUploadData());
                fileUpload.setFileDataHash(fileUploadHash);
            }
        }

        // Perform main logic
        if (deliveryDetails.isWsPushModeType1()) {
            formsClientWS.NotifyFormSubmission(submission.getClient().getClientCode(), submission.getSubmitKey());

            long time = System.currentTimeMillis() - startTime;
            String msg = "NotifyFormSubmission web service invoked in " + time + " ms";

            submission.setDeliveryStatus(Submission.STATUS_Sent_WS);
            submission.setDeliveryTime(new Date());
            submission.setDeliveryMessage(CoreUtils.limitLength(msg, 200));

            ServiceFactory.getEventLogService().logInfoEvent(msg, submission);

            return "NotifyFormSubmission web service invoked for Submission " + submission.getId() + ".";

        } else if (deliveryDetails.isWsPushModeType2()) {

            SubmissionConfirmation submissionConfirmation =
                formsClientWS.SubmitForm(submission.getClient().getClientCode(),
                                         SubmissionBeanUtils.createSubmissionBeanWithAttachments(submission));

            if (submissionConfirmation == null) {
                String msg = "SubmissionConfirmation not received when invoking SubmitForm Web Service. "
                    + "WS Endpoint: " + deliveryDetails.getDeliveryWsAddress();

                submission.setDeliveryStatus(Submission.STATUS_Error);
                submission.setDeliveryTime(new Date());
                submission.setDeliveryMessage(CoreUtils.limitLength(msg, 200));

                ServiceFactory.getEventLogService().logErrorEvent(msg, submission);

                return msg;
            }

            if (submission.getFormXmlHash().equalsIgnoreCase(submissionConfirmation.getSubmissionHash())) {

                // Check all the confirmation attachments

                boolean attachmentsOK = true;
                String errorMsg = null;
                String clientKey = submission.getClient().getClientKey();
                Set<String> clientAttachmentKeySet = new HashSet<String>();

                List<AttachmentConfirmation> acList = submissionConfirmation.getAttachmentConfirmationList();

                if (acList != null) {
                    for (AttachmentConfirmation attachmentConfirmation : acList) {
                        String attachmentKey = attachmentConfirmation.getAttachmentKey();
                        clientAttachmentKeySet.add(attachmentKey);

                        Attachment attachment =
                            DaoFactory.getAttachmentDao().getAttachmentForAttachmentKey(clientKey, attachmentKey);

                        if (attachment != null) {
                            FileUpload fileUpload = attachment.getFileUpload();

                            // Note file may be delivered manually so there will be no matching file upload data
                            if (fileUpload != null) {
                                String attachmentHash = fileUpload.getFileDataHash();
                                if (!attachmentHash.equalsIgnoreCase(attachmentConfirmation.getAttachmentHash())) {
                                    attachmentsOK = false;
                                    errorMsg = "Attachment " + attachment.getId()
                                        + " data hash does not match returned AttachmentConfirmation value: "
                                        + attachmentConfirmation.getAttachmentHash();
                                    break;
                                }
                            }
                        }
                    }
                }

                // Check to that there are matching attachment keys on both sides
                if (attachmentsOK) {
                    Set<String> serverAttachmentKeySet = new HashSet<String>();
                    for (Attachment attachment : submission.getAttachments()) {
                        serverAttachmentKeySet.add(attachment.getAttachmentKey());
                    }

                    Set<String> serverSet = new HashSet<String>(serverAttachmentKeySet);
                    Set<String> clientSet = new HashSet<String>(clientAttachmentKeySet);
                    serverSet.removeAll(clientSet);

                    if (!serverSet.isEmpty()) {
                        attachmentsOK = false;
                        errorMsg = "There were " + serverSet.size() + " attachments not confirmed as delivered";

                        String msg = "Attachments Keys with no delivery confirmation: " + serverSet;
                        ServiceFactory.getEventLogService().logErrorEvent(msg, submission);
                    }
                }

                if (attachmentsOK) {

                    String deliveryMessage = getDeliveryMessage(deliveryDetails);

                    deliveryMessage += " in " + (System.currentTimeMillis() - startTime) + " ms";

                    submission.setDeliveryStatus(Submission.STATUS_Completed);
                    submission.setDeliveryAuditStatus(Submission.STATUS_Ready);
                    submission.setDeliveryTime(new Date());
                    submission.setDeliveryMessage(CoreUtils.limitLength(deliveryMessage, 200));

                    // Set any attachments to have delivery completed.
                    if (acList != null) {
                        for (AttachmentConfirmation attachmentConfirmation : acList) {
                            String attachmentKey = attachmentConfirmation.getAttachmentKey();

                            Attachment attachment =
                                DaoFactory.getAttachmentDao().getAttachmentForAttachmentKey(clientKey, attachmentKey);

                            if (attachment != null) {
                                FileUpload fileUpload = attachment.getFileUpload();

                                // Note file may be delivered manually so there will be no matching file upload data
                                if (fileUpload != null) {
                                    fileUpload.setDeliveryStatus(Submission.STATUS_Completed);
                                    fileUpload.setDeliveryAuditStatus(Submission.STATUS_Ready);
                                }
                            }
                        }
                    }

                    ServiceFactory.getEventLogService().logInfoEvent(deliveryMessage, submission);

                    return "Submission delivery completed using SubmitForm WS.";

                } else {

                    String msg = "Delivery error invoking SubmitForm Web Service: " + errorMsg;

                    submission.setDeliveryStatus(Submission.STATUS_Error);
                    submission.setDeliveryTime(new Date());
                    submission.setDeliveryMessage(CoreUtils.limitLength(msg, 200));

                    ServiceFactory.getEventLogService().logErrorEvent(msg, submission);

                    return msg;
                }

            } else {
                String msg = "Delivery error invoking SubmitForm Web Service: SubmissionConfirmation SHA-256 Data Hash "
                    + " does not match Submission Data Hash.";

                submission.setDeliveryStatus(Submission.STATUS_Error);
                submission.setDeliveryTime(new Date());
                submission.setDeliveryMessage(CoreUtils.limitLength(msg, 200));

                ServiceFactory.getEventLogService().logErrorEvent(msg, submission);

                return "Delivery error invoking SubmitForm WS.";
            }

        } else {
            // Should never occur
            assert(false);
            return "";
        }
    }

    // Private Methods --------------------------------------------------------

    private void setDeliveryMethod(Submission submission, DeliveryDetails deliveryDetails) {

        final String deliveryWsMode = deliveryDetails.getDeliveryWsMode();

        if (DeliveryDetails.METHOD_WEB_SERVICE.equals(deliveryDetails.getDeliveryMethod())) {
            if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_1.equals(deliveryWsMode)) {
                //set as pull notified
                submission.setDeliveryMethod(Submission.DELIVERY_WEB_SERVICE_PUSH_TYPE_1);

            } else if (DeliveryDetails.DELIVERY_WS_MODE_PUSH_TYPE_2.equals(deliveryWsMode)) {
                // set push deliveries
                submission.setDeliveryMethod(Submission.DELIVERY_WEB_SERVICE_PUSH_TYPE_2);

            } else if (DeliveryDetails.DELIVERY_WS_MODE_PULL.equals(deliveryWsMode)) {
                // set pull
                submission.setDeliveryMethod(Submission.DELIVERY_WEB_SERVICE_PULL);
            }

        } else if(DeliveryDetails.METHOD_EMAIL.equals(deliveryDetails.getDeliveryMethod())) {
            //set email submission
            submission.setDeliveryMethod(Submission.DELIVERY_EMAIL);

        } else if (DeliveryDetails.METHOD_EMAIL_SECURE.equals(deliveryDetails.getDeliveryMethod())) {
            submission.setDeliveryMethod(Submission.DELIVERY_EMAIL_SECURE);

        }else if (DeliveryDetails.METHOD_LC_PROCESS.equals(deliveryDetails.getDeliveryMethod())) {
            submission.setDeliveryMethod(Submission.DELIVERY_PROCESS);
        }
    }

    private String getEmailAddresses(List<UserAccount> admins) {
        if (admins == null || admins.size() == 0) {
            return null;
        }

        StringBuffer result = new StringBuffer();
        for (int i = 0; i < admins.size(); i++) {
            UserAccount curAdmin = admins.get(i);
            result.append(curAdmin.getEmail());
            result.append(";");
        }

        return result.toString();
    }

    private String renderTemplateString(String templateString, Map model) {
        String environmentName = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Environment_Name);
        String supportEmail = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Support_Sender);
        model.put("environmentName", environmentName);
        model.put("supportEmail", supportEmail);

        StringTemplate stringTemplate = new StringTemplate(templateString);

        return stringTemplate.merge(model);
    }

    private File createXMLForDelivery(Submission submission){
        Validate.notNull(submission, "Null submission parameter");

        SubmissionData submissionData = submission.getSubmissionData();
        if (submissionData == null || submissionData.getSubmissionData() == null || submissionData.getSubmissionData().length == 0) {
            throw new ApplicationException("DeliveryXMLError", "Submission ID = " + submission.getId(),
                    "Submission contains no form data", "Examine Submission record");
        }

        String seedXmlString = submissionData.getSubmissionDataString();
        String fileName = "" + submission.getId() + ".xml";

        try {
            return FileUtils.writeToFile(getDeliveryTempDirectory() + fileName, seedXmlString.getBytes());

        } catch (IOException ioe) {
            throw new ApplicationException("DeliveryXMLError", ioe, "Submission ID = " + submission.getId(),
                    "Error creating XML DeliveryFile", "Error creating XML DeliveryFile. See Java IO exception for details");
        }
    }

    private File createTransformXMLForDelivery(byte[] transformXsltData,Submission submission){
        Validate.notNull(transformXsltData, "Null transformXsltData parameter");
        Validate.notNull(submission, "Null submission parameter");

        SubmissionData submissionData = submission.getSubmissionData();
        if (submissionData == null || submissionData.getSubmissionData() == null || submissionData.getSubmissionData().length == 0) {
            throw new ApplicationException("DeliveryXMLError", "Submission ID = " + submission.getId(),
                    "Submission contains no form data", "Examine Submission record");
        }

        String seedXmlString = submissionData.getSubmissionDataString();
        String fileName = "" + submission.getId() + ".xml";

        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(transformXsltData);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();

            // Use the TransformerFactory to instantiate a Transformer that
            // will work with the stylesheet you specify.
            // This method call also processes the stylesheet into a
            // compiled Templates object.
            Transformer transformer = transformerFactory.newTransformer(new StreamSource(bais));

            String sourceFilename = "" + submission.getId() + "-raw.xml";
            File sourceFile = FileUtils.writeToFile(getDeliveryTempDirectory() + sourceFilename, seedXmlString.getBytes());

            String qualifiedFilename = getDeliveryTempDirectory() + fileName;
            FileOutputStream destFileOutputStream = new FileOutputStream(qualifiedFilename);

            transformer.transform(new StreamSource(sourceFile), new StreamResult(destFileOutputStream));

            CoreUtils.close(destFileOutputStream);

            return new File(qualifiedFilename);

        } catch (IOException ioe) {
            throw new ApplicationException("DeliveryXMLError", ioe, "Submission ID = " + submission.getId(),
                    "Error creating XML DeliveryFile", "Error creating XML DeliveryFile. See Java IO exception for details");

        } catch (TransformerException te) {
            throw new ApplicationException("DeliveryXMLError", te, "Submission ID = " + submission.getId(),
                    "Error transforming XML DeliveryFile",
                    "Error transforming XML DeliveryFile. See Transformer exception for details");
        }
    }

    private File createPDFReceiptFile(Submission submission){

        String fileName = "" + submission.getId() + ".pdf";

        ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
        byte[] formBytes = receiptDataService.getReceiptPdf(submission);

        try {
            return FileUtils.writeToFile(getDeliveryTempDirectory() + fileName, formBytes);

        } catch (IOException ex) {
            throw new ApplicationException("DeliveryPDFError", ex, "Submission ID = " + submission.getId(),
                    "Error creating PDF DeliveryFile", "Error creating PDF DeliveryFile. See Java IO exception for details");
        }
    }

    private String getDeliveryTempDirectory(){
        return deploymentPropertyDao.getConfigSubDirectory("delivery");
    }

    private String getDeliveryMessage(DeliveryDetails deliveryDetails) {
        StringBuilder builder = new StringBuilder();

        builder.append("Delivered via '");
        builder.append(deliveryDetails.getName());
        builder.append("' ");

        if (DeliveryDetails.METHOD_WEB_SERVICE.equals(deliveryDetails.getDeliveryMethod())) {
            builder.append(deliveryDetails.getDeliveryWsMode());
            builder.append(" ");
            builder.append(deliveryDetails.getDeliveryMethod());
            builder.append(" to ");
            builder.append(deliveryDetails.getClient().getClientName());

        } else if (DeliveryDetails.METHOD_EMAIL_SECURE.equals(deliveryDetails.getDeliveryMethod())) {
            builder.append(deliveryDetails.getDeliveryMethod());
            builder.append(" to ");
            builder.append(RemoteUserProvider.getRemoteUser());

        } else if (DeliveryDetails.METHOD_EMAIL.equals(deliveryDetails.getDeliveryMethod())) {
            builder.append(deliveryDetails.getDeliveryMethod());
            builder.append(" to ");
            builder.append(deliveryDetails.getEmailAddresses());
        }

        return builder.toString();
    }

}

package com.avoka.fc.core.service.export;

import java.util.List;
import java.util.Map;

import org.apache.click.util.ClickUtils;

public class FieldMetaData {

    private String name;

    private String label;

    private Object initialValue;

    private List<Object> initialValues;

    private Map<Object, Object> selectOptions;

    private FieldType fieldType;

    private boolean required;

    public FieldMetaData() {
    }

    public FieldMetaData(String name) {
        this(name, FieldType.TEXT);
    }

    public FieldMetaData(String name, FieldType fieldType) {
        this(name, null, fieldType);
    }

    public FieldMetaData(String name, String label) {
        this(name, label, null);
    }

    public FieldMetaData(String name, String label, Object initialValue) {
        this(name, label, initialValue, null);
    }

    public FieldMetaData(String name, String label, FieldType fieldType) {
        this(name, label, null, fieldType);
    }

    public FieldMetaData(String name, String label, Object initialValue, FieldType fieldType) {
        this.name = name;
        this.label = label;
        this.initialValue = initialValue;
        this.fieldType = fieldType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLabel() {
        if (label == null) {
            return ClickUtils.toLabel(getName());
        }
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Object getInitialValue() {
        return initialValue;
    }

    public void setInitialValue(Object initialValue) {
        this.initialValue = initialValue;
    }

    public List<Object> getInitialValues() {
        return initialValues;
    }

    public void setInitialValues(List<Object> initialValues) {
        this.initialValues = initialValues;
    }

    public FieldType getFieldType() {
        if (fieldType == null) {
            return FieldType.TEXT;
        }
        return fieldType;
    }

    public void setFieldType(FieldType fieldType) {
        this.fieldType = fieldType;
    }

    public void setSelectOptions(Map<Object, Object> selectOptions) {
        this.selectOptions = selectOptions;
    }

    public Map<Object, Object> getSelectOptions() {
        return selectOptions;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isRequired() {
        return required;
    }

    public enum FieldType {
        TEXT,
        BOOLEAN,
        SELECT,
        DATE
    }
}

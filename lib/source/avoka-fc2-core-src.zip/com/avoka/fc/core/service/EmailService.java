/*
 * Copyright (c) 2007-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang.math.NumberUtils;

import com.avoka.core.util.FileUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Group;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.StringTemplate;

public class EmailService extends BaseService {

    private DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();

    public void sendMessage(String subject, String message, String from, String toAddress) {
        this.sendMessage(subject, message, from, toAddress, null, Collections.EMPTY_LIST);
    }

    public void sendMessage(String subject, String message, String from, String toAddress, String ccAddress) {
        this.sendMessage(subject, message, from, toAddress, ccAddress, Collections.EMPTY_LIST);
    }

    public void sendMessage(String subject, String message, String from, String toAddress, String ccAddress, List attachmentList) {

        Validate.notNull(subject, "Null subject parameter");
        Validate.notNull(message, "Null message parameter");
        Validate.notEmpty(from, "Null from parameter");
        Validate.notEmpty(toAddress, "Null toAddress parameter");

        // Set SMTP Server connection properties
        String host = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_SMTP_Host);

        Properties props = new Properties();
        props.put("mail.smtp.host", host);

        String port = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_SMTP_Port);
        if (NumberUtils.isNumber(port)) {
            props.put("mail.smtp.port", port);
        }


        String user = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_SMTP_User);
        String password = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_SMTP_Password);
        if (StringUtils.isNotBlank(user) && StringUtils.isNotBlank(password)) {
            props.put("mail.smtp.auth", "true");
        }

        // Create some properties and get the default Session
        Session session = Session.getInstance(props, null);

        // Create a message
        MimeMessage mimeMessage = new MimeMessage(session);

        // Set the from
        InternetAddress fromIntenetAddress;
        try {
            fromIntenetAddress = new InternetAddress(from);
            mimeMessage.setFrom(fromIntenetAddress);

            // Prevent parsing exceptions
            toAddress = toAddress.replace(';', ',');

            InternetAddress[] toInternetAddresses = InternetAddress.parse(toAddress);

            mimeMessage.setRecipients(Message.RecipientType.TO, toInternetAddresses);

            if (StringUtils.isNotBlank(ccAddress)) {
                // Prevent parsing exceptions
                ccAddress = ccAddress.replace(';', ',');

                InternetAddress[] toCCInternetAddresses = InternetAddress.parse(ccAddress);
                mimeMessage.setRecipients(Message.RecipientType.CC, toCCInternetAddresses);
            }

            mimeMessage.setSentDate(new java.util.Date());
            mimeMessage.setSubject(subject);

            // create the message part
            MimeBodyPart messageBodyPart = new MimeBodyPart();

            // fill message
            messageBodyPart.setText(message);
            messageBodyPart.addHeader("Content-Type", "text/html");
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            // Part two is attachment

            Iterator iterator = attachmentList.iterator();
            while (iterator.hasNext()) {
                File fileAttachment = (File) iterator.next();
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(fileAttachment);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(fileAttachment.getName());
                multipart.addBodyPart(messageBodyPart);
            }

            // Put parts in message
            mimeMessage.setContent(multipart);

            // If user and password defined authenticate

            if (StringUtils.isNotBlank(user) && StringUtils.isNotBlank(password)) {
                Transport transport = session.getTransport("smtp");
                try {
                    if (NumberUtils.isNumber(port)) {
                        transport.connect(host, Integer.parseInt(port), user, password);

                    } else {
                        transport.connect(host, user, password);
                    }

                    transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());

                } finally {
                    transport.close();
                }

            } else {
                Transport.send(mimeMessage);
            }

            if (getLogger().isDebugEnabled()) {
                getLogger().debug("Sent email to " + toAddress + " Subject: " + subject + ", Message: " + message);
            }

        } catch (Exception e) {
            String context = "STMP Properties=" + props;
            if (StringUtils.isNotBlank(user) && StringUtils.isNotBlank(password)) {
                context += ", user=" + user + ", password=" + password;
            }
            context += ", toAddress=" + toAddress + ", from=" + from + ", subject=" + subject;
            throw new ApplicationException("SendEmailException", e, context, "Error sending email",
                                           "Please check the email service has been configured and is active.");
        }
    }

    public void sendFormReceiptMessage(Submission submission, String toAddress) {
        Map model = new HashMap();
        model.put("submission", submission);

        String subject = renderTemplate(DeploymentProperty.PROPERTY_Email_Receipt_Subject, model);
        String message = renderTemplate(DeploymentProperty.PROPERTY_Email_Receipt_Message, model);

        SubmissionDeliveryService deliveryService = (SubmissionDeliveryService)
            ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DELIVERY);
        String fromAddress = deliveryService.getDeliveryEmailSender();

        List<File> fileAttachmentList = new ArrayList<File>();
        fileAttachmentList.add(createPDFReceipt(submission));

        sendMessage(subject, message, fromAddress, toAddress, null, fileAttachmentList);

        // Delete any file attachments from the file system
        for (File attachment : fileAttachmentList) {
            attachment.delete();
        }
    }

    public void sendPromotionNotificationMessage (String toAddress, String formName, String promotionLevelName, String clientName, String notes) {
        Map model = new HashMap();
        model.put("formName", formName);
        model.put("promotionLevelName", promotionLevelName);
        model.put("clientName", clientName);
        model.put("notes", notes);

        String subject = renderTemplate(DeploymentProperty.PROPERTY_Email_Promotion_Subject, model);
        String message = renderTemplate(DeploymentProperty.PROPERTY_Email_Promotion_Message, model);

        String fromAddress = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Promotion_Sender);

        sendMessage(subject, message, fromAddress, toAddress);
    }

    public void sendLostPasswordMessage(UserAccount userAccount) {
        Map model = new HashMap();
        model.put("user", userAccount);

        String subject = renderTemplate(DeploymentProperty.PROPERTY_Email_Lost_Password_Subject, model);
        String message = renderTemplate(DeploymentProperty.PROPERTY_Email_Lost_Password_Message, model);

        String fromAddress = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Support_Sender);

        sendMessage(subject, message, fromAddress, userAccount.getEmail());
    }

    public void sendSubmissionUpdateNotificationMessage(Submission submission) {
        Map model = new HashMap();
        model.put("user", submission.getUser());
        model.put("submission", submission);

        String subject = renderTemplate(DeploymentProperty.PROPERTY_Email_Submission_Update_Subject, model);
        String message = renderTemplate(DeploymentProperty.PROPERTY_Email_Submission_Update_Message, model);

        String fromAddress = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Support_Sender);

        sendMessage(subject, message, fromAddress, submission.getUser().getEmail());
    }

    public void sendWelcomeUserMessage(UserAccount userAccount, Portal portal) {
        Validate.notNull(userAccount, "Null userAccount parameter");
        Validate.notNull(portal, "Null portal parameter");

        Map model = new HashMap();
        model.put("user", userAccount);
        model.put("portal", portal);

        String subject = renderTemplate(DeploymentProperty.PROPERTY_Email_Welcome_User_Subject, model);
        String message = renderTemplate(DeploymentProperty.PROPERTY_Email_Welcome_User_Message, model);

        String fromAddress = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Support_Sender);

        sendMessage(subject, message, fromAddress, userAccount.getEmail());
    }

    public boolean sendTaskNotification(Task task) {
        Validate.notNull(task, "Null task parameter");

        Map model = new HashMap();
        model.put("task", task);
        model.put("portal", task.getPortal());

        String environmentName = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Environment_Name);
        String supportEmail = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Support_Sender);
        model.put("environmentName", environmentName);
        model.put("supportEmail", supportEmail);

        DeploymentPropertyDao deploymentPropertyDao = DaoFactory.getDeploymentPropertyDao();

        String rawSubject = task.getEmailSubject();
        if (StringUtils.isEmpty(rawSubject)) {
            rawSubject = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Task_Notification_Subject);
        }

        String rawMessage = task.getEmailMessage();
        if (StringUtils.isEmpty(rawMessage)) {
            rawMessage = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Task_Notification_Message);
        }

        StringTemplate subjectTemplate = new StringTemplate(rawSubject);
        String subject = subjectTemplate.merge(model);

        StringTemplate messageTemplate = new StringTemplate(rawMessage);
        String message = messageTemplate.merge(model);

        String fromAddress = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Task_Sender);

        if (task.getUser() != null) {
            // task is assigned to a single user
            sendMessage(subject, message, fromAddress, task.getUser().getEmail());
            return true;

        } else {
            // task is assigned to group
            Group group = task.getGroup();
            int emailsSent = 0;

            if (group != null) {
                UserAccountDao userAccountDao = DaoFactory.getUserAccountDao();
                List<UserAccount> assigneeList = userAccountDao.getActiveUsersInGroup(group.getGroupName());

                for (UserAccount assignee: assigneeList) {
                    try {
                        sendMessage(subject, message, fromAddress, assignee.getEmail());
                        ++emailsSent;
                    } catch (ApplicationException ae) {
                        EventLogService eventLogService = ServiceFactory.getEventLogService();
                        eventLogService.logWarnEvent("Task notification email for user " + assignee.getLoginName()
                                + " could not be sent. \nEmail address: " + assignee.getEmail()
                                + " \n Error: " + ae.getUserMessage());
                    }
                }
            }

            return (emailsSent > 0);
        }
    }

    /**
     * Render the named deployment property template with the model using the
     * Velocity engine.
     *
     * @param templateName the template deployment property name
     * @param model the model to render
     * @return the rendered deployment property template
     */
    public String renderTemplate(String templateName, Map model) {
        String environmentName = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Environment_Name);
        String supportEmail = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Email_Support_Sender);
        model.put("environmentName", environmentName);
        model.put("supportEmail", supportEmail);

        String template = deploymentPropertyDao.getPropertyValue(templateName);

        StringTemplate stringTemplate = new StringTemplate(template);

        return stringTemplate.merge(model);
    }

    // -------------------------------------------------------- Private Methods

    private File createPDFReceipt(Submission submission) {

        String fileName = "" + submission.getId() + ".pdf";

        ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
        byte[] formBytes = receiptDataService.getReceiptPdf(submission);

        try {
            return FileUtils.writeToFile(getDeliveryTempDirectory() + fileName, formBytes);

        } catch (IOException ex) {
            throw new ApplicationException("DeliveryPDFError", ex, "Submission OID = " + submission.getId(),
                    "Error creating PDF DeliveryFile", "Error creating PDF DeliveryFile. See Java IO exception for details");
        }
    }

    private String getDeliveryTempDirectory() {
        return deploymentPropertyDao.getConfigSubDirectory("delivery");
    }

}

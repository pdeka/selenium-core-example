package com.avoka.fc.core.service.selenium;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.Validate;

import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.RenderFormService;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides a Form render service for Selenium testing.
 * <p/>
 * Selenium cannot interact with with PDF forms, so in order to submit
 * PDF XML data, we use this custom service to automatically render
 * and post the XML data using an HTML Form.
 *
 * @see SeleniumSubmissionDataExtractionService
 */
public class SeleniumTestRenderFormService implements RenderFormService {

    public void renderForm(TemplateVersion templateVersion, Form form,
            String xmlData, HttpServletRequest request,
            HttpServletResponse response, String targetUrl,
            RequestLog requestLog) throws ApplicationException {

        String target = form.getPortal().getContextPath() + targetUrl;
        Map model = new HashMap();
        model.put(SeleniumSubmissionDataExtractionService.TEST_DATA_PARAM, xmlData);

        autoPostRedirect(request, response, target, model, false);
    }

    /**
     * Perform an auto post redirect to the specified target using the given
     * response. If the params Map is defined then the form will post these
     * values as name value pairs. If the compress value is true, this method
     * will attempt to gzip compress the response content if requesting
     * browser accepts "gzip" encoding.
     * <p/>
     * Once this method has returned you should not attempt to write to the
     * servlet response.
     *
     * @param request the servlet request
     * @param response the servlet response
     * @param target the target URL to send the auto post redirect to
     * @param params the map of parameter values to post
     * @param compress the flag to specify whether to attempt gzip compression
     *         of the response content
     */
    public static void autoPostRedirect(HttpServletRequest request,
            HttpServletResponse response, String target, Map params,
            boolean compress) {

        Validate.notNull(request, "Null response parameter");
        Validate.notNull(response, "Null response parameter");
        Validate.notNull(target, "Null target parameter");

        StringBuilder buffer = new StringBuilder(1024);
        buffer.append("<html><body onload=\"document.forms[0].submit();\">");
        buffer.append("<form name=\"form\" method=\"post\" style=\"{display:none;}\" action=\"");
        buffer.append(target);
        buffer.append("\">");
        for (Iterator i = params.keySet().iterator(); i.hasNext();) {
            String name = i.next().toString();
            String value = params.get(name).toString();
            buffer.append("<textarea");
            buffer.append(" name=\"").append(name).append("\"");
            buffer.append(">");
            buffer.append(value);
            buffer.append("</textarea>");
        }
        buffer.append("</form></body></html>");

        // Determine whether browser will accept gzip compression
        if (compress) {
            compress = false;
            Enumeration e = request.getHeaders("Accept-Encoding");

            while (e.hasMoreElements()) {
                String name = (String) e.nextElement();
                if (name.indexOf("gzip") != -1) {
                    compress = true;
                    break;
                }
            }
        }

        OutputStream os = null;
        GZIPOutputStream gos = null;
        try {
            response.setContentType("text/html");

            if (compress) {
                response.setHeader("Content-Encoding", "gzip");

                os = response.getOutputStream();
                gos = new GZIPOutputStream(os);
                gos.write(buffer.toString().getBytes());

            } else {
                response.setContentLength(buffer.length());

                os = response.getOutputStream();
                os.write(buffer.toString().getBytes());
            }

        } catch (IOException ex) {
            ex.printStackTrace();

        } finally {
            IOUtils.closeQuietly(gos);
            IOUtils.closeQuietly(os);
        }
    }

}

package com.avoka.fc.core.service.finder;

public enum DatabaseColumnNames {

    COLUMN_SERVICE_CODE("service_code"),
    COLUMN_SERVICE_NAME("service_name"),
    COLUMN_SERVICE_TYPE("service_type"),
    COLUMN_SUMMARY("summary"),
    COLUMN_DESCRIPTION("description");

    private String name;

    DatabaseColumnNames(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public boolean equalsTo(String name) {
        return getName().equals(name);
    }

    public static boolean contains(String name) {
        for (DatabaseColumnNames columnName : values()) {
            if (columnName.equalsTo(name)) {
                return true;
            }
        }
        return false;
    }
}

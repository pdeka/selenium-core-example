package com.avoka.fc.core.service.impl;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.service.AuthenticationService;
import com.avoka.fc.core.service.ErrorLogService;
import com.avoka.fc.core.service.FormPrefillService;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.FormUtils;
import com.avoka.fc.forms.api.FormsClientWebService;

public class FormPrefillServiceImpl implements FormPrefillService {

    /** The user account authentication service. */
    private AuthenticationService authenticationService;

    /**
     * @see FormPrefillService#getFormPrefillData(Form, HttpServletRequest)
     */
    public String getFormPrefillData(Form form, HttpServletRequest request) {

        String formsClientWsAddress = FormUtils.getFormClientWsAddress(form);

        if (StringUtils.isNotBlank(formsClientWsAddress)) {
            return null;
        }

        String clientCode = form.getClient().getClientCode();
        String formCode = form.getClientFormCode();
        String clientFormId = form.getClientFormId();

        String userAccountId = (authenticationService != null)
            ? authenticationService.getUserId(request) : null;

        try {
            FormsClientWebService fcWS = ServiceFactory.getFormsClientService(formsClientWsAddress);

            return fcWS.GetFormPrefillData(clientCode, formCode, clientFormId, userAccountId);

        } catch (Exception e) {
            StringBuilder context = new StringBuilder();
            context.append("formsClientWsAddress=" + formsClientWsAddress);
            context.append("clientCode=" + clientCode);
            context.append("formCode=" + formCode);
            context.append("clientFormId=" + clientFormId);
            context.append("userAccountId=" + userAccountId);

            String userMsg = "Error invoking GetFormPrefillData WS: " + e;

            ApplicationException ae = new ApplicationException("FormPrefill", e, context.toString(), userMsg, null);

            ErrorLogService els = ServiceFactory.getErrorLogService();
            els.logException(ae, request, false, null);

            return null;
        }
    }

    /**
     * @see FormPrefillService#setAuthenticationService(AuthenticationService)
     */
    public void setAuthenticationService(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

}

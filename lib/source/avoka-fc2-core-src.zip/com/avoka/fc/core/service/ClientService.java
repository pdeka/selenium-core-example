package com.avoka.fc.core.service;

import java.util.Date;

import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.entity.Client;

public class ClientService extends CayenneService {

    /**
     * Package private constructor to enforce ServiceFactory pattern.
     */
    ClientService() {
    }

    /**
     * Create a new client for the given information.
     */
    public Client createNewClient(String name, String code) {
        Validate.notNull(name, "Null name parameter");
        Validate.notNull(code, "Null code parameter");

        Client client = new Client();
        registerNewObject(client);

        client.setClientName(name);
        client.setClientCode(code);
        client.setActiveFlag(Boolean.TRUE);
        client.setActivateTimestamp(new Date());

        String seed = code + System.currentTimeMillis();
        String clientKey = CoreUtils.toMD5Hash(seed);
        client.setClientKey(clientKey);

        commitChanges();

        return client;
    }
}

package com.avoka.fc.core.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.conf.Configuration;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.fc.core.dao.MetadataListValueDao;
import com.avoka.fc.core.entity.MetadataListValue;
import com.avoka.fc.core.entity.MetadataTag;
import com.avoka.fc.core.util.ApplicationException;

public class MetadataService extends CayenneService {

    public List<MetadataListValue> loadListValuesFromStream(InputStream stream, MetadataTag tag, boolean isHierarchyList) {
        List<MetadataListValue> result = null;

        DataDomain domain = Configuration.getSharedConfiguration().getDomain();
        Transaction transaction = domain.createTransaction();

        Transaction.bindThreadTransaction(transaction);

        try {
            MetadataListValueDao metadataListValueDao = new MetadataListValueDao();
            List <MetadataListValue> oldValues = metadataListValueDao.getListValuesForTag(tag.getId().toString());
            getDataContext().deleteObjects(oldValues);
            commitChanges();

            result = parseListValues(stream, tag, isHierarchyList);
            transaction.commit();
        }
        catch (Exception e) {
            e.printStackTrace();

            try {
                transaction.rollback();
            }
            catch (Exception er) {
                getLogger().error("Error rolling back transaction", er);
            }

            throw new ApplicationException("Error uploading list values", e, "Uploading list values for tag " + tag.getId(), "An error occurred when parsing metadata list values", "Make sure the csv file is correct and complete.");
        }
        finally {
            Transaction.bindThreadTransaction(null);
        }
        return result;
    }

    public List<MetadataListValue> parseListValues(InputStream stream, MetadataTag tag, boolean isHierarchyList) {
        Validate.notNull(tag);

        List<MetadataListValue> result = new ArrayList<MetadataListValue>();

        if (stream != null) {
            int lineCount = 0;
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
                String line = reader.readLine();
                while (StringUtils.isNotEmpty(line)) {
                    ++ lineCount;
                    MetadataListValue newValue = null;
                    if (isHierarchyList) {
                        newValue = parseHierarchyListValue(line, result, tag);
                    }
                    else {
                        newValue = parseListValue(line, result, tag);
                    }
                    if (newValue != null) {
                        result.add(newValue);
                        newValue.setSequence(result.size());
                    }

                    line = reader.readLine();
                }
                getDataContext().commitChanges();
            } catch (IOException ioe) {
                throw new ApplicationException("Error occurred", ioe, "Parsing line " + lineCount, "An error occurred when importing Metadata List Values", "Make sure the file exists, is readable and a valid CSV file");

            } finally {
                IOUtils.closeQuietly(stream);
            }
        }

        return result;
    }

    private MetadataListValue parseListValue(String line, List<MetadataListValue> elements, MetadataTag tag) {
        MetadataListValue result = null;
        if (StringUtils.isNotEmpty(line)) {
            if (line.startsWith("\"") && line.endsWith("\"") && line.length() > 1) {
                line = line.substring(1, line.length()-1);
            }
            result = new MetadataListValue();
            result.setValue(line);
            result.setMetadataTag(tag);
        }
        return result;
    }

    private MetadataListValue parseHierarchyListValue(String line, List<MetadataListValue> elements, MetadataTag tag) {
        MetadataListValue result = null;
        if (StringUtils.isNotEmpty(line)) {
            // remove surrounding quotes
            if (line.startsWith("\"") && line.endsWith("\"") && line.length() > 1) {
                line = line.substring(1, line.length()-1);
            }

            String[] values = line.split(",");
            result = new MetadataListValue();
            result.setValue(values[values.length-1]);
            result.setMetadataTag(tag);
            if (values.length == 2) {
                MetadataListValue parentValue = findParent(values[0], elements, tag);
                result.setParentValue(parentValue);
            }
            else if (values.length == 3) {
                MetadataListValue parentValue = findParent(values[0], values[1], elements, tag);
                result.setParentValue(parentValue);
            }
            else if (values.length > 3) {
                throw new ApplicationException("Error parsing Metadata List Values", "Error at line '" + line + "'", "Expected at most three comma-separated values", "Please correct the CSV file and upload it again");
            }
        }
        return result;
    }

    private MetadataListValue findParent(String level1Value, List<MetadataListValue> elements, MetadataTag tag) {
        Validate.notNull(level1Value);
        MetadataListValue result = null;
        for (int i = elements.size() - 1; i >=0; i--) {
            result = elements.get(i);
            if (level1Value.equals(result.getValue()) && result.getParentValue() == null) {
                return result;
            }
        }

        result = new MetadataListValue();
        result.setValue(level1Value);
        result.setMetadataTag(tag);
        elements.add(result);
        result.setSequence(elements.size());
        return result;
    }

    private MetadataListValue findParent(String level1Value, String level2Value, List<MetadataListValue> elements, MetadataTag tag) {
        Validate.notNull(level1Value);
        Validate.notNull(level2Value);
        MetadataListValue result = null;
        MetadataListValue level1Parent = findParent(level1Value, elements, tag);
        for (int i = elements.size() - 1; i >=0; i--) {
            result = elements.get(i);
            if (level2Value.equals(result.getValue()) && level1Parent.getValue().equals(result.getParentValue().getValue())) {
                return result;
            }
        }

        result = new MetadataListValue();
        result.setValue(level2Value);
        result.setParentValue(level1Parent);
        result.setMetadataTag(tag);
        elements.add(result);
        result.setSequence(elements.size());

        return result;
    }
}

package com.avoka.fc.core.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.Group;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.entity.UserAccount;

public class TaskService extends CayenneService {

    public Task createTask(Form form, Portal portal, String taskMessage, String formDataXml,
            String prefillDataXml, boolean sendEmailFlag, String emailSubject, String emailMessage,
            boolean userDeletableFlag) {
        Validate.notNull(form, "Null form parameter");
        Validate.notNull(portal, "Null portal parameter");
        Validate.notEmpty(taskMessage, "Null taskMessage parameter");
        Validate.isTrue(StringUtils.isEmpty(formDataXml) || StringUtils.isEmpty(prefillDataXml),
                "Both formDataXml and prefillDataXml specified");

        Task task = (Task) createAndRegisterNewObject(Task.class);

        task.setDatetimeCreated(new Date());
        task.setTaskKey(CoreUtils.createAltKey());
        task.setTaskStatus(Task.TASK_STATUS_ASSIGNED);

        task.setTaskMessage(taskMessage);

        task.setSendEmailFlag(sendEmailFlag);
        if (sendEmailFlag) {
            task.setEmailStatus(Task.EMAIL_STATUS_READY);

            task.setEmailSubject(emailSubject);
            task.setEmailMessage(emailMessage);
        }

        task.setUserDeletableFlag(userDeletableFlag);

        task.setForm(form);
        task.setPortal(portal);
        if (StringUtils.isNotEmpty(formDataXml)) {
            task.setFormDataXmlString(formDataXml);
        }
        if (StringUtils.isNotEmpty(prefillDataXml)) {
            task.setPrefillDataXmlString(prefillDataXml);
        }

        return task;
    }

    public boolean isAssignee(Task task, UserAccount user) {
        Validate.notNull(task, "Null task parameter");

        if (user == null) {
            return false;
        }

        UserAccount assignee = task.getUser();
        if (assignee != null) {
            // task is assigned to a single user
            return (user.getLoginName().equals(assignee.getLoginName()));
        }

        Group assigneeGroup = task.getGroup();
        if (assigneeGroup != null) {
            // task is assigned to a user group
            UserAccountDao userAccountDao = DaoFactory.getUserAccountDao();
            List<UserAccount> assigneeList = userAccountDao.getActiveUsersInGroup(assigneeGroup.getGroupName());
            for (UserAccount curAssignee: assigneeList) {
                if (user.getLoginName().equals(curAssignee.getLoginName())) {
                    return true;
                }
            }
        }

        return false;
    }
}

package com.avoka.fc.core.service;

import java.io.Serializable;

public class EmbeddedAttachment  implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String filename;
    private final byte[] fileBytes;
    private final boolean isPDFForm;

    public EmbeddedAttachment(String filename, byte[] fileBytes, boolean isPDFForm) {
        this.filename = filename;
        this.fileBytes = fileBytes;
        this.isPDFForm = isPDFForm;
    }

    public String getFilename() {
        return filename;
    }

    public byte[] getFileBytes() {
        return fileBytes;
    }

    public boolean isPDFForm() {
        return isPDFForm;
    }

}

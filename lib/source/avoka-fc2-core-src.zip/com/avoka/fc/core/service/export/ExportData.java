package com.avoka.fc.core.service.export;

import java.util.ArrayList;
import java.util.List;

public class ExportData {

    private List<String> headers;

    private List<String> formatters;

    private List<ExportDataRow> rowList;

    public void addHeader(String header) {
        getHeaders().add(header);
    }

    public void setHeaders(List<String> headers) {
        this.headers = headers;
    }

    public List<String> getHeaders() {
        if (headers == null) {
            headers = new ArrayList();
        }
        return headers;
    }

    public void addRow(ExportDataRow exportDataRow) {
        getRowList().add(exportDataRow);
    }

    public void setRowList(List<ExportDataRow> rowList) {
        this.rowList = rowList;
    }

    public List<ExportDataRow> getRowList() {
        if (rowList == null) {
            rowList = new ArrayList<ExportDataRow>();
        }
        return rowList;
    }

    public void setFormatters(List<String> formatters) {
        this.formatters = formatters;
    }

    public List<String> getFormatters() {
        if (formatters == null) {
            formatters = new ArrayList<String>();
        }
        return formatters;
    }
}

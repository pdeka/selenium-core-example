package com.avoka.fc.core.service;

import java.text.MessageFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.avoka.core.util.CoreUtils;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.AuditLog;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.Task;

public class SubmissionStatusService extends CayenneService {

    /**
     * Update the status of the submission and commits the changes
     */
    public void updateStatus(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        // as soon as a form for a task is submitted, mark the task as completed
        // the user submitting the task form will then get a new to do item for the incomplete form
        if (submission.isFormSubmitted()) {
            Task task = submission.getTask();
            if (task != null && task.isAssigned()) {
                task.setTaskStatus(Task.TASK_STATUS_COMPLETED);
                task.setDatetimeCompleted(new Date());
                // make sure the task is set to use the current submission (relevant in scenarios with online saves)
                task.setSubmission(submission);
            }
        }

        // check if all user-related steps (attachments, payment) are completed
        // if so, mark form as completed
        if (submission.isFormSubmitted()
                && (submission.getAttachmentsStatus() == null || submission.isAttachmentsCompleted())
                && (submission.getPaymentStatus() == null || submission.isPaymentCompleted())
                && virusScanComplete(submission)) {

            submission.setFormStatus(Submission.STATUS_Completed);

        } else {
            // check if submission is ready for delivery when it shouldn't be (e.g. virus scan error, payment incomplete)
            // if so, set delivery to Not Ready
            if (!submission.isFormCompleted()
                    && Submission.STATUS_Ready.equals(submission.getDeliveryStatus())) {
                submission.setDeliveryStatus(Submission.STATUS_NotReady);
            }
        }

        // check if the submission is missing the xml data
        // if so, it cannot be delivered or receipted
        ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
        if (submission.isFormCompleted()) {

            // check that the submission has receipt data
            if (receiptDataService.hasReceiptXml(submission)) {

                // check if the submission has been completed by the user, and xml data is available (normal case)
                // if so, it is ready to be receipted
                if (!submission.isReceiptCompleted()
                    && !submission.isUndeliverable()
                    && !submission.isDeliveryCompleted()) {

                    submission.setReceiptStatus(Submission.STATUS_Ready);
                }

            } else {
                // make submission unreceiptable as no receipt data is available
                if (!submission.isReceiptCompleted()) {
                    submission.setReceiptStatus(Submission.STATUS_Error_No_Data);
                }

                // make submission undeliverable unless it has already been delivered or is currently being delivered
                if (submission.getDeliveryStatus() == null
                    || submission.isDeliveryNotReady()
                    || submission.isDeliveryReady()
                    || submission.isDeliveryError()) {

                    submission.setDeliveryStatus(Submission.STATUS_Undeliverable);
                }
            }
        }

        // check if the form has been receipted
        // if so, set delivery and remote audit to Ready
        if (submission.isFormCompleted() && submission.isReceiptCompleted()) {

            // set delivery to Ready unless it has been delivered or marked as undeliverable
            if (!submission.isDeliveryCompleted() && !submission.isUndeliverable()) {
                submission.setDeliveryStatus(Submission.STATUS_Ready);
            }

            // set remote audit to Ready unless it has already been completed
            if (!Submission.STATUS_Completed.equals(submission.getSubmissionAuditStatus())) {
                submission.setSubmissionAuditStatus(Submission.STATUS_Ready);
            }
        }

        commitChanges();
    }

    public void updateDeliveryStatusManually(Submission submission, String newStatus, String loginName) {
        String format = "Submission Delivery Status changed from ''{0}'' to ''{1}'' by {2}";
        Object[] args = { submission.getDeliveryStatus(), newStatus, loginName };

        final String message = MessageFormat.format(format, args);

        if (Submission.STATUS_Completed.equals(newStatus)) {
            SubmissionDeliveryService submissionDeliveryService = (SubmissionDeliveryService)
                ServiceLocator.getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_SUBMISSION_DELIVERY);

            submissionDeliveryService.setSubmissionDeliveryCompletedByAdmin(submission, loginName);

        } else {

            submission.setDeliveryStatus(newStatus);
            submission.setDeliveryMessage(CoreUtils.limitLength(message, 200));
            submission.setDeliveryTime(new Date());

            // If set to delivery ready then reset the attachments to be ready for delivery
            if (submission.isDeliveryReady()) {
                for (Attachment attachment : submission.getAttachments()) {
                    FileUpload fileUpload = attachment.getFileUpload();
                    if (fileUpload != null) {
                        fileUpload.setDeliveryStatus(Submission.STATUS_Ready);
                    }
                }
            }

            ServiceFactory.getEventLogService().logInfoEvent(message, submission);
        }

        // Create audit log record
        DaoFactory.getAuditLogDao().createAuditLogRecord(submission, message, AuditLog.EVENT_TYPE_UPDATE);

        commitChanges();
    }

    public boolean virusScanComplete(Submission submission) {
        // no virus service set up? no need to scan
        if (!ServiceLocator.hasServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_VIRUS_SCAN)) {
            return true;
        }

        // check uploads for virus scan errors and pending scans
        List<Attachment> attachments = submission.getAttachments();
        for (Attachment attachment: attachments) {
            if (attachment.getFileUpload() != null) {
                String virusStatus = attachment.getFileUpload().getVirusStatus();
                if (StringUtils.isEmpty(virusStatus) || FileUpload.VIRUS_STATUS_SCAN_ERROR.equals(virusStatus)) {
                    return false;
                }
            }
        }

        return true;
    }
}

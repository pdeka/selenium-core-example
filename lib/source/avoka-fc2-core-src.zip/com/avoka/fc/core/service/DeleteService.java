/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */

package com.avoka.fc.core.service;

import java.util.List;

import com.avoka.core.xml.export.ExportManager;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.dao.UserAccountDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ClientProperty;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.FormDeployXml;
import com.avoka.fc.core.entity.MetadataTag;
import com.avoka.fc.core.entity.MetadataValue;
import com.avoka.fc.core.entity.PaymentAccount;
import com.avoka.fc.core.entity.PromotionLog;
import com.avoka.fc.core.entity.PropertyType;
import com.avoka.fc.core.entity.ReportClient;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.SpecifiedAttachment;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SupportLog;
import com.avoka.fc.core.entity.Template;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.entity.UserAccount;
import com.avoka.fc.core.util.ApplicationException;
import com.avoka.fc.core.util.RemoteUserProvider;

public class DeleteService extends CayenneService{

    ExportManager exportManager = new ExportManager(new FC2CayenneMetaData());

    public void deleteClient(Client clientToDelete, boolean deleteSubmissionsFlag){

        String clientName = clientToDelete.getClientName();

        // TODO PRC - Nice to create an export of the client prior to deleting.

        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        String mode = deploymentPropertyDao.getPropertyValue(DeploymentProperty.PROPERTY_Production_Mode);
        if (mode.equalsIgnoreCase(DeploymentProperty.PRODUCTION_Mode_Production)) {
            UserAccountDao adminDao = new UserAccountDao();

            UserAccount adminUser = adminDao.getUserAccountForPK(RemoteUserProvider.getAdminId());

            throw new ApplicationException("CannotDeleteClientInProd", "ClientName=" + clientName + " AdminName = "
                    + adminUser.getLoginName(), "Client Organizations cannot be deleted in Production Mode", "");
        }

        if (clientToDelete.getActiveFlag().booleanValue() == true) {

            UserAccountDao adminDao = new UserAccountDao();

            UserAccount adminUser = adminDao.getUserAccountForPK(RemoteUserProvider.getAdminId());
            throw new ApplicationException("CannotDeleteActiveClient", "ClientName=" + clientName + " AdminName = "
                    + adminUser.getLoginName(), "Cannot delete Active Clients. Please make the client inactive prior to deleting.", "");
        }


        exportManager.addRow(clientToDelete);

        List<UserAccount> adminList = clientToDelete.getAdmins();
        for (UserAccount adminDetails : adminList) {
            exportManager.addRow(adminDetails);
        }

        List<PaymentAccount> accountsList = clientToDelete.getAccounts();
        for (PaymentAccount paymentAccount : accountsList) {
            exportManager.addRow(paymentAccount);
        }

        List<ClientProperty> clientPropertiesList = clientToDelete.getClientProperties();
        for (ClientProperty clientProperty : clientPropertiesList) {
            exportManager.addRow(clientProperty);
        }

        List<DeliveryDetails> deliveryDetailsList = clientToDelete.getDeliveryDetails();
        for (DeliveryDetails deliveryDetails : deliveryDetailsList) {
            exportManager.addRow(deliveryDetails);
        }

        List<Form> formList = clientToDelete.getForms();
        for (Form form : formList) {
            deleteForm(clientToDelete, form, deleteSubmissionsFlag);
        }

        List<MetadataTag> tagList = clientToDelete.getMetadataTags();
        for (MetadataTag tag : tagList) {
            exportManager.addRow(tag);
        }

        List<PromotionLog> promotionLogList = clientToDelete.getPromotionLog();
        for (PromotionLog promotionLog : promotionLogList) {
            exportManager.addRow(promotionLog);
        }

        List<PropertyType> propertyTypesList = clientToDelete.getPropertyTypes();
        for (PropertyType propertyType : propertyTypesList) {
            exportManager.addRow(propertyType);
        }

        List<ReportClient> reportsList = clientToDelete.getReports();
        for (ReportClient reportClient : reportsList) {
            exportManager.addRow(reportClient);
            // Cayenne should cascade the delete to the rest

            // List<ReportSchedule> scheduledReportList = reportClient.getScheduledReports();
            // for (ReportSchedule reportSchedule : scheduledReportList) {
            // exportManager.addRow(reportSchedule);
            // List<ReportLog> reportLogList = reportSchedule.getReportLog();
            // for (ReportLog reportLog : reportLogList) {
            // exportManager.addRow(reportSchedule);
            // }
            // }
        }

        List<RequestLog> requestLogList = clientToDelete.getRequestLog();
        for (RequestLog requestLog : requestLogList) {
            exportManager.addRow(requestLog);
        }

        List<SchemaSeed> schemaList = clientToDelete.getSchemas();
        for (SchemaSeed schemaSeed : schemaList) {
            exportManager.addRow(schemaSeed);
            // Canyenne cascade will get property type map, schema_config
        }

        if (deleteSubmissionsFlag) {
            List<Submission> submissionList = clientToDelete.getSubmissions();
            for (Submission submission : submissionList) {
                deleteSubmission(submission);
            }
        }

        List<SupportLog> supportLogList = clientToDelete.getSupportLogs();
        for (SupportLog supportLog : supportLogList) {
            exportManager.addRow(supportLog);
        }

        List<Template> templateList = clientToDelete.getTemplates();
        for (Template template : templateList) {
            deleteTemplate(template);
        }

        exportManager.deleteRows();

        UserAccountDao adminDao = DaoFactory.getUserAccountDao();

        UserAccount adminUser = adminDao.getUserAccountForPK(RemoteUserProvider.getAdminId());

        EventLogService eventService = ServiceFactory.getEventLogService();
        eventService.logInfoEvent("Client Organization has been deleted. Name=" + clientName + " Administrator = "
                + adminUser.getLoginName());

    }

    public void deleteForm(Client clientToDelete, Form form, boolean deleteSubmissionsFlag){

        String clientToDeleteCode = clientToDelete.getClientCode();

        exportManager.addRow(form);
        System.out.println("Delete form " + form.getClientFormCode());

        Template template = form.getTemplate();

        Client templateOwner = template.getClient();

        // Dont delete shared or global templates
        if (!Boolean.TRUE.equals(template.getSharedFlag()) && templateOwner != null) {
            if (templateOwner.getClientCode().equalsIgnoreCase(clientToDeleteCode)) {
                deleteTemplate(template);
            }
        }

        System.out.println("After Delete Template...");
        List<FormDeployXml> formDeployXmlList = form.getFormDeployXml();
        for (FormDeployXml formDeployXml : formDeployXmlList) {
            exportManager.addRow(formDeployXml);
            // This will cascade to its children
        }

        List<SpecifiedAttachment> specifiedAttachmentList = form.getSpecifiedAttachments();
        for (SpecifiedAttachment specifiedAttachment : specifiedAttachmentList) {
            exportManager.addRow(specifiedAttachment);
        }

        System.out.println("End Delete form " + form.getClientFormCode());

    }

    private void deleteTemplate(Template template){
        exportManager.addRow(template);
        List<TemplateVersion> versionList = template.getVersions();
        for (TemplateVersion templateVersion : versionList) {
            exportManager.addRow(templateVersion);
        }

        List<MetadataValue> metadataValueList = template.getMetadataValues();
        for (MetadataValue metadataValue : metadataValueList) {
            exportManager.addRow(metadataValue);
        }

        List<SpecifiedAttachment> specifiedAttachmentList = template.getSpecifiedAttachments();
        for (SpecifiedAttachment specifiedAttachment : specifiedAttachmentList) {
            exportManager.addRow(specifiedAttachment);
        }

    }

    public void deleteSubmission(Submission submission){
        exportManager.addRow(submission);
    }
}

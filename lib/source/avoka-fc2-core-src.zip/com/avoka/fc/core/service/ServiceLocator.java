/*
 * Copyright (c) 2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import java.util.List;

import ognl.Ognl;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avoka.fc.core.dao.ServiceDefinitionDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.ServiceDefinition;
import com.avoka.fc.core.entity.ServiceParameter;
import com.avoka.fc.core.util.ApplicationException;

/**
 * Provides a Service Locator for looking up service classes.
 *
 * @author Malcolm Edgar
 */
public class ServiceLocator {

    /**
     * Return a new service instance for the given service definition.
     *
     * @param serviceDefinition the service definition
     * @return a new service instance for the given service definition
     */
    public static Object getServiceForDefinition(ServiceDefinition serviceDefinition) {
        Validate.notNull(serviceDefinition, "Null serviceDefinition parameter");

        Object service = createService(serviceDefinition);

        return service;
    }

    /**
     * Return a new service instance for the given service definition name.
     *
     * @param serviceName the name of the service definition
     * @return a new service instance for the given service definition name
     */
    public static Object getServiceForName(String serviceName) {
        ServiceDefinitionDao serviceDefinitionDao = new ServiceDefinitionDao();

        ServiceDefinition serviceDefinition = serviceDefinitionDao.getServiceDefinitionForName(serviceName);

        Object service = createService(serviceDefinition);

        return service;
    }

    /**
     * Return a new service instance for the given service definition or type. If the service definition
     * is not specified the default service definition for the service type will be used.
     *
     * @param serviceDefinition the service definition, can be null
     * @param serviceType the service type, cannot be null
     * @return a new service instance for the given definition
     */
    public static Object getServiceForDefinitionOrType(ServiceDefinition serviceDefinition, String serviceType) {
        Validate.notNull(serviceType, "Null serviceType parameter");

        if (getLogger().isDebugEnabled()) {
            String message = "getService() serviceType=" + serviceType + ",serviceDefinition=" + serviceDefinition;
            getLogger().debug(message);
        }

        // If service definition not defined lookup default service for type
        if (serviceDefinition == null) {
            ServiceDefinitionDao serviceDefinitionDao = new ServiceDefinitionDao();

            serviceDefinition = serviceDefinitionDao.getServiceDefinitionDefaultForType(serviceType);
        }

        if (serviceDefinition == null) {
            String msg = "No default service defined for the type: " + serviceType;
            String context = "serviceType=" + serviceType;
            throw new ApplicationException("ServiceLocator", msg, context, null);
        }

        Object service = createService(serviceDefinition);

        return service;
    }

    /**
     * Return a new service instance for the given default service type.
     *
     * @param serviceType the service type, cannot be null
     * @return a new service instance for the given default service type
     */
    public static Object getServiceForTypeDefault(String serviceType) {
        Validate.notNull(serviceType, "Null serviceType parameter");

        ServiceDefinitionDao serviceDefinitionDao = new ServiceDefinitionDao();

        ServiceDefinition serviceDefinition = serviceDefinitionDao.getServiceDefinitionDefaultForType(serviceType);

        Object service = createService(serviceDefinition);

        return service;
    }

    /**
     * Return true if there is a ServiceDefinition for the given service type.
     *
     * @param serviceType the service name to lookup
     * @return true if there is a ServiceDefinition for the given service type
     */
    public static boolean hasServiceForTypeDefault(String serviceType) {
        Validate.notNull(serviceType, "Null serviceType parameter");

        ServiceDefinitionDao serviceDefinitionDao = new ServiceDefinitionDao();

        return serviceDefinitionDao.hasDefaultServiceDefinitionForType(serviceType);
    }

    /**
     * Returns the payment service configured for the client, falling back to the default payment service if needed
     *
     * @param client the client to look up the payment service for
     * @return the payment service (null if not configured and no default payment service exists)
     */
    public static Object getPaymentServiceForClient(Client client) {
        Validate.notNull(client, "Null client parameter");

        ServiceDefinition paymentServiceDefinition = client.getPaymentService();
        Object paymentService = null;
        if (paymentServiceDefinition != null) {
            paymentService = createService(paymentServiceDefinition);
        }
        else {
            paymentService = getServiceForTypeDefault(ServiceDefinition.SERVICE_TYPE_CARD_PAYMENT);
        }

        return paymentService;
    }

    // -------------------------------------------------------- Private Methods

    private static Object createService(ServiceDefinition serviceDefinition) {

        String className = serviceDefinition.getClassname();
        try {

            Class serviceClass = Thread.currentThread().getContextClassLoader().loadClass(className);

            Object service = serviceClass.newInstance();

            if (service instanceof ServiceDefinitionAware) {
                ((ServiceDefinitionAware) service).setServiceDefinition(serviceDefinition);
            }

            List<ServiceParameter> serviceParameters = serviceDefinition.getParameters();
            if (serviceParameters != null) {
                for (ServiceParameter serviceParameter : serviceParameters) {

                    String name = serviceParameter.getName();
                    String value = serviceParameter.getValue();

                    if (value != null) {
                        Ognl.setValue(name, service, value);
                    }
                }
            }

            return service;

        } catch (Exception e) {
            String msg = "Could not instantiate serivce for className: " + className;
            throw new ApplicationException("ServiceLocator", e, msg, msg, null);
        }
    }

    private static Logger getLogger() {
        return LoggerFactory.getLogger(ServiceLocator.class);
    }

}

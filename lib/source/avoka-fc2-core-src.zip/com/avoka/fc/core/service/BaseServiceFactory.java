/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import org.apache.commons.lang.Validate;

import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.util.ApplicationException;

/**
 * The abstract service factory for custom service factories to extend.
 *
 * <pre>
 * CardPaymentServiceFactory factory = new CardPaymentServiceFactory();
 * CardPaymentService cardPaymentService = factory.createCardPaymentService();
 *
 * cardPaymentService.performPayment(..);
 * </pre>
 *
 * @author medgar@avoka.com
 */
public abstract class BaseServiceFactory {

    /**
     * Return a new Service object. Subclasses should use this method to create
     * service objects.
     *
     * @return a new Service object
     */
    protected Object createService(String classPropertyKey) throws ApplicationException {

        Validate.notNull(classPropertyKey, "Null classPropertyKey parameter");

        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();

        String className = deploymentPropertyDao.getPropertyValue(classPropertyKey);

        try {
            Class serviceClass = Thread.currentThread().getContextClassLoader().loadClass(className);

            return serviceClass.newInstance();

        } catch (Exception e) {
            String msg = "Could not instantiate serivce for className: " + className;
            throw new ApplicationException("ServiceFactory", e, msg, msg, null);
        }
    }
}

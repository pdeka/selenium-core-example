/*
 * Copyright (c) 2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.service;

import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.Submission;

public interface SubmissionDeliveryService {

    /**
     * Deliver the given submission and return a delivery status message.
     *
     * @param submission the submission to deliver
     * @return a delivery status message
     */
    public String deliverSubmission(Submission submission);

    /**
     * Set the attachment delivery status as completed.
     *
     * @param attachment the attachment to update as delivery completed
     * @param dataHash the attachment SHA-256 data confirmation hash
     */
    public void setAttachmentDeliveryCompleted(Attachment attachment, String dataHash);

    /**
     * Set the submission delivery status as completed and delete the submission data if configured. Note this method
     * does not commit these changes, that is the responsibility of the calling code.
     *
     * @param submission the submission to update as delivery completed
     * @param dataHash the attachment SHA-256 data confirmation hash
     */
    public void setSubmissionDeliveryCompleted(Submission submission, String dataHash);

    /**
     * Send an submission delivery reminder email.
     *
     * @param submission the submission to send the reminder email to
     */
    public void sendEmailReminder(Submission submission);

    /**
     * Send an submission delivery escalation email.
     *
     * @param submission the submission to send the escalation email to
     */
    public void sendEmailEscalation(Submission submission);

    /**
     * Set the submission delivery status as completed.
     *
     * @param submission the submission to update as delivery completed
     */
    public void setEmailSubmissionDeliveryCompleted(Submission submission);

    /**
     * Set the submission delivery status as completed.
     *
     * @param submission the submission to update as delivery completed
     * @param userName the login name for the administrator who set delivery to be completed
     */
    public void setSubmissionDeliveryCompletedByAdmin(Submission submission, String userName);

    /**
     * Return the delivery service email sender address.
     *
     * @return the delivery service email sender address
     */
    public String getDeliveryEmailSender();

    public String getSecureEmailReminderAgeHours();

    public String getDeliveryEmailEscalationAgeHours();
}

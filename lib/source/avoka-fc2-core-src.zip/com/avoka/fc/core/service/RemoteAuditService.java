package com.avoka.fc.core.service;

import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.Submission;

public interface RemoteAuditService {

    public void auditSubmittedSubmission(Submission submission);
    public void auditSubmittedAttachment(FileUpload fileUpload);
    public void auditDeliveredSubmission(Submission submission);
    public void auditDeliveredAttachment(FileUpload fileUpload);

}

package com.avoka.fc.core.service;

import com.avoka.fc.core.entity.Form;

/**
 * Provides a form meta data rendering service.
 *
 * @author medgar@avoka.com
 */
public interface FormMetaDataService {

    /**
     * Return the list of meta data elements for the form.
     *
     * @param form the form to render the meta data from
     * @return the list of created meta data elements
     */
    public String renderHtmlMetaData(Form form);

}

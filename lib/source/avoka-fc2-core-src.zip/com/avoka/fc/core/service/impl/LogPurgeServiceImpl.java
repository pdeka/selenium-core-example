package com.avoka.fc.core.service.impl;

import com.avoka.fc.core.dao.AuditLogDao;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.ErrorLogDao;
import com.avoka.fc.core.dao.EventLogDao;
import com.avoka.fc.core.dao.HealthMonitorDao;
import com.avoka.fc.core.service.CayenneService;
import com.avoka.fc.core.service.LogPurgeService;

public class LogPurgeServiceImpl extends CayenneService implements LogPurgeService {

    // Constants

    public static final String PARAM_MAX_AUDIT_LOG_AGE_DAYS = "maxAuditLogAgeDays";

    public static final String PARAM_MAX_ERROR_LOG_AGE_DAYS = "maxErrorLogAgeDays";

    public static final String PARAM_MAX_EVENT_LOG_AGE_DAYS = "maxEventLogAgeDays";

    public static final String PARAM_MAX_SYSTEM_HEALTH_LOG_AGE_DAYS = "maxSystemHealthLogAgeDays";

    // Attributes

    /** The maximum age in days for a audit log record. */
    private int maxAuditLogAgeDays;

    /** The maximum age in days for a error log record. */
    private int maxErrorLogAgeDays;

    /** The maximum age in days for a event log record. */
    private int maxEventLogAgeDays;

    /** The maximum age in days for a health monitor log record. */
    private int maxSystemHealthLogAgeDays;

    public void purgeDatabaseRecords() {
        // Purge audit log records
        if (getMaxAuditLogAgeDays() > 0) {
            AuditLogDao auditLogDao = DaoFactory.getAuditLogDao();
            auditLogDao.purgeAuditLog(getMaxAuditLogAgeDays());
            commitChanges();
            getLogger().info("Audit log purged successfully");
        }

        // Purge error log records
        if (getMaxErrorLogAgeDays() > 0) {
            ErrorLogDao errorLogDao = DaoFactory.getErrorLogDao();
            errorLogDao.purgeErrorLog(getMaxErrorLogAgeDays());
            commitChanges();
            getLogger().info("Error log purged successfully");
        }

        // Purge Event log records
        if (getMaxEventLogAgeDays() > 0) {
            EventLogDao eventLogDao = DaoFactory.getEventLogDao();
            eventLogDao.purgeEventLog(getMaxEventLogAgeDays());
            commitChanges();
            getLogger().info("Event log purged successfully");
        }

        // Purge Health Monitor log records
        if (getMaxSystemHealthLogAgeDays() > 0) {
            HealthMonitorDao healthMonitorDao = DaoFactory.getHealthMonitorDao();
            healthMonitorDao.purgeSystemHealthLog(getMaxSystemHealthLogAgeDays());
            commitChanges();
            getLogger().info("Health Monitor log purged successfully");
        }
    }

    public int getMaxAuditLogAgeDays() {
        return maxAuditLogAgeDays;
    }

    public void setMaxAuditLogAgeDays(int maxAuditLogAgeDays) {
        this.maxAuditLogAgeDays = maxAuditLogAgeDays;
    }

    public int getMaxErrorLogAgeDays() {
        return maxErrorLogAgeDays;
    }

    public void setMaxErrorLogAgeDays(int maxErrorLogAgeDays) {
        this.maxErrorLogAgeDays = maxErrorLogAgeDays;
    }

    public int getMaxEventLogAgeDays() {
        return maxEventLogAgeDays;
    }

    public void setMaxEventLogAgeDays(int maxEventLogAgeDays) {
        this.maxEventLogAgeDays = maxEventLogAgeDays;
    }

    public void setMaxSystemHealthLogAgeDays(int maxSystemHealthLogAgeDays) {
        this.maxSystemHealthLogAgeDays = maxSystemHealthLogAgeDays;
    }

    public int getMaxSystemHealthLogAgeDays() {
        return maxSystemHealthLogAgeDays;
    }
}

package com.avoka.fc.core.service;

import java.io.OutputStream;
import java.util.List;

import com.avoka.core.xml.export.ExportManager;
import com.avoka.fc.core.dao.RoleDao;
import com.avoka.fc.core.entity.Permission;
import com.avoka.fc.core.entity.Role;
import com.avoka.fc.core.entity.RolePermission;

public class ExportRolesService{

    public static final String EXPORT_Type     = "Role Export";

    public void exportRoles(OutputStream exportOutStream, String roleName, String description, String environmentName){

        ExportManager exportManager = new ExportManager(new FC2CayenneMetaData());

        RoleDao roleDao = new RoleDao();
        List<Role> roleList = roleDao.getRoles();
        for (Role role : roleList) {
            if (role.getRoleName().equalsIgnoreCase("Administrator") == false) {
                // Don't export Administrator
                exportManager.addRow(role, true, true);
                List<RolePermission> rolePermissionList = role.getRolePermissions();
                for (RolePermission rolePermission : rolePermissionList) {
                    exportManager.addRow(rolePermission, true, true);
                    Permission permission = rolePermission.getPermission();
                    exportManager.addRow(permission, true, true);
                }
            }
        }

        // exportManager.writeXml(exportDir, "client_export" + name + ".xml", metaDataManager,
        // exportOutStream, "Client Export", clientName, description);
        exportManager.writeXml(exportOutStream, EXPORT_Type, roleName, description, environmentName);
    }

}

package com.avoka.fc.core.mbean;

public interface CayenneRuntimeMBean {

    public String getDataSourceFactory();

    public String getDataSourceLocation();

    public String getDataNodeName();

    public String getDomainName();

    public boolean getSharedCacheEnabled();

    public String getVersion();

}

package com.avoka.fc.core.mbean;

import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.DataNode;
import org.apache.cayenne.conf.Configuration;

public class CayenneRuntime implements CayenneRuntimeMBean {

    public String getDomainName() {
        return Configuration.getSharedConfiguration().getDomain().getName();
    }

    public boolean getSharedCacheEnabled() {
        return Configuration.getSharedConfiguration().getDomain().isSharedCacheEnabled();
    }

    public String getVersion() {
        return Configuration.getSharedConfiguration().getProjectVersion();
    }

    public String getDataNodeName() {
        DataDomain dataDomain = Configuration.getSharedConfiguration().getDomain();
        DataNode dataNode = dataDomain.getDataNodes().iterator().next();
        return dataNode.getName();
    }

    public String getDataSourceFactory() {
        DataDomain dataDomain = Configuration.getSharedConfiguration().getDomain();
        DataNode dataNode = dataDomain.getDataNodes().iterator().next();
        return dataNode.getDataSourceFactory();
    }

    public String getDataSourceLocation() {
        DataDomain dataDomain = Configuration.getSharedConfiguration().getDomain();
        DataNode dataNode = dataDomain.getDataNodes().iterator().next();
        return dataNode.getDataSourceLocation();
    }

}

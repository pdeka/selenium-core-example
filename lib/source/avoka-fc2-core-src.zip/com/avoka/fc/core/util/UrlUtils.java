package com.avoka.fc.core.util;

import java.net.URI;
import java.net.URISyntaxException;

/**
 *
 *
 * @author mdeandrade
 *
 */
public class UrlUtils {

    /**
     * Extract the domain out of a url
     *
     * @param url
     *
     * @return
     */
    public static String getDomainOfUrl(String url) {

        URI uri = null;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        String domainName = null;
        if( uri!=null){
            domainName = uri.getHost();
        }
        return domainName;

    }

}

package com.avoka.fc.core.util;

public class ApplicationFileUploadException extends ApplicationException {

    // Constants
    private static final long serialVersionUID = 1L;

    public ApplicationFileUploadException(String name, Throwable cause, String context, String userMessage,  String solution) {
        super(name, cause, context, userMessage, solution);
    }

    public ApplicationFileUploadException(String name, String context, String userMessage,  String solution) {
        super(name, context, userMessage, solution);
    }
}

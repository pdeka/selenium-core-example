package com.avoka.fc.core.util.xml;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.avoka.fc.core.entity.SchemaSeed;

public class XmlPropertyUtils {

    /**
     * Return the configured schema element for the given schema config name and XML document.
     *
     * @param document the XML document
     * @param schema the XML schema definition
     * @param name the name of the schema config xpath
     * @return the configured schema element for the given schema config name and XML document
     */
    public static Element getElement(Document document, SchemaSeed schema, String name) {
        Validate.notNull(document, "Null document parameter");
        Validate.notNull(schema, "Null schema parameter");
        Validate.notNull(name, "Null name parameter");

        String configXPath = schema.getConfigXPath(name);

        if (configXPath == null) {
            throw new IllegalArgumentException("Schema config xpath could not be found for name: " + name);
        }

        return getElement(document, configXPath);
    }

    /**
     * Return the configured schema element for the given schema config name and XML document.
     *
     * @param document the XML document
     * @param schema the XML schema definition
     * @param name the name of the schema config xpath
     * @return the configured schema element for the given schema config name and XML document
     */
    public static Element getElement(Document document, String elementXPath) {
        Validate.notNull(document, "Null document parameter");
        Validate.notNull(elementXPath, "Null elementXPath parameter");

        if (elementXPath.endsWith("/")) {
            elementXPath = elementXPath.substring(0, elementXPath.length() - 1);
        }

        try {
            XPathFactory factory = XPathFactory.newInstance();
            XPath xpath = factory.newXPath();

            XPathExpression expr = xpath.compile(elementXPath);

            Object result = expr.evaluate(document, XPathConstants.NODESET);

            NodeList nodes = (NodeList) result;
            if (nodes.getLength() > 0) {
                return (Element) nodes.item(0);

            } else {
                return null;
            }

        } catch (XPathExpressionException xee) {
            String msg = "XPath expression error for xpath '" + elementXPath + "'";
            throw new RuntimeException(msg, xee);
        }
    }

    public static Element getOrCreateElement(Document document, SchemaSeed schema, String name) {
        Element element = getElement(document, schema, name);

        // If element not found then create the element and it to the document
        if (element == null) {
            String configXPath = schema.getConfigXPath(name);

            // Strip off leading and trailing elements.

            if (configXPath.startsWith("//")) {
                configXPath = configXPath.substring(2, configXPath.length());
            }
            if (configXPath.endsWith("/")) {
                configXPath = configXPath.substring(0, configXPath.length() - 1);
            }

            String[] elements = configXPath.split("/");

            Element parent = document.getDocumentElement();

            for (String value : elements) {
                Element valueElement = document.createElement(value);
                parent.appendChild(valueElement);
                parent = valueElement;
            }
        }

        return element;
    }

    public static Element getOrCreateElement(Document document, String elementXPath) {
        Validate.notNull(document, "Null document parameter");
        Validate.notNull(elementXPath, "Null elementXPath parameter");

        Element element = getElement(document, elementXPath);

        if (element != null) {
            return element;

        } else {
            // Else create the element using the provided element xpath

            // First strip off leading and trailing //.
            if (elementXPath.startsWith("//")) {
                elementXPath = elementXPath.substring(2, elementXPath.length());
            }
            if (elementXPath.endsWith("/")) {
                elementXPath = elementXPath.substring(0, elementXPath.length() - 1);
            }

            String[] elements = elementXPath.split("/");

            Element parent = document.getDocumentElement();

            for (String value : elements) {
                Element valueElement = document.createElement(value);
                parent.appendChild(valueElement);
                parent = valueElement;
            }

            // Return the last element created
            return parent;
        }
    }

}

package com.avoka.fc.core.util.xml;

import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

import com.avoka.core.util.XmlUtils;

public class SystemProfileHelper{

    public static final String  MODE_ENTRY                               = "Entry";
    public static final String  MODE_RECEIPT                             = "Receipt";

    private static final String SYSTEM_PROFILE_XPATH                     = "//SystemProfile";

    private static final String REQUEST_LOG_KEY                          = "RequestLogKey";
    private static final String SUBMISSION_EXPIRY_DATE                   = "SubmissionExpiryDate";
    private static final String SUBMISSION_EXPIRY_DURATION               = "SubmissionExpiryDuration";

    // System Properties
    private static final String SYSTEM_Property_DisplayMode              = "DisplayMode";
    private static final String SYSTEM_Property_FormCode                 = "FormCode";
    private static final String SYSTEM_Property_FormDeployOid            = "FormDeployOid";
    private static final String SYSTEM_Property_IncompatibleReaderURL    = "IncompatibleReaderURL";
    private static final String SYSTEM_Property_LocalSaveEnabledFlag     = "LocalSaveEnabledFlag";
    private static final String SYSTEM_Property_OnlineSaveEnabledFlag    = "OnlineSaveEnabledFlag";
    private static final String SYSTEM_Property_RegistrationRequiredFlag = "RegistrationRequiredFlag";
    private static final String SYSTEM_Property_ReaderVersionRequired    = "ReaderVersionRequired";
    private static final String SYSTEM_Property_ReceiptNumber            = "ReceiptNumber";
    private static final String SYSTEM_Property_RedirectTarget           = "RedirectTarget";
    private static final String SYSTEM_Property_Referer                  = "Referer";
    private static final String SYSTEM_Property_ServerBuildNumber        = "ServerBuildNumber";
    private static final String SYSTEM_Property_SubmissionMessage        = "SubmissionMessage";
    private static final String SYSTEM_Property_SubmissionNumber         = "SubmissionNumber";
    private static final String SYSTEM_Property_SubmissionType           = "SubmissionType";
    private static final String SYSTEM_Property_SubmitDateString         = "SubmitDateString";
    private static final String SYSTEM_Property_TaskKey                  = "TaskKey";

    private static final String SYSTEM_Property_TemplateVersionOid       = "TemplateVersionOid";
    private static final String SYSTEM_Property_TestMode                 = "TestMode";
    private static final String SYSTEM_Property_UserCode                 = "UserCode";

    /** The XML element. */
    private Document            document;

    /** The SystemProfile element. */
    private Element             systemProfileElement;

    // ---------------------------------------------------------------------------------------------------
    // Constructors

    /**
     * Create a SystemProfileHelper for the given XML document.
     *
     * @param schema
     *            the form template schema
     */
    public SystemProfileHelper(Document document){
        Validate.notNull(document, "Null document parameter");

        this.document = document;
        this.systemProfileElement = XmlPropertyUtils.getOrCreateElement(document, SYSTEM_PROFILE_XPATH);
    }

    // -------------------------------------------------------------------------------------------------
    // Public Methods

    public String getFormCode(){
        return getChildValue(SYSTEM_Property_FormCode);
    }

    public void setFormCode(String value){
        setChildValue(SYSTEM_Property_FormCode, value);
    }

    public String getTemplateVersionOid(){
        return getChildValue(SYSTEM_Property_TemplateVersionOid);
    }

    public void setTemplateVersionOid(Object value){
        setChildValue(SYSTEM_Property_TemplateVersionOid, value);
    }

    /**
     * Return the unique user code, which is the save as the user key.
     *
     * @return the unique user code or user key value
     */
    public String getUserCode(){
        return getChildValue(SYSTEM_Property_UserCode);
    }

    /**
     * Set the unique user code, which is the save as the user key.
     *
     * @param value
     *            the unique user code or user key value
     */
    public void setUserCode(String value){
        setChildValue(SYSTEM_Property_UserCode, value);
    }

    public String getReaderVersionRequired(){
        return getChildValue(SYSTEM_Property_ReaderVersionRequired);
    }

    public void setReaderVersionRequired(String value){
        setChildValue(SYSTEM_Property_ReaderVersionRequired, value);
    }

    public String getReceiptNumber(){
        return getChildValue(SYSTEM_Property_ReceiptNumber);
    }

    public void setReceiptNumber(String value){
        setChildValue(SYSTEM_Property_ReceiptNumber, value);
    }

    public String getReferer(){
        return getChildValue(SYSTEM_Property_Referer);
    }

    public void setReferer(String value){
        setChildValue(SYSTEM_Property_Referer, value);
    }

    public String getRedirectTarget(){
        return getChildValueOptional(SYSTEM_Property_RedirectTarget);
    }

    public void setRedirectTarget(String value){
        setChildValue(SYSTEM_Property_RedirectTarget, value);
    }

    public String getRequestLogKey(){
        return getChildValue(REQUEST_LOG_KEY);
    }

    public void setRequestLogKey(Object value){
        setChildValue(REQUEST_LOG_KEY, value);
    }

    public String getExpiryDate(){
        return getChildValue(SUBMISSION_EXPIRY_DATE);
    }

    public void setExpiryDate(String value){
        setChildValue(SUBMISSION_EXPIRY_DATE, value);
    }

    public String getIncompatibleReaderURL(){
        return getChildValue(SYSTEM_Property_IncompatibleReaderURL);
    }

    public void setIncompatibleReaderURL(String value){
        setChildValue(SYSTEM_Property_IncompatibleReaderURL, value);
    }

    public Boolean getTestMode(){
        return getBooleanChildValue(SYSTEM_Property_TestMode);
    }

    public void setTestMode(Boolean value){
        setChildValue(SYSTEM_Property_TestMode, value);
    }

    public String getDisplayMode(){
        return getChildValue(SYSTEM_Property_DisplayMode);
    }

    public void setDisplayMode(String value){
        setChildValue(SYSTEM_Property_DisplayMode, value);
    }

    public String getServerBuildNumber(){
        return getChildValue(SYSTEM_Property_ServerBuildNumber);
    }

    public void setServerBuildNumber(String value){
        setChildValue(SYSTEM_Property_ServerBuildNumber, value);
    }

    public String getSubmissionExpiryDate(){
        return getChildValue(SUBMISSION_EXPIRY_DATE);
    }

    public void setSubmissionExpiryDate(String value){
        setChildValue(SUBMISSION_EXPIRY_DATE, value);
    }

    public String getSubmissionExpiryDuration(){
        return getChildValue(SUBMISSION_EXPIRY_DURATION);
    }

    public void setSubmissionExpiryDuration(Object value){
        setChildValue(SUBMISSION_EXPIRY_DURATION, value);
    }

    public String getSubmissionMessage(){
        return getChildValueOptional(SYSTEM_Property_SubmissionMessage);
    }

    public void setSubmissionMessage(String value){
        setChildValue(SYSTEM_Property_SubmissionMessage, value);
    }

    public String getSubmissionNumber(){
        return getChildValue(SYSTEM_Property_SubmissionNumber);
    }

    public void setSubmissionNumber(Object value){
        setChildValue(SYSTEM_Property_SubmissionNumber, value);
    }

    public String getSubmissionType(){
        return getChildValue(SYSTEM_Property_SubmissionType);
    }

    public void setSubmissionType(String value){
        setChildValue(SYSTEM_Property_SubmissionType, value);
    }

    public String getLocalSaveEnabledFlag(){
        return getChildValue(SYSTEM_Property_LocalSaveEnabledFlag);
    }

    public void setLocalSaveEnabledFlag(Object value){
        setChildValue(SYSTEM_Property_LocalSaveEnabledFlag, value);
    }

    public String getOnlineSaveEnabledFlag(){
        return getChildValue(SYSTEM_Property_OnlineSaveEnabledFlag);
    }

    public void setOnlineSaveEnabledFlag(Object value){
        setChildValue(SYSTEM_Property_OnlineSaveEnabledFlag, value);
    }

    public String getRegistrationRequiredFlag(){
        return getChildValue(SYSTEM_Property_RegistrationRequiredFlag);
    }

    public void setRegistrationRequiredFlag(Object value){
        setChildValue(SYSTEM_Property_RegistrationRequiredFlag, value);
    }

    public String getFormDeployOid(){
        return getChildValueOptional(SYSTEM_Property_FormDeployOid);
    }

    public void setFormDeployOid(Object value){
        setChildValue(SYSTEM_Property_FormDeployOid, value);
    }

    public String getSubmitDateString(){
        return getChildValue(SYSTEM_Property_SubmitDateString);
    }

    public void setSubmitDateString(String value){
        setChildValue(SYSTEM_Property_SubmitDateString, value);
    }

    public String getTaskKey(){
        return getChildValueOptional(SYSTEM_Property_TaskKey);
    }

    public void setTaskKey(String value){
        setChildValue(SYSTEM_Property_TaskKey, value);
    }

    // -----------------------------------------------------------------------------------------------
    // Private Methods

    private String getChildValue(String childName){
        Element childElement = XmlUtils.getChild(systemProfileElement, childName);

        Validate.notNull(childElement, "Element " + SYSTEM_PROFILE_XPATH + "/" + childName + " not found");

        if (childElement.getChildNodes().getLength() > 0) {
            Node node = childElement.getChildNodes().item(0);

            String value = node.getNodeValue();

            // Strip any CDATA enclosure
            if (value != null && value.startsWith("<![CDATA[") && value.endsWith("]]>")) {
                return value.substring(9, value.length() - 3);

            } else {
                return value;
            }


        } else {
            return null;
        }
    }

    private String getChildValueOptional(String childName){
        Element childElement = XmlUtils.getChild(systemProfileElement, childName);

        if (childElement != null) {
            if (childElement.getChildNodes().getLength() > 0) {
                return childElement.getChildNodes().item(0).getNodeValue();

            } else {
                return null;
            }

        } else {
            return null;
        }
    }

    private Boolean getBooleanChildValue(String childName){
        String value = getChildValue(childName);
        return "true".equalsIgnoreCase(value) ? Boolean.TRUE : Boolean.FALSE;
    }

    private void setChildValue(String childName, Object value){
        if (value != null) {
            Element childElement = XmlUtils.getChild(systemProfileElement, childName);

            if (childElement == null) {
                childElement = document.createElement(childName);
                systemProfileElement.appendChild(childElement);

            } else {
                // Remove any child nodes
                int length = childElement.getChildNodes().getLength();
                for (int i = length - 1; i >= 0; i--) {
                    Node node = childElement.getChildNodes().item(i);
                    childElement.removeChild(node);
                }
            }

            Text textNode = document.createTextNode(String.valueOf(value));

            childElement.appendChild(textNode);
        }
    }

}

package com.avoka.fc.core.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.common.Constants;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.PortalDao;
import com.avoka.fc.core.dao.PortalPageDao;
import com.avoka.fc.core.dao.RequestLogDao;
import com.avoka.fc.core.dao.SubmissionDao;
import com.avoka.fc.core.entity.ErrorLog;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.OfflineSubmissionForm;
import com.avoka.fc.core.entity.Portal;
import com.avoka.fc.core.entity.PortalPage;
import com.avoka.fc.core.entity.RequestLog;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.entity.Task;
import com.avoka.fc.core.service.ServiceFactory;
import com.avoka.fc.core.servlet.FormRenderServlet;
import com.avoka.fc.core.servlet.ReceiptRenderServlet;
import com.avoka.fc.core.servlet.TaskRenderServlet;
import com.avoka.fc.core.util.xml.OfflineSubmissionFormHelper;
import com.avoka.fc.core.util.xml.SystemProfileHelper;

public class PortalUtils {

    public static Portal getPortal(HttpServletRequest request) {
        String contextPath = getPortalContext(request);

        PortalDao portalDao = DaoFactory.getPortalDao();
        Portal portal = portalDao.getPortalByContextPath(contextPath);

        return portal;
    }

    public static Portal getPortalForSubmission(Submission submission) {
        Validate.notNull(submission, "Null submission parameter");

        String xmlDataString = null;
        SubmissionData submissionData = submission.getSubmissionData();
        if (submissionData != null) {
            xmlDataString = submissionData.getSubmissionDataString();
        }

        if (xmlDataString != null) {
            Document document = XmlUtils.parseDocumentFromString(xmlDataString, false, false);
            SystemProfileHelper systemProfileHelper = new SystemProfileHelper(document);
            String requestLogKey = systemProfileHelper.getRequestLogKey();
            RequestLogDao requestLogDao = new RequestLogDao();
            RequestLog requestLog = requestLogDao.getRequestLogFromKey(requestLogKey);

            if (requestLog != null && requestLog.getPortal() != null) {
                return requestLog.getPortal();
            }
        }

        Form form = submission.getForm();
        return form.getPortal();
    }

    public static String getFormLandingPagePath(Form form) {
        Validate.notNull(form, "Null form parameter");

        return getFormLandingPagePath(form.getPortal(), form.getClientFormCode());
    }

    public static String getFormLandingPagePath(Portal portal, String formCode) {
        String path = getFormLandingPath(portal);

        path = StringUtils.replace(path, "${portalContentPath}", portal.getContextPath());

        path += "?" + Constants.PARAM_FormCode + "=" + formCode;

        return path;
    }

    public static String getFormLandingPageURL(String portalContext, String landingPagePath, String formCode) {
        StringBuilder buffer = new StringBuilder();

        buffer.append(portalContext);
        if (!portalContext.endsWith("/") && !landingPagePath.startsWith("/")) {
            buffer.append("/");
        }
        buffer.append(landingPagePath);
        buffer.append("?");
        buffer.append(Constants.PARAM_FormCode);
        buffer.append("=");
        buffer.append(formCode);

        return buffer.toString();
    }

    public static String getFriendlyFormURL(Form form) {
        Validate.notNull(form, "Null form parameter");
        Validate.notNull(form.getClient(), "Null form.client parameter");
        Validate.notNull(form.getPortal(), "Null form.portal parameter");

        Portal portal = form.getPortal();
        String portalContext = portal.getContextPath();

        String clientCode = form.getClient().getClientCode();

        String formName = form.getFormName();

        return getFriendlyFormURL(portalContext, clientCode, formName);
    }

    public static String getFriendlyFormURL(String portalContext, String clientCode, String formName) {
        StringBuilder buffer = new StringBuilder();

        buffer.append(portalContext);
        if (!portalContext.endsWith("/")) {
            buffer.append("/");
        }
        buffer.append(clientCode.replace(" ", "-"));
        buffer.append("/");
        buffer.append(formName.replace(" ", "-"));
        buffer.append("/");

        return buffer.toString().toLowerCase();
    }

    public static String getFormRenderURL(String portalContext, String formCode) {
        if (portalContext.endsWith("/")) {
            portalContext = portalContext.substring(0, portalContext.length() - 1);
        }
        String formRenderURL = portalContext + FormRenderServlet.SERVLET_URL;
        formRenderURL += "?" + Constants.PARAM_FormCode + "=" + formCode;

        return formRenderURL;
    }

    public static String getFormRenderURL(Form form) {
        Portal portal = form.getPortal();
        String portalContext = portal.getContextPath();
        if (portalContext.endsWith("/")) {
            portalContext = portalContext.substring(0, portalContext.length() - 1);
        }
        String formRenderURL = portalContext + FormRenderServlet.SERVLET_URL;
        formRenderURL += "?" + Constants.PARAM_FormCode + "=" + form.getClientFormCode();

        return formRenderURL;
    }

    public static String getFormRenderURL(Submission submission) {
        return getFormRenderURL(submission, false);
    }

    public static String getFormRenderURL(Submission submission, boolean useCurrentTemplateVersion) {
        Portal portal = submission.getPortal();
        String portalContext = portal.getContextPath();
        if (portalContext.endsWith("/")) {
            portalContext = portalContext.substring(0, portalContext.length() - 1);
        }
        String formRenderURL = portalContext + FormRenderServlet.SERVLET_URL;
        formRenderURL += "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();

        if (useCurrentTemplateVersion) {
            formRenderURL += "?" + Constants.PARAM_useCurrentVersion + "=true";
        }

        return formRenderURL;
    }

    public static String getFormReceiptURL(String submitKey) {
        return getFormReceiptURL(submitKey, null);
    }

    public static String getFormReceiptURL(String submitKey, String renderMode) {
        SubmissionDao submissionDao = DaoFactory.getSubmissionDao();
        Submission submission = submissionDao.getSubmissionByKey(submitKey);
        if (submission != null) {
            if (submission.getPortal() != null) {
                String contextPath = submission.getPortal().getContextPath();
                if (contextPath.endsWith("/")) {
                    contextPath = contextPath.substring(0, contextPath.length() - 1);
                }
                String receiptURL = contextPath + ReceiptRenderServlet.SERVLET_URL;
                receiptURL += "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();
                if (StringUtils.isNotEmpty(renderMode)) {
                    receiptURL += "&" + Constants.PARAM_RenderMode + "=" + renderMode;
                }
                return receiptURL;

            } else {
                String msg = "PortalUtils.getFormReceiptURL could not resolve portal associated with submission: "
                    + submission.getId();
                ServiceFactory.getEventLogService().logErrorEvent(msg, submission);
                return null;
            }

        } else {
            return null;
        }
    }

    public static String getFormReceiptURL(Submission submission) {
        Portal portal = submission.getPortal();
        if (portal != null) {
            String contextPath = portal.getContextPath();
            if (contextPath.endsWith("/")) {
                contextPath = contextPath.substring(0, contextPath.length() - 1);
            }
            String receiptURL = contextPath + ReceiptRenderServlet.SERVLET_URL;
            receiptURL += "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();
            return receiptURL;

        } else {
            return null;
        }
    }

    public static String getTaskRenderURL(Task task) {
        Portal portal = task.getPortal();
        if (portal != null) {
            String contextPath = portal.getContextPath();
            if (contextPath.endsWith("/")) {
                contextPath = contextPath.substring(0, contextPath.length() - 1);
            }
            String taskURL = contextPath + TaskRenderServlet.SERVLET_URL;
            taskURL += "?" + Constants.PARAM_TaskKey + "=" + task.getTaskKey();
            return taskURL;

        } else {
            return null;
        }
    }

    public static String addContextToPath(Portal portal, String path) {
        Validate.notNull(path, "Null path parameter");

        String portalContext = portal.getContextPath();
        if (!portalContext.endsWith("/") && !path.startsWith("/")) {
            portalContext += "/";
        }

        String fullPath = portalContext + path;

        return fullPath;
    }

    public static String getDefaultPortalPath(String pathName) {
        Validate.notEmpty(pathName, "Empty pathName parameter");
        PortalDao portalDao = DaoFactory.getPortalDao();
        Portal portal = portalDao.getDefaultPortal();
        if (portal == null) {
            throw new ApplicationException("Default portal not set", "Attempting to retrieve the default portal", "Your page could not be displayed because no default portal has been defined", "Contact an administrator to have the default portal configured");
        }

        PortalPageDao portalPageDao = DaoFactory.getPortalPageDao();
        PortalPage portalPage = portalPageDao.getPortalPageByName(portal.getId(), pathName);
        if (portalPage == null) {
            throw new ApplicationException("Path for page '" + pathName + "' not set", "Attempting to retrieve portal page", "The path for the page you requested has not been configured", "Contact an administrator to have the page path configured");
        }
        String path = portalPage.getPath();
        return addContextToPath(portal, path);
    }

    public static String getPath(Portal portal, String pathName) {
        Validate.notNull(portal, "Null portal parameter");
        Validate.notEmpty(pathName, "Empty pathName parameter");

        PortalPageDao portalPageDao = DaoFactory.getPortalPageDao();
        PortalPage portalPage = portalPageDao.getPortalPageByName(portal, pathName);
        if (portalPage == null) {
            throw new ApplicationException("Path for page '" + pathName + "' not set", "Attempting to retrieve portal page", "The path for the page you requested has not been configured", "Contact an administrator to have the page path configured");
        }

        String path = portalPage.getPath();

        return addContextToPath(portal, path);
    }

    public static String getFormErrorPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Form_Error);
    }

    public static String getFormLandingPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Form_Landing);
    }

    public static String getFormNotFoundPath(HttpServletRequest request) {
        Portal portal = getPortal(request);
        return getPath(portal, PortalPage.PAGE_Form_Not_Found);
    }

    public static String getIncompatibleReaderPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Incompatible_Reader);
    }

    public static String getOffLinePath() {
        return getDefaultPortalPath(PortalPage.PAGE_Offline);
    }

    public static String getSubmissionAttachmentPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Attachment);
    }

    public static String getSubmissionConfirmationPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Confirmation);
    }

    public static String getSubmissionErrorsPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Errors);
    }

    public static String getSubmissionExpiredPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Expired);
    }

    public static String getSubmissionFailedPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Failed);
    }

    public static String getSubmissionPaymentPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Payment);
    }

    public static String getSubmissionPaymentCompletePath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Payment_Complete);
    }

    public static String getSubmissionSavedPath(Portal portal) {
        return getPath(portal, PortalPage.PAGE_Submission_Saved);
    }

    public static String getOfflineSubmissionFormErrorXml(Portal portal, ErrorLog errorLog, String linkUrl) {
        Validate.notNull(portal, "Null portal parameter");
        Validate.notNull(errorLog, "Null errorLog parameter");
        Validate.notEmpty(linkUrl, "Empty linkUrl parameter");

        OfflineSubmissionForm offlineSubmissionForm = portal.getOfflineSubmissionForm();
        if (offlineSubmissionForm == null) {
            throw new ApplicationException("Offline Submission Form not found", "Attempting to process offline submission", "Could not display the offline submission form", "Set up an offline submission form for the appropriate portal");
        }

        String seedDocumentString = new String(offlineSubmissionForm.getSchemaXmlData());
        Document seedDocument = XmlUtils.parseDocumentFromString(seedDocumentString, false, false);
        OfflineSubmissionFormHelper helper = new OfflineSubmissionFormHelper(seedDocument);
        helper.setHeaderText(offlineSubmissionForm.getHeaderText());
        helper.setHeaderFontColor(offlineSubmissionForm.getHeaderFontColor());
        helper.setHeaderBgColor(offlineSubmissionForm.getHeaderBgColor());
        helper.setBodyText(offlineSubmissionForm.getBodyTextError());
        helper.setButtonText(offlineSubmissionForm.getButtonTextError());
        helper.setReceiptNo("Error during form submission");

        helper.setLinkUrl(linkUrl);

        return XmlUtils.toString(seedDocument.getDocumentElement());
    }

    public static String getOfflineSubmissionFormErrorXml(Portal portal, ErrorLog errorLog) {
        String linkUrl = getFormErrorPath(portal) + "?entityId=" + errorLog.getId();
        return getOfflineSubmissionFormErrorXml(portal, errorLog, linkUrl);
    }

    public static String getOfflineSubmissionFormXml(Portal portal, Submission submission, String linkUrl) {
        Validate.notNull(portal, "Null portal parameter");
        Validate.notNull(submission, "Null submission parameter");
        Validate.notEmpty(linkUrl, "Empty linkUrl parameter");

        OfflineSubmissionForm offlineSubmissionForm = portal.getOfflineSubmissionForm();
        if (offlineSubmissionForm == null) {
            throw new ApplicationException("Offline Submission Form not found", "Attempting to process offline submission", "Could not display the offline submission form", "Set up an offline submission form for the appropriate portal");
        }

        String seedDocumentString = new String(offlineSubmissionForm.getSchemaXmlData());
        Document seedDocument = XmlUtils.parseDocumentFromString(seedDocumentString, false, false);
        OfflineSubmissionFormHelper helper = new OfflineSubmissionFormHelper(seedDocument);
        helper.setHeaderText(offlineSubmissionForm.getHeaderText());
        helper.setHeaderFontColor(offlineSubmissionForm.getHeaderFontColor());
        helper.setHeaderBgColor(offlineSubmissionForm.getHeaderBgColor());

        if (submission.isFormSaved()) {
            helper.setBodyText(offlineSubmissionForm.getBodyTextSaved());
            helper.setButtonText(offlineSubmissionForm.getButtonTextSaved());
            helper.setReceiptNo("Please complete form");
        }
        else if (!submission.getRequiredAttachments().isEmpty()) {
            helper.setBodyText(offlineSubmissionForm.getBodyTextAttachments());
            helper.setButtonText(offlineSubmissionForm.getButtonTextAttachments());
            helper.setReceiptNo("Please complete attachments");
        }
        else if (submission.isPaymentRequired() && submission.isPaymentTypeCreditCard()) {
            helper.setBodyText(offlineSubmissionForm.getBodyTextPayment());
            helper.setButtonText(offlineSubmissionForm.getButtonTextPayment());
            helper.setReceiptNo("Please make payment");
        }
        else {
            helper.setBodyText(offlineSubmissionForm.getBodyTextSubmitted());
            helper.setButtonText(offlineSubmissionForm.getButtonTextSubmitted());
            helper.setReceiptNo(submission.getReceiptNumber());
        }

        helper.setLinkUrl(linkUrl);

        return XmlUtils.toString(seedDocument.getDocumentElement());
    }

    public static String getOfflineSubmissionFormXml(Portal portal, Submission submission) {
        String linkUrl = "";
        if (!submission.getRequiredAttachments().isEmpty()) {
            linkUrl = getSubmissionAttachmentPath(portal) + "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();

        } else if (submission.isPaymentRequired() && submission.isPaymentTypeCreditCard() && !submission.isFormSaved()) {
            linkUrl = getSubmissionPaymentPath(portal) + "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();

        } else {
            linkUrl = getSubmissionConfirmationPath(portal) + "?" + Constants.PARAM_SubmitKey + "=" + submission.getSubmitKey();
        }
        return getOfflineSubmissionFormXml(portal, submission, linkUrl);
    }

    // Private Methods --------------------------------------------------------

    private static String getPortalContext(HttpServletRequest request) {
        String requestURL = request.getRequestURL().toString();
        String contextPath = request.getContextPath();

        int index = requestURL.indexOf(contextPath);

        return requestURL.substring(0, index + contextPath.length() + 1);
    }

}

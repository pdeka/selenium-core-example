/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on Dec 24, 2005 Created By pcopeland
 */
package com.avoka.fc.core.util;

import org.apache.commons.lang.Validate;

import com.avoka.fc.core.entity.Client;

/**
 * Provides the base application exception.
 *
 * @author pcopeland@avoka.com
 */
public class ApplicationException extends RuntimeException {

    private static final long serialVersionUID    = 1L;

    /** The name of the exception. */
    String name;

    /** The user context to record any parameters that may be relevant to the exception. */
    String context;

    /** The user message type. This will display various messages to the end user. */
    String userMessage;

    /** The suggested solution for this problem. */
    String solution;

    /** The associated submission form XML. */
    String formXml;

    /** The associated client, if any. */
    Client client;

    // ----------------------------------------------------------- Constructors

    /**
     * Create an application exception object.
     *
     * @param name
     * @param cause
     * @param context
     * @param userMessage - An optional message about the error.
     * @param solution
     */
    public ApplicationException(String name, Throwable cause, String context, String userMessage,  String solution) {
        super(cause.toString(), cause);

        Validate.notNull(name, "Null name parameter");
        Validate.notNull(cause, "Null cause parameter");
        Validate.notNull(context, "Null context parameter");
        Validate.notNull(userMessage, "Null userMessage parameter");

        this.name = name;
        this.context = context;
        this.userMessage = userMessage;
        this.solution = solution;
    }

    /**
     * Create an application exception object.
     *
     * @param name
     * @param context
     * @param userMessage
     * @param solution
     */
    public ApplicationException(String name, String context, String userMessage, String solution) {
        super(name + ": " + context);

        Validate.notNull(name, "Null name parameter");
        Validate.notNull(context, "Null context parameter");
        Validate.notNull(userMessage, "Null userMessage parameter");

        this.name = name;
        this.context = context;
        this.userMessage = userMessage;
        this.solution = solution;
    }

    ApplicationException(String name) {
        super(name);
        this.name = name;
        this.context = null;
        this.userMessage = null;
        this.solution = null;
    }

    // --------------------------------------------------------- Public Methods

    /**
     * Return the user context to record any parameters that may be relevant to
     * the exception.
     *
     * @return the user context of the exception
     */
    public String getContext() {
        return context;
    }

    /**
     * Return the name of the exception.
     *
     *  @return the name of the exception
     */
    public String getName() {
        return name;
    }

    /**
     * Return the user message. This will display various messages to the end
     * user.
     *
     * @return the user message
     */
    public String getUserMessage() {
        return userMessage;
    }

    /**
     * Return the suggested the solution for this problem.
     *
     * @return the suggested the solution for this problem
     */
    public String getSolution() {
        return solution;
    }

    /**
     * Return the submission form XML.
     *
     * @return the submission form XML
     */
    public String getFormXml() {
        return formXml;
    }

    /**
     * Set the submission form XML.
     *
     * @param formXml the submission form XML
     */
    public void setFormXml(String formXml) {
        this.formXml = formXml;
    }

    /**
     * Return the client.
     *
     * @return the client
     */
    public Client getClient() {
        return client;
    }

    /**
     * Set the client.
     *
     * @param client the client
     */
    public void setClient(Client client) {
        this.client = client;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(getClass().getSimpleName());
        builder.append(": ");
        builder.append(getName());
        if (getUserMessage() != null) {
            builder.append(": ");
            builder.append(getUserMessage());
        }

        return builder.toString();
    }

}

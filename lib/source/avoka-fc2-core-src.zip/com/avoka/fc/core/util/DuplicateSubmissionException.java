package com.avoka.fc.core.util;

import org.apache.click.util.HtmlStringBuffer;

import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.RequestLog;

public class DuplicateSubmissionException extends ApplicationException {

    private static final long serialVersionUID = 1L;

    public DuplicateSubmissionException(RequestLog requestLog, Form form) {
        super("Duplicate Form Submission");
        this.context = "Submission.RequestLog.RequestKey: " + ((requestLog != null) ? requestLog.getRequestKey() : "unknown");

        HtmlStringBuffer buffer = new HtmlStringBuffer();

        buffer.append("Sorry because of security reasons, you cannot submit the same form twice. ");

        if (form != null && form.getPortal() != null) {
            buffer.append("Please download a new copy of the ");
            buffer.elementStart("a");
            buffer.appendAttribute("target", "_blank");
            buffer.appendAttribute("href", PortalUtils.getFormRenderURL(form));
            buffer.closeTag();
            buffer.append(form.getFormName());
            buffer.elementEnd("a");
            if (!form.getFormName().trim().toLowerCase().contains("form")) {
                buffer.append(" form");
            }
            buffer.append(", fillout the form again and resubmit it.");

            this.solution = buffer.toString();

        } else {
            this.solution = "Please download a new form and resubmit your data";
        }

        this.userMessage = buffer.toString();
    }

}

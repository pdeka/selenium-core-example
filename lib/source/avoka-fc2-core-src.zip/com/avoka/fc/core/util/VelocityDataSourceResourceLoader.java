package com.avoka.fc.core.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import org.apache.click.Context;
import org.apache.commons.lang.StringUtils;
import org.apache.cxf.helpers.IOUtils;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.resource.Resource;
import org.apache.velocity.runtime.resource.loader.DataSourceResourceLoader;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.DeploymentProperty;
import com.avoka.fc.core.entity.Portal;

public class VelocityDataSourceResourceLoader extends DataSourceResourceLoader {

    @Override
    public synchronized InputStream getResourceStream(String name) throws ResourceNotFoundException {
        if (StringUtils.isEmpty(name)) {
            throw new ResourceNotFoundException(
                "DataSourceResourceLoader: Template name was empty or null");
        }

        name = StringUtils.removeStart(name, "/");

        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = openDbConnection();
            rs = readData(conn, templateColumn, name);

            if (rs.next()) {
                InputStream stream = rs.getBinaryStream(templateColumn);
                if (stream == null) {
                    throw new ResourceNotFoundException(
                        "DataSourceResourceLoader: " + "template column for '"
                                + name + "' is null");
                }

                try {
                    byte[] data = IOUtils.readBytesFromStream(stream);
                    return new ByteArrayInputStream(data);
                } catch (IOException e) {
                    throw new ResourceNotFoundException(e);
                }
            } else {
                throw new ResourceNotFoundException(
                    "DataSourceResourceLoader: " + "could not find resource '"
                            + name + "'");

            }
        } catch (SQLException sqle) {
            String msg = "DataSourceResourceLoader: database problem while getting resource '"
                    + name + "': ";

            log.error(msg, sqle);
            throw new ResourceNotFoundException(msg);
        } catch (NamingException ne) {
            String msg = "DataSourceResourceLoader: database problem while getting resource '"
                    + name + "': ";

            log.error(msg, ne);
            throw new ResourceNotFoundException(msg);
        } finally {
            closeResultSet(rs);
            closeDbConnection(conn);
        }
    }

    public boolean isSourceModified(final Resource resource) {
        DeploymentPropertyDao dao = DaoFactory.getDeploymentPropertyDao();
        boolean cacheTemplates = dao.getPropertyValueBoolean(DeploymentProperty.PROPERTY_Portal_Cache_Enabled);
        if (cacheTemplates) {
            return false;
        }

        final String template = resource.getName();
        String tmp = StringUtils.removeStart(template, "/");
        resource.setName(tmp);
        boolean result = super.isSourceModified(resource);
        resource.setName(template);
        return result;
    }

    public long getLastModified(final Resource resource) {
        final String template = resource.getName();
        String tmp = StringUtils.removeStart(template, "/");
        resource.setName(tmp);
        long result = super.getLastModified(resource);
        resource.setName(template);
        return result;
    }

    protected ResultSet readData(final Connection conn,
            final String columnNames, final String templateName)
            throws SQLException {
        PreparedStatement ps = conn.prepareStatement("SELECT " + columnNames
                + " FROM " + tableName + " WHERE " + keyColumn
                + " = ? and portal_oid = ?");

        Portal portal = getPortal(templateName);
        ps.setString(1, templateName);
        ps.setLong(2, portal.getId());
        return ps.executeQuery();
    }

    protected Portal getPortal(String name) {
        Context context = null;
        try {
            context = Context.getThreadLocalContext();
        } catch (RuntimeException e) {
            // Exception will be thrown when Velocity loads resource at startup, such as macros
            throw new ResourceNotFoundException(
                "DataSourceResourceLoader: " + "could not find resource '"
                        + name + "'");
        }
        return PortalUtils.getPortal(context.getRequest());
    }
}

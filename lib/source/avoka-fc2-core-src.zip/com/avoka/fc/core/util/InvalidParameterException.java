/*
 * Copyright (c) 2006 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka
 * Technologies ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only as may be permitted in writing by
 * Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited.
 * No part of this work may be produced or transmitted in any form by any
 * means, electronic or mechanical, including photocopying and recording,
 * or by any information storage or retrieval system accept as may be permitted
 * in writing by Avoka Technologies Pty Limited.
 *
 * Created on May 28, 2006
 * Created By pcopeland
 */

/*
 * CVS History
 *
 * $Revision: 1.2 $
 *
 * $Log: InvalidParameterException.java,v $
 * Revision 1.2  2008/03/31 05:52:47  medgar
 * *** empty log message ***
 *
 * Revision 1.1  2008/03/17 02:12:50  medgar
 * initial import
 *
 * Revision 1.1  2006/11/29 03:55:22  dfrizelle
 * *** empty log message ***
 *
 * Revision 1.1  2006/11/29 02:32:38  dfrizelle
 * project refactoring
 *
 * Revision 1.1  2006/10/04 06:07:38  dfrizelle
 * Initial Version
 *
 * Revision 1.1  2006/10/01 20:45:55  pcopeland
 * Added
 *
 * Revision 1.2  2006/06/20 08:58:00  pcopeland
 * Added CVS Tags to header
 *
 */
package com.avoka.fc.core.util;

/**
 * Thrown from Servlets when they encounter a bad parameter. Enables us to handle
 * badly formed Servlet requests differently to other exceptions.
 *
 * @author pcopeland
 */
public class InvalidParameterException extends Exception {

    private static final long serialVersionUID = 1L;

    private String parameterName = "None";
    private String parameterValue = "None";

    public InvalidParameterException(String parameterName, String parameterValue) {
        this.parameterName = parameterName;
        this.parameterValue = parameterValue;
    }

    public String getParameterName() {
        return parameterName;
    }

    public String getParameterValue() {
        return parameterValue;
    }

}

package com.avoka.fc.core.util.xml;

import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

import com.avoka.core.util.XmlUtils;

public class OfflineSubmissionFormHelper {

    private static final String HEADER_XPATH                     = "//banner";
    private static final String BODY_XPATH                       = "//body";

    // Header elements
    private static final String HEADER_TEXT                      = "titleText";
    private static final String HEADER_FONT_COLOR                = "titleColor";
    private static final String HEADER_BG_COLOR                  = "titleBgColor";

    // Body elements
    private static final String RECEIPT_NO                       = "receipt";
    private static final String BODY_TEXT                        = "bodyText";
    private static final String BUTTON_TEXT                      = "buttonText";
    private static final String LINK_URL                         = "linkUrl";

    /** The XML element. */
    private Document            document;
    /** The header element. */
    private Element             headerElement;
    /** The body element. */
    private Element             bodyElement;

    public OfflineSubmissionFormHelper(Document document){
        Validate.notNull(document, "Null document parameter");

        this.document = document;
        headerElement = XmlPropertyUtils.getOrCreateElement(document, HEADER_XPATH);
        bodyElement = XmlPropertyUtils.getOrCreateElement(document, BODY_XPATH);
    }

    public String getHeaderText() {
        return getHeaderValue(HEADER_TEXT);
    }

    public void setHeaderText(String headerText) {
        setChildValue(headerElement, HEADER_TEXT, headerText);
    }

    public String getHeaderFontColor() {
        return getHeaderValue(HEADER_FONT_COLOR);
    }

    public void setHeaderFontColor(String headerFontColor) {
        setChildValue(headerElement, HEADER_FONT_COLOR, headerFontColor);
    }

    public String getHeaderBgColor() {
        return getHeaderValue(HEADER_BG_COLOR);
    }

    public void setHeaderBgColor(String headerBgColor) {
        setChildValue(headerElement, HEADER_BG_COLOR, headerBgColor);
    }

    public String getReceiptNo() {
        return getBodyValue(RECEIPT_NO);
    }

    public void setReceiptNo(String receiptNo) {
        setChildValue(bodyElement, RECEIPT_NO, receiptNo);
    }

    public String getBodyText() {
        return getBodyValue(BODY_TEXT);
    }

    public void setBodyText(String bodyText) {
        setChildValue(bodyElement, BODY_TEXT, bodyText);
    }

    public String getButtonText() {
        return getBodyValue(BUTTON_TEXT);
    }

    public void setButtonText(String buttonText) {
        setChildValue(bodyElement, BUTTON_TEXT, buttonText);
    }

    public String getLinkUrl() {
        return getBodyValue(LINK_URL);
    }

    public void setLinkUrl(String linkUrl) {
        setChildValue(bodyElement, LINK_URL, linkUrl);
    }


    private String getHeaderValue(String childName){
        Element childElement = XmlUtils.getChild(headerElement, childName);

        Validate.notNull(childElement, "Element " + HEADER_XPATH + "/" + childName + " not found");

        if (childElement.getChildNodes().getLength() > 0) {
            return childElement.getChildNodes().item(0).getNodeValue();

        } else {
            return null;
        }
    }

    private String getBodyValue(String childName){
        Element childElement = XmlUtils.getChild(bodyElement, childName);

        Validate.notNull(childElement, "Element " + BODY_XPATH + "/" + childName + " not found");

        if (childElement.getChildNodes().getLength() > 0) {
            return childElement.getChildNodes().item(0).getNodeValue();

        } else {
            return null;
        }
    }

    private void setChildValue(Element parentElement, String childName, Object value){
        if (value != null) {
            Element childElement = XmlUtils.getChild(parentElement, childName);

            if (childElement == null) {
                childElement = document.createElement(childName);
                parentElement.appendChild(childElement);

            } else {
                // Remove any child nodes
                int length = childElement.getChildNodes().getLength();
                for (int i = length - 1; i >= 0; i--) {
                    Node node = childElement.getChildNodes().item(i);
                    childElement.removeChild(node);
                }
            }

            Text textNode = document.createTextNode(String.valueOf(value));

            childElement.appendChild(textNode);
        }
    }
}

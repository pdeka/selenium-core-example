/***************************************************************************************************
 * Copyright (c) 2005-2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system except as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * Created on Nov 28, 2005
 **************************************************************************************************/
package com.avoka.fc.core.util;

import java.util.List;

import org.apache.commons.lang.Validate;
import org.jaxen.JaxenException;
import org.jaxen.dom.DOMXPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.adobe.workflow.DOMUtil;
import com.avoka.core.util.XmlUtils;

/**
 * This class "flips" the standard way of doing Jaxen around - it allows you to
 * define the element once, and then evaluate multiple xpath expressions against
 * that node.
 *
 * @author htreisman
 */
public class XPath {

    private final Element documentElement;

    private Logger logger;

    // ----------------------------------------------------------- Constructors

    public XPath(Document document) {
        Validate.notNull(document, "Null document parameter");
        this.documentElement = document.getDocumentElement();
    }

    public XPath(Element documentElement) {
        Validate.notNull(documentElement, "Null documentElement parameter");
        this.documentElement = documentElement;
    }

    // --------------------------------------------------------- Public Methods

    public Element selectSingleNode(String xpath) {
        try {
            DOMXPath domXPath = createDomXPath(xpath);
            return (Element) domXPath.selectSingleNode(documentElement);

        } catch (JaxenException je) {
            String msg = "XPath error for xpath: " + xpath + ", on documentElement: " + documentElement;
            throw new ApplicationException("XPath Error", je, msg, msg, null);
        }
    }

    public List selectNodes(String xpath) {
        try {
            DOMXPath domXPath = createDomXPath(xpath);
            return (List) domXPath.selectNodes(documentElement);

        } catch (JaxenException je) {
            String msg = "XPath error for xpath: " + xpath + ", on documentElement: " + documentElement;
            throw new ApplicationException("XPath Error", je, msg, msg, null);
        }
    }

    public String stringValueOf(String xpath) {
        try {
            DOMXPath domXPath = createDomXPath(xpath);
            return (String) domXPath.stringValueOf(documentElement);

        } catch (JaxenException je) {
            String msg = "XPath error for xpath: " + xpath + ", on documentElement: " + documentElement;
            throw new ApplicationException("XPath Error", je, msg, msg, null);
        }
    }

    /**
     * Return the trimmed string value for the given path.
     */
    public String getPathValue(String path) {
        String value = stringValueOf(path);
        if (value != null) {
            return value.trim();
        } else {
            return value;
        }
    }

    public void setNodeValue(String path, String value)  {
        setNodeValue(path, value, false);
    }

    public void setNodeValue(String path, Boolean value)  {
        Validate.notNull(value, "Null value parameter for path: " + path);
        setNodeValue(path, value.toString(), false);
    }

    public void setNodeValue(String path, Number value)  {
        Validate.notNull(value, "Null value parameter for path: " + path);
        setNodeValue(path, value.toString(), false);
    }

    public void setNodeValue(String path, String value, boolean optional)  {
        Element element = null;
        try {
            element = selectSingleNode(path);

            if (element != null) {
                DOMUtil.setNodeText(element, value);

            } else {
                if (!optional) {
                    throw new ApplicationException("XPathExpressionFailed", null,
                            "No XML node found for path: " + path,
                            "XPath Expression Failed",
                            "The XPath expression failed. Please check the expression and correct it.");
                } else {
                    getLogger().error("No XML node found for path: " + path);
                }
            }

        } catch (Exception ex) {
            if (element != null) {
                getLogger().error("Exception in xpath.SetNodeValue. XML Object Follows");
                getLogger().error(XmlUtils.toString(element));
            }

            String context = "XPath Expression = " + path + " Value = " + value;
            throw new ApplicationException("XPathExpressionFailed", ex, context,
                    "xPath Expression Failed",
                    "The XPath expression failed. Please check the expression and correct it.");
        }
    }

    // -------------------------------------------------------- Private Methods

    /**
     * Creates a new DOMXPath.
     */
    private DOMXPath createDomXPath(String path) throws JaxenException {
        DOMXPath domXPath = new DOMXPath(path);

        Object object = domXPath.evaluate(documentElement);

        if (object == null) {
            getLogger().warn("Xpath expression returned null. Expression: " + path);

        } else if (object instanceof List) {
            List list = (List) object;
            if (list.size() == 0) {
                getLogger().warn("Xpath expression returned an empty list. Expression: " + path);
            }
        }

        return domXPath;
    }


    /**
     * Return the service log.
     *
     * @return the service log
     */
    private Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(getClass());
        }
        return logger;
    }

}

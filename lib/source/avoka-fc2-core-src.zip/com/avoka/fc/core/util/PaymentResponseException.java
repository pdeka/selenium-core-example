package com.avoka.fc.core.util;

public class PaymentResponseException extends ApplicationException {

    private static final long serialVersionUID = 1L;

    public PaymentResponseException(String name, Throwable cause, String context, String userMessage,  String solution) {
        super(name, cause, context, userMessage, solution);
    }

    public PaymentResponseException(String name, String context, String userMessage,  String solution) {
        super(name, context, userMessage, solution);
    }
}

package com.avoka.fc.core.util;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;

import com.avoka.fc.core.util.xml.SystemProfileHelper;

public class SubmissionException extends ApplicationException {

    private static final long serialVersionUID  = 1L;

    /** The formCode of the form that was submitted */
    private String formCode;

    /** The xml data that was submitted */
    private Document formData;

    public SubmissionException(String name, Throwable cause, String context, String userMessage,  String solution, String formCode, Document formData) {
        super(name, cause, context, userMessage, solution);
        this.formCode = formCode;
        this.formData = formData;
    }

    public SubmissionException(String name, String context, String userMessage,  String solution, String formCode, Document formData) {
        super(name, context, userMessage, solution);
        this.formCode = formCode;
        this.formData = formData;
    }

    public String getFormCode() {
        Document curDocument = getFormData();
        if (StringUtils.isEmpty(formCode) && curDocument != null) {
            SystemProfileHelper systemProfileHelper = new SystemProfileHelper(curDocument);
            formCode = systemProfileHelper.getFormCode();
        }
        return formCode;
    }

    public void setFormCode(String newFormCode) {
        formCode = newFormCode;
    }

    public Document getFormData() {
        return formData;
    }

    public void setFormData(Document newFormData) {
        formData = newFormData;
        // reset form code
        formCode = null;
    }

    public String toString() {

        String message = "Submission Exception. Name = " + super.getName();
        message += "\n" + "Form Code = " + formCode;
        message += "\n" + "User Message = " + super.getUserMessage();
        message += "\n" + "Solution = " + super.getSolution();
        message += "\n" + "Context = " + super.getContext();

        return message;

    }
}

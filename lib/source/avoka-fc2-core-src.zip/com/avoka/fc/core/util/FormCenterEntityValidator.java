package com.avoka.fc.core.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.avoka.core.entity.BaseEntity;
import com.avoka.core.xml.importer.IAddEntityListener;
import com.avoka.core.xml.importer.IEntityValidator;
import com.avoka.core.xml.importer.RowBean;
import com.avoka.core.xml.importer.ValidationException;
import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.dao.FormDao;
import com.avoka.fc.core.entity.Client;
import com.avoka.fc.core.entity.Form;

public class FormCenterEntityValidator implements IEntityValidator, IAddEntityListener {

    private Map<String, String> context = new HashMap<String, String>();

    public void validateEntity(RowBean newRow) throws ValidationException {
        String tableName = null;
        if (newRow.getTableBean() != null) {
            tableName = newRow.getTableBean().getTableName();
        }

        if ("Form".equalsIgnoreCase(tableName)) {
            String clientFormCode = newRow.getColumn(Form.CLIENT_FORM_CODE_PROPERTY);
            if (StringUtils.isEmpty(clientFormCode)) {
                throw new ValidationException("Form has no form code.");
            }

            FormDao formDao = DaoFactory.getFormDao();
            Form existingForm = formDao.getFormByFormCode(clientFormCode);
            if (existingForm != null) {
                String newClientCode = context.get(Client.CLIENT_CODE_PROPERTY);
                if (StringUtils.isEmpty(newClientCode)) {
                    throw new ValidationException("Client code for form '" + clientFormCode + "' could not be determined.");
                }

                String existingClientCode = existingForm.getClient().getClientCode();
                if (!newClientCode.equalsIgnoreCase(existingClientCode)) {
                    throw new ValidationException("Form with form code '" + clientFormCode + "' already exists for client '" + existingClientCode + "'.");
                }
            }
        }
    }

    public void preAddEntity(RowBean newRow) {
    }

    public void postAddEntity(BaseEntity newEntity) {
        if (newEntity instanceof Client) {
            Client client = (Client) newEntity;
            context.put(Client.CLIENT_CODE_PROPERTY, client.getClientCode());
        }
    }
}

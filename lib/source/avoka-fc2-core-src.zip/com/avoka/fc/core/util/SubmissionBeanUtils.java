package com.avoka.fc.core.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import com.avoka.fc.core.dao.DaoFactory;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;
import com.avoka.fc.core.service.ReceiptDataService;
import com.avoka.fc.core.service.ServiceFactory;

public class SubmissionBeanUtils {

    public static com.avoka.fc.forms.api.Submission createSubmissionBeanWithAttachments(Submission submission) {
        com.avoka.fc.forms.api.Submission submissionBean = createSubmissionBean(submission);

        List<com.avoka.fc.core.entity.Attachment> attachments =
            DaoFactory.getAttachmentDao().getSubmissionFileAttachments(submission);

        ArrayList<com.avoka.fc.forms.api.Attachment> attachmentBeans = new ArrayList<com.avoka.fc.forms.api.Attachment>();

        for (com.avoka.fc.core.entity.Attachment attachment : attachments) {
            com.avoka.fc.forms.api.Attachment attachmentBean =     DeliveryUtils.createAttachmentBean(attachment);
 
            attachmentBeans.add(attachmentBean);
        }

        submissionBean.setAttachmentList(attachmentBeans);

        return submissionBean;
    }

    public static com.avoka.fc.forms.api.Submission createSubmissionBeanWithAttachmentKeys(Submission submission) {
        com.avoka.fc.forms.api.Submission submissionBean = createSubmissionBean(submission);

        if (submission != null) {
            List<com.avoka.fc.core.entity.Attachment> attachments =
                    DaoFactory.getAttachmentDao().getSubmissionFileAttachments(submission);

            if (attachments != null) {
                ArrayList<String> attachmentKeys = new ArrayList<String>();

                for (com.avoka.fc.core.entity.Attachment attachment : attachments) {
                    attachmentKeys.add(attachment.getAttachmentKey());
                }

                submissionBean.setAttachmentKeys(attachmentKeys);
            }
        }

        return submissionBean;
    }

    private static com.avoka.fc.forms.api.Submission createSubmissionBean(Submission submission) {
        com.avoka.fc.forms.api.Submission submissionBean = new com.avoka.fc.forms.api.Submission();

        try {
            SubmissionData submissionData = submission.getSubmissionData();
            if (submissionData != null) {
                submissionBean.setFormDataBytes(submissionData.getSubmissionDataString().getBytes("UTF-8"));
            }
        } catch (UnsupportedEncodingException uee) {
            // Should never occur
            throw new RuntimeException(uee);
        }

        submissionBean.setFormCode(submission.getForm().getClientFormCode());
        submissionBean.setFormName(submission.getForm().getFormName());
        submissionBean.setFormTemplateVersion(submission.getVersion().getVersionNumber());
        submissionBean.setSubmissionId(submission.getId());
        submissionBean.setSubmissionKey(submission.getSubmitKey());
        submissionBean.setSubmissionTime(submission.getTimeSubmission().getTime());
        submissionBean.setReceiptNumber(submission.getReceiptNumber());

        ReceiptDataService receiptDataService = ServiceFactory.getReceiptDataService();
        submissionBean.setPdfReceiptBytes(receiptDataService.getReceiptPdf(submission));

        return submissionBean;
    }

}

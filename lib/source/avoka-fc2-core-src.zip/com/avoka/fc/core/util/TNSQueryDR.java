/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;

import javax.net.ssl.SSLSocketFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@SuppressWarnings({ "deprecation", "restriction" })
public class TNSQueryDR {

    private Logger logger = LoggerFactory.getLogger(getClass());

    // Define Static Constants
    @SuppressWarnings("deprecation")
    public static com.sun.net.ssl.X509TrustManager    X509_TRUST_MANAGER    = null;
    public static SSLSocketFactory    SSL_SOCKET_FACTORY    = null;

    static {
        X509_TRUST_MANAGER = new com.sun.net.ssl.X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[]{};
            }
            public boolean isClientTrusted(X509Certificate[] chain) {
                return true;
            }
            public boolean isServerTrusted(X509Certificate[] chain) {
                return true;
            }
        };

        java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        try {
            com.sun.net.ssl.SSLContext context = com.sun.net.ssl.SSLContext.getInstance("TLS");
            context.init(null, new com.sun.net.ssl.X509TrustManager[]{X509_TRUST_MANAGER}, null);
            SSL_SOCKET_FACTORY = context.getSocketFactory();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    // ----------------------------------------------------------Public Methods

    public Map executeQueryDR(String vpcUrl, Map<String, String> requestParameters) throws IOException {
        String postData = createPostDataFromMap(requestParameters);

        if (getLogger().isDebugEnabled()) {
            getLogger().debug("postData: " + postData);
        }

        String queryResponse = doPost(vpcUrl, postData);

        if (getLogger().isDebugEnabled()) {
            getLogger().debug("queryResponse: " + queryResponse);
        }

        Map<String, String> responseMap = createMapFromResponse(queryResponse);
        if (responseMap == null || responseMap.size() == 0) {
            throw new PaymentResponseException("EmptyPaymentResponse", "Error processing payment response: " + queryResponse, "The payment response could not be parsed correctly", null);
        }
        return responseMap;
    }

    public Map executeRequest(String vpcURL, Map<String, String> requestParameters) throws IOException {

        String postData = createPostDataFromMap(requestParameters);

        // Don't log any confidential credit card parameters

        String queryResponse = doPost(vpcURL, postData);

        if (getLogger().isDebugEnabled()) {
            getLogger().debug("queryResponse: " + queryResponse);
        }

        Map<String, String> responseMap = createMapFromResponse(queryResponse);
        if (responseMap == null || responseMap.size() == 0) {
            throw new PaymentResponseException("EmptyPaymentResponse", "Error processing payment response: " + queryResponse, "The payment response could not be parsed correctly", null);
        }
        return responseMap;
    }

    /**
     * This function uses the returned status code retrieved from the Digital Response and returns
     * an appropriate description for the code
     *
     * @param vResponseCode String containing the vpc_TxnResponseCode @return description String
     * containing the appropriate description
     */
    public String getTxnResponseDescription(String vResponseCode) {
        String result = "";

        // check if a single digit response code
        if (vResponseCode != null && vResponseCode.length() == 1) {

            // Java cannot switch on a string so turn everything to a char
            char input = vResponseCode.charAt(0);

            switch (input) {
                case '0' :
                    result = "Transaction Successful";
                    break;
                case '1' :
                    result = "Unknown Error";
                    break;
                case '2' :
                    result = "Bank Declined Transaction";
                    break;
                case '3' :
                    result = "No Reply from Bank";
                    break;
                case '4' :
                    result = "Expired Card";
                    break;
                case '5' :
                    result = "Insufficient Funds";
                    break;
                case '6' :
                    result = "Error Communicating with Bank";
                    break;
                case '7' :
                    result = "Payment Server System Error";
                    break;
                case '8' :
                    result = "Transaction Type Not Supported";
                    break;
                case '9' :
                    result = "Bank declined transaction (Do not contact Bank)";
                    break;
                case 'A' :
                    result = "Transaction Aborted";
                    break;
                case 'C' :
                    result = "Transaction Cancelled";
                    break;
                case 'D' :
                    result = "Deferred transaction has been received and is awaiting processing";
                    break;
                case 'F' :
                    result = "3D Secure Authentication failed";
                    break;
                case 'I' :
                    result = "Card Security Code verification failed";
                    break;
                case 'L' :
                    result = "Shopping Transaction Locked (Please try the transaction again later)";
                    break;
                case 'N' :
                    result = "Cardholder is not enrolled in Authentication Scheme";
                    break;
                case 'P' :
                    result = "Transaction has been received by the Payment Adaptor and is being processed";
                    break;
                case 'R' :
                    result = "Transaction was not processed - Reached limit of retry attempts allowed";
                    break;
                case 'S' :
                    result = "Duplicate SessionID (OrderInfo)";
                    break;
                case 'T' :
                    result = "Address Verification Failed";
                    break;
                case 'U' :
                    result = "Card Security Code Failed";
                    break;
                case 'V' :
                    result = "Address Verification and Card Security Code Failed";
                    break;
                case '?' :
                    result = "Transaction status is unknown";
                    break;
                default :
                    result = "Unable to be determined";
            }

            return result;

        } else {
            return "No Value Returned";
        }
    }

    // ------------------------------------------------------- Private Methods

    private Logger getLogger() {
        return logger;
    }

    /**
     * This method is for performing a Form POST operation from input data parameters.
     *
     * @param vpc_Host - is a String containing the vpc URL
     * @param data - is a String containing the post data key value pairs
     * @param useProxy - is a boolean indicating if a Proxy Server is involved in the transfer
     * @param proxyHost - is a String containing the IP address of the Proxy to send the data to
     * @param proxyPort - is an integer containing the port number of the Proxy socket listener
     * @return - is body data of the POST data response
     */
    private String doPost(String vpc_Host, String data) throws IOException {

        InputStream is;
        OutputStream os;
        int vpc_Port = 443;
        String fileName = "";
        boolean useSSL = false;

        // determine if SSL encryption is being used
        if (vpc_Host.substring(0, 8).equalsIgnoreCase("HTTPS://")) {
            useSSL = true;
            // remove 'HTTPS://' from host URL
            vpc_Host = vpc_Host.substring(8);
            // get the filename from the last section of vpc_URL
            fileName = vpc_Host.substring(vpc_Host.lastIndexOf("/"));
            // get the IP address of the VPC machine
            vpc_Host = vpc_Host.substring(0, vpc_Host.lastIndexOf("/"));
        }

        // use next block of code if using SSL encryption
        if (useSSL) {
            Socket s = SSL_SOCKET_FACTORY.createSocket(vpc_Host, vpc_Port);
            os = s.getOutputStream();
            is = s.getInputStream();
            // use next block of code if NOT using SSL encryption
        } else {
            Socket s = new Socket(vpc_Host, vpc_Port);
            os = s.getOutputStream();
            is = s.getInputStream();
        }

        String req = "POST " + fileName + " HTTP/1.0\r\n" + "User-Agent: HTTP Client\r\n"
                + "Content-Type: application/x-www-form-urlencoded\r\n" + "Content-Length: " + data.length() + "\r\n\r\n" + data;

        os.write(req.getBytes());

        String res = new String(readAll(is));

        // check if a successful connection
        if (res.indexOf("200") < 0) {
            throw new IOException("Connection Refused - " + res);
        }

        if (res.indexOf("404 Not Found") > 0) {
            throw new IOException("File Not Found Error - " + res);
        }

        int resIndex = res.indexOf("\r\n\r\n");
        String body = res.substring(resIndex + 4, res.length());

        return body;
    }

    /**
     * This method is for creating a byte array from input stream data.
     *
     * @param is - the input stream containing the data
     * @return is the byte array of the input stream data
     */
    private byte[] readAll(InputStream is) throws IOException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];

        while (true) {
            int len = is.read(buf);
            if (len < 0) {
                break;
            }
            baos.write(buf, 0, len);
        }
        return baos.toByteArray();
    }

    /**
     * This method is for creating a URL POST data string.
     *
     * @param fields is the input parameters from the order page
     * @return is the output String containing POST data key value pairs
     */
    private String createPostDataFromMap(Map<String, String> fields) {
        StringBuffer buf = new StringBuffer();

        String ampersand = "";

        // append all fields in a data string
        for (Iterator i = fields.keySet().iterator(); i.hasNext();) {

            String key = (String) i.next();
            String value = fields.get(key);

            if ((value != null) && (value.length() > 0)) {
                // append the parameters
                buf.append(ampersand);
                buf.append(URLEncoder.encode(key));
                buf.append('=');
                buf.append(URLEncoder.encode(value));
            }
            ampersand = "&";
        }

        // return string
        return buf.toString();
    }

    /**
     * This method is for creating a URL POST data string.
     *
     * @param queryString is the input String from POST data response
     * @return is a Hashmap of Post data response inputs
     */
    private Map<String, String> createMapFromResponse(String queryString) {
        Map<String, String> map = new TreeMap<String, String>();
        StringTokenizer st = new StringTokenizer(queryString, "&");
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            int i = token.indexOf('=');
            if (i > 0) {
                try {
                    String key = token.substring(0, i);
                    String value = URLDecoder.decode(token.substring(i + 1, token.length()));
                    map.put(key, value);
                } catch (Exception ex) {
                    // Do Nothing and keep looping through data
                }
            }
        }
        return map;
    }

}

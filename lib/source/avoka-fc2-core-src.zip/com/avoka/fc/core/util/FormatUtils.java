package com.avoka.fc.core.util;

public class FormatUtils {

    public static String formatHttpUrl(String url) {
        if (url != null && !url.startsWith("http://") && !url.startsWith("https://")) {
            return "http://" + url;
        }
        return url;
    }
}

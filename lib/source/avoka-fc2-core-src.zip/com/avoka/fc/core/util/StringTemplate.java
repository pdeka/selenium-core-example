/*
 * Copyright (c) 2007 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.core.util;

import java.io.StringWriter;
import java.util.Collections;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

/**
 * Provides a StringTemplate which utilizes the Velocity Engine.
 *
 * @author medgar@avoka.com
 */
public class StringTemplate {

    /** The Velocity runtime environment. */
    private static final VelocityEngine VE = new VelocityEngine();

    static {
        try {
            VE.init();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /** The string template content. */
    private final String content;

    /**
     * Create a template with the given content.
     *
     * @param content the template content
     */
    public StringTemplate(String content) {
        if (content == null) {
            throw new IllegalArgumentException("Null content parameter");
        }
        this.content = content;
    }

    /**
     * Merge the given model data with the template.
     *
     * @param model the model data to merge
     * @return the rendered template merged with the model
     */
    public String merge(Map model) {
        VelocityContext context = new VelocityContext(model);

        StringWriter stringWriter = new StringWriter();

        try {
            VE.evaluate(context, stringWriter, "StringTemplate", content);

            return stringWriter.toString();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Merge the given model key name and value with the template.
     *
     * @param key the model key name
     * @param value the model value
     * @return the rendered template merged with the model
     */
    public String merge(String key, Object value) {
        return merge(Collections.singletonMap(key, value));
    }

}

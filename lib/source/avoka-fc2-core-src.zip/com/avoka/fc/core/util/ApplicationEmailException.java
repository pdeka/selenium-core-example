package com.avoka.fc.core.util;

public class ApplicationEmailException extends ApplicationException {

    // Constants
    private static final long serialVersionUID = 1L;

    public ApplicationEmailException(String name, Throwable cause, String context, String userMessage,  String solution) {
        super(name, cause, context, userMessage, solution);
    }

    public ApplicationEmailException(String name, String context, String userMessage,  String solution) {
        super(name, context, userMessage, solution);
    }
}

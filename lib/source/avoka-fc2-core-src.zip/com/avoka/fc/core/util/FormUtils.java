package com.avoka.fc.core.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.Form;
import com.avoka.fc.core.entity.SchemaConfigMap;
import com.avoka.fc.core.entity.SchemaSeed;
import com.avoka.fc.core.entity.TemplateVersion;
import com.avoka.fc.core.service.SubmissionDataBean;

public final class FormUtils {

    private static final String XFA_SCHEMA = "xfa:dataNode=\"dataGroup\"";
    private static final String XFDF_FIELD = "xfdf:field";

    private static final String VERSION_TAG             = "<?originalXFAVersion";
    private static final String LEGACY_RENDERING_TAG     = "LegacyRendering:1?>";
    private static final String RENDER_FORMAT_TAG         = "<?formServer defaultPDFRenderFormat";
    private static final String RENDER_STATIC_TAG        = "static?>";

    public static String valiateSchemaSeed(String schemaSeed) {
        try {
            XmlUtils.parseDocumentFromString(schemaSeed);
            return null;
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    public static String validateSchemaConfigMap(SchemaConfigMap schemaConfigMap) {
        Validate.notNull(schemaConfigMap, "Null schemaConfigMap parameter");

        final String xpath = schemaConfigMap.getXpath();

        if (xpath.contains("\\\\")) {
            return "Invalid XPath expression, please use // instead.";
        }

        SchemaSeed schemaSeed = schemaConfigMap.getSchema();
        if (schemaSeed.getFileData() != null) {
            String seedFileData = new String(schemaSeed.getFileData());
            try {
                Document document = XmlUtils.parseDocumentFromString(seedFileData);

                Element element = XmlUtils.getXPathElement(document, xpath);
                if (element == null) {
                    return "No XML element found for XPath: " +  schemaConfigMap.getXpath();
                }

            } catch (Exception e) {
                return e.getMessage();
            }
        }

        return null;
    }

    public static String validateTemplateFilename(String templateFileName, String formType) {
        if (StringUtils.isBlank(templateFileName)) {
            return "Form template must be specified";
        }

        String filename = templateFileName.toLowerCase();

        if (TemplateVersion.FORM_TYPE_FORM_GUIDE.equals(formType)) {
            if (!filename.endsWith(".zip")) {
                return "Form Guide template must be a ZIP file";
            }

        } else if (TemplateVersion.FORM_TYPE_DYNAMIC_XML_FORM.equals(formType)) {
            if (!filename.endsWith(".xdp") && !filename.endsWith(".pdf")) {
                return "Dynamic XML Form template must be a XDP or PDF file";
            }

        } else if (TemplateVersion.FORM_TYPE_STATIC_PDF_FORM.equals(formType)) {
            if (!filename.endsWith(".xdp") && !filename.endsWith(".pdf")) {
                return "Static PDF Form template must be a XDP or PDF file";
            }

        } else {
            assert(false);
        }

        return null;
    }

    public static SubmissionDataBean getSubmissionData(HttpServletRequest request){
        String contentType = request.getContentType();
        if (contentType.contains("pdf") || contentType.contains("PDF")) {
            // cannot handle pdf submissions
            throw new ApplicationException("SubmissionExtractFormatError",
                    "Error processing submission",
                    "Cannot process PDF submissions.",
                    "Please change the form submit type to XDP.");

        }
        String data = null;
        try {
            data = IOUtils.toString(request.getReader());

            // Remove xfa:dataNode schema refs from submitted XML data
            if (data.contains(XFA_SCHEMA)) {
                data = StringUtils.remove(data, XFA_SCHEMA);
            }

            Document document = XmlUtils.parseDocumentFromString(data, false, false);

            Element dataElement = getRootDataElement(document);
            data = XmlUtils.toString(dataElement);

            document = XmlUtils.parseDocumentFromString(data, false, false);

            stripXfdfFields(document);

            return new SubmissionDataBean(document);

        } catch (IOException e) {
            if (data != null) {
                LoggerFactory.getLogger(FormUtils.class).error(data);
            }
            throw new ApplicationException("SubmissionReadIOError", e, null,
                    "An unexpected error occured loading your submission.",
                    "Please review submission data to determine the cause.");
        }
    }

    /**
     * Return the form submission data from XML document, stripping out any XFA elements if present.
     */
    public static Document getSubmissionDataDocument(Document document) {
        String documentString = XmlUtils.toString(document);

        // Remove xfa:dataNode schema refs from submitted XML data
        if (documentString.contains(XFA_SCHEMA)) {
            documentString = StringUtils.remove(documentString, XFA_SCHEMA);
        }

        Document strippedDocument = XmlUtils.parseDocumentFromString(documentString, false, false);
        Element rootDataElement = getRootDataElement(strippedDocument);

        String xmlSubmission = XmlUtils.toString(rootDataElement);

        Document resultDocument = XmlUtils.parseDocumentFromString(xmlSubmission, false, false);
        stripXfdfFields(resultDocument);
        return resultDocument;
    }

    public static void stripXfdfFields(Document document) {
        Element rootElement = document.getDocumentElement();
        List<Element> xfdfFields = XmlUtils.getChildren(rootElement, XFDF_FIELD);
        for (int i = 0; i < xfdfFields.size(); i++) {
            rootElement.removeChild(xfdfFields.get(i));
        }
    }

    /**
     * Return the submitted data payload from the submitted XML document.
     *
     * @param document the XML document submitted
     * @return the XML data payload
     */
    public static Element getRootDataElement(Document document) {
        Validate.notNull(document, "Null document parameter");

        Element rootElement = document.getDocumentElement();

        NodeList nodeList = null;

        if (rootElement.getNodeName().equals("xdp:xdp")) {
            Element xfaDataSetsElement = XmlUtils.getChild(rootElement, "xfa:datasets");

            Element xfaDataElement = XmlUtils.getChild(xfaDataSetsElement, "xfa:data");

            nodeList = xfaDataElement.getChildNodes();

        } else if (rootElement.getNodeName().equals("xfa:datasets")) {
            Element xfaDataElement = XmlUtils.getChild(rootElement, "xfa:data");

            nodeList = xfaDataElement.getChildNodes();

        } else if (rootElement.getNodeName().equals("xfa:data")) {
            nodeList = rootElement.getChildNodes();

        }

        if (nodeList == null) {
            // assume that all the surrounding nodes have already been stripped out
            return rootElement;
        }
        else {
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node childNode = nodeList.item(i);
                if (childNode instanceof Element) {
                    return (Element) childNode;
                }
            }

            // No node found? Exception
            throw new ApplicationException("No data node found", "Error when parsing submission data", "There was an error when parsing the submitted data. The document may be malformed or in an unsupported format.", "Make sure the form is set up correctly and contains data.");
        }
    }

    public static String validateTemplate(String xdp, String filename) {
        if (StringUtils.isBlank(xdp)) {
            return "Empty Form";
        }

        filename = filename.toLowerCase();

        if (filename.endsWith(".pdf")) {
            return null;
        }

        if (!filename.endsWith(".xdp")) {
            return null;
        }

        // Check legacy rendering mode
        int versionStart = xdp.indexOf(VERSION_TAG);
        if (versionStart != -1) {
            int versionEnd = xdp.indexOf(">", versionStart + 1);

            String versionTag = xdp.substring(versionStart, versionEnd + 1);

            if (versionTag != null && versionTag.endsWith(LEGACY_RENDERING_TAG)) {
                // return "Adobe XML Form using Legacy Rendering mode";
                System.out.println("Form Template using Legacy Rendering mode");
            }
        }

        // Check render format
        int renderFormatStart = xdp.indexOf(RENDER_FORMAT_TAG);
        if (renderFormatStart != -1) {
            int renderFormatEnd = xdp.indexOf(">", renderFormatStart + 1);

            String renderFormat = xdp.substring(renderFormatStart, renderFormatEnd + 1);
            if (renderFormat != null && renderFormat.endsWith(RENDER_STATIC_TAG)) {
                return "Form Template using Server PDF Render Format 'Static PDF Form'.";
            }
        }

        return null;
    }


    public static String getFormGuideFilename(byte[] templateFileData) {
        ZipInputStream zis = null;
        try {
            zis = new ZipInputStream(new ByteArrayInputStream(templateFileData));

            ZipEntry ze = null;
            while ((ze = zis.getNextEntry()) != null) {
                if (ze.isDirectory()) {
                    continue;
                }
                String filename = ze.getName();
                if (filename.toLowerCase().endsWith(".xdp")
                    && !filename.contains("/")
                    && !filename.contains("\\")) {

                    return filename;
                }
            }

            return null;

        } catch (IOException ioe) {
            throw new RuntimeException(ioe);

        } finally {
            IOUtils.closeQuietly(zis);
        }
    }

    public static Long getFormGuideFilesize(byte[] templateFileData) {
        ZipInputStream zis = null;
        try {
            zis = new ZipInputStream(new ByteArrayInputStream(templateFileData));

            ZipEntry ze = null;
            while ((ze = zis.getNextEntry()) != null) {
                if (ze.isDirectory()) {
                    continue;
                }
                String filename = ze.getName();
                if (filename.toLowerCase().endsWith(".xdp")
                    && !filename.contains("/")
                    && !filename.contains("\\")) {

                    return ze.getSize();
                }
            }

            return null;

        } catch (IOException ioe) {
            throw new RuntimeException(ioe);

        } finally {
            IOUtils.closeQuietly(zis);
        }
    }

    public static boolean isAcrobatUserAgent(HttpServletRequest request) {
        String referrer = request.getHeader("referer");
        boolean isAcrobat = !StringUtils.isEmpty(request.getHeader("acrobat-version")) && StringUtils.isEmpty(referrer);
        return isAcrobat;
    }

    public static boolean isReaderUserAgent(HttpServletRequest request) {
        String userAgent = request.getHeader("user-agent");
        boolean isReader = userAgent.contains("AcroForms");
        return isReader;
    }

    public static boolean isAdobeUserAgent(HttpServletRequest request) {
        boolean isReader = isReaderUserAgent(request);
        boolean isAcrobat = isAcrobatUserAgent(request);
        return isReader || isAcrobat;
    }

    public static String getAcrobatVersion(HttpServletRequest request) {
        return request.getHeader("acrobat-version");
    }

    public static String getFormClientWsAddress(Form form) {
        String formsClientWsAddress = form.getFormsClientWsAddress();

        // If not defined look for delivery WS address
        if (StringUtils.isNotBlank(formsClientWsAddress)) {
            return formsClientWsAddress;

        } else {
            DeliveryDetails deliveryDetails = null;
            if (form.isTestEnabled()) {
                deliveryDetails = form.getDeliveryTest();
            } else {
                deliveryDetails = form.getDeliveryProd();
            }

            if (deliveryDetails != null && deliveryDetails.isWebServicePushDelivery()) {
                return deliveryDetails.getDeliveryWsAddress();

            } else {
                return null;
            }
        }
    }

    public static boolean isOfflineSubmission(HttpServletRequest request) {

        if (getLogger().isDebugEnabled()) {
            getLogger().debug("Offline Submission Check Request Headers:");

            Enumeration<String> headersEnum = request.getHeaderNames();

            TreeMap<String, String> headersMap = new TreeMap<String, String>();

            while (headersEnum.hasMoreElements()) {
                final String curHeader = headersEnum.nextElement();

                StringBuffer headerValues = new StringBuffer();

                Enumeration<String> headerContents = request.getHeaders(curHeader);
                while (headerContents.hasMoreElements()) {
                    headerValues.append(headerContents.nextElement());
                    headerValues.append("; ");
                }

                headersMap.put(curHeader, headerValues.toString());
            }

            for (Iterator i = headersMap.keySet().iterator(); i.hasNext();) {
                String name = i.next().toString();
                String value = headersMap.get(name);
                getLogger().debug(name + "=" + value);
            }
        }

        return FormUtils.isAdobeUserAgent(request);
    }

    private static Logger getLogger() {
        return LoggerFactory.getLogger(FormUtils.class);
    }

}

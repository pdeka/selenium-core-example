package com.avoka.fc.core.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang.Validate;
import org.w3c.dom.Document;

import com.avoka.core.util.CoreUtils;
import com.avoka.core.util.FileUtils;
import com.avoka.core.util.XmlUtils;
import com.avoka.fc.core.dao.DeploymentPropertyDao;
import com.avoka.fc.core.entity.Attachment;
import com.avoka.fc.core.entity.DeliveryDetails;
import com.avoka.fc.core.entity.FileUpload;
import com.avoka.fc.core.entity.RequiredAttachment;
import com.avoka.fc.core.entity.Submission;
import com.avoka.fc.core.entity.SubmissionData;

public class DeliveryUtils {

    public static com.avoka.fc.forms.api.Attachment createAttachmentBean(Attachment attachment) {
        com.avoka.fc.forms.api.Attachment attachmentBean = new com.avoka.fc.forms.api.Attachment();

        attachmentBean.setAttachmentKey(attachment.getAttachmentKey());

        RequiredAttachment requiredAttachment = attachment.getRequiredAttachment();
        if (requiredAttachment != null) {
            attachmentBean.setAttachmentName(requiredAttachment.getAttachmentName());
            attachmentBean.setDocumentCode(requiredAttachment.getDocumentCode());
            attachmentBean.setDocumentTypeName(requiredAttachment.getDocumentTypeName());
            attachmentBean.setRequiredFlag(requiredAttachment.getRequiredFlag());
            attachmentBean.setSubmittedManuallyFlag(requiredAttachment.getSubmitManuallyFlag());
        }

        FileUpload fileUpload = attachment.getFileUpload();
        if (fileUpload != null && fileUpload.getFileUploadData() != null) {
            byte[] bytes = fileUpload.getFileUploadData().getFileUploadData();
            attachmentBean.setFileBytes(bytes);
            attachmentBean.setFileName(fileUpload.getFileName());
            attachmentBean.setDescription(fileUpload.getDescription());
        }

        return attachmentBean;
    }

    public static String createTransformXMLReceiptString(DeliveryDetails deliveryDetails, Submission submission){

        File file = createTransformXMLReceiptFile(deliveryDetails, submission);

        try {
            return FileUtils.readFileAsString(file).toString();

        } catch (IOException ioe) {
            throw new ApplicationException("DeliveryXMLError", ioe, "Submission ID = " + submission.getId(),
                    "Error creating Transform XML DeliveryFile",
                    "Error creating Transform XML DeliveryFile. See Java IO exception for details");
        }
    }

    public static File createTransformXMLReceiptFile(DeliveryDetails deliveryDetails, Submission submission){
        Validate.notNull(deliveryDetails, "Null deliveryDetails parameter");
        Validate.notNull(submission, "Null submission parameter");

        byte[] transformXsltData = deliveryDetails.getTransformXsltData();

        // Get clean XML submission
        String seedXmlString = null;
        SubmissionData submissionData = submission.getSubmissionData();
        if (submissionData != null) {
            seedXmlString = submissionData.getSubmissionDataString();
        }

        if (submissionData == null) {
            throw new ApplicationException("ReceiptDataUnavailable", "Error parsing receipt for transform", "The submission contains no xml data", null);
        }

        Document document = XmlUtils.parseDocumentFromString(seedXmlString, false, false);
        document = FormUtils.getSubmissionDataDocument(document);
        seedXmlString = XmlUtils.toString(document);

        String fileName = "" + submission.getId() + ".xml";

        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(transformXsltData);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();

            // Use the TransformerFactory to instantiate a Transformer that
            // will work with the stylesheet you specify.
            // This method call also processes the stylesheet into a
            // compiled Templates object.
            Transformer transformer = transformerFactory.newTransformer(new StreamSource(bais));

            String sourceFilename = "" + submission.getId() + "-raw.xml";
            File sourceFile = FileUtils.writeToFile(getDeliveryTempDirectory() + sourceFilename, seedXmlString.getBytes());

            String qualifiedFilename = getDeliveryTempDirectory() + fileName;
            FileOutputStream destFileOutputStream = new FileOutputStream(qualifiedFilename);

            transformer.transform(new StreamSource(sourceFile), new StreamResult(destFileOutputStream));

            CoreUtils.close(destFileOutputStream);

            return new File(qualifiedFilename);

        } catch (IOException ioe) {
            throw new ApplicationException("DeliveryXMLError", ioe, "Submission ID = " + submission.getId(),
                    "Error creating XML DeliveryFile", "Error creating XML DeliveryFile. See Java IO exception for details");

        } catch (TransformerException te) {
            throw new ApplicationException("DeliveryXMLError", te, "Submission ID = " + submission.getId(),
                    "Error transforming XML DeliveryFile",
                    "Error transforming XML DeliveryFile. See Transformer exception for details");
        }
    }

    private static String getDeliveryTempDirectory() {
        DeploymentPropertyDao deploymentPropertyDao = new DeploymentPropertyDao();
        return deploymentPropertyDao.getConfigSubDirectory("delivery");
    }
}

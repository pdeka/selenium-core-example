package com.avoka.fc.common;

/**
 * Defines commons constants between the FC projects.
 */
public class Constants {

    public final static String    SERVER_Build                            = "2.0.29";

    public final static String  SESSION_ATTRIBUTE_userId                = "userId";
    public static final String  SESSION_ATTRIBUTE_submissionFailureData = "submissionFailureData";
    public static final String  SESSION_ATTRIBUTE_ReferringUrl          = "referringUrl";

    // TODO: MAE 24/4/08 - Do we need to handle rendering of old template versions?
    // public static final String    PARAM_VersionCode                = "versionCode";

    public static final String  PARAM_FormGuideSWF                      = "formGuideSWF";

    public static final String  PARAM_EntityId                          = "entityId";
    public static final String  PARAM_FormCode                          = "formCode";
    public static final String  PARAM_GetFormPrefillData                = "getFormPrefillData";
    public static final String  PARAM_XmlData                           = "xmlData";
    public static final String  PARAM_XmlDataEncoded                    = "xmlDataEncoded";
    public static final String  PARAM_UserKey                           = "userKey";
    public static final String  PARAM_RequestKey                        = "requestKey";
    public static final String  PARAM_SubmitKey                         = "submitKey";
    public static final String  PARAM_TaskKey                           = "taskKey";
    public static final String  PARAM_NoUserAccountPrefill              = "noUserAccountPrefill";
    public static final String  PARAM_RedirectTarget                    = "redirectTarget";
    public static final String  PARAM_OverrideAdminOid                  = "overrideAdminOid";
    public static final String  PARAM_SubmissionDataXml                 = "submissionDataXml";
    public static final String  PARAM_RenderMode                        = "renderMode";
    public static final String  PARAM_RenderMode_File                   = "file";
    public static final String  PARAM_submissionRetryRequestLogKey      = "submissionRetryRequestLogKey";
    public static final String  PARAM_clientFormCode                    = "clientFormCode";
    public static final String  PARAM_submissionData                    = "submissionData";
    public static final String  PARAM_useCurrentVersion                 = "useCurrentVersion";
    public static final String  PARAM_validationErrors                  = "validationErrors";

}

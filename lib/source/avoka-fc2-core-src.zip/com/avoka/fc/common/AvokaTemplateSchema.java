/*
 * Copyright (c) 2006-2008 Avoka Technologies Pty Limited All Rights Reserved.
 *
 * This software contains confidential and proprietary information of Avoka Technologies
 * ("Confidential Information"). You shall not disclose such Confidential Information and shall use
 * it only as may be permitted in writing by Avoka Technologies Pty Limited.
 *
 * All materials contained herein are the property of Avoka Technologies Pty Limited. No part of
 * this work may be produced or transmitted in any form by any means, electronic or mechanical,
 * including photocopying and recording, or by any information storage or retrieval system accept as
 * may be permitted in writing by Avoka Technologies Pty Limited.
 */
package com.avoka.fc.common;

/**
 * Provides the XML path constants of <tt>AvokaGenericInclude.xsd</tt> schema.
 *
 * @author medgar@avoka.com
 */
public interface AvokaTemplateSchema {

    // UserProfile section
    public static final String USER_PROFILE_GIVEN_NAME                    = "//UserProfile/Individual/GivenName";
    public static final String USER_PROFILE_FAMILY_NAME                    = "//UserProfile/Individual/FamilyName";
    public static final String USER_PROFILE_ACCOUNTS_ITEM_LIST            = "Accounts/ItemList";

    // Common Item List structure
    public static final String ITEM                                        = "Item";
    public static final String ITEM_LIST                                 = "ItemList";
    public static final String ITEM_LIST_ITEM                             = "ItemList/Item";

    // Payment section
    public static final String PAYMENT_DETAILS_PAYMENT                     = "Payment";
    public static final String PAYMENT_DETAILS_PAYMENT_GST                = "Payment/GST";
    public static final String PAYMENT_DETAILS_PAYMENT_SUB_TOTAL        = "Payment/SubTotal";
    public static final String PAYMENT_DETAILS_PAYMENT_TOTAL            = "Payment/Total";
    public static final String PAYMENT_DETAILS_CLIENT_REFERENCE_NUMBER     = "ClientReferenceNumber";
    public static final String PAYMENT_DETAILS_BPAY_REFERENCE_NUMBER    = "BPAYReferenceNumber";

    public static final String SUB_TOTAL                                = "SubTotal";
    public static final String SERVICE_FEE                                = "ServiceFee";
    public static final String GST                                         = "GST";
    public static final String TOTAL                                     = "Total";
    public static final String PAYMENT_TYPE                             = "PaymentType";
    public static final String BPAY_BILLER_CODE                         = "BPAYBillerCode";
    public static final String BPAY_REFERENCE_NUMBER                    = "BPAYReferenceNumber";
    public static final String BSB_NUMBER                                = "BSBNumber";
    public static final String EFT_ACCOUNT_NUMBER                        = "EFTAccountNumber";
    public static final String ACCOUNT_NUMBER                             = "AccountNumber";

    public static final String PAYMENT_ITEM_DESCRIPTION                    = "Description";
    public static final String PAYMENT_ITEM_QUANTITY                    = "Quantity";
    public static final String PAYMENT_ITEM_UNIT_VALUE                    = "UnitValue";
    public static final String PAYMENT_ITEM_GST                            = "GST";
    public static final String PAYMENT_ITEM_TOTAL                        = "Total";
    public static final String PAYMENT_ITEM_FEE_CODE                    = "FeeCode";
    public static final String PAYMENT_ITEM_RECEIPT_CODE                = "ReceiptCode";

    // Attachments section
    public static final String DOCUMENT_TYPE_ID                         = "DocumentTypeId";
    public static final String DOCUMENT_TYPE_CODE                       = "DocumentCode";
    public static final String DOCUMENT_TYPE_NAME                       = "DocumentName";
    public static final String ATTACHMENT_NAME                             = "AttachmentName";
    public static final String ATTACHMENT_DESCRIPTION                     = "AttachmentDescription";
    public static final String ATTACHMENT_TYPE                          = "AttachmentType";
    public static final String MANDATORY_STATUS                         = "MandatoryStatus";
    public static final String MAX_SIZE                                 = "MaxSize";
    public static final String MIME_OR_FILE_TYPES                       = "MimeOrFileTypes";
    public static final String SUBMIT_METHOD                              = "SubmitMethod";

    public static final String MANDATORY_STATUS_REQUIRED                 = "Required";
    public static final String MANDATORY_STATUS_OPTIONAL                 = "Optional";

    // Receipt section
    public static final String RECEIPT_RECEIPT_NO                        = "ReceiptNo";
    public static final String RECEIPT_RECEIPT_DATE_TIME                = "ReceiptDateTime";
    public static final String RECEIPT_PAYMENT_TOTAL                     = "Payment/Total";
    public static final String RECEIPT_PAYMENT_SUB_TOTAL                = "Payment/SubTotal";
    public static final String RECEIPT_PAYMENT_SERVICE_FEE                = "Payment/ServiceFee";
    public static final String RECEIPT_PAYMENT_GST                         = "Payment/GST";

}
